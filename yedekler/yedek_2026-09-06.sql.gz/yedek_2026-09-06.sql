--
-- PostgreSQL database dump
--

\restrict huA5hA60Sp7acBc5Ba1vQnW9627cjclOCIyGbcZO7XlvCL87EaiF9Hhd6HYOuMN

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA extensions;


--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql;


--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql_public;


--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pgbouncer;


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA realtime;


--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA storage;


--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA vault;


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


--
-- Name: bakim_tip_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bakim_tip_t AS ENUM (
    'GELIR',
    'GIDER'
);


--
-- Name: banka_hareket_tip_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.banka_hareket_tip_t AS ENUM (
    'GIRIS',
    'CIKIS',
    'HESAPLAR_ARASI_TRANSFER',
    'DOVIZ_ALIM',
    'DOVIZ_SATIM'
);


--
-- Name: borc_tip_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.borc_tip_t AS ENUM (
    'ORTAKTAN_ALINAN',
    'DISARIDAN_ALINAN',
    'ORTAGA_VERILEN'
);


--
-- Name: cari_tip_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.cari_tip_t AS ENUM (
    'MUSTERI',
    'TEDARIKCI',
    'PERSONEL',
    'ORTAK',
    'DIGER'
);


--
-- Name: cek_durum_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.cek_durum_t AS ENUM (
    'PORTFOYDE',
    'CIRO_EDILDI',
    'TAHSIL_EDILDI',
    'ODENDI',
    'KARSILIKSIZ',
    'IPTAL'
);


--
-- Name: cek_tip_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.cek_tip_t AS ENUM (
    'ALINAN',
    'VERILEN'
);


--
-- Name: hareket_yon_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.hareket_yon_t AS ENUM (
    'GIRIS',
    'CIKIS'
);


--
-- Name: maliyet_tip_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.maliyet_tip_t AS ENUM (
    'SATINALMA',
    'NAKLIYE',
    'GUMRUK',
    'ANTREPO',
    'MILLILESTIRME',
    'LEASING',
    'DIGER',
    'ARDIYE',
    'ILAVE_GUMRUK_VERGISI',
    'DAMGA_VERGISI',
    'TSE_UCRETI',
    'GUMRUKCU_MASRAFI',
    'BANKA_MASRAFI',
    'KDV',
    'SIGORTA'
);


--
-- Name: para_birimi_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.para_birimi_t AS ENUM (
    'TRY',
    'USD',
    'EUR',
    'ALTIN'
);


--
-- Name: personel_odeme_tip_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.personel_odeme_tip_t AS ENUM (
    'MAAS',
    'AVANS',
    'PRIM',
    'SGK',
    'DIGER'
);


--
-- Name: siparis_durum_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.siparis_durum_t AS ENUM (
    'TASLAK',
    'ONAYLANDI',
    'YOLDA',
    'GUMRUKTE',
    'TESLIM_ALINDI',
    'TAMAMLANDI',
    'IPTAL'
);


--
-- Name: stok_durum_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.stok_durum_t AS ENUM (
    'DEPODA',
    'SIPARISTE',
    'YOLDA',
    'GUMRUKTE',
    'ANTREPODA',
    'SATILDI',
    'KIRADA',
    'BAKIMDA',
    'HURDA'
);


--
-- Name: stok_kaynak_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.stok_kaynak_t AS ENUM (
    'ITHALAT',
    'YURTICI_ALIM'
);


--
-- Name: action; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in',
    'like',
    'ilike',
    'is',
    'match',
    'imatch',
    'isdistinct'
);


--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text,
	negate boolean
);


--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: -
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
    revoke trigger on cron.job_run_details from postgres;
  END IF;
END;
$$;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $_$
begin
    if not exists (
        select 1
        from pg_catalog.pg_event_trigger_ddl_commands() ev
        join pg_catalog.pg_extension e on ev.objid = e.oid
        where e.extname = 'pg_graphql'
    ) then
        return;
    end if;

    drop function if exists graphql_public.graphql;
    create or replace function graphql_public.graphql(
        "operationName" text default null,
        query text default null,
        variables jsonb default null,
        extensions jsonb default null
    )
        returns jsonb
        language sql
    as $$
        select graphql.resolve(
            query := query,
            variables := coalesce(variables, '{}'),
            "operationName" := "operationName",
            extensions := extensions
        );
    $$;

    -- Attach the wrapper to the extension so DROP EXTENSION cascades to it,
    -- which in turn triggers set_graphql_placeholder to reinstall the "not enabled" stub.
    alter extension pg_graphql add function graphql_public.graphql(text, text, jsonb, jsonb);

    grant usage on schema graphql to postgres, anon, authenticated, service_role;
    grant execute on function graphql.resolve to postgres, anon, authenticated, service_role;
    grant usage on schema graphql to postgres with grant option;
    grant usage on schema graphql_public to postgres with grant option;
end;
$_$;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8.0', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
            set search_path to ''
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql(text, text, jsonb, jsonb); Type: FUNCTION; Schema: graphql_public; Owner: -
--

CREATE FUNCTION graphql_public.graphql("operationName" text DEFAULT NULL::text, query text DEFAULT NULL::text, variables jsonb DEFAULT NULL::jsonb, extensions jsonb DEFAULT NULL::jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: -
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
    -- Regclass of the table e.g. public.notes
    entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

    -- I, U, D, T: insert, update ...
    action realtime.action = (
        case wal ->> 'action'
            when 'I' then 'INSERT'
            when 'U' then 'UPDATE'
            when 'D' then 'DELETE'
            else 'ERROR'
        end
    );

    -- Is row level security enabled for the table
    is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

    subscriptions realtime.subscription[] = array_agg(subs)
        from
            realtime.subscription subs
        where
            subs.entity = entity_
            -- Filter by action early - only get subscriptions interested in this action
            -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
            and (subs.action_filter = '*' or subs.action_filter = action::text);

    -- Subscription vars
    working_role regrole;
    working_selected_columns text[];
    claimed_role regrole;
    claims jsonb;

    subscription_id uuid;
    subscription_has_access bool;
    visible_to_subscription_ids uuid[] = '{}';

    -- structured info for wal's columns
    columns realtime.wal_column[];
    -- previous identity values for update/delete
    old_columns realtime.wal_column[];

    error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

    -- Primary jsonb output for record
    output jsonb;

    -- Loop record for iterating unique roles (outer loop)
    role_record record;
    -- Loop record for iterating unique selected_columns within a role (inner loop)
    cols_record record;
    -- Subscription ids visible at the role level (before fanning out by selected_columns)
    visible_role_sub_ids uuid[] = '{}';

begin
    perform set_config('role', null, true);

    columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'columns') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    old_columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'identity') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    for role_record in
        select claims_role
        from (select distinct claims_role from unnest(subscriptions)) t
        order by claims_role::text
    loop
        working_role := role_record.claims_role;

        -- Update `is_selectable` for columns and old_columns (once per role)
        columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(columns) c;

        old_columns =
                array_agg(
                    (
                        c.name,
                        c.type_name,
                        c.type_oid,
                        c.value,
                        c.is_pkey,
                        pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                    )::realtime.wal_column
                )
                from
                    unnest(old_columns) c;

        if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
            -- Fan out 400 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 400: Bad Request, no primary key']
                )::realtime.wal_rls;
            end loop;

        -- The claims role does not have SELECT permission to the primary key of entity
        elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
            -- Fan out 401 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 401: Unauthorized']
                )::realtime.wal_rls;
            end loop;

        else
            -- Create the prepared statement (once per role)
            if is_rls_enabled and action <> 'DELETE' then
                if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                    deallocate walrus_rls_stmt;
                end if;
                execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
            end if;

            -- Collect all visible subscription IDs for this role (filter check + RLS check)
            visible_role_sub_ids = '{}';

            for subscription_id, claims in (
                    select
                        subs.subscription_id,
                        subs.claims
                    from
                        unnest(subscriptions) subs
                    where
                        subs.entity = entity_
                        and subs.claims_role = working_role
                        and (
                            realtime.is_visible_through_filters(columns, subs.filters)
                            or (
                              action = 'DELETE'
                              and realtime.is_visible_through_filters(old_columns, subs.filters)
                            )
                        )
            ) loop

                if not is_rls_enabled or action = 'DELETE' then
                    visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                else
                    -- Check if RLS allows the role to see the record
                    perform
                        -- Trim leading and trailing quotes from working_role because set_config
                        -- doesn't recognize the role as valid if they are included
                        set_config('role', trim(both '"' from working_role::text), true),
                        set_config('request.jwt.claims', claims::text, true);

                    execute 'execute walrus_rls_stmt' into subscription_has_access;

                    -- Reset the role on every FOR..LOOP batch execution.
                    -- The first batch of 10 rows is pre-fetched using the current connection role (PG internal behaviour)
                    -- then we have to reset it again otherwise it would use the role defined in the `set_config` above
                    -- to fetch the remaining rows when rows>10, which could be a user-defined role that lacks execution grants.
                    -- The flow is:
                    --   1. run batch with conn role
                    --   2. set_config working_role
                    --   3. execute walrus
                    --   4. reset role (revert)
                    --   5. repeat
                    perform set_config('role', null, true);

                    if subscription_has_access then
                        visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                    end if;
                end if;
            end loop;

            perform set_config('role', null, true);

            -- Inner loop: per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;

                output = jsonb_build_object(
                    'schema', wal ->> 'schema',
                    'table', wal ->> 'table',
                    'type', action,
                    'commit_timestamp', to_char(
                        ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                        'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
                    ),
                    'columns', (
                        select
                            jsonb_agg(
                                jsonb_build_object(
                                    'name', pa.attname,
                                    'type', pt.typname
                                )
                                order by pa.attnum asc
                            )
                        from
                            pg_attribute pa
                            join pg_type pt
                                on pa.atttypid = pt.oid
                            left join (
                                select unnest(conkey) as pkey_attnum
                                from pg_constraint
                                where conrelid = entity_ and contype = 'p'
                            ) pk on pk.pkey_attnum = pa.attnum
                        where
                            attrelid = entity_
                            and attnum > 0
                            and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                            and (working_selected_columns is null or pa.attname = any(working_selected_columns) or pk.pkey_attnum is not null)
                    )
                )
                -- Add "record" key for insert and update
                || case
                    when action in ('INSERT', 'UPDATE') then
                        jsonb_build_object(
                            'record',
                            (
                                select
                                    jsonb_object_agg(
                                        -- if unchanged toast, get column name and value from old record
                                        coalesce((c).name, (oc).name),
                                        case
                                            when (c).name is null then (oc).value
                                            else (c).value
                                        end
                                    )
                                from
                                    unnest(columns) c
                                    full outer join unnest(old_columns) oc
                                        on (c).name = (oc).name
                                where
                                    coalesce((c).is_selectable, (oc).is_selectable)
                                    and (working_selected_columns is null or coalesce((c).name, (oc).name) = any(working_selected_columns) or coalesce((c).is_pkey, (oc).is_pkey))
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            )
                        )
                    else '{}'::jsonb
                end
                -- Add "old_record" key for update and delete
                || case
                    when action = 'UPDATE' then
                        jsonb_build_object(
                                'old_record',
                                (
                                    select jsonb_object_agg((c).name, (c).value)
                                    from unnest(old_columns) c
                                    where
                                        (c).is_selectable
                                        and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                        and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                )
                            )
                    when action = 'DELETE' then
                        jsonb_build_object(
                            'old_record',
                            (
                                select jsonb_object_agg((c).name, (c).value)
                                from unnest(old_columns) c
                                where
                                    (c).is_selectable
                                    and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                    and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                            )
                        )
                    else '{}'::jsonb
                end;

                -- Filter visible_role_sub_ids to those matching the current selected_columns group
                visible_to_subscription_ids = coalesce(
                    (
                        select array_agg(s.subscription_id)
                        from unnest(subscriptions) s
                        where s.claims_role = working_role
                          and (s.selected_columns is not distinct from working_selected_columns)
                          and s.subscription_id = any(visible_role_sub_ids)
                    ),
                    '{}'::uuid[]
                );

                return next (
                    output,
                    is_rls_enabled,
                    visible_to_subscription_ids,
                    case
                        when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                        else '{}'
                    end
                )::realtime.wal_rls;
            end loop;

        end if;
    end loop;

    perform set_config('role', null, true);
end;
$$;


--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
/*
Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
*/
declare
    op_symbol text = (
        case
            when op = 'eq' then '='
            when op = 'neq' then '!='
            when op = 'lt' then '<'
            when op = 'lte' then '<='
            when op = 'gt' then '>'
            when op = 'gte' then '>='
            when op = 'in' then '= any'
            else 'UNKNOWN OP'
        end
    );
    res boolean;
begin
    execute format(
        'select %L::'|| type_::text || ' ' || op_symbol
        || ' ( %L::'
        || (
            case
                when op = 'in' then type_::text || '[]'
                else type_::text end
        )
        || ')', val_1, val_2) into res;
    return res;
end;
$$;


--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $$
declare
    op_symbol text;
    res boolean;
begin
    -- IS DISTINCT FROM / IS NOT DISTINCT FROM: infix, both sides typed literals
    if op = 'isdistinct' then
        execute format(
            'select %L::%s %s %L::%s',
            val_1,
            type_::text,
            case when negate then 'IS NOT DISTINCT FROM' else 'IS DISTINCT FROM' end,
            val_2,
            type_::text
        ) into res;
        return res;
    end if;

    -- IS requires a keyword RHS (NULL, TRUE, FALSE, UNKNOWN), not a typed literal
    if op = 'is' then
        if val_2 not in ('null', 'true', 'false', 'unknown') then
            raise exception 'invalid value for is filter: must be null, true, false, or unknown';
        end if;
        execute format(
            'select %L::%s %s %s',
            val_1,
            type_::text,
            case when negate then 'IS NOT' else 'IS' end,
            upper(val_2)
        ) into res;
        return res;
    end if;

    op_symbol = case
        when op = 'eq'    then '='
        when op = 'neq'   then '!='
        when op = 'lt'    then '<'
        when op = 'lte'   then '<='
        when op = 'gt'    then '>'
        when op = 'gte'   then '>='
        when op = 'in'    then '= any'
        when op = 'like'   then 'LIKE'
        when op = 'ilike'  then 'ILIKE'
        when op = 'match'  then '~'
        when op = 'imatch' then '~*'
        else null
    end;

    if op_symbol is null then
        raise exception 'unsupported equality operator: %', op::text;
    end if;

    execute format(
        'select %L::%s %s (%L::%s)',
        val_1,
        type_::text,
        op_symbol,
        val_2,
        case when op = 'in' then type_::text || '[]' else type_::text end
    ) into res;

    return case when negate then not res else res end;
end;
$$;


--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
    select
        filters is null
        or array_length(filters, 1) is null
        or coalesce(
            count(col.name) = count(1)
            and sum(
                realtime.check_equality_op(
                    op:=f.op,
                    type_:=coalesce(col.type_oid::regtype, col.type_name::regtype),
                    val_1:=col.value #>> '{}',
                    val_2:=f.value,
                    negate:=coalesce(f.negate, false)
                )::int
            ) filter (where col.name is not null) = count(col.name),
            false
        )
    from
        unnest(filters) f
        left join unnest(columns) col
            on f.column_name = col.name;
$$;


--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS TABLE(wal jsonb, is_rls_enabled boolean, subscription_ids uuid[], errors text[], slot_changes_count bigint)
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;


--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- Name: send_binary(bytea, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
    col_names text[] = coalesce(
            array_agg(a.attname order by a.attnum),
            '{}'::text[]
        )
        from
            pg_catalog.pg_attribute a
        where
            a.attrelid = new.entity
            and a.attnum > 0
            and not a.attisdropped
            and pg_catalog.has_column_privilege(
                (new.claims ->> 'role'),
                a.attrelid,
                a.attnum,
                'SELECT'
            );
    filter realtime.user_defined_filter;
    col_type regtype;
    in_val jsonb;
    selected_col text;
begin
    for filter in select * from unnest(new.filters) loop
        if not filter.column_name = any(col_names) then
            raise exception 'invalid column for filter %', filter.column_name;
        end if;

        col_type = (
            select atttypid::regtype
            from pg_catalog.pg_attribute
            where attrelid = new.entity
                  and attname = filter.column_name
        );
        if col_type is null then
            raise exception 'failed to lookup type for column %', filter.column_name;
        end if;

        if filter.op = 'in'::realtime.equality_op then
            in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
            if coalesce(jsonb_array_length(in_val), 0) > 100 then
                raise exception 'too many values for `in` filter. Maximum 100';
            end if;
        elsif filter.op = 'is'::realtime.equality_op then
            -- `is` requires a keyword RHS rather than a typed literal
            if filter.value not in ('null', 'true', 'false', 'unknown') then
                raise exception 'invalid value for is filter: must be null, true, false, or unknown';
            end if;
            -- IS NULL works for any type, but IS TRUE/FALSE/UNKNOWN require a boolean
            -- operand. Reject the non-null keywords on non-boolean columns here so they
            -- don't abort apply_rls at WAL time.
            if filter.value <> 'null' and col_type <> 'boolean'::regtype then
                raise exception 'is % filter requires a boolean column, got %', filter.value, col_type::text;
            end if;
        elsif filter.op in ('like'::realtime.equality_op, 'ilike'::realtime.equality_op) then
            -- like/ilike apply the text pattern operator (~~); reject column types that
            -- have no such operator instead of failing at WAL time
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = '~~' and oprleft = col_type
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
        elsif filter.op in ('match'::realtime.equality_op, 'imatch'::realtime.equality_op) then
            -- match/imatch apply the regex operators ~ / ~*; reject column types that have
            -- no such operator (e.g. integer) instead of failing at WAL time, mirroring the
            -- like/ilike guard above.
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = case when filter.op = 'imatch'::realtime.equality_op then '~*' else '~' end
                  and oprleft = col_type
                  and oprright = col_type
                  and oprresult = 'boolean'::regtype
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
            -- validate the regex eagerly so a bad pattern is rejected here, not inside
            -- apply_rls where it would abort the WAL stream for the entity
            begin
                perform '' ~ filter.value;
            exception when others then
                raise exception 'invalid regular expression for % filter: %', filter.op::text, sqlerrm;
            end;
        else
            -- eq/neq/lt/lte/gt/gte: value must be coercable to the type
            perform realtime.cast(filter.value, col_type);
        end if;
    end loop;

    if new.selected_columns is not null then
        for selected_col in select * from unnest(new.selected_columns) loop
            if not selected_col = any(col_names) then
                raise exception 'invalid column for select %', selected_col;
            end if;
        end loop;
    end if;

    -- Apply consistent order to filters so the unique constraint can't be tricked by a
    -- different filter order. negate is part of the sort key.
    new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value, f.negate),
        '{}'
    ) from unnest(new.filters) f;

    new.selected_columns = (
        select array_agg(c order by c)
        from unnest(new.selected_columns) c
    );

    return new;
end;
$$;


--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


--
-- Name: wal2json_escape_identifier(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.wal2json_escape_identifier(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;


--
-- Name: allow_any_operation(text[]); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.allow_any_operation(expected_operations text[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


--
-- Name: allow_only_operation(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.allow_only_operation(expected_operation text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    RETURN _parts[array_length(_parts, 1)];
END
$$;


--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


--
-- Name: get_common_prefix(text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.protect_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_prefix_len INT;
    v_prefix_start INT;
    v_combined_levels INT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_prefix_len := length(coalesce(prefix, ''));
    v_prefix_start := coalesce(array_length(string_to_array(coalesce(prefix, ''), v_delimiter), 1), 1);
    v_combined_levels := coalesce(array_length(string_to_array(v_prefix, v_delimiter), 1), 1);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT array_to_string(path_tokens[$1:$2], '/') AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $3 || '%%'
                  AND bucket_id = $4
                  AND array_length(objects.path_tokens, 1) <> $2
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT array_to_string(path_tokens[$1:$2], '/') AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $3 || '%%'
               AND bucket_id = $4
               AND array_length(objects.path_tokens, 1) = $2
             ORDER BY %I %s)
            LIMIT $5 OFFSET $6
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING v_prefix_start, v_combined_levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := substring(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter) from v_prefix_len + 1);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := substring(v_current.name from v_prefix_len + 1);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


--
-- Name: search_by_timestamp(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
    v_sort_order text;
    v_sort_column text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    -- Defense-in-depth: this function is independently reachable and must
    -- not trust p_sort_order/p_sort_column to already be validated by a
    -- caller. Normalize to the same strict allow-list storage.search_v2
    -- uses before interpolating anything into dynamic SQL below.
    v_sort_order := lower(coalesce(p_sort_order, 'asc'));
    IF v_sort_order NOT IN ('asc', 'desc') THEN
        v_sort_order := 'asc';
    END IF;

    v_sort_column := lower(coalesce(p_sort_column, 'updated_at'));
    IF v_sort_column NOT IN ('updated_at', 'created_at') THEN
        v_sort_column := 'updated_at';
    END IF;

    IF v_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        v_sort_column,
        v_cursor_op,
        v_sort_column,
        v_sort_order,
        v_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


--
-- Name: search_v2(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.custom_oauth_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_type text NOT NULL,
    identifier text NOT NULL,
    name text NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    acceptable_client_ids text[] DEFAULT '{}'::text[] NOT NULL,
    scopes text[] DEFAULT '{}'::text[] NOT NULL,
    pkce_enabled boolean DEFAULT true NOT NULL,
    attribute_mapping jsonb DEFAULT '{}'::jsonb NOT NULL,
    authorization_params jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    email_optional boolean DEFAULT false NOT NULL,
    issuer text,
    discovery_url text,
    skip_nonce_check boolean DEFAULT false NOT NULL,
    cached_discovery jsonb,
    discovery_cached_at timestamp with time zone,
    authorization_url text,
    token_url text,
    userinfo_url text,
    jwks_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    custom_claims_allowlist text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT custom_oauth_providers_authorization_url_https CHECK (((authorization_url IS NULL) OR (authorization_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_authorization_url_length CHECK (((authorization_url IS NULL) OR (char_length(authorization_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_client_id_length CHECK (((char_length(client_id) >= 1) AND (char_length(client_id) <= 512))),
    CONSTRAINT custom_oauth_providers_discovery_url_length CHECK (((discovery_url IS NULL) OR (char_length(discovery_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_identifier_format CHECK ((identifier ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::text)),
    CONSTRAINT custom_oauth_providers_issuer_length CHECK (((issuer IS NULL) OR ((char_length(issuer) >= 1) AND (char_length(issuer) <= 2048)))),
    CONSTRAINT custom_oauth_providers_jwks_uri_https CHECK (((jwks_uri IS NULL) OR (jwks_uri ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_jwks_uri_length CHECK (((jwks_uri IS NULL) OR (char_length(jwks_uri) <= 2048))),
    CONSTRAINT custom_oauth_providers_name_length CHECK (((char_length(name) >= 1) AND (char_length(name) <= 100))),
    CONSTRAINT custom_oauth_providers_oauth2_requires_endpoints CHECK (((provider_type <> 'oauth2'::text) OR ((authorization_url IS NOT NULL) AND (token_url IS NOT NULL) AND (userinfo_url IS NOT NULL)))),
    CONSTRAINT custom_oauth_providers_oidc_discovery_url_https CHECK (((provider_type <> 'oidc'::text) OR (discovery_url IS NULL) OR (discovery_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_issuer_https CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NULL) OR (issuer ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_requires_issuer CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NOT NULL))),
    CONSTRAINT custom_oauth_providers_provider_type_check CHECK ((provider_type = ANY (ARRAY['oauth2'::text, 'oidc'::text]))),
    CONSTRAINT custom_oauth_providers_token_url_https CHECK (((token_url IS NULL) OR (token_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_token_url_length CHECK (((token_url IS NULL) OR (char_length(token_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_userinfo_url_https CHECK (((userinfo_url IS NULL) OR (userinfo_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_userinfo_url_length CHECK (((userinfo_url IS NULL) OR (char_length(userinfo_url) <= 2048)))
);


--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text,
    code_challenge_method auth.code_challenge_method,
    code_challenge text,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone,
    invite_token text,
    referrer text,
    oauth_client_state_id uuid,
    linking_target_id uuid,
    email_optional boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.flow_state IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid,
    last_webauthn_challenge_data jsonb
);


--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: COLUMN mfa_factors.last_webauthn_challenge_data; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.mfa_factors.last_webauthn_challenge_data IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    nonce text,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_nonce_length CHECK ((char_length(nonce) <= 255)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_client_states (
    id uuid NOT NULL,
    provider_type text NOT NULL,
    code_verifier text,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: TABLE oauth_client_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.oauth_client_states IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    token_endpoint_auth_method text NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048)),
    CONSTRAINT oauth_clients_token_endpoint_auth_method_check CHECK ((token_endpoint_auth_method = ANY (ARRAY['client_secret_basic'::text, 'client_secret_post'::text, 'none'::text])))
);


--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: -
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: -
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid,
    refresh_token_hmac_key text,
    refresh_token_counter bigint,
    scopes text,
    CONSTRAINT sessions_scopes_length CHECK ((char_length(scopes) <= 4096))
);


--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN sessions.refresh_token_hmac_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_hmac_key IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN sessions.refresh_token_counter; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_counter IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    challenge_type text NOT NULL,
    session_data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT webauthn_challenges_challenge_type_check CHECK ((challenge_type = ANY (ARRAY['signup'::text, 'registration'::text, 'authentication'::text])))
);


--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    credential_id bytea NOT NULL,
    public_key bytea NOT NULL,
    attestation_type text DEFAULT ''::text NOT NULL,
    aaguid uuid,
    sign_count bigint DEFAULT 0 NOT NULL,
    transports jsonb DEFAULT '[]'::jsonb NOT NULL,
    backup_eligible boolean DEFAULT false NOT NULL,
    backed_up boolean DEFAULT false NOT NULL,
    friendly_name text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone
);


--
-- Name: akreditif_kalem_taksitleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.akreditif_kalem_taksitleri (
    id bigint NOT NULL,
    kalem_id bigint NOT NULL,
    taksit_no integer NOT NULL,
    vade_tarihi date NOT NULL,
    tutar numeric(18,2) NOT NULL,
    odendi_mi boolean DEFAULT false,
    odeme_tarihi date
);


--
-- Name: akreditif_kalem_taksitleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.akreditif_kalem_taksitleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: akreditif_kalem_taksitleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.akreditif_kalem_taksitleri_id_seq OWNED BY public.akreditif_kalem_taksitleri.id;


--
-- Name: akreditif_kalemleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.akreditif_kalemleri (
    id bigint NOT NULL,
    akreditif_id bigint NOT NULL,
    tip character varying(20) NOT NULL,
    aciklama character varying(300),
    tutar numeric(18,2) NOT NULL,
    vade_tarihi date NOT NULL,
    odendi_mi boolean DEFAULT false,
    odeme_tarihi date,
    odenen_tutar numeric(18,2) DEFAULT 0 NOT NULL
);


--
-- Name: akreditif_kalemleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.akreditif_kalemleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: akreditif_kalemleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.akreditif_kalemleri_id_seq OWNED BY public.akreditif_kalemleri.id;


--
-- Name: akreditif_maliyet_dagitimlari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.akreditif_maliyet_dagitimlari (
    id bigint NOT NULL,
    akreditif_id bigint NOT NULL,
    stok_seri_no_id bigint NOT NULL,
    yontem character varying(20) NOT NULL,
    kur numeric(18,4),
    tutar_try numeric(18,2) NOT NULL,
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: akreditif_maliyet_dagitimlari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.akreditif_maliyet_dagitimlari_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: akreditif_maliyet_dagitimlari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.akreditif_maliyet_dagitimlari_id_seq OWNED BY public.akreditif_maliyet_dagitimlari.id;


--
-- Name: akreditifler; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.akreditifler (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    siparis_id bigint NOT NULL,
    banka_hesap_id bigint NOT NULL,
    akreditif_no character varying(100),
    tip character varying(20) DEFAULT 'VADELI'::character varying NOT NULL,
    para_birimi character varying(10) NOT NULL,
    tutar numeric(18,2) NOT NULL,
    acilis_tarihi date NOT NULL,
    vade_tarihi date,
    durum character varying(20) DEFAULT 'ACIK'::character varying NOT NULL,
    notlar text,
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: akreditifler_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.akreditifler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: akreditifler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.akreditifler_id_seq OWNED BY public.akreditifler.id;


--
-- Name: bakim_kayitlari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bakim_kayitlari (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    stok_seri_no_id bigint NOT NULL,
    tarih date NOT NULL,
    tip public.bakim_tip_t NOT NULL,
    aciklama character varying(500),
    ilgili_cari_id bigint,
    tutar numeric(18,2) NOT NULL,
    para_birimi public.para_birimi_t DEFAULT 'TRY'::public.para_birimi_t NOT NULL,
    odendi_tahsil_edildi_mi boolean DEFAULT false,
    silindi_mi boolean DEFAULT false NOT NULL,
    silinme_tarihi timestamp without time zone
);


--
-- Name: bakim_kayitlari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bakim_kayitlari_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bakim_kayitlari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bakim_kayitlari_id_seq OWNED BY public.bakim_kayitlari.id;


--
-- Name: banka_hareketleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.banka_hareketleri (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    banka_hesap_id bigint NOT NULL,
    tarih date NOT NULL,
    tip public.banka_hareket_tip_t NOT NULL,
    tutar numeric(18,2) NOT NULL,
    aciklama character varying(500),
    karsi_hesap_id bigint,
    kullanilan_kur numeric(18,4),
    kaynak_tablo character varying(50),
    kaynak_id bigint,
    cari_id bigint,
    olusturan_kullanici_id bigint,
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    tutar_try_karsiligi numeric(18,2)
);


--
-- Name: banka_hareketleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.banka_hareketleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: banka_hareketleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.banka_hareketleri_id_seq OWNED BY public.banka_hareketleri.id;


--
-- Name: banka_hesaplari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.banka_hesaplari (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    banka_adi character varying(150) NOT NULL,
    sube character varying(100),
    hesap_adi character varying(150),
    iban character varying(50),
    para_birimi public.para_birimi_t NOT NULL,
    guncel_bakiye numeric(18,2) DEFAULT 0,
    aktif boolean DEFAULT true
);


--
-- Name: banka_hesaplari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.banka_hesaplari_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: banka_hesaplari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.banka_hesaplari_id_seq OWNED BY public.banka_hesaplari.id;


--
-- Name: belgeler; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.belgeler (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    kaynak_tablo character varying(50) NOT NULL,
    kaynak_id bigint NOT NULL,
    dosya_adi character varying(255) NOT NULL,
    icerik bytea NOT NULL,
    content_type character varying(100),
    boyut_bayt bigint,
    yukleyen_kullanici_id bigint,
    yukleme_tarihi timestamp without time zone DEFAULT now(),
    klasor_adi character varying(100)
);


--
-- Name: belgeler_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.belgeler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: belgeler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.belgeler_id_seq OWNED BY public.belgeler.id;


--
-- Name: borc_odemeleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.borc_odemeleri (
    id bigint NOT NULL,
    borc_id bigint NOT NULL,
    tarih date NOT NULL,
    tutar numeric(18,2) NOT NULL,
    aciklama character varying(300)
);


--
-- Name: borc_odemeleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.borc_odemeleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: borc_odemeleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.borc_odemeleri_id_seq OWNED BY public.borc_odemeleri.id;


--
-- Name: borclar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.borclar (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    tip public.borc_tip_t NOT NULL,
    cari_id bigint NOT NULL,
    tutar numeric(18,2) NOT NULL,
    para_birimi public.para_birimi_t NOT NULL,
    faiz_orani numeric(6,3) DEFAULT 0,
    alinma_tarihi date NOT NULL,
    vade_tarihi date,
    notlar text,
    silindi_mi boolean DEFAULT false NOT NULL,
    silinme_tarihi timestamp without time zone
);


--
-- Name: borclar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.borclar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: borclar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.borclar_id_seq OWNED BY public.borclar.id;


--
-- Name: cari_acilis_bakiyeleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cari_acilis_bakiyeleri (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    cari_id bigint NOT NULL,
    tutar numeric(18,2) NOT NULL,
    para_birimi public.para_birimi_t DEFAULT 'TRY'::public.para_birimi_t NOT NULL,
    kur numeric(18,6) DEFAULT 1 NOT NULL,
    tarih date NOT NULL,
    aciklama character varying(300),
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: cari_acilis_bakiyeleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cari_acilis_bakiyeleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cari_acilis_bakiyeleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cari_acilis_bakiyeleri_id_seq OWNED BY public.cari_acilis_bakiyeleri.id;


--
-- Name: cari_hareketler; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cari_hareketler (
    id bigint NOT NULL,
    cari_id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    tarih date NOT NULL,
    aciklama character varying(500),
    yon public.hareket_yon_t NOT NULL,
    para_birimi public.para_birimi_t NOT NULL,
    tutar numeric(18,2) NOT NULL,
    tutar_try_karsiligi numeric(18,2),
    kaynak_tablo character varying(50),
    kaynak_id bigint,
    olusturan_kullanici_id bigint,
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: cari_hareketler_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cari_hareketler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cari_hareketler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cari_hareketler_id_seq OWNED BY public.cari_hareketler.id;


--
-- Name: cari_hesaplar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cari_hesaplar (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    tip public.cari_tip_t NOT NULL,
    unvan character varying(255) NOT NULL,
    vergi_no character varying(20),
    vergi_dairesi character varying(100),
    adres text,
    telefon character varying(50),
    email character varying(100),
    otomatik_dolduruldu boolean DEFAULT false,
    bakiye_try numeric(18,2) DEFAULT 0,
    bakiye_usd numeric(18,2) DEFAULT 0,
    bakiye_eur numeric(18,2) DEFAULT 0,
    aktif boolean DEFAULT true,
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    silindi_mi boolean DEFAULT false NOT NULL,
    silinme_tarihi timestamp without time zone
);


--
-- Name: cari_hesaplar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cari_hesaplar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cari_hesaplar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cari_hesaplar_id_seq OWNED BY public.cari_hesaplar.id;


--
-- Name: cek_hareket_gecmisi; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cek_hareket_gecmisi (
    id bigint NOT NULL,
    cek_id bigint NOT NULL,
    tarih date NOT NULL,
    eski_durum public.cek_durum_t,
    yeni_durum public.cek_durum_t,
    aciklama character varying(300),
    olusturan_kullanici_id bigint
);


--
-- Name: cek_hareket_gecmisi_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cek_hareket_gecmisi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cek_hareket_gecmisi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cek_hareket_gecmisi_id_seq OWNED BY public.cek_hareket_gecmisi.id;


--
-- Name: cekler; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cekler (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    tip public.cek_tip_t NOT NULL,
    cek_no character varying(50),
    banka_adi character varying(150),
    cari_id bigint,
    tutar numeric(18,2) NOT NULL,
    para_birimi public.para_birimi_t DEFAULT 'TRY'::public.para_birimi_t NOT NULL,
    vade_tarihi date NOT NULL,
    alinma_verilme_tarihi date NOT NULL,
    durum public.cek_durum_t DEFAULT 'PORTFOYDE'::public.cek_durum_t,
    ciro_edilen_cari_id bigint,
    ciro_tarihi date,
    notlar character varying(500),
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    silindi_mi boolean DEFAULT false NOT NULL,
    silinme_tarihi timestamp without time zone
);


--
-- Name: cekler_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cekler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cekler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cekler_id_seq OWNED BY public.cekler.id;


--
-- Name: demirbaslar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.demirbaslar (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    kategori character varying(30) NOT NULL,
    ad character varying(200) NOT NULL,
    tanimlayici_no character varying(100),
    konum character varying(300),
    durum character varying(20) DEFAULT 'KULLANIMDA'::character varying NOT NULL,
    kiraci_cari_id bigint,
    maliyet_try numeric(18,2) DEFAULT 0 NOT NULL,
    alim_tarihi date,
    satis_fiyati_try numeric(18,2),
    satis_tarihi date,
    notlar character varying(500),
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    maliyet_orijinal numeric(18,2),
    para_birimi character varying(10) DEFAULT 'TRY'::character varying NOT NULL,
    amortisman_orani numeric(5,2),
    silindi_mi boolean DEFAULT false NOT NULL,
    silinme_tarihi timestamp without time zone
);


--
-- Name: demirbaslar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.demirbaslar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: demirbaslar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.demirbaslar_id_seq OWNED BY public.demirbaslar.id;


--
-- Name: doviz_kurlari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doviz_kurlari (
    id bigint NOT NULL,
    para_birimi public.para_birimi_t NOT NULL,
    tarih date NOT NULL,
    alis numeric(18,4) NOT NULL,
    satis numeric(18,4) NOT NULL
);


--
-- Name: doviz_kurlari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.doviz_kurlari_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: doviz_kurlari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.doviz_kurlari_id_seq OWNED BY public.doviz_kurlari.id;


--
-- Name: duzenleme_kayitlari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.duzenleme_kayitlari (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    kullanici_id bigint NOT NULL,
    tablo_adi character varying(50) NOT NULL,
    kayit_id bigint NOT NULL,
    degisiklikler text,
    tarih timestamp without time zone DEFAULT now(),
    islem_tipi character varying(20) DEFAULT 'DUZENLEME'::character varying NOT NULL
);


--
-- Name: duzenleme_kayitlari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.duzenleme_kayitlari_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: duzenleme_kayitlari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.duzenleme_kayitlari_id_seq OWNED BY public.duzenleme_kayitlari.id;


--
-- Name: fatura_detay; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fatura_detay (
    id bigint NOT NULL,
    fatura_id bigint NOT NULL,
    stok_karti_id bigint,
    stok_seri_no_id bigint,
    aciklama character varying(300),
    miktar numeric(18,2) DEFAULT 1 NOT NULL,
    birim_fiyat numeric(18,2) NOT NULL,
    kdv_orani numeric(5,2) DEFAULT 20
);


--
-- Name: fatura_detay_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fatura_detay_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fatura_detay_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fatura_detay_id_seq OWNED BY public.fatura_detay.id;


--
-- Name: faturalar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.faturalar (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    fatura_no character varying(50) NOT NULL,
    proforma_id bigint,
    cari_id bigint NOT NULL,
    tarih date NOT NULL,
    para_birimi public.para_birimi_t NOT NULL,
    ara_toplam numeric(18,2) NOT NULL,
    kdv_tutari numeric(18,2) DEFAULT 0,
    genel_toplam numeric(18,2) NOT NULL,
    odeme_durumu character varying(20) DEFAULT 'ODENMEDI'::character varying,
    notlar text,
    olusturan_kullanici_id bigint,
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: faturalar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.faturalar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: faturalar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.faturalar_id_seq OWNED BY public.faturalar.id;


--
-- Name: gumruk_beyannameleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gumruk_beyannameleri (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    siparis_id bigint NOT NULL,
    beyanname_no character varying(100),
    beyanname_tarihi date NOT NULL,
    gumruk_musaviri_cari_id bigint,
    tutar numeric(18,2) NOT NULL,
    para_birimi character varying(10) DEFAULT 'TRY'::character varying NOT NULL,
    kur numeric(18,6) DEFAULT 1 NOT NULL,
    tutar_try numeric(18,2) NOT NULL,
    notlar character varying(500),
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    kdv_tutari numeric(18,2) DEFAULT 0 NOT NULL
);


--
-- Name: gumruk_beyannameleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gumruk_beyannameleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gumruk_beyannameleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gumruk_beyannameleri_id_seq OWNED BY public.gumruk_beyannameleri.id;


--
-- Name: harcama_turleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.harcama_turleri (
    id bigint NOT NULL,
    ad character varying(150) NOT NULL,
    aktif boolean DEFAULT true
);


--
-- Name: harcama_turleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.harcama_turleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: harcama_turleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.harcama_turleri_id_seq OWNED BY public.harcama_turleri.id;


--
-- Name: islem_loglari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.islem_loglari (
    id bigint NOT NULL,
    sirket_id bigint,
    kullanici_id bigint,
    tablo_adi character varying(100),
    kayit_id bigint,
    islem_tipi character varying(20),
    eski_deger jsonb,
    yeni_deger jsonb,
    tarih timestamp without time zone DEFAULT now()
);


--
-- Name: islem_loglari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.islem_loglari_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: islem_loglari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.islem_loglari_id_seq OWNED BY public.islem_loglari.id;


--
-- Name: izinler; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.izinler (
    id bigint NOT NULL,
    kod character varying(100) NOT NULL,
    modul character varying(100) NOT NULL,
    aciklama character varying(255)
);


--
-- Name: izinler_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.izinler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: izinler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.izinler_id_seq OWNED BY public.izinler.id;


--
-- Name: kasa_hareketleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kasa_hareketleri (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    tarih date NOT NULL,
    yon public.hareket_yon_t NOT NULL,
    tutar numeric(18,2) NOT NULL,
    aciklama character varying(500),
    kaynak_tablo character varying(50),
    kaynak_id bigint,
    olusturan_kullanici_id bigint,
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    para_birimi character varying(10) DEFAULT 'TRY'::character varying NOT NULL,
    tutar_try_karsiligi numeric(18,2),
    cari_id bigint
);


--
-- Name: kasa_hareketleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kasa_hareketleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kasa_hareketleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kasa_hareketleri_id_seq OWNED BY public.kasa_hareketleri.id;


--
-- Name: kdv_manuel_girisler; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kdv_manuel_girisler (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    ay character varying(7) NOT NULL,
    tutar_try numeric(18,2) NOT NULL,
    aciklama character varying(300),
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: kdv_manuel_girisler_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kdv_manuel_girisler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kdv_manuel_girisler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kdv_manuel_girisler_id_seq OWNED BY public.kdv_manuel_girisler.id;


--
-- Name: kiralama_kalem_urunleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kiralama_kalem_urunleri (
    id bigint NOT NULL,
    kalem_id bigint NOT NULL,
    stok_seri_no_id bigint NOT NULL
);


--
-- Name: kiralama_kalem_urunleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kiralama_kalem_urunleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kiralama_kalem_urunleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kiralama_kalem_urunleri_id_seq OWNED BY public.kiralama_kalem_urunleri.id;


--
-- Name: kiralama_odemeleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kiralama_odemeleri (
    id bigint NOT NULL,
    sozlesme_id bigint NOT NULL,
    donem_basi date NOT NULL,
    donem_sonu date NOT NULL,
    tutar numeric(18,2) NOT NULL,
    odendi_mi boolean DEFAULT false,
    odeme_tarihi date,
    tahsilat_kaynak_tablo character varying(50),
    tahsilat_kaynak_id bigint,
    aciklama character varying(300)
);


--
-- Name: kiralama_odemeleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kiralama_odemeleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kiralama_odemeleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kiralama_odemeleri_id_seq OWNED BY public.kiralama_odemeleri.id;


--
-- Name: kiralama_sozlesme_kalemleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kiralama_sozlesme_kalemleri (
    id bigint NOT NULL,
    sozlesme_id bigint NOT NULL,
    stok_karti_id bigint NOT NULL,
    miktar integer DEFAULT 1 NOT NULL,
    birim_fiyat numeric(18,2) NOT NULL
);


--
-- Name: kiralama_sozlesme_kalemleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kiralama_sozlesme_kalemleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kiralama_sozlesme_kalemleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kiralama_sozlesme_kalemleri_id_seq OWNED BY public.kiralama_sozlesme_kalemleri.id;


--
-- Name: kiralama_sozlesmeleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kiralama_sozlesmeleri (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    stok_seri_no_id bigint,
    kiraci_cari_id bigint NOT NULL,
    baslangic_tarihi date NOT NULL,
    bitis_tarihi date,
    aylik_kira_tutari numeric(18,2) NOT NULL,
    para_birimi public.para_birimi_t NOT NULL,
    depozito numeric(18,2) DEFAULT 0,
    durum character varying(20) DEFAULT 'AKTIF'::character varying,
    notlar text,
    referans_kur numeric(18,6) DEFAULT 1,
    silindi_mi boolean DEFAULT false NOT NULL,
    silinme_tarihi timestamp without time zone
);


--
-- Name: kiralama_sozlesmeleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kiralama_sozlesmeleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kiralama_sozlesmeleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kiralama_sozlesmeleri_id_seq OWNED BY public.kiralama_sozlesmeleri.id;


--
-- Name: kullanici_rolleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kullanici_rolleri (
    kullanici_id bigint NOT NULL,
    rol_id bigint NOT NULL,
    sirket_id bigint NOT NULL
);


--
-- Name: kullanici_sirket_erisim; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kullanici_sirket_erisim (
    id bigint NOT NULL,
    kullanici_id bigint NOT NULL,
    sirket_id bigint NOT NULL
);


--
-- Name: kullanici_sirket_erisim_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kullanici_sirket_erisim_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kullanici_sirket_erisim_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kullanici_sirket_erisim_id_seq OWNED BY public.kullanici_sirket_erisim.id;


--
-- Name: kullanicilar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kullanicilar (
    id bigint NOT NULL,
    ad_soyad character varying(150) NOT NULL,
    email character varying(150) NOT NULL,
    sifre_hash character varying(255) NOT NULL,
    telefon character varying(50),
    aktif boolean DEFAULT true,
    son_giris timestamp without time zone,
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    sifre_sifirlama_token text,
    sifre_sifirlama_son_gecerlilik timestamp without time zone
);


--
-- Name: kullanicilar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kullanicilar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kullanicilar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kullanicilar_id_seq OWNED BY public.kullanicilar.id;


--
-- Name: leasing_kalem_urunleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leasing_kalem_urunleri (
    id bigint NOT NULL,
    kalem_id bigint NOT NULL,
    stok_seri_no_id bigint NOT NULL
);


--
-- Name: leasing_kalem_urunleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leasing_kalem_urunleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leasing_kalem_urunleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leasing_kalem_urunleri_id_seq OWNED BY public.leasing_kalem_urunleri.id;


--
-- Name: leasing_odeme_plani; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leasing_odeme_plani (
    id bigint NOT NULL,
    leasing_id bigint NOT NULL,
    taksit_no integer NOT NULL,
    vade_tarihi date NOT NULL,
    tutar numeric(18,2) NOT NULL,
    odendi_mi boolean DEFAULT false,
    odeme_tarihi date,
    banka_hareket_id bigint
);


--
-- Name: leasing_odeme_plani_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leasing_odeme_plani_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leasing_odeme_plani_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leasing_odeme_plani_id_seq OWNED BY public.leasing_odeme_plani.id;


--
-- Name: leasing_sozlesme_kalemleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leasing_sozlesme_kalemleri (
    id bigint NOT NULL,
    leasing_id bigint NOT NULL,
    stok_karti_id bigint NOT NULL,
    miktar integer DEFAULT 1 NOT NULL,
    birim_fiyat numeric(18,2) NOT NULL
);


--
-- Name: leasing_sozlesme_kalemleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leasing_sozlesme_kalemleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leasing_sozlesme_kalemleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leasing_sozlesme_kalemleri_id_seq OWNED BY public.leasing_sozlesme_kalemleri.id;


--
-- Name: leasing_sozlesmeleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leasing_sozlesmeleri (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    leasing_firmasi_cari_id bigint NOT NULL,
    stok_seri_no_id bigint,
    sozlesme_no character varying(100),
    baslangic_tarihi date,
    toplam_tutar numeric(18,2),
    para_birimi public.para_birimi_t NOT NULL,
    taksit_sayisi integer,
    notlar text,
    silindi_mi boolean DEFAULT false NOT NULL,
    silinme_tarihi timestamp without time zone
);


--
-- Name: leasing_sozlesmeleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leasing_sozlesmeleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leasing_sozlesmeleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leasing_sozlesmeleri_id_seq OWNED BY public.leasing_sozlesmeleri.id;


--
-- Name: personel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personel (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    ad_soyad character varying(150) NOT NULL,
    pozisyon character varying(100),
    aylik_maas numeric(18,2),
    ise_baslama_tarihi date,
    aktif boolean DEFAULT true
);


--
-- Name: personel_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.personel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: personel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.personel_id_seq OWNED BY public.personel.id;


--
-- Name: personel_odemeleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personel_odemeleri (
    id bigint NOT NULL,
    personel_id bigint NOT NULL,
    donem date NOT NULL,
    tip public.personel_odeme_tip_t NOT NULL,
    tutar numeric(18,2) NOT NULL,
    odendi_mi boolean DEFAULT false,
    odeme_tarihi date,
    aciklama character varying(300)
);


--
-- Name: personel_odemeleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.personel_odemeleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: personel_odemeleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.personel_odemeleri_id_seq OWNED BY public.personel_odemeleri.id;


--
-- Name: pos_taksit_detay; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_taksit_detay (
    id bigint NOT NULL,
    plan_id bigint NOT NULL,
    taksit_no integer NOT NULL,
    vade_tarihi date NOT NULL,
    tutar numeric(18,2) NOT NULL,
    yatti_mi boolean DEFAULT false,
    yatma_tarihi date
);


--
-- Name: pos_taksit_detay_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pos_taksit_detay_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pos_taksit_detay_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pos_taksit_detay_id_seq OWNED BY public.pos_taksit_detay.id;


--
-- Name: pos_taksit_planlari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_taksit_planlari (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    stok_seri_no_id bigint NOT NULL,
    musteri_cari_id bigint,
    banka_hesap_id bigint NOT NULL,
    toplam_tutar numeric(18,2) NOT NULL,
    taksit_sayisi integer NOT NULL,
    baslangic_tarihi date NOT NULL,
    notlar character varying(300),
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    silindi_mi boolean DEFAULT false NOT NULL,
    silinme_tarihi timestamp without time zone
);


--
-- Name: pos_taksit_planlari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pos_taksit_planlari_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pos_taksit_planlari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pos_taksit_planlari_id_seq OWNED BY public.pos_taksit_planlari.id;


--
-- Name: proforma_detay; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proforma_detay (
    id bigint NOT NULL,
    proforma_id bigint NOT NULL,
    stok_karti_id bigint,
    aciklama character varying(300),
    miktar numeric(18,2) DEFAULT 1 NOT NULL,
    birim_fiyat numeric(18,2) NOT NULL,
    kdv_orani numeric(5,2) DEFAULT 20,
    stok_seri_no_id bigint
);


--
-- Name: proforma_detay_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.proforma_detay_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: proforma_detay_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.proforma_detay_id_seq OWNED BY public.proforma_detay.id;


--
-- Name: proforma_faturalar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proforma_faturalar (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    proforma_no character varying(50) NOT NULL,
    cari_id bigint NOT NULL,
    tarih date NOT NULL,
    gecerlilik_tarihi date,
    para_birimi public.para_birimi_t NOT NULL,
    ara_toplam numeric(18,2) NOT NULL,
    kdv_tutari numeric(18,2) DEFAULT 0,
    genel_toplam numeric(18,2) NOT NULL,
    durum character varying(20) DEFAULT 'BEKLEMEDE'::character varying,
    notlar text,
    olusturan_kullanici_id bigint,
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: proforma_faturalar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.proforma_faturalar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: proforma_faturalar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.proforma_faturalar_id_seq OWNED BY public.proforma_faturalar.id;


--
-- Name: rol_izinleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rol_izinleri (
    rol_id bigint NOT NULL,
    izin_id bigint NOT NULL
);


--
-- Name: roller; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roller (
    id bigint NOT NULL,
    sirket_id bigint,
    ad character varying(100) NOT NULL,
    aciklama character varying(255)
);


--
-- Name: roller_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roller_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roller_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roller_id_seq OWNED BY public.roller.id;


--
-- Name: sabit_gider_kategorileri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sabit_gider_kategorileri (
    id bigint NOT NULL,
    ad character varying(100) NOT NULL
);


--
-- Name: sabit_gider_kategorileri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sabit_gider_kategorileri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sabit_gider_kategorileri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sabit_gider_kategorileri_id_seq OWNED BY public.sabit_gider_kategorileri.id;


--
-- Name: sabit_giderler; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sabit_giderler (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    kategori_id bigint,
    donem date NOT NULL,
    tutar numeric(18,2) NOT NULL,
    odendi_mi boolean DEFAULT false,
    odeme_tarihi date,
    aciklama character varying(300),
    kategori character varying(150),
    para_birimi public.para_birimi_t DEFAULT 'TRY'::public.para_birimi_t NOT NULL,
    kur numeric(18,6) DEFAULT 1 NOT NULL,
    tutar_try numeric(18,2) NOT NULL,
    silindi_mi boolean DEFAULT false NOT NULL,
    silinme_tarihi timestamp without time zone
);


--
-- Name: sabit_giderler_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sabit_giderler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sabit_giderler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sabit_giderler_id_seq OWNED BY public.sabit_giderler.id;


--
-- Name: siparis_detay; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.siparis_detay (
    id bigint NOT NULL,
    siparis_id bigint NOT NULL,
    stok_karti_id bigint NOT NULL,
    miktar integer DEFAULT 1 NOT NULL,
    birim_fiyat numeric(18,2) NOT NULL,
    para_birimi public.para_birimi_t NOT NULL,
    birim_agirlik_kg numeric(10,2),
    aciklama character varying(300),
    kdv_orani numeric(5,2) DEFAULT 20 NOT NULL
);


--
-- Name: siparis_detay_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.siparis_detay_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: siparis_detay_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.siparis_detay_id_seq OWNED BY public.siparis_detay.id;


--
-- Name: siparis_odemeleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.siparis_odemeleri (
    id bigint NOT NULL,
    siparis_id bigint NOT NULL,
    tarih date NOT NULL,
    tutar numeric(18,2) NOT NULL,
    notlar character varying(300),
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    odeme_yontemi character varying(10),
    cek_id bigint
);


--
-- Name: siparis_odemeleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.siparis_odemeleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: siparis_odemeleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.siparis_odemeleri_id_seq OWNED BY public.siparis_odemeleri.id;


--
-- Name: siparisler; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.siparisler (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    siparis_no character varying(50) NOT NULL,
    tedarikci_cari_id bigint NOT NULL,
    kaynak public.stok_kaynak_t NOT NULL,
    kopya_kaynak_siparis_id bigint,
    siparis_tarihi date NOT NULL,
    tahmini_teslim_tarihi date,
    durum public.siparis_durum_t DEFAULT 'TASLAK'::public.siparis_durum_t,
    para_birimi public.para_birimi_t NOT NULL,
    cikis_limani character varying(150),
    varis_limani character varying(150),
    konsimento_no character varying(100),
    gumruk_beyanname_no character varying(100),
    notlar text,
    olusturan_kullanici_id bigint,
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    silindi_mi boolean DEFAULT false NOT NULL,
    silinme_tarihi timestamp without time zone
);


--
-- Name: siparisler_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.siparisler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: siparisler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.siparisler_id_seq OWNED BY public.siparisler.id;


--
-- Name: sirketler; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sirketler (
    id bigint NOT NULL,
    unvan character varying(255) NOT NULL,
    vergi_dairesi character varying(100),
    vergi_no character varying(20),
    adres text,
    telefon character varying(50),
    email character varying(100),
    logo_dosya_yolu character varying(500),
    aktif boolean DEFAULT true,
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    logo_verisi bytea,
    logo_content_type character varying(100)
);


--
-- Name: sirketler_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sirketler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sirketler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sirketler_id_seq OWNED BY public.sirketler.id;


--
-- Name: stok_kartlari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stok_kartlari (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    kategori_id bigint,
    marka character varying(100),
    model character varying(150),
    aciklama text,
    birim character varying(20) DEFAULT 'ADET'::character varying,
    birim_agirlik_kg numeric(10,2),
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    mense_ulke character varying(100),
    gtip_kodu character varying(20),
    standart_alt_metin text,
    silindi_mi boolean DEFAULT false NOT NULL,
    silinme_tarihi timestamp without time zone
);


--
-- Name: stok_kartlari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stok_kartlari_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stok_kartlari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stok_kartlari_id_seq OWNED BY public.stok_kartlari.id;


--
-- Name: stok_kategorileri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stok_kategorileri (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    ad character varying(150) NOT NULL
);


--
-- Name: stok_kategorileri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stok_kategorileri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stok_kategorileri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stok_kategorileri_id_seq OWNED BY public.stok_kategorileri.id;


--
-- Name: stok_maliyet_kalemleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stok_maliyet_kalemleri (
    id bigint NOT NULL,
    stok_seri_no_id bigint NOT NULL,
    tip public.maliyet_tip_t NOT NULL,
    aciklama character varying(300),
    tedarikci_cari_id bigint,
    para_birimi public.para_birimi_t NOT NULL,
    tutar numeric(18,2) NOT NULL,
    kur numeric(18,4) DEFAULT 1,
    tutar_try numeric(18,2) NOT NULL,
    belge_no character varying(100),
    tarih date NOT NULL,
    odendi_mi boolean DEFAULT false,
    referans_usd_kuru numeric(18,6),
    tedarikci_fatura_odeme_id bigint
);


--
-- Name: stok_maliyet_kalemleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stok_maliyet_kalemleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stok_maliyet_kalemleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stok_maliyet_kalemleri_id_seq OWNED BY public.stok_maliyet_kalemleri.id;


--
-- Name: stok_seri_no; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stok_seri_no (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    stok_karti_id bigint NOT NULL,
    seri_no character varying(100) NOT NULL,
    sasi_no character varying(100),
    uretim_yili integer,
    kaynak public.stok_kaynak_t NOT NULL,
    siparis_id bigint,
    durum public.stok_durum_t DEFAULT 'SIPARISTE'::public.stok_durum_t NOT NULL,
    tedarikci_cari_id bigint,
    satinalma_maliyeti_try numeric(18,2) DEFAULT 0,
    nakliye_maliyeti_try numeric(18,2) DEFAULT 0,
    gumruk_maliyeti_try numeric(18,2) DEFAULT 0,
    antrepo_maliyeti_try numeric(18,2) DEFAULT 0,
    millilestirme_maliyeti_try numeric(18,2) DEFAULT 0,
    leasing_maliyeti_try numeric(18,2) DEFAULT 0,
    diger_maliyet_try numeric(18,2) DEFAULT 0,
    toplam_maliyet_try numeric(18,2) GENERATED ALWAYS AS (((((((COALESCE(satinalma_maliyeti_try, (0)::numeric) + COALESCE(nakliye_maliyeti_try, (0)::numeric)) + COALESCE(gumruk_maliyeti_try, (0)::numeric)) + COALESCE(antrepo_maliyeti_try, (0)::numeric)) + COALESCE(millilestirme_maliyeti_try, (0)::numeric)) + COALESCE(leasing_maliyeti_try, (0)::numeric)) + COALESCE(diger_maliyet_try, (0)::numeric))) STORED,
    satis_fiyati_try numeric(18,2),
    satis_tarihi date,
    musteri_cari_id bigint,
    giris_tarihi date,
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    garanti_bitis_tarihi date,
    barkod character varying(100),
    satis_cek_id bigint,
    sahiplik_tipi character varying(20) DEFAULT 'TICARI'::character varying NOT NULL,
    ardiye_maliyeti_try numeric(18,2) DEFAULT 0,
    ilave_gumruk_vergisi_try numeric(18,2) DEFAULT 0,
    damga_vergisi_try numeric(18,2) DEFAULT 0,
    tse_ucreti_try numeric(18,2) DEFAULT 0,
    gumrukcu_masrafi_try numeric(18,2) DEFAULT 0,
    banka_masrafi_try numeric(18,2) DEFAULT 0,
    kdv_try numeric(18,2) DEFAULT 0,
    satis_odeme_tipi character varying(20),
    satis_kayit_zamani timestamp without time zone,
    sigorta_maliyeti_try numeric(18,2) DEFAULT 0,
    satis_yontemi character varying(20),
    silindi_mi boolean DEFAULT false NOT NULL,
    silinme_tarihi timestamp without time zone,
    bakim_periyodu_gun integer
);


--
-- Name: stok_seri_no_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stok_seri_no_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stok_seri_no_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stok_seri_no_id_seq OWNED BY public.stok_seri_no.id;


--
-- Name: taksit_detay; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taksit_detay (
    id bigint NOT NULL,
    plan_id bigint NOT NULL,
    taksit_no integer NOT NULL,
    vade_tarihi date NOT NULL,
    tutar numeric(18,2) NOT NULL,
    odendi_mi boolean DEFAULT false,
    odeme_tarihi date,
    tahsilat_kaynak_tablo character varying(50),
    tahsilat_kaynak_id bigint,
    odenen_tutar numeric(18,2) DEFAULT 0 NOT NULL,
    ilk_taksit_id bigint
);


--
-- Name: taksit_detay_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.taksit_detay_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: taksit_detay_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.taksit_detay_id_seq OWNED BY public.taksit_detay.id;


--
-- Name: taksitli_satis_kalem_urunleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taksitli_satis_kalem_urunleri (
    id bigint NOT NULL,
    kalem_id bigint NOT NULL,
    stok_seri_no_id bigint NOT NULL
);


--
-- Name: taksitli_satis_kalem_urunleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.taksitli_satis_kalem_urunleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: taksitli_satis_kalem_urunleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.taksitli_satis_kalem_urunleri_id_seq OWNED BY public.taksitli_satis_kalem_urunleri.id;


--
-- Name: taksitli_satis_kalemleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taksitli_satis_kalemleri (
    id bigint NOT NULL,
    plan_id bigint NOT NULL,
    stok_karti_id bigint NOT NULL,
    miktar integer DEFAULT 1 NOT NULL,
    birim_fiyat numeric(18,2) NOT NULL
);


--
-- Name: taksitli_satis_kalemleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.taksitli_satis_kalemleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: taksitli_satis_kalemleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.taksitli_satis_kalemleri_id_seq OWNED BY public.taksitli_satis_kalemleri.id;


--
-- Name: taksitli_satis_planlari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taksitli_satis_planlari (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    musteri_cari_id bigint NOT NULL,
    stok_seri_no_id bigint,
    toplam_tutar numeric(18,2) NOT NULL,
    para_birimi public.para_birimi_t NOT NULL,
    pesinat numeric(18,2) DEFAULT 0,
    taksit_sayisi integer NOT NULL,
    baslangic_tarihi date NOT NULL,
    notlar text,
    silindi_mi boolean DEFAULT false NOT NULL,
    silinme_tarihi timestamp without time zone
);


--
-- Name: taksitli_satis_planlari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.taksitli_satis_planlari_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: taksitli_satis_planlari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.taksitli_satis_planlari_id_seq OWNED BY public.taksitli_satis_planlari.id;


--
-- Name: tedarikci_fatura_odemeleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tedarikci_fatura_odemeleri (
    id bigint NOT NULL,
    fatura_id bigint NOT NULL,
    tutar numeric(18,2) NOT NULL,
    odeme_tarihi date NOT NULL,
    odeme_yontemi character varying(10) NOT NULL,
    banka_hesap_id bigint,
    kur numeric(18,6) DEFAULT 1,
    dagitim_tipi character varying(10) NOT NULL,
    siparis_id bigint,
    stok_seri_no_id bigint,
    maliyet_tipi public.maliyet_tip_t NOT NULL,
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: tedarikci_fatura_odemeleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tedarikci_fatura_odemeleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tedarikci_fatura_odemeleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tedarikci_fatura_odemeleri_id_seq OWNED BY public.tedarikci_fatura_odemeleri.id;


--
-- Name: tedarikci_faturalari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tedarikci_faturalari (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    tedarikci_cari_id bigint NOT NULL,
    fatura_no character varying(100),
    tarih date NOT NULL,
    tutar numeric(18,2) NOT NULL,
    para_birimi public.para_birimi_t DEFAULT 'TRY'::public.para_birimi_t NOT NULL,
    aciklama text,
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    varsayilan_maliyet_tipi public.maliyet_tip_t DEFAULT 'DIGER'::public.maliyet_tip_t NOT NULL
);


--
-- Name: tedarikci_faturalari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tedarikci_faturalari_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tedarikci_faturalari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tedarikci_faturalari_id_seq OWNED BY public.tedarikci_faturalari.id;


--
-- Name: urun_sahiplik_gecmisi; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.urun_sahiplik_gecmisi (
    id bigint NOT NULL,
    stok_seri_no_id bigint NOT NULL,
    eski_cari_id bigint,
    yeni_cari_id bigint NOT NULL,
    aciklama text,
    tarih date DEFAULT CURRENT_DATE NOT NULL,
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: urun_sahiplik_gecmisi_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.urun_sahiplik_gecmisi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: urun_sahiplik_gecmisi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.urun_sahiplik_gecmisi_id_seq OWNED BY public.urun_sahiplik_gecmisi.id;


--
-- Name: v_ana_kasa_bakiye; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_ana_kasa_bakiye AS
 SELECT sirket_id,
    sum(
        CASE
            WHEN (yon = 'GIRIS'::public.hareket_yon_t) THEN tutar
            ELSE (- tutar)
        END) AS net_bakiye
   FROM public.kasa_hareketleri
  GROUP BY sirket_id;


--
-- Name: v_banka_bakiyeleri; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_banka_bakiyeleri AS
 SELECT bh.sirket_id,
    bh.id AS banka_hesap_id,
    bh.banka_adi,
    bh.hesap_adi,
    bh.para_birimi,
    COALESCE(sum(bk.tutar), (0)::numeric) AS bakiye
   FROM (public.banka_hesaplari bh
     LEFT JOIN public.banka_hareketleri bk ON ((bk.banka_hesap_id = bh.id)))
  GROUP BY bh.sirket_id, bh.id, bh.banka_adi, bh.hesap_adi, bh.para_birimi;


--
-- Name: v_cari_hareket_ozet; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_cari_hareket_ozet AS
 SELECT cari_id,
    sirket_id,
    para_birimi,
    sum(
        CASE
            WHEN (yon = 'GIRIS'::public.hareket_yon_t) THEN tutar
            ELSE (0)::numeric
        END) AS toplam_giris,
    sum(
        CASE
            WHEN (yon = 'CIKIS'::public.hareket_yon_t) THEN tutar
            ELSE (0)::numeric
        END) AS toplam_cikis,
    sum(
        CASE
            WHEN (yon = 'GIRIS'::public.hareket_yon_t) THEN tutar
            ELSE (- tutar)
        END) AS net_bakiye
   FROM public.cari_hareketler
  GROUP BY cari_id, sirket_id, para_birimi;


--
-- Name: v_seri_no_kar_raporu; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_seri_no_kar_raporu AS
 SELECT s.sirket_id,
    s.seri_no,
    sk.marka,
    sk.model,
    s.satinalma_maliyeti_try,
    s.nakliye_maliyeti_try,
    s.gumruk_maliyeti_try,
    s.antrepo_maliyeti_try,
    s.millilestirme_maliyeti_try,
    s.leasing_maliyeti_try,
    s.diger_maliyet_try,
    s.toplam_maliyet_try,
    s.satis_fiyati_try,
    (s.satis_fiyati_try - s.toplam_maliyet_try) AS kar_zarar_try,
    s.durum
   FROM (public.stok_seri_no s
     JOIN public.stok_kartlari sk ON ((sk.id = s.stok_karti_id)));


--
-- Name: yedek_parca_hareketleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.yedek_parca_hareketleri (
    id bigint NOT NULL,
    yedek_parca_id bigint NOT NULL,
    tarih date NOT NULL,
    yon character varying(10) NOT NULL,
    miktar numeric(18,2) NOT NULL,
    birim_fiyat_try numeric(18,2),
    ilgili_cari_id bigint,
    aciklama character varying(300),
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    birim_fiyat_orijinal numeric(18,2),
    para_birimi character varying(10) DEFAULT 'TRY'::character varying NOT NULL,
    kur numeric(18,6) DEFAULT 1 NOT NULL,
    maliyet_birim_fiyat_try numeric(18,2),
    odeme_yontemi character varying(10),
    banka_hesap_id bigint,
    ilgili_stok_seri_no_id bigint
);


--
-- Name: yedek_parca_hareketleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.yedek_parca_hareketleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: yedek_parca_hareketleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.yedek_parca_hareketleri_id_seq OWNED BY public.yedek_parca_hareketleri.id;


--
-- Name: yedek_parcalar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.yedek_parcalar (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    ad character varying(200) NOT NULL,
    birim character varying(20) DEFAULT 'ADET'::character varying NOT NULL,
    mevcut_miktar numeric(18,2) DEFAULT 0 NOT NULL,
    birim_fiyat_try numeric(18,2) DEFAULT 0 NOT NULL,
    min_stok_seviyesi numeric(18,2) DEFAULT 0,
    notlar character varying(500),
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    silindi_mi boolean DEFAULT false NOT NULL,
    silinme_tarihi timestamp without time zone
);


--
-- Name: yedek_parcalar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.yedek_parcalar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: yedek_parcalar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.yedek_parcalar_id_seq OWNED BY public.yedek_parcalar.id;


--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea
)
PARTITION BY RANGE (inserted_at);


--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    action_filter text DEFAULT '*'::text,
    selected_columns text[],
    CONSTRAINT subscription_action_filter_check CHECK ((action_filter = ANY (ARRAY['*'::text, 'INSERT'::text, 'UPDATE'::text, 'DELETE'::text])))
);


--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: -
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL,
    versioning_status text DEFAULT 'DISABLED'::text NOT NULL,
    CONSTRAINT buckets_versioning_dark_check CHECK ((versioning_status = 'DISABLED'::text)),
    CONSTRAINT buckets_versioning_standard_only_check CHECK (((type = 'STANDARD'::storage.buckettype) OR (versioning_status = 'DISABLED'::text))),
    CONSTRAINT buckets_versioning_status_check CHECK ((versioning_status = ANY (ARRAY['DISABLED'::text, 'ENABLED'::text, 'SUSPENDED'::text])))
);


--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_analytics (
    name text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_vectors (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'VECTOR'::storage.buckettype NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: objects; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb,
    archived_at timestamp with time zone,
    is_delete_marker boolean DEFAULT false NOT NULL,
    is_versioned boolean DEFAULT false NOT NULL
);


--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb,
    metadata jsonb
);


--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.vector_indexes (
    id text DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    bucket_id text NOT NULL,
    data_type text NOT NULL,
    dimension integer NOT NULL,
    distance_metric text NOT NULL,
    metadata_configuration jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Name: akreditif_kalem_taksitleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditif_kalem_taksitleri ALTER COLUMN id SET DEFAULT nextval('public.akreditif_kalem_taksitleri_id_seq'::regclass);


--
-- Name: akreditif_kalemleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditif_kalemleri ALTER COLUMN id SET DEFAULT nextval('public.akreditif_kalemleri_id_seq'::regclass);


--
-- Name: akreditif_maliyet_dagitimlari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditif_maliyet_dagitimlari ALTER COLUMN id SET DEFAULT nextval('public.akreditif_maliyet_dagitimlari_id_seq'::regclass);


--
-- Name: akreditifler id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditifler ALTER COLUMN id SET DEFAULT nextval('public.akreditifler_id_seq'::regclass);


--
-- Name: bakim_kayitlari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bakim_kayitlari ALTER COLUMN id SET DEFAULT nextval('public.bakim_kayitlari_id_seq'::regclass);


--
-- Name: banka_hareketleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hareketleri ALTER COLUMN id SET DEFAULT nextval('public.banka_hareketleri_id_seq'::regclass);


--
-- Name: banka_hesaplari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hesaplari ALTER COLUMN id SET DEFAULT nextval('public.banka_hesaplari_id_seq'::regclass);


--
-- Name: belgeler id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.belgeler ALTER COLUMN id SET DEFAULT nextval('public.belgeler_id_seq'::regclass);


--
-- Name: borc_odemeleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.borc_odemeleri ALTER COLUMN id SET DEFAULT nextval('public.borc_odemeleri_id_seq'::regclass);


--
-- Name: borclar id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.borclar ALTER COLUMN id SET DEFAULT nextval('public.borclar_id_seq'::regclass);


--
-- Name: cari_acilis_bakiyeleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_acilis_bakiyeleri ALTER COLUMN id SET DEFAULT nextval('public.cari_acilis_bakiyeleri_id_seq'::regclass);


--
-- Name: cari_hareketler id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_hareketler ALTER COLUMN id SET DEFAULT nextval('public.cari_hareketler_id_seq'::regclass);


--
-- Name: cari_hesaplar id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_hesaplar ALTER COLUMN id SET DEFAULT nextval('public.cari_hesaplar_id_seq'::regclass);


--
-- Name: cek_hareket_gecmisi id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cek_hareket_gecmisi ALTER COLUMN id SET DEFAULT nextval('public.cek_hareket_gecmisi_id_seq'::regclass);


--
-- Name: cekler id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cekler ALTER COLUMN id SET DEFAULT nextval('public.cekler_id_seq'::regclass);


--
-- Name: demirbaslar id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demirbaslar ALTER COLUMN id SET DEFAULT nextval('public.demirbaslar_id_seq'::regclass);


--
-- Name: doviz_kurlari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doviz_kurlari ALTER COLUMN id SET DEFAULT nextval('public.doviz_kurlari_id_seq'::regclass);


--
-- Name: duzenleme_kayitlari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duzenleme_kayitlari ALTER COLUMN id SET DEFAULT nextval('public.duzenleme_kayitlari_id_seq'::regclass);


--
-- Name: fatura_detay id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fatura_detay ALTER COLUMN id SET DEFAULT nextval('public.fatura_detay_id_seq'::regclass);


--
-- Name: faturalar id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faturalar ALTER COLUMN id SET DEFAULT nextval('public.faturalar_id_seq'::regclass);


--
-- Name: gumruk_beyannameleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gumruk_beyannameleri ALTER COLUMN id SET DEFAULT nextval('public.gumruk_beyannameleri_id_seq'::regclass);


--
-- Name: harcama_turleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.harcama_turleri ALTER COLUMN id SET DEFAULT nextval('public.harcama_turleri_id_seq'::regclass);


--
-- Name: islem_loglari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.islem_loglari ALTER COLUMN id SET DEFAULT nextval('public.islem_loglari_id_seq'::regclass);


--
-- Name: izinler id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.izinler ALTER COLUMN id SET DEFAULT nextval('public.izinler_id_seq'::regclass);


--
-- Name: kasa_hareketleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kasa_hareketleri ALTER COLUMN id SET DEFAULT nextval('public.kasa_hareketleri_id_seq'::regclass);


--
-- Name: kdv_manuel_girisler id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kdv_manuel_girisler ALTER COLUMN id SET DEFAULT nextval('public.kdv_manuel_girisler_id_seq'::regclass);


--
-- Name: kiralama_kalem_urunleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_kalem_urunleri ALTER COLUMN id SET DEFAULT nextval('public.kiralama_kalem_urunleri_id_seq'::regclass);


--
-- Name: kiralama_odemeleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_odemeleri ALTER COLUMN id SET DEFAULT nextval('public.kiralama_odemeleri_id_seq'::regclass);


--
-- Name: kiralama_sozlesme_kalemleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_sozlesme_kalemleri ALTER COLUMN id SET DEFAULT nextval('public.kiralama_sozlesme_kalemleri_id_seq'::regclass);


--
-- Name: kiralama_sozlesmeleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_sozlesmeleri ALTER COLUMN id SET DEFAULT nextval('public.kiralama_sozlesmeleri_id_seq'::regclass);


--
-- Name: kullanici_sirket_erisim id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanici_sirket_erisim ALTER COLUMN id SET DEFAULT nextval('public.kullanici_sirket_erisim_id_seq'::regclass);


--
-- Name: kullanicilar id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanicilar ALTER COLUMN id SET DEFAULT nextval('public.kullanicilar_id_seq'::regclass);


--
-- Name: leasing_kalem_urunleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_kalem_urunleri ALTER COLUMN id SET DEFAULT nextval('public.leasing_kalem_urunleri_id_seq'::regclass);


--
-- Name: leasing_odeme_plani id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_odeme_plani ALTER COLUMN id SET DEFAULT nextval('public.leasing_odeme_plani_id_seq'::regclass);


--
-- Name: leasing_sozlesme_kalemleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_sozlesme_kalemleri ALTER COLUMN id SET DEFAULT nextval('public.leasing_sozlesme_kalemleri_id_seq'::regclass);


--
-- Name: leasing_sozlesmeleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_sozlesmeleri ALTER COLUMN id SET DEFAULT nextval('public.leasing_sozlesmeleri_id_seq'::regclass);


--
-- Name: personel id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personel ALTER COLUMN id SET DEFAULT nextval('public.personel_id_seq'::regclass);


--
-- Name: personel_odemeleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personel_odemeleri ALTER COLUMN id SET DEFAULT nextval('public.personel_odemeleri_id_seq'::regclass);


--
-- Name: pos_taksit_detay id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_taksit_detay ALTER COLUMN id SET DEFAULT nextval('public.pos_taksit_detay_id_seq'::regclass);


--
-- Name: pos_taksit_planlari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_taksit_planlari ALTER COLUMN id SET DEFAULT nextval('public.pos_taksit_planlari_id_seq'::regclass);


--
-- Name: proforma_detay id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_detay ALTER COLUMN id SET DEFAULT nextval('public.proforma_detay_id_seq'::regclass);


--
-- Name: proforma_faturalar id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_faturalar ALTER COLUMN id SET DEFAULT nextval('public.proforma_faturalar_id_seq'::regclass);


--
-- Name: roller id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roller ALTER COLUMN id SET DEFAULT nextval('public.roller_id_seq'::regclass);


--
-- Name: sabit_gider_kategorileri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sabit_gider_kategorileri ALTER COLUMN id SET DEFAULT nextval('public.sabit_gider_kategorileri_id_seq'::regclass);


--
-- Name: sabit_giderler id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sabit_giderler ALTER COLUMN id SET DEFAULT nextval('public.sabit_giderler_id_seq'::regclass);


--
-- Name: siparis_detay id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparis_detay ALTER COLUMN id SET DEFAULT nextval('public.siparis_detay_id_seq'::regclass);


--
-- Name: siparis_odemeleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparis_odemeleri ALTER COLUMN id SET DEFAULT nextval('public.siparis_odemeleri_id_seq'::regclass);


--
-- Name: siparisler id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparisler ALTER COLUMN id SET DEFAULT nextval('public.siparisler_id_seq'::regclass);


--
-- Name: sirketler id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sirketler ALTER COLUMN id SET DEFAULT nextval('public.sirketler_id_seq'::regclass);


--
-- Name: stok_kartlari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_kartlari ALTER COLUMN id SET DEFAULT nextval('public.stok_kartlari_id_seq'::regclass);


--
-- Name: stok_kategorileri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_kategorileri ALTER COLUMN id SET DEFAULT nextval('public.stok_kategorileri_id_seq'::regclass);


--
-- Name: stok_maliyet_kalemleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_maliyet_kalemleri ALTER COLUMN id SET DEFAULT nextval('public.stok_maliyet_kalemleri_id_seq'::regclass);


--
-- Name: stok_seri_no id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_seri_no ALTER COLUMN id SET DEFAULT nextval('public.stok_seri_no_id_seq'::regclass);


--
-- Name: taksit_detay id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksit_detay ALTER COLUMN id SET DEFAULT nextval('public.taksit_detay_id_seq'::regclass);


--
-- Name: taksitli_satis_kalem_urunleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_kalem_urunleri ALTER COLUMN id SET DEFAULT nextval('public.taksitli_satis_kalem_urunleri_id_seq'::regclass);


--
-- Name: taksitli_satis_kalemleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_kalemleri ALTER COLUMN id SET DEFAULT nextval('public.taksitli_satis_kalemleri_id_seq'::regclass);


--
-- Name: taksitli_satis_planlari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_planlari ALTER COLUMN id SET DEFAULT nextval('public.taksitli_satis_planlari_id_seq'::regclass);


--
-- Name: tedarikci_fatura_odemeleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tedarikci_fatura_odemeleri ALTER COLUMN id SET DEFAULT nextval('public.tedarikci_fatura_odemeleri_id_seq'::regclass);


--
-- Name: tedarikci_faturalari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tedarikci_faturalari ALTER COLUMN id SET DEFAULT nextval('public.tedarikci_faturalari_id_seq'::regclass);


--
-- Name: urun_sahiplik_gecmisi id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.urun_sahiplik_gecmisi ALTER COLUMN id SET DEFAULT nextval('public.urun_sahiplik_gecmisi_id_seq'::regclass);


--
-- Name: yedek_parca_hareketleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yedek_parca_hareketleri ALTER COLUMN id SET DEFAULT nextval('public.yedek_parca_hareketleri_id_seq'::regclass);


--
-- Name: yedek_parcalar id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yedek_parcalar ALTER COLUMN id SET DEFAULT nextval('public.yedek_parcalar_id_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.custom_oauth_providers (id, provider_type, identifier, name, client_id, client_secret, acceptable_client_ids, scopes, pkce_enabled, attribute_mapping, authorization_params, enabled, email_optional, issuer, discovery_url, skip_nonce_check, cached_discovery, discovery_cached_at, authorization_url, token_url, userinfo_url, jwks_uri, created_at, updated_at, custom_claims_allowlist) FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at, invite_token, referrer, oauth_client_state_id, linking_target_id, email_optional) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid, last_webauthn_challenge_data) FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at, nonce) FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_client_states (id, provider_type, code_verifier, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type, token_endpoint_auth_method) FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
20260625000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) FROM stdin;
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_challenges (id, user_id, challenge_type, session_data, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_credentials (id, user_id, credential_id, public_key, attestation_type, aaguid, sign_count, transports, backup_eligible, backed_up, friendly_name, created_at, updated_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: akreditif_kalem_taksitleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.akreditif_kalem_taksitleri (id, kalem_id, taksit_no, vade_tarihi, tutar, odendi_mi, odeme_tarihi) FROM stdin;
\.


--
-- Data for Name: akreditif_kalemleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.akreditif_kalemleri (id, akreditif_id, tip, aciklama, tutar, vade_tarihi, odendi_mi, odeme_tarihi, odenen_tutar) FROM stdin;
\.


--
-- Data for Name: akreditif_maliyet_dagitimlari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.akreditif_maliyet_dagitimlari (id, akreditif_id, stok_seri_no_id, yontem, kur, tutar_try, olusturma_tarihi) FROM stdin;
\.


--
-- Data for Name: akreditifler; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.akreditifler (id, sirket_id, siparis_id, banka_hesap_id, akreditif_no, tip, para_birimi, tutar, acilis_tarihi, vade_tarihi, durum, notlar, olusturma_tarihi) FROM stdin;
\.


--
-- Data for Name: bakim_kayitlari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bakim_kayitlari (id, sirket_id, stok_seri_no_id, tarih, tip, aciklama, ilgili_cari_id, tutar, para_birimi, odendi_tahsil_edildi_mi, silindi_mi, silinme_tarihi) FROM stdin;
\.


--
-- Data for Name: banka_hareketleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.banka_hareketleri (id, sirket_id, banka_hesap_id, tarih, tip, tutar, aciklama, karsi_hesap_id, kullanilan_kur, kaynak_tablo, kaynak_id, cari_id, olusturan_kullanici_id, olusturma_tarihi, tutar_try_karsiligi) FROM stdin;
\.


--
-- Data for Name: banka_hesaplari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.banka_hesaplari (id, sirket_id, banka_adi, sube, hesap_adi, iban, para_birimi, guncel_bakiye, aktif) FROM stdin;
1	1	KUVEYTTÜRK	\N	KUVEYT USD	TR00000000000000000	USD	0.00	t
2	1	ZİRAAT BANKASI	\N	ZİRAAT USD	TR00000000000001	USD	0.00	t
4	1	KUVEYTTTÜRK	\N	KUVEYTTÜRK TL	TR00000000000000	TRY	0.00	t
5	1	FINANS KATILIM USD	\N	FINANS KATILIM USD		USD	0.00	t
\.


--
-- Data for Name: belgeler; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.belgeler (id, sirket_id, kaynak_tablo, kaynak_id, dosya_adi, icerik, content_type, boyut_bayt, yukleyen_kullanici_id, yukleme_tarihi, klasor_adi) FROM stdin;
\.


--
-- Data for Name: borc_odemeleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.borc_odemeleri (id, borc_id, tarih, tutar, aciklama) FROM stdin;
\.


--
-- Data for Name: borclar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.borclar (id, sirket_id, tip, cari_id, tutar, para_birimi, faiz_orani, alinma_tarihi, vade_tarihi, notlar, silindi_mi, silinme_tarihi) FROM stdin;
\.


--
-- Data for Name: cari_acilis_bakiyeleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cari_acilis_bakiyeleri (id, sirket_id, cari_id, tutar, para_birimi, kur, tarih, aciklama, olusturma_tarihi) FROM stdin;
\.


--
-- Data for Name: cari_hareketler; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cari_hareketler (id, cari_id, sirket_id, tarih, aciklama, yon, para_birimi, tutar, tutar_try_karsiligi, kaynak_tablo, kaynak_id, olusturan_kullanici_id, olusturma_tarihi) FROM stdin;
\.


--
-- Data for Name: cari_hesaplar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cari_hesaplar (id, sirket_id, tip, unvan, vergi_no, vergi_dairesi, adres, telefon, email, otomatik_dolduruldu, bakiye_try, bakiye_usd, bakiye_eur, aktif, olusturma_tarihi, silindi_mi, silinme_tarihi) FROM stdin;
14	1	ORTAK	EMRULLAH KUT [CR00002]	\N	\N	Sakarya Akyazı	5056775464	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:25.566	f	\N
15	1	DIGER	SAHARA BİLİŞİM Artvin [CR00005]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:25.695473	f	\N
16	1	ORTAK	ENGİN KOCAKUZU [CR00003]	\N	\N	Sakarya Akyazı	5325802780	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:25.731782	f	\N
17	1	TEDARIKCI	EMREN BİLİŞİM PAZ. İNŞ. [CR00006]	\N	\N	Sakarya Akyazı	2644189000	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:25.804864	f	\N
18	1	ORTAK	UĞUR KILIÇOĞLU [CR00004]	\N	\N	Sakarya Akyazı	505666666	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:25.893769	f	\N
19	1	TEDARIKCI	ADNAN BAYRAKTAR [CR00007]	\N	\N	Sakarya Adapazarı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:25.93298	f	\N
20	1	TEDARIKCI	JAC HEAVY DUTY IMPORT & [CR00008]	\N	\N	HEFEI	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:26.011928	f	\N
21	1	TEDARIKCI	ADA LONCA AŞ [CR00009]	\N	\N	Sakarya Adapazarı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:26.094426	f	\N
22	1	TEDARIKCI	GL PLATFORM FUAR [CR00010]	\N	\N	Sakarya Hendek	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:26.131092	f	\N
23	1	TEDARIKCI	FARUK ŞEKER ŞEKER FORKLİFT [CR00011]	\N	\N	Sakarya Arifiye	05324879862	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:26.21024	f	\N
24	1	TEDARIKCI	GÜMRÜK [CR00012]	\N	\N	Kocaeli Derince	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:26.286506	f	\N
25	1	TEDARIKCI	AMAZON GÜMRÜK [CR00013]	\N	\N	Bursa	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:26.321628	f	\N
26	1	TEDARIKCI	Tüyap Tüm Fuarcılık Yapım A.Ş [CR00014]	\N	\N	İstanbul Beylikdüzü	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:26.396508	f	\N
27	1	TEDARIKCI	OSMAN AVCI [CR00015]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:26.436648	f	\N
28	1	TEDARIKCI	EMEK MOBİLYA [CR00016]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:26.515734	f	\N
29	1	TEDARIKCI	HİKMET İLİŞEN [CR00017]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:26.695788	f	\N
30	1	TEDARIKCI	KUVEYT TÜRK KATILIM [CR00018]	\N	\N	İstanbul Şişli	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:26.787063	f	\N
31	1	ORTAK	YAKUP ÇALIKOĞLU [CR00019]	\N	\N	Sakarya Akyazı	05427921276	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:26.888227	f	\N
32	1	TEDARIKCI	ARŞİMET İSTİF MAKİNALARI [CR00020]	\N	\N	İstanbul Tuzla	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:26.934349	f	\N
33	1	DIGER	AKKON DENİZCİLİK NAKLİYAT İstanbul Ümraniye [CR00022]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:27.010564	f	\N
34	1	DIGER	LİYAKAT GÜMRÜK İstanbul Fatih [CR00023]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:27.094663	f	\N
35	1	TEDARIKCI	Jining Hengwang [CR00021]	\N	\N	Shandong Jining City	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:27.135696	f	\N
36	1	MUSTERI	FARUK GÜNAY LONKİNG [CR00024]	\N	\N	Düzce Merkez	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:27.219789	f	\N
37	1	MUSTERI	ÜMİT YILMAZ YILMAZ OĞULLARI KERESTE [CR00025]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:27.300484	f	\N
38	1	MUSTERI	ÇOMAK ÇEKİCİ [CR00026]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:27.395688	f	\N
39	1	MUSTERI	RECEP YILMAZ [CR00028]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:27.486216	f	\N
40	1	MUSTERI	ÇAK TEKSTİL SAN. VE TİC. [CR00027]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:27.529288	f	\N
41	1	DIGER	YAZAKİ OTOMOTİV AŞ Sakarya Akyazı [CR00029]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:27.616429	f	\N
42	1	TEDARIKCI	TEKMAK İSTİF MAKİNALARI [CR00030]	\N	\N	İstanbul Maltepe	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:27.712017	f	\N
43	1	MUSTERI	MİLKON SÜT VE GIDA [CR00031]	\N	\N	Sakarya Akyazı	05372648460	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:27.798466	f	\N
44	1	MUSTERI	YUSUF ÇOKAL ÇOKAL MERMER [CR00032]	\N	\N	Sakarya Erenler	05335742411	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:27.90852	f	\N
45	1	MUSTERI	MARMARA METAL MAKİNE [CR00033]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:27.994472	f	\N
46	1	TEDARIKCI	KUVARS TAŞIMACILIK VE [CR00034]	\N	\N	İstanbul Ümraniye	05327179292	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:28.086627	f	\N
47	1	MUSTERI	EREL MAKİNA SAN. VE TİC. [CR00035]	\N	\N	Sakarya Arifiye	0(537) 671	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:28.125055	f	\N
48	1	TEDARIKCI	Shandong Huayee Import [CR00038]	\N	\N	Shandong Jining City	+86130129375	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:28.208405	f	\N
49	1	MUSTERI	GORİLLA İÇECEK DAĞITIM [CR00036]	\N	\N	İstanbul Başakşehir	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:28.293679	f	\N
50	1	MUSTERI	BEDİRHAN GEYVE KİRA [CR00039]	\N	\N	Sakarya Geyve	05415793553	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:28.38627	f	\N
51	1	MUSTERI	BARAN OLUKLU MUKAVVA [CR00037]	\N	\N	Kocaeli İzmit	05324766365	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:28.426835	f	\N
52	1	TEDARIKCI	CEYTECH MAKİNA SANAYİ VE [CR00040]	\N	\N	Gaziantep Şehitkamil	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:28.498579	f	\N
53	1	MUSTERI	KOÇKAR MAKİNA KİMYA [CR00041]	\N	\N	Sakarya Akyazı	0(543) 038	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:28.607374	f	\N
54	1	MUSTERI	AHMET TERZİ [CR00042]	\N	\N	Sakarya Adapazarı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:28.715789	f	\N
55	1	MUSTERI	MECİT KOMŞU [CR00043]	\N	\N	Sakarya Adapazarı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:28.801102	f	\N
56	1	MUSTERI	HARMAN ARGO GIDA SANAYİ [CR00044]	\N	\N	Sakarya Erenler	0(535) 243	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:28.896063	f	\N
57	1	MUSTERI	KORCAN TARIM VE ORMAN [CR00045]	\N	\N	Sakarya Erenler	0(539) 260	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:28.934977	f	\N
58	1	MUSTERI	TAMER CİRİT CİPA SÜPERMARKET [CR00046]	\N	\N	Sakarya Karapürçek	0(532) 559	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:29.010455	f	\N
59	1	MUSTERI	ÖMER AKSOY AKDOĞA TİCARET [CR00047]	\N	\N	Şanlıurfa Eyyübiye	0(532) 332	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:29.100506	f	\N
60	1	TEDARIKCI	HÜSEYİN BAŞKAYA [CR00218]	\N	\N	Sakarya Akyazı	05462718228	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:29.137595	f	\N
61	1	TEDARIKCI	CLP METAL İŞLEME SANAYİ [CR00048]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:29.209782	f	\N
62	1	MUSTERI	MEHMET BİLGİN BİLGİN GIDA [CR00049]	\N	\N	Sakarya Erenler	0(533) 557	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:29.295432	f	\N
63	1	TEDARIKCI	AYSEL ŞENKOL DOSTUM GIDA [CR00050]	\N	\N	Sakarya Erenler	0537 417	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:29.410274	f	\N
64	1	MUSTERI	ADAPAZARI HUZUR YAPI [CR00051]	\N	\N	Sakarya Adapazarı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:29.445781	f	\N
65	1	MUSTERI	MUHAMMED YALÇIN YALÇIN TÜP BAYİİ [CR00052]	\N	\N	Sakarya Kocaali	0(543) 903	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:29.499544	f	\N
66	1	MUSTERI	GÖKHAN GÜREŞÇİ ESLEM KURUYEMİŞ [CR00053]	\N	\N	Sakarya Erenler	0(534) 323	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:29.540048	f	\N
67	1	MUSTERI	CAN KARAAĞAÇ ASİL GIDA OKTAY [CR00054]	\N	\N	Sakarya Erenler	0(534) 563	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:29.614215	f	\N
68	1	MUSTERI	CONSTELLA OTOMOTİV [CR00055]	\N	\N	Sakarya Adapazarı	0(532) 502	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:29.700602	f	\N
69	1	DIGER	ADNAN ALBAYRAK 05387106481 Sakarya Arifiye [CR00163]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:29.793432	f	\N
70	1	MUSTERI	ASTERPHARMA İLAÇ SAN. VE [CR00056]	\N	\N	Sakarya Erenler	0(533) 710	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:29.832478	f	\N
71	1	MUSTERI	BİROL ÇETİNKALA SAKARYA İŞ MAKİNALARI [CR00057]	\N	\N	Sakarya Erenler	0(507) 239	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:29.908027	f	\N
72	1	MUSTERI	AKKOR ELEKTRİK SANAYİ VE [CR00058]	\N	\N	Sakarya Erenler	0(507) 054	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:29.993597	f	\N
73	1	TEDARIKCI	CLK FORKLİFT YEDEK PARÇA [CR00059]	\N	\N	İstanbul Tuzla	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:30.030436	f	\N
74	1	TEDARIKCI	EASTİF MAKİNE ANONİM [CR00060]	\N	\N	İstanbul Tuzla	05331044044	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:30.098141	f	\N
75	1	TEDARIKCI	AAT MAKİNA SAN TİC.A.Ş. [CR00062]	\N	\N	Kocaeli Kartepe	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:30.134323	f	\N
76	1	TEDARIKCI	VOLKAN GEMİKSİZ GMK VİNÇ VE SEPETLİ [CR00061]	\N	\N	Kocaeli Gebze	05432692995	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:30.215012	f	\N
77	1	MUSTERI	OKUYAN MASA SOFRA TİC. [CR00063]	\N	\N	Sakarya Erenler	05326753556	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:30.31188	f	\N
78	1	MUSTERI	EMİN KILIÇ MAB BALABAN YAPI [CR00069]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:30.396128	f	\N
79	1	MUSTERI	DAVUT KALKAN KOYUNCUOĞLU YAPI İNŞAAT [CR00064]	\N	\N	Sakarya Karasu	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:30.435291	f	\N
80	1	MUSTERI	MUSTAFA ÇİÇEK ENES KALIP ESP-EPP VE [CR00065]	\N	\N	Sakarya Akyazı	0(533) 921	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:30.513314	f	\N
81	1	MUSTERI	MAHMUT ÇELİK [CR00066]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:30.610357	f	\N
82	1	MUSTERI	Maya Tekstil San. Ve Tic. Ltd. [CR00067]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:30.648247	f	\N
83	1	MUSTERI	BNP PARIBAS FİNANSAL [CR00068]	\N	\N	İstanbul Beşiktaş	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:30.709212	f	\N
84	1	MUSTERI	FARUK ACAR [CR00070]	\N	\N	Sakarya Arifiye	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:30.786801	f	\N
85	1	MUSTERI	ADA CK MAKİNA MONTAJ [CR00071]	\N	\N	Sakarya Adapazarı	05444038695	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:30.825413	f	\N
86	1	MUSTERI	ÖZGÜR OĞUZ SAKARYA FORKLİFT İSTİF [CR00072]	\N	\N	Sakarya Arifiye	05326740270	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:30.894705	f	\N
87	1	MUSTERI	3K LABORATUVAR MEDİKAL [CR00073]	\N	\N	Sakarya Hendek	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:30.931334	f	\N
88	1	MUSTERI	ELİF KARANFİL KARANFİL METAL [CR00074]	\N	\N	Sakarya Erenler	0537 022 5071	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:30.999601	f	\N
89	1	MUSTERI	ENGİN TARIM MAKİNELERİ [CR00075]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:31.038377	f	\N
90	1	MUSTERI	TAŞINLAR OTOMOTİV YEDEK [CR00076]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:31.111548	f	\N
91	1	MUSTERI	YAKUP YELEKOĞLU [CR00077]	\N	\N	İstanbul Bayrampaşa	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:31.196337	f	\N
92	1	TEDARIKCI	NAZMİ ÇOBANOĞLU [CR00078]	\N	\N	Sakarya Akyazı	05337805635	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:31.236185	f	\N
93	1	MUSTERI	UMUT ÇAVDAR ÇAVDAR GRUP [CR00079]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:31.313327	f	\N
94	1	TEDARIKCI	OKTAY ERDEN [CR00080]	\N	\N	Ankara Keçiören	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:31.400715	f	\N
95	1	MUSTERI	ERDOĞAN [CR00081]	\N	\N	Sakarya Serdivan	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:31.495578	f	\N
96	1	TEDARIKCI	DEMO MAKİNA EL. EL. TAAH. [CR00082]	\N	\N	Kocaeli Kartepe	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:31.530273	f	\N
97	1	MUSTERI	GÖLMER YAPI İNŞAAT [CR00083]	\N	\N	Kocaeli Gölcük	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:31.598028	f	\N
98	1	MUSTERI	ÖZKAN ENDÜSTRİ MAKİNA [CR00084]	\N	\N	Sakarya Adapazarı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:31.633447	f	\N
99	1	MUSTERI	İNERT [CR00085]	\N	\N	SANAYİ VE Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:31.708257	f	\N
100	1	MUSTERI	SELÇUK ARGINCIKLIGİL BSA KASAP [CR00086]	\N	\N	Sakarya Adapazarı	0(546) 912	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:31.785634	f	\N
101	1	MUSTERI	MUSA BIÇAKÇI [CR00087]	\N	\N	İstanbul Esenyurt	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:31.820781	f	\N
102	1	MUSTERI	AY ERTUĞ İNŞ.YAPI [CR00091]	\N	\N	Sakarya Hendek	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:31.89341	f	\N
103	1	TEDARIKCI	YARIMCA GÜMRÜK [CR00139]	\N	\N	Kocaeli Derince	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:31.929117	f	\N
104	1	MUSTERI	FATİH AYKOL MOBİLYA EV [CR00088]	\N	\N	Sakarya Adapazarı	0(532) 331	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:31.994723	f	\N
105	1	MUSTERI	İŞ FİNANSAL KİRALAMA A.Ş [CR00089]	\N	\N	İstanbul	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:32.028206	f	\N
106	1	TEDARIKCI	SAYMAZ VİNÇ İŞ [CR00090]	\N	\N	İstanbul Pendik	05320596153	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:32.087028	f	\N
107	1	TEDARIKCI	TRANSLİFT MAKİNE SANAYİ V [CR00092]	\N	\N	İstanbul Kartal	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:32.124258	f	\N
108	1	MUSTERI	ONUR TURAN TRN ORMAN ÜRÜNLERİ [CR00093]	\N	\N	Sakarya Akyazı	0(506) 029	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:32.193427	f	\N
109	1	TEDARIKCI	CEM TOPRAK [CR00094]	\N	\N	İstanbul Maltepe	05428287919	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:32.231289	f	\N
110	1	TEDARIKCI	UĞUR AKÜ VE [CR00095]	\N	\N	Kocaeli İzmit	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:32.303621	f	\N
111	1	MUSTERI	MUHAMMET PALA PALA MOBİLYA [CR00097]	\N	\N	Sakarya Hendek	05455266572	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:32.339406	f	\N
112	1	MUSTERI	COSKAP METAL DIŞ TİCARET [CR00096]	\N	\N	Sakarya Söğütlü	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:32.405449	f	\N
113	1	TEDARIKCI	SHANDONG HERACLES [CR00098]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:32.442215	f	\N
114	1	TEDARIKCI	Weifang Jinxu Heavy [CR00099]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:32.512596	f	\N
115	1	TEDARIKCI	SITTNAK LOJİSTİK ANONİM [CR00100]	\N	\N	İstanbul Çatalca	05321511523	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:32.596817	f	\N
116	1	TEDARIKCI	ATS GÜMRÜK MÜŞAVİRLİĞİ [CR00101]	\N	\N	İstanbul Maltepe	05337406422	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:32.631409	f	\N
117	1	MUSTERI	AYYAT YATAK MOBİLYA [CR00102]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:32.700595	f	\N
118	1	MUSTERI	ERDAL GÜVEN ERDAL GÜLEN [CR00106]	\N	\N	Bolu 14780	05340775737	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:32.736641	f	\N
119	1	MUSTERI	ALBARAKA TÜRK KATILIM [CR00107]	\N	\N	İstanbul Üsküdar	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:32.809949	f	\N
120	1	MUSTERI	ERSİN YILMAZ FİX İSKELE SANAYİ VE [CR00108]	\N	\N	SAKARYA Söğütlü	0533 230 85 10	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:32.846589	f	\N
121	1	TEDARIKCI	ARAS KARGO YURT İÇİ YURT [CR00110]	\N	\N	İstanbul Beykoz	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:32.909908	f	\N
122	1	MUSTERI	ÖSA MAKİNA SANAYİ VE [CR00109]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:32.992927	f	\N
123	1	TEDARIKCI	AKIN YAZILIM BİLGİSAYAR [CR00103]	\N	\N	Konya Selçuklu	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:33.029668	f	\N
124	1	TEDARIKCI	PCA SERTİFİKASYON [CR00104]	\N	\N	İstanbul Kartal	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:33.097676	f	\N
125	1	MUSTERI	ÖZÇETİNLER KERESTE [CR00105]	\N	\N	Sakarya Akyazı	5445712946	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:33.133117	f	\N
126	1	TEDARIKCI	YURTİÇİ KARGO SERVİSİ [CR00111]	\N	\N	İstanbul Sarıyer	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:33.21687	f	\N
127	1	DIGER	TTNET A.Ş. İstanbul [CR00112]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:33.296838	f	\N
128	1	TEDARIKCI	MERİÇ İNTERNET [CR00113]	\N	\N	Gaziantep Şehitkamil	0850) 346 37	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:33.334526	f	\N
129	1	TEDARIKCI	SAHİBİNDEN BİLGİ [CR00114]	\N	\N	İstanbul Ataşehir	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:33.420132	f	\N
130	1	TEDARIKCI	MUSTAFA AKA [CR00115]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:33.495005	f	\N
131	1	TEDARIKCI	FATİH YILMAZ [CR00116]	\N	\N	Antalya Manavgat	05358610462	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:33.533268	f	\N
132	1	TEDARIKCI	GENPAŞ VİNÇ TAŞIMACILIK [CR00117]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:33.612784	f	\N
133	1	TEDARIKCI	D-MARKET ELEKTRONİK [CR00118]	\N	\N	İstanbul Şişli	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:33.693561	f	\N
134	1	TEDARIKCI	ZIRHLI GIDA MAGAZACILIK [CR00119]	\N	\N	İstanbul Bağcılar	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:33.730993	f	\N
135	1	TEDARIKCI	ÜNKAMAK OTOMOTİV [CR00121]	\N	\N	Konya Selçuklu	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:33.810798	f	\N
136	1	TEDARIKCI	MUHİDDİN SÜTİÇEN ÖZGENÇLER FORKLİFT [CR00120]	\N	\N	Konya Selçuklu	05304730430	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:33.886343	f	\N
137	1	MUSTERI	10K GRUP İNŞAAT SANAYİ VE [CR00123]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:33.920597	f	\N
138	1	MUSTERI	ADA LİVA İZOLASYON [CR00124]	\N	\N	Sakarya KÖPRÜBAŞI	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:33.994587	f	\N
139	1	MUSTERI	ERKAN DELİ ERKAN DELİ [CR00125]	\N	\N	SAKARYA Serdivan	05337136087	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:34.031459	f	\N
140	1	TEDARIKCI	COŞTER NAKLİYAT VE [CR00126]	\N	\N	Kocaeli Dilovası	05334904134	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:34.113444	f	\N
141	1	TEDARIKCI	DP WORLD YARIMCA LIMAN [CR00127]	\N	\N	Kocaeli Körfez	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:34.19386	f	\N
142	1	TEDARIKCI	TÜRK STANDARDLARI [CR00128]	\N	\N	Ankara Çankaya	444 0 873	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:34.239514	f	\N
143	1	TEDARIKCI	ACİL TERCÜME VE BİREKLAM [CR00129]	\N	\N	İstanbul Kadıköy	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:34.312897	f	\N
144	1	TEDARIKCI	SAKARYA ELEKTRİK [CR00130]	\N	\N	Kocaeli İzmit	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:34.348924	f	\N
145	1	MUSTERI	GENEL MÜŞTERİ [CR00131]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:34.414067	f	\N
146	1	MUSTERI	ADİNSA YAPI MALZEMELERİ [CR00132]	\N	\N	Sakarya Adapazarı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:34.494762	f	\N
147	1	DIGER	MEMOĞLU AMBALAJ GIDA Sakarya Erenler [CR00133]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:34.535577	f	\N
148	1	MUSTERI	FURKAN ILGIN KUTU AMBALAJ SANAYİ [CR00134]	\N	\N	Sakarya Hendek	0539 887 42	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:34.620733	f	\N
149	1	TEDARIKCI	BİLAL MİR MİR TREYLER OTOMOTİV [CR00135]	\N	\N	Sakarya Akyazı	05370635520	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:34.698048	f	\N
150	1	MUSTERI	HALİS FİLİZFİDAN YAPI [CR00136]	\N	\N	Sakarya Erenler	05331280782	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:34.735979	f	\N
151	1	MUSTERI	KHN MINERALS İÇ VE DIŞ [CR00138]	\N	\N	İstanbul Ataşehir	05322818294	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:34.812748	f	\N
152	1	MUSTERI	ALİ GÜRTAŞ HALS METAL MÜHENDİSLİK [CR00160]	\N	\N	Sakarya Arifiye	05537459298	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:34.894508	f	\N
153	1	TEDARIKCI	SERVET EXPORT PLASTIK [CR00140]	\N	\N	Kayseri Kocasinan	05324191266	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:34.931433	f	\N
154	1	MUSTERI	KANSAYİ TEKNOLOJİ [CR00141]	\N	\N	İstanbul Gaziosmanpaşa	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:35.005595	f	\N
155	1	MUSTERI	SARE ARSLANOĞLU [CR00142]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:35.041918	f	\N
156	1	DIGER	TAKSİT TAKİP KUVEYTÜRK TAKSİT Sakarya Akyazı [CR00143]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:35.119179	f	\N
157	1	MUSTERI	MİNE GÖNÜLLÜ FATİH MİNE GÖNÜLLÜ FOCUS GIDA [CR00145]	\N	\N	Sakarya Erenler	05322881754	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:35.187742	f	\N
158	1	TEDARIKCI	HENAN RENFA INDUSTRY CO [CR00144]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:35.225598	f	\N
159	1	MUSTERI	AHMET BAHÇELİ BAHÇELİ KURUYEMİŞ GIDA [CR00146]	\N	\N	Sakarya Erenler	05396405244	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:35.299211	f	\N
160	1	MUSTERI	YUMSAN MAKİNE [CR00147]	\N	\N	Sakarya Arifiye	05066281624	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:35.345683	f	\N
161	1	TEDARIKCI	ALİ KURŞUN [CR00335]	\N	\N	Sakarya Karapürçek	05363674274	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:35.437196	f	\N
162	1	MUSTERI	EMİN HAN SPS SAVUNMA OTOMOTİV [CR00148]	\N	\N	SAKARYA Arifiye	05332055454	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:35.529346	f	\N
163	1	MUSTERI	FATİH TUREV PEYZAJ YAPI SAN VE [CR00149]	\N	\N	İstanbul Esenyurt	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:35.605893	f	\N
164	1	MUSTERI	AYFARM TAVUKÇULUK [CR00150]	\N	\N	Sakarya Adapazarı	05445447435	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:35.693605	f	\N
165	1	MUSTERI	GÖKHAN TOK SAKMAR GIDA VE İHTİYAÇ [CR00151]	\N	\N	Sakarya Serdivan	05322080054	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:35.740465	f	\N
166	1	MUSTERI	İLKER AKYOL AYKOLLAR GIDA- İLKER [CR00152]	\N	\N	Sakarya Akyazı	05528125454	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:35.829292	f	\N
167	1	ORTAK	EMRULLAH DIŞ DIŞ BORÇ Sakarya Akyazı [CR00153]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:35.896783	f	\N
168	1	ORTAK	ENGİN DIŞ DIŞ BORÇ Sakarya Akyazı [CR00154]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:35.93794	f	\N
169	1	ORTAK	UĞUR DIŞ DIŞ BORÇ Sakarya Akyazı [CR00155]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:36.013104	f	\N
170	1	ORTAK	YAKUP DIŞ DIŞ BORÇ Sakarya Akyazı [CR00156]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:36.095068	f	\N
171	1	MUSTERI	HALİT AYDIN AYDIN AKARYAKIT [CR00157]	\N	\N	Bolu Göynük	05334183986	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:36.148476	f	\N
172	1	MUSTERI	ÇELİK HALAT ve TEL SANAYİİ [CR00158]	\N	\N	Kocaeli Kartepe	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:36.223724	f	\N
173	1	MUSTERI	MELİHA ÇELİK FC PAPER CUP [CR00159]	\N	\N	Sakarya Arifiye	05353716519	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:36.301779	f	\N
174	1	MUSTERI	SÜLEYMAN DİZDAR SÜLEYMAN DİZDAROĞLU [CR00161]	\N	\N	Sakarya Akyazı	05419449083	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:36.388433	f	\N
175	1	MUSTERI	SALİH BÖCEK SAKARYA ADA PANEL SAN. [CR00162]	\N	\N	Sakarya Erenler	0 549 291 00	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:36.438422	f	\N
176	1	TEDARIKCI	MURAT SERHAN İŞBİLEN [CR00164]	\N	\N	Yalova	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:36.517374	f	\N
177	1	TEDARIKCI	ENGİN RULMAN TİCARETVE [CR00165]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:36.600658	f	\N
178	1	TEDARIKCI	Bizim Toptan Satış Mağazaları [CR00166]	\N	\N	İstanbul Üsküdar	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:36.64633	f	\N
179	1	TEDARIKCI	SÜLEYMAN BULUT [CR00167]	\N	\N	Sakarya Hendek	05343406061	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:36.722272	f	\N
180	1	TEDARIKCI	ADAPAZARI TAŞ.KARGO VE [CR00168]	\N	\N	Sakarya Adapazarı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:36.799408	f	\N
181	1	TEDARIKCI	Gönül Halı Day.Tüketim [CR00169]	\N	\N	Manisa Turgutlu	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:36.84534	f	\N
182	1	MUSTERI	DENİZ FİNANSAL KİRALAMA [CR00170]	\N	\N	İstanbul Şişli	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:36.932733	f	\N
183	1	MUSTERI	MEHMET KÖK MK SOLAR ENERJİ SANAYİ [CR00171]	\N	\N	Sakarya Erenler	05320648854	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:37.01986	f	\N
184	1	MUSTERI	UFUK GÜVEN SİMETRİ TANK RAF SAT. VE [CR00172]	\N	\N	Düzce Çilimli	05063391354	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:37.10004	f	\N
185	1	MUSTERI	MEVLÜT GÜL MIPSA KALIP MAKINA SANAYI [CR00173]	\N	\N	Sakarya Arifiye	05443691873	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:37.186174	f	\N
186	1	MUSTERI	YÖRÜNGE UPS ELEKTRİK [CR00174]	\N	\N	Sakarya Arifiye	05423218694	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:37.230513	f	\N
187	1	MUSTERI	MAHMUT ÇELİK AKYAZI ÇELIK METAL [CR00175]	\N	\N	Sakarya Akyazı	05364514935	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:37.30512	f	\N
188	1	MUSTERI	TUNCAY VERDORA AROMA SANAYİ VE [CR00176]	\N	\N	Sakarya Adapazarı	05438552017	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:37.347108	f	\N
189	1	MUSTERI	UFUK ALSER TEKNOLOJİ SANAYİ VE [CR00177]	\N	\N	Sakarya Akyazı	05326212054	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:37.42844	f	\N
190	1	TEDARIKCI	LASTİK TOPTAN OTOMOTİV [CR00179]	\N	\N	İstanbul Büyükçekmece	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:37.509432	f	\N
191	1	MUSTERI	ŞEBNEM PIRILDAR ŞEBNEM PIRILDAR [CR00180]	\N	\N	Sakarya Adapazarı	05423312942	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:37.586598	f	\N
192	1	MUSTERI	LOKMAN KANTAR MOL POLİMER KİMYA SAN. VE [CR00178]	\N	\N	Sakarya Arifiye	05330806898	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:37.623498	f	\N
193	1	MUSTERI	BAYRAM KÜNELİ BAYRAM KÜNELİ [CR00181]	\N	\N	Kütahya Merkez	05344081440	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:37.694452	f	\N
194	1	MUSTERI	MUHYEDİN İDİ [CR00182]	\N	\N	Sakarya Adapazarı	05442949019	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:37.731053	f	\N
195	1	MUSTERI	KNS OTOMOTİV AŞ [CR00183]	\N	\N	Sakarya Erenler	05334823547	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:37.794255	f	\N
196	1	MUSTERI	SÜLEYMAN KIRLIOGLU TARIMSAL [CR00184]	\N	\N	Aydın Nazilli	05550153142	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:37.830224	f	\N
197	1	MUSTERI	ÜRETKEN ÇELİK SANAYİ [CR00185]	\N	\N	Sakarya Arifiye	5374077978	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:37.898822	f	\N
198	1	MUSTERI	ufuk çakır murat ay ÇAKIROĞLU DIŞ TİCARET [CR00186]	\N	\N	İstanbul Kağıthane	05322344870	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:37.936208	f	\N
199	1	MUSTERI	Atasan Metal San. ve Tic. A.Ş [CR00187]	\N	\N	Sakarya Arifiye	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:37.995031	f	\N
200	1	MUSTERI	YILMAZ ÇETİN KERESTECİLİK [CR00188]	\N	\N	Sakarya Akyazı	05322469694	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:38.030458	f	\N
201	1	TEDARIKCI	EVYAP DENİZ İŞLETMECİLİĞİ [CR00189]	\N	\N	İstanbul Tuzla	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:38.110046	f	\N
202	1	TEDARIKCI	ERSOY PERİYODİK KONTROL [CR00190]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:38.193247	f	\N
203	1	TEDARIKCI	MARK GLOBAL LOJİSTİK [CR00191]	\N	\N	İstanbul Şişli	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:38.228321	f	\N
204	1	TEDARIKCI	MARDAŞ MARMARA DENİZ [CR00192]	\N	\N	İstanbul Beylikdüzü	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:38.304745	f	\N
205	1	TEDARIKCI	CHARTER LINK TURKEY [CR00193]	\N	\N	İstanbul Beşiktaş	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:38.340974	f	\N
206	1	MUSTERI	TOZAN LİFT ASANSÖR [CR00194]	\N	\N	Sakarya Erenler	05541812408	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:38.40858	f	\N
207	1	TEDARIKCI	BELNAK ULUSLARARASI [CR00195]	\N	\N	İstanbul Beylikdüzü	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:38.444235	f	\N
208	1	MUSTERI	İSMAİL DEMİRCİ İSMAİL DEMİRCİ [CR00196]	\N	\N	Sakarya Hendek	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:38.511777	f	\N
209	1	MUSTERI	ERDEM YÖRDEM SEYİT USTA TREYLER SANAYİ [CR00197]	\N	\N	Sakarya Hendek	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:38.596107	f	\N
210	1	MUSTERI	HAKAN ADA NAZAR YAPI SAN. VE [CR00198]	\N	\N	Sakarya Serdivan	05366609562	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:38.632985	f	\N
211	1	MUSTERI	UĞUR GİDEN SAKARYA UZMAN ELLER ÖZEL [CR00199]	\N	\N	Sakarya Serdivan	05355000003	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:38.708447	f	\N
212	1	MUSTERI	SABRİ AKKAYA [CR00200]	\N	\N	Sakarya Serdivan	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:38.786257	f	\N
213	1	MUSTERI	KEVSER İRME ALBAYRAKLAR YAPI MARKET [CR00201]	\N	\N	Sakarya Hendek	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:38.821699	f	\N
214	1	MUSTERI	BELİN GRUP YAPI ANONİM [CR00202]	\N	\N	Sakarya Kaynarca	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:38.893673	f	\N
215	1	TEDARIKCI	BİROL ÇUMAK [CR00203]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:38.932129	f	\N
216	1	TEDARIKCI	UYAN RULMAN SANAYİ [CR00204]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:39.017962	f	\N
217	1	TEDARIKCI	Elpim Mak. İnş. Elk. Mlz. Pzl. [CR00205]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:39.09576	f	\N
218	1	TEDARIKCI	PALAZLAR MOTORLU [CR00206]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:39.138373	f	\N
219	1	TEDARIKCI	TUNÇ KESİCİ TAKIMLAR [CR00207]	\N	\N	Sakarya Akyazı	0 542 595 77	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:39.215119	f	\N
220	1	TEDARIKCI	KITA TEKNOLOJİ VE YAZILIM [CR00208]	\N	\N	İstanbul Çatalca	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:39.300369	f	\N
221	1	TEDARIKCI	MİTA BRANDA VE REKLAM [CR00209]	\N	\N	Kocaeli Kartepe	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:39.338741	f	\N
222	1	TEDARIKCI	COSCO SHIPPING LINES [CR00210]	\N	\N	İstanbul Şişli	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:39.410405	f	\N
223	1	TEDARIKCI	SAFİ DERİNCE [CR00211]	\N	\N	Kocaeli Derince	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:39.494177	f	\N
224	1	TEDARIKCI	TIRTUR TAŞIMACILIK YAPI [CR00212]	\N	\N	Kocaeli Derince	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:39.529481	f	\N
225	1	MUSTERI	İHSAN ALKAN ADA ALKAN YAPI [CR00213]	\N	\N	Sakarya Erenler	05327978766	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:39.599682	f	\N
226	1	DIGER	TOYOTA BOSHOKU TÜRKİYE Sakarya Arifiye [CR00214]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:39.685823	f	\N
227	1	TEDARIKCI	54 GENÇLER OTOMOTİV [CR00215]	\N	\N	Sakarya Erenler	0545 599 66 76	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:39.723525	f	\N
228	1	MUSTERI	BEŞİROĞLU ORMAN VE [CR00216]	\N	\N	Sakarya Akyazı	05352117847	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:39.786468	f	\N
229	1	MUSTERI	RRM İNŞAAT ENERJİ [CR00217]	\N	\N	Erzincan Merkez	05533942424	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:39.824337	f	\N
230	1	TEDARIKCI	DUYAROĞLUBOYA [CR00219]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:39.90359	f	\N
231	1	MUSTERI	İSA KURHAN KURHAN TARIM ÜRÜNLERİ [CR00220]	\N	\N	Sakarya Kaynarca	05323968115	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:39.99414	f	\N
232	1	MUSTERI	ADAPOWER ENDÜSTRİYEL [CR00221]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:40.032544	f	\N
233	1	MUSTERI	ÖMER KURTEŞ EKSADO YAPI TİCARET VE [CR00222]	\N	\N	Sakarya Serdivan	05424365259	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:40.109716	f	\N
234	1	MUSTERI	Ziraat Finansal Kiralama [CR00223]	\N	\N	İstanbul Ümraniye	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:40.186515	f	\N
235	1	MUSTERI	YENİLAB LABO.VE [CR00224]	\N	\N	Kocaeli Kartepe	05443029457	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:40.222769	f	\N
236	1	TEDARIKCI	CITS VİZE HİZMETLERİ [CR00225]	\N	\N	İstanbul Sarıyer	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:40.305118	f	\N
237	1	TEDARIKCI	SERKAN AKÜ SANAYİ VE [CR00226]	\N	\N	İstanbul	0 534 262 95	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:40.344058	f	\N
238	1	TEDARIKCI	ESBİR GIDA VE İHTİYAÇ [CR00227]	\N	\N	Sakarya Adapazarı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:40.422216	f	\N
239	1	TEDARIKCI	ZIM INTEGRATED SHIPPING [CR00228]	\N	\N	İzmir	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:40.501692	f	\N
240	1	TEDARIKCI	BELSTAR DENİZCİLİK VE [CR00229]	\N	\N	İzmir	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:40.585989	f	\N
241	1	TEDARIKCI	ASAS ELEKTRONİK ÜRÜNLERİ [CR00230]	\N	\N	İstanbul Kağıthane	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:40.624543	f	\N
242	1	MUSTERI	ESTAŞ KALSİT MİKRONİZE [CR00231]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:40.696122	f	\N
243	1	MUSTERI	YAPI KREDİ FİNANSAL [CR00232]	\N	\N	İstanbul Beşiktaş	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:40.733736	f	\N
244	1	MUSTERI	OBA MAKARNACILIK SAN. VE [CR00233]	\N	\N	Gaziantep Şahinbey	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:40.806981	f	\N
245	1	MUSTERI	YAZAKI OTOMOTIV YAN [CR00234]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:40.845617	f	\N
246	1	MUSTERI	Murat Terzi Aktif yapıştırıcılar a.ş [CR00235]	\N	\N	İstanbul Tuzla	05553103581	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:40.913321	f	\N
247	1	MUSTERI	AKIN TARIM ÜRÜNLERİ VE [CR00236]	\N	\N	Sakarya Adapazarı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:40.995136	f	\N
248	1	TEDARIKCI	BİRMONT TEKSTİL İŞ [CR00237]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:41.034257	f	\N
249	1	TEDARIKCI	SOLİDLAS OTO VE DIŞ TİC [CR00238]	\N	\N	Çankırı Korgun	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:41.110927	f	\N
250	1	TEDARIKCI	MERSEN PLATFORM OTO [CR00239]	\N	\N	Sakarya Erenler	0 530 229 20	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:41.186433	f	\N
251	1	TEDARIKCI	HAKAN FATİH EROĞLU [CR00240]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:41.222726	f	\N
252	1	TEDARIKCI	GL PLATFORM FUAR HİZM. [CR00241]	\N	\N	İzmir	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:41.292791	f	\N
253	1	TEDARIKCI	TT MOBİL İLETİŞİM [CR00242]	\N	\N	İstanbul Beşiktaş	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:41.330141	f	\N
254	1	TEDARIKCI	TUNAHAN TAŞKIN [CR00243]	\N	\N	Sakarya Serdivan	5418540154	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:41.393368	f	\N
255	1	MUSTERI	SEHAT BERBER SERHAT BERBER [CR00244]	\N	\N	Sakarya Akyazı	05333933935	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:41.429416	f	\N
256	1	MUSTERI	BATUHAN CANDAN ALLIANCE HEALTHCARE [CR00245]	\N	\N	Sakarya Adapazarı	05396300529	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:41.509749	f	\N
257	1	MUSTERI	EMİN AKSOY DENİZ ELEKTRİKLİ ev [CR00246]	\N	\N	Bolu Merkez	05322454525	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:41.59454	f	\N
258	1	MUSTERI	İBRAHİM ÖZDOĞAN İKONİA RESTORAN GIDA [CR00247]	\N	\N	Sakarya Adapazarı	05422530325	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:41.633032	f	\N
259	1	MUSTERI	ÇOKAY AMBALAJ VE PLASTİK [CR00248]	\N	\N	Sakarya Erenler	5332465251	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:41.708024	f	\N
260	1	MUSTERI	DURDU BİDERKESEN İNSETKOM LİMİTED ŞİRKETİ [CR00249]	\N	\N	Mersin Yenişehir	05337914751	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:41.786479	f	\N
261	1	MUSTERI	METİN KİLİTSAN KALIP İMALAT [CR00250]	\N	\N	Sakarya Hendek	05393982050	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:41.822903	f	\N
262	1	MUSTERI	İHSAN RİSK DIŞ TİC. VE DAN. MÜH. [CR00251]	\N	\N	İstanbul Esenler	05324720612	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:41.899183	f	\N
263	1	MUSTERI	MERT YILMAZ EMRAH AKYÜZ GRUP [CR00252]	\N	\N	Sakarya Kocaali	05369436703	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:41.993225	f	\N
264	1	TEDARIKCI	SAKARYA 1.ORGANİZE [CR00253]	\N	\N	Sakarya Arifiye	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:42.031751	f	\N
265	1	TEDARIKCI	ALİ YILDIRIM ALİ YILDIRIM [CR00254]	\N	\N	Sakarya Akyazı	+90533777656	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:42.098014	f	\N
266	1	MUSTERI	HALK FİNANSAL KİRALAMA [CR00255]	\N	\N	İstanbul Şişli	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:42.135792	f	\N
267	1	MUSTERI	REMET METAL SANAYİ VE [CR00256]	\N	\N	İstanbul Kağıthane	54345818078	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:42.217742	f	\N
268	1	TEDARIKCI	YASİN KAVUK YASİN KAVUK [CR00257]	\N	\N	KARABÜK	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:42.294191	f	\N
269	1	MUSTERI	ONUR ATİLER GIDA TRZ. [CR00258]	\N	\N	Düzce Merkez	05545770081	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:42.330524	f	\N
270	1	MUSTERI	AYHAN SAĞLIK ADASAĞLIK NAKLİYAT [CR00259]	\N	\N	Sakarya Adapazarı	05324845579	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:42.406413	f	\N
271	1	MUSTERI	YAKUP ÇALIKOĞLU ARKİM KİMYA SANAYİ [CR00260]	\N	\N	İstanbul Bağcılar	05427921276	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:42.492917	f	\N
272	1	MUSTERI	UFUK KÜÇÜK UFUK KÜÇÜK [CR00261]	\N	\N	Sakarya Erenler	05320565491	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:42.529795	f	\N
273	1	MUSTERI	MUSTAFA BURAK ÖZTÜRK MUSTAFA BURAK ÖZTÜRK [CR00263]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:42.609186	f	\N
274	1	MUSTERI	MUHAMMED ALİ URAL MUHAMMED ALI URAL [CR00264]	\N	\N	Bolu Merkez	0 554 555 07	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:42.643774	f	\N
275	1	MUSTERI	EMİN KARA HASAN KARA [CR00262]	\N	\N	Sakarya Erenler	05326655953	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:42.704953	f	\N
276	1	MUSTERI	SERKAN GEZİCİ ADA BMS GIDA PAZARLAMA [CR00265]	\N	\N	Sakarya Erenler	05301689486	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:42.741102	f	\N
277	1	TEDARIKCI	AHMET SAİD BULUT [CR00266]	\N	\N	Sakarya AKyazı	05336745864	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:42.808461	f	\N
278	1	MUSTERI	GÖKHAN FAZLIOĞLU MOBİLYA SANAYİ [CR00267]	\N	\N	Sakarya Akyazı	05334392899	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:42.894931	f	\N
279	1	MUSTERI	SÜLEYMAN EKŞİOĞLU EKŞİOĞLU MOBİLYA TASARIM [CR00269]	\N	\N	İstanbul Kartal	05352554430	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:42.932684	f	\N
280	1	MUSTERI	TUĞBA AKDAĞ GCI KOMPOZİT ENDÜSTRİ [CR00268]	\N	\N	Düzce Merkez	05335980681	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:43.020412	f	\N
281	1	MUSTERI	Garanti Finansal Kiralama A.Ş. [CR00270]	\N	\N	İstanbul Pendik	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:43.100653	f	\N
282	1	MUSTERI	HAKAN ÇOBAN MURAT GÜLPINAR [CR00272]	\N	\N	İstanbul Bahçelievler	05396487859	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:43.193985	f	\N
283	1	MUSTERI	Noksel Çelik Boru San. A.Ş. [CR00271]	\N	\N	Sakarya Hendek	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:43.238747	f	\N
284	1	MUSTERI	AKGÜN TOPRAK SANAYİ [CR00273]	\N	\N	Sakarya Arifiye	05445717837	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:43.319056	f	\N
285	1	DIGER	TARKAN BEY FEDERAL ELEKTRİK 05331287839 [CR00306]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:43.398648	f	\N
286	1	MUSTERI	ESAT SARICI ESAT SARICI [CR00274]	\N	\N	Malatya Battalgazi	05444847464	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:43.494059	f	\N
287	1	MUSTERI	SERHAN GİRGİN SERHAN GİRGİN [CR00275]	\N	\N	Sakarya Erenler	05542798424	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:43.533431	f	\N
288	1	TEDARIKCI	ABDUL SAMET GÜNHAN [CR00276]	\N	\N	Sakarya Erenler	05356013333	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:43.612459	f	\N
289	1	MUSTERI	HAYATİ GÖRME GÖRMELİ ORMAN ÜRÜNLERİ [CR00277]	\N	\N	Sakarya Akyazı	05364985800	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:43.712044	f	\N
290	1	MUSTERI	ENDER ÇAKAR EKEN FİDE YETİŞTİRİCİLİĞİ [CR00281]	\N	\N	Kocaeli Kandıra	05425058146	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:43.814446	f	\N
291	1	MUSTERI	ENES TUNÇ ET MAMÜLLERİ [CR00282]	\N	\N	Düzce Gölyaka	05397887973	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:43.898133	f	\N
292	1	MUSTERI	FARUK GÜNAY [CR00278]	\N	\N	SAkarya AKyazı	05325247178	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:43.940671	f	\N
293	1	MUSTERI	LITPACK ENERJI DEPOLAMA [CR00279]	\N	\N	İstanbul Pendik	5424128308	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:44.016407	f	\N
294	1	MUSTERI	BAYRAM ÖZKAN AYŞE ÖZKAN [CR00280]	\N	\N	Sakarya Karasu	05423156573	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:44.111863	f	\N
295	1	MUSTERI	SEDAT ÇAMOĞLU ADA BARIŞ KİTABEVİ EĞİTİM [CR00283]	\N	\N	Sakarya Adapazarı	05422732857	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:44.196091	f	\N
296	1	MUSTERI	HYZ OTOMOTİV İNŞAAT [CR00286]	\N	\N	Sakarya Hendek	05309618054	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:44.285991	f	\N
297	1	MUSTERI	BURAK AKIN TEDEX GIDA DAĞITIM [CR00284]	\N	\N	İstanbul Üsküdar	05332139456	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:44.321413	f	\N
298	1	MUSTERI	ZEYNEP ŞAHİN FORMTEKNİK PANO ELEKTRİK [CR00287]	\N	\N	İstanbul Büyükçekmece	0 549 805 17	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:44.396468	f	\N
299	1	MUSTERI	GİMTAŞ MOBİLYA İNŞ. SAN [CR00285]	\N	\N	Sakarya Adapazarı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:44.494141	f	\N
300	1	MUSTERI	SUBOR BORU SANAYİ VE [CR00288]	\N	\N	İstanbul Kadıköy	05327014945	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:44.533227	f	\N
301	1	MUSTERI	MEHMET GÖKALP KUMTEL DAYANIKLI TÜKETİM [CR00289]	\N	\N	Kayseri Melikgazi	0 544 175 38	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:44.607668	f	\N
302	1	MUSTERI	YİĞİTOĞLU KİMYA AŞ. [CR00290]	\N	\N	İstanbul Beşiktaş	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:44.68661	f	\N
303	1	MUSTERI	MBA YAZILIM TARIM SANAYİ [CR00291]	\N	\N	Kocaeli İzmit	05419584131	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:44.723721	f	\N
304	1	MUSTERI	CERAMİCUT GRANİT [CR00292]	\N	\N	Bilecik Bozüyük	0 532 237 0070	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:44.807965	f	\N
305	1	MUSTERI	SEMİH ÇELİK DKÇ BOYA İNŞAAT SANAYİ [CR00293]	\N	\N	Sakarya Serdivan	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:44.894365	f	\N
306	1	MUSTERI	SUDE BAKIR ADOBA GIDA TİCARET [CR00294]	\N	\N	Sakarya Ferizli	0 549 188 24	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:44.934417	f	\N
307	1	TEDARIKCI	ELVAN MAĞAZACILIK [CR00296]	\N	\N	İstanbul Küçükçekmece	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:45.008941	f	\N
308	1	MUSTERI	NUSRET BOĞAZ BOYE YAPI SANAYİ VE [CR00295]	\N	\N	Sakarya Arifiye	05397654570	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:45.086304	f	\N
309	1	TEDARIKCI	EKT TEKNOLOJİ SANAYİ VE [CR00297]	\N	\N	İstanbul Tuzla	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:45.126704	f	\N
310	1	TEDARIKCI	CEM KAİM [CR00298]	\N	\N	Sakarya Erenler	5523432254	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:45.213725	f	\N
311	1	TEDARIKCI	ALKAYA ELEKTRONİK SAN VE [CR00299]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:45.296136	f	\N
312	1	TEDARIKCI	AHMET SAFA KURT [CR00300]	\N	\N	Sakarya Arifiye	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:45.387528	f	\N
313	1	MUSTERI	KAR METAL MAKİNE SANAYİ [CR00301]	\N	\N	Sakarya Arifiye	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:45.423318	f	\N
314	1	TEDARIKCI	KONAKÇILAR ULUSLARARASI [CR00305]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:45.500318	f	\N
315	1	MUSTERI	YILPAR PARKE SAN. TİC. [CR00302]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:45.538818	f	\N
316	1	TEDARIKCI	HALİL DURU NAKLİYE [CR00303]	\N	\N	Konya Kadınhanı	05455120587	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:45.60742	f	\N
317	1	TEDARIKCI	MASTER TECH YAZILIM VE [CR00304]	\N	\N	İstanbul Avcılar	5344500722	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:45.686184	f	\N
318	1	TEDARIKCI	EROL AKSOY [CR00307]	\N	\N	Sakarya Akyazı	05304649648	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:45.723963	f	\N
319	1	MUSTERI	BORA KOMPRESÖR TİCARET [CR00308]	\N	\N	İstanbul Başakşehir	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:45.795893	f	\N
320	1	MUSTERI	AKKUR PLASTİK YAPI [CR00309]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:45.88616	f	\N
321	1	MUSTERI	ELİT ARITMA SİSTEMLERİ [CR00310]	\N	\N	İstanbul Ümraniye	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:45.921976	f	\N
322	1	MUSTERI	SELGE KİMYA A.Ş. [CR00311]	\N	\N	İstanbul Kartal	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:45.994888	f	\N
323	1	MUSTERI	Azelis TR Kimya End. Ur. İth. [CR00312]	\N	\N	İstanbul Ümraniye	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:46.032192	f	\N
324	1	MUSTERI	ORSAN HİDROLİK PNOMATİK [CR00313]	\N	\N	Sakarya Arifiye	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:46.105644	f	\N
325	1	TEDARIKCI	TİM FORKLİFT SANAYİ [CR00314]	\N	\N	İstanbul Tuzla	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:46.139251	f	\N
326	1	MUSTERI	Alis Kontrol Otomasyon [CR00315]	\N	\N	İstanbul Küçükçekmece	05435953778	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:46.20943	f	\N
327	1	TEDARIKCI	AND FİLTRE İMALAT İÇ VE [CR00316]	\N	\N	İstanbul Ümraniye	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:46.245317	f	\N
328	1	MUSTERI	Tio Otomasyon Sanayi Ve [CR00317]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:46.309018	f	\N
329	1	DIGER	MAHMUT BOSTAN AVENSA İNŞAAT 05325120506 Sakarya Adapazarı [CR00332]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:46.400111	f	\N
330	1	MUSTERI	ŞEFİK ÖZDOĞAN ŞEFİK ÖZDOĞAN [CR00319]	\N	\N	Sakarya Kaynarca	05376816543	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:46.493962	f	\N
331	1	MUSTERI	MUHAMMET TANRIKULU TANRIKULU KAUÇUK VE [CR00320]	\N	\N	Sakarya Akyazı	05413351130	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:46.530845	f	\N
332	1	MUSTERI	ÖMER AĞDAĞ ÖMER AĞDAĞ [CR00323]	\N	\N	Bilecik Osmaneli	05467210611	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:46.601088	f	\N
333	1	MUSTERI	ENES DOĞU DOĞU POLİMER GERİ [CR00321]	\N	\N	Sakarya Arifiye	0 539 217 44	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:46.636338	f	\N
334	1	MUSTERI	EMRE ENS ENDÜSTRİ MAKİNA [CR00322]	\N	\N	Sakarya Arifiye	05363441934	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:46.712008	f	\N
335	1	MUSTERI	MESUT DEMİRKAYA DEMİRKAYA KABİN MAKİNA [CR00324]	\N	\N	Eskişehir Odunpazarı	0 532 365 14	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:46.795508	f	\N
336	1	MUSTERI	SEYFULLAH KÖYLÜ FİMAKSAN AĞAÇ [CR00325]	\N	\N	Sakarya Erenler	05435716994	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:46.828932	f	\N
337	1	MUSTERI	TAHA MUSTAFA EMİR TAHA MUSTAFA EMİR [CR00326]	\N	\N	Antalya Serik	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:46.908574	f	\N
338	1	MUSTERI	KNZ EURO ÇELİK METAL [CR00327]	\N	\N	Sakarya Akyazı	05326451054	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:46.943877	f	\N
339	1	TEDARIKCI	OTTOLOJİ OTOMOTİV SAN [CR00328]	\N	\N	Düzce Merkez	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:47.006972	f	\N
340	1	MUSTERI	TÜRKİYE EMLAK KATILIM [CR00329]	\N	\N	İstanbul Ataşehir	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:47.043896	f	\N
341	1	MUSTERI	MERVE ÇAKMAK BERSSE ENDÜSTRİYEL BIÇAK [CR00330]	\N	\N	Sakarya Arifiye	05545271494	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:47.110374	f	\N
342	1	MUSTERI	PİM PASTANE İHTİYAÇ [CR00331]	\N	\N	Sakarya Adapazarı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:47.144523	f	\N
343	1	MUSTERI	ERHAN AVCI AES OTOMASYON [CR00333]	\N	\N	Sakarya Erenler	05073488037	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:47.220332	f	\N
344	1	TEDARIKCI	ERHAN İŞGÜZAR [CR00336]	\N	\N	Sakarya Serdivan	05382346034	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:47.304692	f	\N
345	1	MUSTERI	İSMAİL ÖZBAHÇELİ İSMAİL ÖZBAHÇELİ [CR00334]	\N	\N	Sakarya Erenler	05325475552	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:47.394536	f	\N
346	1	MUSTERI	ESMA TAYŞİ Songül Aydınlatma İnşaat [CR00337]	\N	\N	İstanbul Sultangazi	05523938244	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:47.431463	f	\N
347	1	MUSTERI	MUSTAFA FURUNCUOĞLU ASR METAL YUSUF [CR00339]	\N	\N	Sakarya Akyazı	05438524360	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:47.509697	f	\N
348	1	MUSTERI	ŞENOL DİRİN ŞENOL DİRİN [CR00340]	\N	\N	Sakarya Erenler	05353552027	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:47.546505	f	\N
349	1	MUSTERI	HÜSAMETTİN KARAMAN HÜSAMETTİN KARAMAN [CR00341]	\N	\N	Sakarya Taraklı	05419109190	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:47.604812	f	\N
350	1	MUSTERI	EMRE EMOKS KİMYA SANAYİ VE [CR00342]	\N	\N	Sakarya Arifiye	0 536 344 19	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:47.641985	f	\N
351	1	MUSTERI	ÖZCAN ARSLAN ÖZCAN ARSLAN [CR00343]	\N	\N	Kocaeli Derince	05363101205	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:47.706123	f	\N
352	1	MUSTERI	TARIK KAKICI MEHMET ALİ ÇELEBİ [CR00344]	\N	\N	İstanbul Pendik	05422662841	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:47.793208	f	\N
353	1	MUSTERI	SEL TIBBİ MALZEMELER [CR00345]	\N	\N	Konya Karatay	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:47.829626	f	\N
354	1	MUSTERI	FATMA DİRİCE PRUVA YAPI MALZEMELERİ [CR00346]	\N	\N	İstanbul Bakırköy	05363162409	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:47.897131	f	\N
355	1	MUSTERI	MERTCAN TANDOĞAN PINAR SANDIKÇI TANDOĞAN [CR00347]	\N	\N	Sakarya Erenler	05383148511	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:47.933927	f	\N
356	1	MUSTERI	UBEYDULLAH ATALAR ÖMER YÜCEL [CR00348]	\N	\N	Sakarya Arifiye	05389814961	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:48.011139	f	\N
357	1	MUSTERI	MARMARA LİDER KİMYA [CR00349]	\N	\N	Sakarya Arifiye	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:48.086576	f	\N
358	1	MUSTERI	MERT BOZTEPE ASKALE İÇECEK ÜRETİM [CR00350]	\N	\N	Sakarya Akyazı	05374335983	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:48.121721	f	\N
359	1	MUSTERI	MEHMET KURT ÖZMAK LAZER SAÇ KESİM [CR00351]	\N	\N	Sakarya Arifiye	05424487421	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:48.195209	f	\N
360	1	MUSTERI	ÇETİN YEĞENCİK EKOSAM LEVHA YAPI [CR00352]	\N	\N	Sakarya Adapazarı	05419705454	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:48.230034	f	\N
361	1	MUSTERI	ESPADA METAL SANAYİ VE [CR00353]	\N	\N	Sakarya Söğütlü	05358747229	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:48.295894	f	\N
362	1	DIGER	MURAT AKSOY EURONOVA YENİ NESİL 0 534 733 90 Kocaeli Gebze [CR00354]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:48.331082	f	\N
363	1	MUSTERI	ARDA PEKMEZ ESLA TAAHÜÜT YAPI İNŞAAT [CR00362]	\N	\N	Ankara Yenimahalle	05458928325	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:48.412058	f	\N
364	1	MUSTERI	HİDROAK MÜH. HİDR. MAK. [CR00355]	\N	\N	Ankara Yenimahalle	0 532 200 27	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:48.496872	f	\N
365	1	MUSTERI	YILDIRIM HIRCA HIRCA MOTORLU ARAÇLAR [CR00356]	\N	\N	Sakarya Erenler	0 542 580 71	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:48.53347	f	\N
366	1	MUSTERI	ARDA SUBAŞI ARDA SUBAŞI [CR00357]	\N	\N	Sakarya Adapazarı	05303156591	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:48.606919	f	\N
367	1	MUSTERI	HAKAN BORAORAL VİKİNG PLASTİK SAN. ve TİC. [CR00358]	\N	\N	Kocaeli Gebze	05342846221	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:48.641644	f	\N
368	1	MUSTERI	SAVAŞ SOYUBOL SAVAŞ SOYUBOL [CR00360]	\N	\N	Sakarya Erenler	05324326910	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:48.710542	f	\N
369	1	MUSTERI	TURGAY SAMAKLIOĞLU YKG METAL ENDÜSTRİ SAN. [CR00359]	\N	\N	Sakarya Arifiye	05392716396	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:48.744461	f	\N
370	1	MUSTERI	YILMAZ KURT YMZ GIDA SANAYİ VE [CR00361]	\N	\N	Sakarya Erenler	05326277007	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:48.814762	f	\N
371	1	MUSTERI	MEHMET BİÇEN BİÇENBEYFİDE TARIM HAY. [CR00366]	\N	\N	Ankara Beypazarı	05327474193	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:48.893657	f	\N
372	1	MUSTERI	ERKAN ALTUN ERKAN ALTUN [CR00363]	\N	\N	Sakarya Adapazarı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:48.929274	f	\N
373	1	MUSTERI	TURHAN KAAN ERKAN YEŞİM ERKAN - TURHAN [CR00364]	\N	\N	Sakarya Adapazarı	05339783518	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:48.994717	f	\N
374	1	MUSTERI	AYVAR SAKARYA DEKORATİF [CR00365]	\N	\N	Sakarya Akyazı	05334373529	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:49.030206	f	\N
375	1	MUSTERI	TURAN TAŞ ÖZTAŞ EKMEK FIRINI UNLU [CR00367]	\N	\N	Sakarya Adapazarı	05340665748	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:49.109014	f	\N
376	1	MUSTERI	TOPRAKLAR ET VE ET [CR00371]	\N	\N	İstanbul Kağıthane	05499054824	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:49.145216	f	\N
377	1	MUSTERI	İBRAHİM DEVRİN İBRAHİM DEVRİN [CR00372]	\N	\N	Sakarya Hendek	05549436000	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:49.211592	f	\N
378	1	MUSTERI	ÖMÜR OTOMASYON [CR00368]	\N	\N	Kocaeli İzmit	05416976212	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:49.292589	f	\N
379	1	MUSTERI	ADA LONCA MÜHENDİSLİK [CR00376]	\N	\N	Sakarya Adapazarı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:49.326574	f	\N
380	1	MUSTERI	HİDROAK İŞ MAKİNA YEDEK [CR00373]	\N	\N	Ankara Sincan	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:49.393709	f	\N
381	1	MUSTERI	ACARKİM KİMYA SANAYİ VE [CR00369]	\N	\N	Bursa Yıldırım	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:49.428488	f	\N
382	1	MUSTERI	HAKSU ARMATÜR SANAYİ [CR00374]	\N	\N	Sakarya Akyazı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:49.49493	f	\N
383	1	MUSTERI	CENGİZ ÇAKILTAŞ TOSUN GIDA [CR00370]	\N	\N	Sakarya Arifiye	05449187963	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:49.532233	f	\N
384	1	MUSTERI	FAZLI PERA LED AYDINLATMA [CR00375]	\N	\N	Sakarya Adapazarı	05324340076	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:49.610114	f	\N
385	1	TEDARIKCI	ANPA GROSS MAĞAZACILIK [CR00377]	\N	\N	İstanbul Başakşehir	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:49.649133	f	\N
386	1	TEDARIKCI	TK TARIM KREDİ PAZARLAMA [CR00378]	\N	\N	Ankara Kahramankaza	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:49.709587	f	\N
387	1	DIGER	CK TEKNOLOJİ SANAYİ VE Sakarya Erenler [CR00379]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:49.799549	f	\N
388	1	TEDARIKCI	ANFORA YAT MALZEMELERİ [CR00380]	\N	\N	İstanbul Kartal	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:49.840693	f	\N
389	1	MUSTERI	SERDAR YARLI SERDAR YARLI [CR00383]	\N	\N	Sakarya Erenler	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:49.915416	f	\N
390	1	TEDARIKCI	RECEP ÖZTÜRK [CR00381]	\N	\N	Kocaeli Kartepe	0 532 608 47	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:49.994447	f	\N
391	1	TEDARIKCI	KOS LOJİSTİK - YÜKSEL KOS [CR00382]	\N	\N	İStanbul Bahçelievler	05339577034	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:50.034489	f	\N
392	1	MUSTERI	MUSA HAMZALI BEST YATAK VE SÜNGER [CR00384]	\N	\N	İstanbul Sultangazi	05416261325	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:50.110431	f	\N
393	1	MUSTERI	VEYSEL BAKKAL [CR00386]	\N	\N	Bilecik Bozüyük	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:50.193092	f	\N
394	1	TEDARIKCI	SPARTEK İTHALAT İHRACAT [CR00385]	\N	\N	Konya Selçuklu	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:50.227413	f	\N
395	1	MUSTERI	GENÇDAL KUMAŞ TEKSTİL VE [CR00387]	\N	\N	İstanbul Zeytinburnu	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:50.296441	f	\N
396	1	MUSTERI	ÇAĞRI KEKEÇ HASRET GÜLTEKİN GÖKMEN [CR00388]	\N	\N	Sakarya Arifiye	05343114293	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:50.331052	f	\N
397	1	TEDARIKCI	ARSLAN İŞ VE İSTİF [CR00391]	\N	\N	İstanbul Başakşehir	05539030677	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:50.405928	f	\N
398	1	TEDARIKCI	BALCI FORKLİFTÇATALI [CR00389]	\N	\N	İstanbul Tuzla	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:50.495674	f	\N
399	1	MUSTERI	DERVİŞ DORUKİM İNŞAAT SAN.TİC. [CR00390]	\N	\N	Sakarya Arifiye	05304427255	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:50.533638	f	\N
400	1	MUSTERI	MARMARA NOVA OTOMOTİV [CR00392]	\N	\N	Sakarya Söğütlü	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:50.596836	f	\N
401	1	MUSTERI	ERHAN KOŞAR KOŞAROĞLU TİCARET [CR00393]	\N	\N	Sakarya Pamukova	05448640654	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:50.635425	f	\N
402	1	MUSTERI	ALPER TUNÇER DTA MÜHENDİSLİK SANAYİ [CR00394]	\N	\N	İstanbul Esenyurt	05349782715	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:50.712679	f	\N
403	1	MUSTERI	HIDIR BEKLİ HIDIR TİCARET [CR00395]	\N	\N	Sakarya Kocaali	5337670225	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:50.787376	f	\N
404	1	MUSTERI	KAHYA REJENERE KAUÇUK [CR00396]	\N	\N	Sakarya Hendek	0542 426 5980	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:50.822505	f	\N
405	1	MUSTERI	MÜHÜRSAN PLASTİK METAL [CR00397]	\N	\N	Sakarya Adapazarı	05331555442	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:50.904435	f	\N
406	1	MUSTERI	YÜCE FORKLİFT MAKİNA [CR00398]	\N	\N	İstanbul Başakşehir	0 541 238 36	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:50.94272	f	\N
407	1	DIGER	SEZGİNLER MAKİNA SAN.VE Bursa Nilüfer [CR00399]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:51.020267	f	\N
408	1	MUSTERI	SEÇKİN Nail Otomotiv Yedek Parça [CR00400]	\N	\N	Sakarya Erenler	05323501691	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:51.095608	f	\N
409	1	MUSTERI	AYŞE NİMEKS ORGANİK TARIM [CR00404]	\N	\N	İzmir Çiğli	05465017646	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:51.133583	f	\N
410	1	DIGER	KADİR ERDEM KADİR ERDEM 05369601417 Sakarya Serdivan [CR00401]	\N	\N	\N	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:51.197459	f	\N
411	1	MUSTERI	RECEP ALİ DİŞLİ DİŞLİOĞULLARI [CR00402]	\N	\N	Sakarya Geyve	05387648555	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:51.232606	f	\N
412	1	MUSTERI	YALÇINLAR AYAKKABI [CR00405]	\N	\N	Sakarya Adapazarı	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:51.309246	f	\N
413	1	MUSTERI	ÖZEN SA HARFİYAT İNŞAAT [CR00403]	\N	\N	Sakarya Sapanca	\N	\N	f	0.00	0.00	0.00	t	2026-08-21 13:00:51.344755	f	\N
\.


--
-- Data for Name: cek_hareket_gecmisi; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cek_hareket_gecmisi (id, cek_id, tarih, eski_durum, yeni_durum, aciklama, olusturan_kullanici_id) FROM stdin;
\.


--
-- Data for Name: cekler; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cekler (id, sirket_id, tip, cek_no, banka_adi, cari_id, tutar, para_birimi, vade_tarihi, alinma_verilme_tarihi, durum, ciro_edilen_cari_id, ciro_tarihi, notlar, olusturma_tarihi, silindi_mi, silinme_tarihi) FROM stdin;
\.


--
-- Data for Name: demirbaslar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.demirbaslar (id, sirket_id, kategori, ad, tanimlayici_no, konum, durum, kiraci_cari_id, maliyet_try, alim_tarihi, satis_fiyati_try, satis_tarihi, notlar, olusturma_tarihi, maliyet_orijinal, para_birimi, amortisman_orani, silindi_mi, silinme_tarihi) FROM stdin;
\.


--
-- Data for Name: doviz_kurlari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.doviz_kurlari (id, para_birimi, tarih, alis, satis) FROM stdin;
\.


--
-- Data for Name: duzenleme_kayitlari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.duzenleme_kayitlari (id, sirket_id, kullanici_id, tablo_adi, kayit_id, degisiklikler, tarih, islem_tipi) FROM stdin;
1	1	1	siparisler	13	{"Notlar": {"eski": "", "yeni": "yakupcalikoglu@hotmail.com"}, "Ürünler": {"eski": "1x #7@12000.00", "yeni": "1x #7@12000"}}	2026-07-16 12:08:30.228962	DUZENLEME
2	1	1	sabit_giderler	3	{"Tutar": {"eski": "32000.00", "yeni": "32000"}, "Kur": {"eski": "1.000000", "yeni": "1"}, "TL Karşılığı": {"eski": "32000.00", "yeni": "32000"}, "Açıklama": {"eski": "", "yeni": "yakupcalikoglu@hotmail.com"}}	2026-07-19 15:39:40.31941	DUZENLEME
3	1	1	sabit_giderler	3	{"Tutar": {"eski": "32000.00", "yeni": "32000"}, "Kur": {"eski": "1.000000", "yeni": "1"}, "TL Karşılığı": {"eski": "32000.00", "yeni": "32000"}}	2026-07-19 15:40:11.767278	DUZENLEME
4	1	1	banka_hareketleri	22	{"Tutar": {"eski": "15000.00", "yeni": "-15000"}, "Kur": {"eski": "47.0000", "yeni": "47"}}	2026-07-19 21:39:15.221803	DUZENLEME
5	1	1	stok_maliyet_kalemleri	42	{"Tedarikçi": {"eski": null, "yeni": 5}, "Para Birimi": {"eski": "TRY", "yeni": "USD"}, "Tutar": {"eski": "18600.00", "yeni": "18600"}, "Kur": {"eski": "1.0000", "yeni": "32"}}	2026-07-26 15:32:48.843018	DUZENLEME
6	1	1	stok_maliyet_kalemleri	42	{"Tutar": {"eski": "18600.00", "yeni": "18600"}, "Kur": {"eski": "32.0000", "yeni": "32"}}	2026-07-26 16:09:49.279428	DUZENLEME
7	1	1	kiralama_sozlesmeleri	12	{"Depozito": {"eski": "0.00", "yeni": "0"}, "Aylık Kira Tutarı": {"eski": "45000.00", "yeni": "45000"}, "Ürün Kalemleri": {"eski": "1x #10@45000.00", "yeni": "1x #10@45000"}}	2026-07-26 21:06:19.456809	DUZENLEME
8	1	1	kiralama_sozlesmeleri	11	{"Depozito": {"eski": "0.00", "yeni": "0"}, "Aylık Kira Tutarı": {"eski": "32000.00", "yeni": "32000"}, "Ürün Kalemleri": {"eski": "1x #6@32000.00", "yeni": "1x #6@32000"}}	2026-07-26 21:06:43.811531	DUZENLEME
9	1	1	yedek_parcalar	1	{"Birim Fiyat": {"eski": "1300.00", "yeni": "1300"}, "Min Stok Seviyesi": {"eski": "0.00", "yeni": "1"}, "Notlar": {"eski": null, "yeni": "yakupcalikoglu@hotmail.com"}}	2026-07-28 18:30:39.526269	DUZENLEME
10	1	1	yedek_parcalar	1	{"Birim Fiyat": {"eski": "615759.59", "yeni": "13000"}, "Min Stok Seviyesi": {"eski": "1.00", "yeni": "1"}}	2026-07-28 20:58:58.016402	DUZENLEME
11	1	1	yedek_parcalar	1	{"Birim Fiyat": {"eski": "13000.00", "yeni": "13000"}, "Min Stok Seviyesi": {"eski": "1.00", "yeni": "1"}}	2026-07-28 20:58:59.587639	DUZENLEME
12	1	1	yedek_parcalar	2	{"Birim Fiyat": {"eski": "80000.00", "yeni": "80000"}, "Min Stok Seviyesi": {"eski": "0.00", "yeni": "2"}, "Notlar": {"eski": null, "yeni": "yakupcalikoglu@hotmail.com"}}	2026-07-28 21:20:28.384188	DUZENLEME
13	1	1	yedek_parcalar	2	{"Birim Fiyat": {"eski": "80000.00", "yeni": "80000"}, "Min Stok Seviyesi": {"eski": "2.00", "yeni": "2"}}	2026-07-28 21:20:30.040586	DUZENLEME
14	1	1	yedek_parcalar	2	{"Birim Fiyat": {"eski": "80000.00", "yeni": "80000"}, "Min Stok Seviyesi": {"eski": "2.00", "yeni": "1"}}	2026-07-28 21:20:47.26298	DUZENLEME
15	1	1	yedek_parcalar	2	{"Birim Fiyat": {"eski": "80000.00", "yeni": "80000"}, "Min Stok Seviyesi": {"eski": "1.00", "yeni": "5"}}	2026-07-28 21:22:18.291229	DUZENLEME
16	1	1	stok_kartlari	8	\N	2026-08-21 12:42:24.642846	SILME
17	1	1	stok_kartlari	9	\N	2026-08-21 12:42:27.25514	SILME
\.


--
-- Data for Name: fatura_detay; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fatura_detay (id, fatura_id, stok_karti_id, stok_seri_no_id, aciklama, miktar, birim_fiyat, kdv_orani) FROM stdin;
\.


--
-- Data for Name: faturalar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.faturalar (id, sirket_id, fatura_no, proforma_id, cari_id, tarih, para_birimi, ara_toplam, kdv_tutari, genel_toplam, odeme_durumu, notlar, olusturan_kullanici_id, olusturma_tarihi) FROM stdin;
\.


--
-- Data for Name: gumruk_beyannameleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gumruk_beyannameleri (id, sirket_id, siparis_id, beyanname_no, beyanname_tarihi, gumruk_musaviri_cari_id, tutar, para_birimi, kur, tutar_try, notlar, olusturma_tarihi, kdv_tutari) FROM stdin;
\.


--
-- Data for Name: harcama_turleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.harcama_turleri (id, ad, aktif) FROM stdin;
1	Kira	t
2	Maaş	t
3	Depozito	t
4	Komisyon	t
5	Prim	t
6	SGK	t
7	Elektrik Faturası	t
8	Su Faturası	t
9	Doğalgaz Faturası	t
10	İnternet Faturası	t
11	Telefon Faturası	t
12	Reklam	t
13	Araç Kirası	t
14	Araç Bakımı	t
15	Yakıt	t
16	Otopark	t
17	HGS/Köprü-Otoyol	t
18	Yemek	t
19	Fuar	t
20	Gezi	t
21	Tatil	t
22	Konaklama	t
23	Uçak Bileti	t
24	Ofis Malzemesi	t
25	Temizlik	t
26	Sigorta	t
27	Vergi	t
28	Muhasebe/Mali Müşavirlik	t
29	Hukuk/Danışmanlık	t
30	Kargo/Nakliye	t
31	Gümrük Müşavirliği	t
32	Banka Masrafı	t
33	Kredi Kartı Komisyonu	t
34	Bakım/Onarım	t
35	Yazılım/Abonelik	t
36	Eğitim	t
37	Hediye/İkram	t
38	Diğer	t
\.


--
-- Data for Name: islem_loglari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.islem_loglari (id, sirket_id, kullanici_id, tablo_adi, kayit_id, islem_tipi, eski_deger, yeni_deger, tarih) FROM stdin;
\.


--
-- Data for Name: izinler; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.izinler (id, kod, modul, aciklama) FROM stdin;
1	SIRKET_YONET	SIRKET	Şirket bilgilerini yönetme
2	STOK_GORUNTULE	STOK	Stok ekranını görüntüleme
3	STOK_DUZENLE	STOK	Stok kaydı ekleme/düzenleme
4	SIPARIS_GORUNTULE	SIPARIS	Sipariş ekranını görüntüleme
5	SIPARIS_DUZENLE	SIPARIS	Sipariş ekleme/düzenleme
6	CARI_GORUNTULE	CARI	Cari ekranını görüntüleme
7	CARI_DUZENLE	CARI	Cari kaydı ekleme/düzenleme
8	BANKA_GORUNTULE	BANKA	Banka ekranını görüntüleme
9	BANKA_DUZENLE	BANKA	Banka hareketi ekleme
10	KASA_GORUNTULE	KASA	Kasa ekranını görüntüleme
11	KASA_DUZENLE	KASA	Kasa hareketi ekleme
12	CEK_GORUNTULE	CEK	Çek ekranını görüntüleme
13	CEK_DUZENLE	CEK	Çek ekleme/düzenleme
14	LEASING_GORUNTULE	LEASING	Leasing ekranını görüntüleme
15	LEASING_DUZENLE	LEASING	Leasing ekleme/düzenleme
16	KIRALAMA_GORUNTULE	KIRALAMA	Kiralama ekranını görüntüleme
17	KIRALAMA_DUZENLE	KIRALAMA	Kiralama ekleme/düzenleme
18	BAKIM_GORUNTULE	BAKIM	Bakım ekranını görüntüleme
19	BAKIM_DUZENLE	BAKIM	Bakım kaydı ekleme
20	PERSONEL_GORUNTULE	PERSONEL	Personel ekranını görüntüleme
21	PERSONEL_DUZENLE	PERSONEL	Personel/ödeme yönetimi
22	GIDER_GORUNTULE	GIDER	Sabit gider ekranını görüntüleme
23	GIDER_DUZENLE	GIDER	Sabit gider ekleme/ödeme
24	BORC_GORUNTULE	BORC	Ortak/dış borç ekranını görüntüleme
25	BORC_DUZENLE	BORC	Borç ekleme/ödeme
26	FATURA_GORUNTULE	FATURA	Proforma/fatura ekranını görüntüleme
27	FATURA_DUZENLE	FATURA	Proforma/fatura oluşturma
28	RAPOR_GORUNTULE	RAPOR	Raporlama ekranını görüntüleme
29	KULLANICI_YONET	KULLANICI	Kullanıcı/rol/izin yönetimi
32	AKREDITIF_GORUNTULE	FINANSAL	Akreditif kayıtlarını görüntüleme
33	AKREDITIF_DUZENLE	FINANSAL	Akreditif ekleme/düzenleme
34	TAKSIT_GORUNTULE	Finansal Takip	Taksitli satış görüntüleme
35	TAKSIT_DUZENLE	Finansal Takip	Taksitli satış ekleme/düzenleme
\.


--
-- Data for Name: kasa_hareketleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kasa_hareketleri (id, sirket_id, tarih, yon, tutar, aciklama, kaynak_tablo, kaynak_id, olusturan_kullanici_id, olusturma_tarihi, para_birimi, tutar_try_karsiligi, cari_id) FROM stdin;
\.


--
-- Data for Name: kdv_manuel_girisler; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kdv_manuel_girisler (id, sirket_id, ay, tutar_try, aciklama, olusturma_tarihi) FROM stdin;
\.


--
-- Data for Name: kiralama_kalem_urunleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kiralama_kalem_urunleri (id, kalem_id, stok_seri_no_id) FROM stdin;
\.


--
-- Data for Name: kiralama_odemeleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kiralama_odemeleri (id, sozlesme_id, donem_basi, donem_sonu, tutar, odendi_mi, odeme_tarihi, tahsilat_kaynak_tablo, tahsilat_kaynak_id, aciklama) FROM stdin;
\.


--
-- Data for Name: kiralama_sozlesme_kalemleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kiralama_sozlesme_kalemleri (id, sozlesme_id, stok_karti_id, miktar, birim_fiyat) FROM stdin;
\.


--
-- Data for Name: kiralama_sozlesmeleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kiralama_sozlesmeleri (id, sirket_id, stok_seri_no_id, kiraci_cari_id, baslangic_tarihi, bitis_tarihi, aylik_kira_tutari, para_birimi, depozito, durum, notlar, referans_kur, silindi_mi, silinme_tarihi) FROM stdin;
\.


--
-- Data for Name: kullanici_rolleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kullanici_rolleri (kullanici_id, rol_id, sirket_id) FROM stdin;
1	1	1
\.


--
-- Data for Name: kullanici_sirket_erisim; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kullanici_sirket_erisim (id, kullanici_id, sirket_id) FROM stdin;
1	1	1
2	1	3
3	1	4
\.


--
-- Data for Name: kullanicilar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kullanicilar (id, ad_soyad, email, sifre_hash, telefon, aktif, son_giris, olusturma_tarihi, sifre_sifirlama_token, sifre_sifirlama_son_gecerlilik) FROM stdin;
1	Admin	yakupcalikoglu@hotmail.com	$2b$12$npstmHDvGvoi4d7t9XIDDuQcMhkMQ2QM5pINQSwX1PKkcfDZp6jly	\N	t	\N	2026-07-01 08:37:13.190099	\N	\N
\.


--
-- Data for Name: leasing_kalem_urunleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leasing_kalem_urunleri (id, kalem_id, stok_seri_no_id) FROM stdin;
\.


--
-- Data for Name: leasing_odeme_plani; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leasing_odeme_plani (id, leasing_id, taksit_no, vade_tarihi, tutar, odendi_mi, odeme_tarihi, banka_hareket_id) FROM stdin;
\.


--
-- Data for Name: leasing_sozlesme_kalemleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leasing_sozlesme_kalemleri (id, leasing_id, stok_karti_id, miktar, birim_fiyat) FROM stdin;
\.


--
-- Data for Name: leasing_sozlesmeleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leasing_sozlesmeleri (id, sirket_id, leasing_firmasi_cari_id, stok_seri_no_id, sozlesme_no, baslangic_tarihi, toplam_tutar, para_birimi, taksit_sayisi, notlar, silindi_mi, silinme_tarihi) FROM stdin;
\.


--
-- Data for Name: personel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.personel (id, sirket_id, ad_soyad, pozisyon, aylik_maas, ise_baslama_tarihi, aktif) FROM stdin;
\.


--
-- Data for Name: personel_odemeleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.personel_odemeleri (id, personel_id, donem, tip, tutar, odendi_mi, odeme_tarihi, aciklama) FROM stdin;
\.


--
-- Data for Name: pos_taksit_detay; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pos_taksit_detay (id, plan_id, taksit_no, vade_tarihi, tutar, yatti_mi, yatma_tarihi) FROM stdin;
\.


--
-- Data for Name: pos_taksit_planlari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pos_taksit_planlari (id, sirket_id, stok_seri_no_id, musteri_cari_id, banka_hesap_id, toplam_tutar, taksit_sayisi, baslangic_tarihi, notlar, olusturma_tarihi, silindi_mi, silinme_tarihi) FROM stdin;
\.


--
-- Data for Name: proforma_detay; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proforma_detay (id, proforma_id, stok_karti_id, aciklama, miktar, birim_fiyat, kdv_orani, stok_seri_no_id) FROM stdin;
\.


--
-- Data for Name: proforma_faturalar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proforma_faturalar (id, sirket_id, proforma_no, cari_id, tarih, gecerlilik_tarihi, para_birimi, ara_toplam, kdv_tutari, genel_toplam, durum, notlar, olusturan_kullanici_id, olusturma_tarihi) FROM stdin;
\.


--
-- Data for Name: rol_izinleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rol_izinleri (rol_id, izin_id) FROM stdin;
1	1
1	2
1	3
1	4
1	5
1	6
1	7
1	8
1	9
1	10
1	11
1	12
1	13
1	14
1	15
1	16
1	17
1	18
1	19
1	20
1	21
1	22
1	23
1	24
1	25
1	26
1	27
1	28
1	29
1	32
1	33
1	34
1	35
\.


--
-- Data for Name: roller; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roller (id, sirket_id, ad, aciklama) FROM stdin;
1	1	Yönetici	Tam yetkili rol
\.


--
-- Data for Name: sabit_gider_kategorileri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sabit_gider_kategorileri (id, ad) FROM stdin;
1	Kira
2	Aidat
3	Elektrik
4	Su
5	Doğalgaz
6	Diğer
\.


--
-- Data for Name: sabit_giderler; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sabit_giderler (id, sirket_id, kategori_id, donem, tutar, odendi_mi, odeme_tarihi, aciklama, kategori, para_birimi, kur, tutar_try, silindi_mi, silinme_tarihi) FROM stdin;
\.


--
-- Data for Name: siparis_detay; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.siparis_detay (id, siparis_id, stok_karti_id, miktar, birim_fiyat, para_birimi, birim_agirlik_kg, aciklama, kdv_orani) FROM stdin;
\.


--
-- Data for Name: siparis_odemeleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.siparis_odemeleri (id, siparis_id, tarih, tutar, notlar, olusturma_tarihi, odeme_yontemi, cek_id) FROM stdin;
\.


--
-- Data for Name: siparisler; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.siparisler (id, sirket_id, siparis_no, tedarikci_cari_id, kaynak, kopya_kaynak_siparis_id, siparis_tarihi, tahmini_teslim_tarihi, durum, para_birimi, cikis_limani, varis_limani, konsimento_no, gumruk_beyanname_no, notlar, olusturan_kullanici_id, olusturma_tarihi, silindi_mi, silinme_tarihi) FROM stdin;
\.


--
-- Data for Name: sirketler; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sirketler (id, unvan, vergi_dairesi, vergi_no, adres, telefon, email, logo_dosya_yolu, aktif, olusturma_tarihi, logo_verisi, logo_content_type) FROM stdin;
3	Aa	\N	\N	\N	\N	\N	\N	t	2026-07-17 21:03:13.375796	\N	\N
4	aaaa	\N	\N	\N	\N	\N	\N	t	2026-08-02 19:59:47.110477	\N	\N
1	Marmara Metal Makina Lift Dış Ticaret Sanayi ve Ticaret Limited Şirketi	AKYAZI	6121723189	Ömercikler Mahallesi. 8005 Sokak. Copkayaoğlu apartmanı. No: 5/1	+90 542 303 67 36	info@marmaralift.com	\N	t	2026-07-01 08:37:13.190099	\\x89504e470d0a1a0a0000000d494844520000061b0000061b080600000006b10b2c000000097048597300002e2300002e230178a53f760000200049444154789cecdd7f94dd677d1ff8cfe7ceb56c5447abba8ee3b8aed13aaa91468e71304b31c5d28059d76e6ca311114b288126d992a4399c866d689b937238b4216c96645336ed699b3409e45743142463134c7db03d123f1cba90c352eb078e7145ea555de3758471e4f168e67efa8765e2b0b6b933739ff9de9979bdce99838f78f43c6fe96061dff77c9e27020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009623bb0e00c078da323575cec6f8f6fea938dddf100bfd7e9cd39f8b857e3f06fd8918f4e7337a1371563f63d05f88eaf7a2fa1913fd85a87e54f59e73e3cc4156ce650c66177270aa97fdd9b9d99acd85d9d9fb3f7bfb632bf84b040000006044940d004b74d9d44de76fe84d6c5a38dddbdccbda3cc8dc94199b2b069b7ad5db14517fa5223665e6e68ad894159b2b6273466d8acc0b469da7221e8a8a8722ebb1a8d89091fd8ae847543f23fa15d9cf88de37ffd8d37f1d991b479d69194e55d46c469eaa88d9a89acdc8d9ca3a15150f67c68988f87f078378287a7922334fe46cefa1c3f7ec7bb4ebe000000000eb91b201e0596cbb76fabc9ccb2d3131b824222ec9ca1766e69688b824aa2e6951163012a72ae278563c50510f54d6977b83def141af1e386bc39f3df0c53bee38d5754000000080b548d900ac7bdbafd9f392ccba32325e9c915754d44b327353d7b918bdaa3a92119f1964dc3938bd70e84b9fbef544d79900000000d6026503b0ae4c4eed3db76a6177465d1b195766e4955d67a23b55f127917528223e3ddf3b7deb7d777d54f900000000b004ca0660cdbbe2baeb362e3cb9f1e688dedf898c1bbbcec3f8aaa8bb22ead7fb1b4eed77e512000000c0f0940dc09a74d55557f5ffecdb2eb97e22e2ef44c5cd63f6f831e3ef5454ec1f647cf0e8ccfebb2262d075200000008071a66c00d694ef7ee5f76e9eef6ff8fb19f9b68cb8b0eb3cac7e5575a222dffff5b989ffebc17bf6cd769d07000000601c291b8035e1f26b6fbea0e6fbefaa8c1fca8873bacec3da53158f44c67b8fccecff3fbbce02000000306e940dc0aa76c575d76d5c983bf7a7a2ea7f7355122be1cca4c37bf2ab13ffeec8917d735de7010000001807ca0660d5dab173cf1b2be3fd99717ed75958971e1c0ceaa78f1e3af01b5d0701000000e89ab2015875b65eb3f7fc0dbd855fcd8c9bbbce0255f5f15e7fe12df7de79ebc35d6761f4b64eedb978430cce1f446c1ef5debdaaf9cadec958c8478e7e72ff43a3de1f0000005692b2015855764c4d5f5f95bf9d19e7759d05bea1ea6464fc83c333a61c56b3c96b76bf2c26723a22ae8cc82b32e2a2953cbfa2ee8bc8991cc4c127364c7cf4814fec7b6c25cf07000080e5503600abc6f6a93dff342bde9d19bdaeb3c0b3a9aa8fcf0dfa3f70ff27f73dd275168637b973fa87a2176fcfc8cbbbcef20d15b311f181c8f95f383c73ebfd5dc7010000806f45d900ac0a3b76ed391019bbbbce01df52d5c9a87ccbe143fb6fed3a0acfef453b6fda3291fddfcccc57769de5b954c520b3fef7c3f1a7ef8a9999f9aef3000000c07351360063ed8aebaedb38ffe45ffa0fe3fc61207cb3aa8a8c7ce7e183fb7fa6eb2c3cbb1dbb5e7b63e4c487226263d7598651155f58a8d3d35f3a74dbf1aeb3000000c0b3513600636bcbd4eecd1b23efccc897749d0596a2a26e3df9f5f9ef3ff1f9db4e759d853fb77d6acf4ff4227eb1eb1c8b55158f0c6ae155c70e7de4deaeb3000000c0375336006369c7d57bcfab0df30733c7e80e7558828abab73718dc70efa18f3cd875162276ec9afe5f23f357baceb174757221ebda6377dff2475d2701000080675236006347d1c05a53518f0e06839b8e1dfac867baceb29e4deeda7d7d66eff6ae738cc083f3a7e7b77fe9d3b73ede7510000000785aafeb0000cf74c575d76dacb3e7ef5434b09664e47913bd894fef78d59e57749d65bd9a9cda7b6e44fe7ad73946e4e2fe5913ffaaeb10000000f04cca06609cf4169efc4b1fc9c82bbb0e024d0cea0f764cddbcb5eb18ebd3fcbb32f3c2ae538c4ebe79fbce3d3bbb4e010000004f5336006363c7aee95f88ccd7749d039ac9dc5cd1bff3b2a99bceef3aca7a72f9b5375f90913fd9758e51eb65bca3eb0c000000f0346503301626a7a6df18993fd1750e682d232e392bcebafde2abf79ed37596f562b030f1e6ae33b4505137be68e74d5bbace0100000011ca06600c5cbef3b51767e4af749d0356d04b376d58f870f8ffe115923fd87582163233fabdfe8f759d03000000227cc8018c8141f6f645c4c6ae73c04aca8cbfbd636afa97baceb1d64dee7cdd951931d9758e86aeef3a0000000044281b808e4deedaf34f32f3e55de7806ee4df9f9cdafda6ae53ac69bd5ae3dff99f576cbd66af3740000000e89cb201e8ccd6a93d1747d6bbbbce015dcaca7fbb7de7ebb6769d632d9a7cd5eb2633e2ad5de7686dc3c4fc755d67000000807ed70180f5ebec885f8dc80d5de7804e656eccac8f6c999abaeaf8cccc6cd7715693cb5e7de345fdc159970ea2fa9583135fbafbd6fb9efeef5e3475f34b73501f8aec32e10aa9f89e88f89dae63000000b0be291b804e6c9b9abe31227c372e4444464c6e8cf3de1f113fd2759671b76d6afac65ec53f8ecc2b7310e746444c4446542f764ced89aa381e19bd8cb8645d140d11111997751d01000000940d40277a11bfd07506182719f1d6edbbf6dc7ef4e0fe5bbace328eb65fb3e7c2ecd5af67e4f5cf572264c696150b352632f2a2ae3300000080371b8015b763d7ee3764a4efc4856f9251bfb96d6af796ae738c9b17edbc694b6f22feefccbcbeeb2c63a9e2bcae2300000080b20158597bf7f62a7aefed3a068ca3cc3cb757f9efbbce316e26b2ffa188b8b8eb1ce3aab236779d01000000940dc08a9afceae937aec76b4e605899f9f2c95dbbdfda758e71313935fda399f9b2ae738cb7dcd075020000005036002babf29d5d47807197993f3739b5f7c2ae7374edd2d7ecdd1495efe93ac7b8cb78eaa16c000000e892b2015831dba6a66fccf456037c6bb93963e1fd5da7e8da0be6e77f34d37b04000000b01a281b80153311f10fbbce00abc8eb774c4daff30791f36d5d270000000086a36c0056c4e5d7de7c41554c759d035697fc958bafde7b4ed729ba30b96bcf3f098f420f6f6aaadf7504000000d6376503b0221616fa6fccccae63c06a73f1a6b3e7ff79d72156dae4d4de0b33cafb2e000000b08a281b8015d1abd8db7506588d32f22777bc6afa8aae73acacf9f745e6c6ae5300000000c3533600cd5df6ea1b2f8a8c57749d0356ad41feebae23ac94c96b76bf2c23dfd4750e0000006071940d40731383fef7759d0156b58c574ceedcfdfaae63ac8889fcb75d4700000000164fd900349791ae5082e5eaf5deb7f5861b36741da3a5c95dd37f3723afec3a07000000b078fdae03006bdb77bd62fa828c7c65d73968a06236b26623622e2ae62af3cc5f3ff56399311b157311395719b31135f7d4cf89b98c988bcad9ca98ada827a3cefcd8993db206b3d18bb985cab9ac988dcab99c58988d85fe5cd6fc5c9e95b3b383de5c2c4cccc6dce373f32f7862eef8ccccec7345dd76edf479bdb9da9ad9db3ae8c5a5bd8a1755c6d688ba2c23cf5ba9dfb2e5c8884bce7ae29c9f8c889fed3a4b0b93537bcf8d5a785fd73900000080a55136004d6d38abf64464d73156bdaa7a3c326623ce7cf89e31175173f5d45fcf46e4dc9f7f60ffd487fd557966dd530540463c19670a8041e45c64cc660ce6a272362be7a257730b51b331a8b99878eac76a3ee67243cee660626e62fed4ecfff7446feec4e76f3bd5f5efc7621dbbf3c0a311f11fcf7cfd0593537b2fcc3cfd8a18e43511f9eac818dbc7987b95ef9c9cdafb6b4766f63dd47596d19b7f57669edf750a0000006069940d4053ae507a7e557128a21ec8c82f570e8ed7a0f72783ca931383274fcecd2f9cbcffb3b73fd675c6b5eecc07f7fbcf7cc5b657ed7ec944f57e3c22de10111bbbccf6ff93714ed6fccf45c45bba8e324a97bf7af7a5b5903fa19704000080d5cbbfd603cd4c4eed3d3763e1eb5de7182ff5c58afcc46030f80fb3bd93879eefea1fba75c575d76d9c9f3bf74d51f5b6ccbcbceb3c7f41c5ff74f8e0fecf751d63542677edf983ccf8db5de758cd0ec7a367c5cccc7cd73900000058bf4c3600cd542eecccea3ac558d85f55b7d5203f7ef49307d6e0f5376bd317efb8e35444fc7244fcf2f69d7b7666afde332eef8f54c62f45c4d55de718851d53d3d747281a964dd100000040c7940d403339a86b23d7e70055453d1a15ffa6d75f78ffbd77defa70d779589ea387f61f8a886bb6eddc7d5d2ff3bd99f9922ef364c4cb77ecdc73f3e143fb6fed32c72854c47bd7e79f12000000b0b6281b806632f2355d675869671e727ef7634ff6ffe583f7ec7345d21a73ecd02d7744c41d3b76ed7e4365efe732e292aeb254d67b226255970d937ff3c64b32f2caae7300000000cbd7eb3a00b0366dbd66eff9917145d7395654d5bfc8b9fe0b8fcc1cf87945c3da76f8e02dbf7b6466ff0b23e267baca9099974feedcfdfaaece1f85ea6fe8744204000000181d6503d0c486defc54d719564a457d2107b5fdf0c1036f3f7ccfbe47bbcec3ca393cb3ff9d55831b22ea6417e767aff7ee2ece1d99aa4d5d47000000004643d900349119d7749d61250c22de7964e6c0f7dc7be8c0b1aeb3d08d23076ff9f8dc7c5e5511f77770fcb6ed3ba7dfdcc1b923d1ebe5a9ae33ac195353aec6040000a053ca06a089aa7879d7195aaaa8e30b39b8eae8ccfeceaed1617cfcf1a7f63ff0e45cfdcdaaba77a5cfcecc7fbe5a3f681e44743211020000008c9eb2016822335fd6758676ea7723fadf7decee5bfea8eb248c8f2f7fe6c0c30bf30b5757d5a756f2dcccb86432cefba1953c73542a07ae1d1b959999f9ae23000000b0be291b8091db3eb567cd4e3554d4cf1f9e39f0fd4766f63dde7516c6cf973e7debe38fcdf5ffe7889a59d183abde3d39b977c38a9e3902133578aceb0c6bc62a9d6e01000060ed5036000d0cd6e85443fdec919903efe83a05e3edc17bf6cd1e9e39f0aaaaf8d84a9d999917c6050b7f77a5ce1b95d31d3dacbd26996c000000a063ca0660e47a9557779d61d4ce4c34fc74d739583d1e9b9b785d547c6ee54eac9f5ab9b346e3be99db1ea9a8e35de768a9aaa2229a7f6db9726af38afda2000000e059281b8091ab882b16f913fe8f412f5ef86731f8cb0b83c1dfaaaadf6f146d492ae2f74d34b0580fdeb36ff6749ebe212a1e5889f33272cbf6a9e937acc459a35483de8f57c43fabaa9fad88df8f5a5bd30e991119edbffadff6edcdaf51aa88a98a285fabeaab490955119f1c835f9bafe1bfdedfe27f070000f0cddcef0b8c5c664e0ebdb8e2a3870feeffc7cff8913b22e28eedafde73496f106f8f88b746c4c611471c5a55fdd16373fd1fe8ea7c56b7fb666e7b64db2ba76f9898c8ff2732ce697d5e46fc7444fc6eeb7346e9e8a10f7f2ce2cfaf9cbae2baeb36cecf9dfbdb19b1bbc358a353f1541bd0d8e0ec986b7f0a0000003c37930dc0484d4eedbe72913fe5179eed078fdeb5ff4f0ecfec7ffb934f3cf19d83aa7754d5432388b72855f5f8fcc4e99b1ebc67dfec4a9fcdda71ec5307ee1b64bc6525cecac8cb2777edbe7e25ce6ae58b77dc716a3e4effbdaa18749d652456a0688888f8fa89afae8ddf2f000000562d6503305219b9982b944e1dce473ff57c0beeffeced8f1d3d78e0e78fe49ffeb58ac10f54d4179619716819f5f7eebbeba32756ea3cd6aea333fb7f2faafeddca9c96abfe6d91fb666e7b2423fea8eb1c23512b73cc57e361930d000000744ad9008c5445be78f8b5f5b99899991f6af1ccccfc91995b7eebc8cc81ef89415d1b511ffbd63f69e9aaeaf70e1fbc65555d47c378fbda5cff6d2bf1187266be72fbd49e97b73ea7b5ca78b0eb0c23912b34da70c105261b000000e894b20118a98cb87ce8b515c79772c6e14307ee3a3c73e07b7350dbabe29797b2c7f3a9a8472716e67e64d4fbb2be3d78cfbed91cc40fafc45959f1532b714e4b59b566ae2fabc6d30d15154317b7000000d088b20118a9aab86c11abff643967dd7be8c0b12307f7ffc8ec5c7d47d4e06722eae472f6fb8641bce33f7dea0f46b3173cc3e14307eeaa880fb43e27336ede71cd6b877fa87d1ce51a7af0b8f570c30a5dd504000000cf47d9008c54666c1976ed207b5f19c5995ffecc81870f1fbce59d5f7bb2ff9d83881fae8825971815f187470e1df8b551e48267331fa7df51558fb73ea72626fe41eb339aaae5959163a57519b0423735010000c0f351360023b3e8efa4aed1de5fffe03dfb668fceecffb5f9dedcd5554b2b1c06556f1f6526f866f7cddcf64844bea7f53959f1e6ef7ee5f76e6e7d4e2ba32a23c7c24a4c364c4df51b9f02000000cf4bd9008ccc42f6b62d727d930760efbbeba3272a9770377ec5e78e1d3cf0870d22c15f702a1ffd171571a2e92119e7cc4f9cfdd6a66734d4cb5c43930dee3902000060ed53360023d3eb2de6bd8688534ff68e378a124767f67fa22aee5fd44fea0ddedb280efc05c7676666a3eaa75b9f93113fdefa8c562aa24919d989d6930dae51020000600c281b80d1a9fc1f875e5af1c883f7ec9b6d1927b28e0cbbb4a28e1fbefb96fd2de3c0331d3978e0038b2ec41629332ed9b6737a4fcb335a993b756aed940dad071b0c4e0000003006940dc0c864d496e1178fd7e3af59f9ab5d6760fdc98a77b53e63a2176f6b7d460bf77ff6f6c7a2ea54d73946c26403000000eb80b20118998ad832ecdaac38de2ec999331691673011bfd1300a3cabc387f6ff4e450c3d81b33439b57d6afaf2b667b451d1fecf891561b2010000807540d9008c4c665c3afce215b88fbd7272a86515878edeb57fac262d5847aaded7fa885ec48fb53ea385cc5c1b5729996c000000601d50360023b1fd9a3d1746647fe89f50f19f1bc689ed3b5fb7353286cb93f5ef5b6681e773e6ed86475a9e51916f6ab97f436ba26cc86adc06986c000000600c281b8091a8de22de6b8888858aa6930415832b865d3b88fa78cb2cf02d65fc52dbed63d3e4cee91f6a79460b15f195ae338c84c906000000d6016503301299c3bf8f10113191d9b46ce865bc7898751571ffb1995b8eb7cc02df4a6f62fedf44d47ccb333273f55da534a83531d910d578f4a0f5e4040000000c41d9008c44465cbc98f5b3a7abed1b0999434d3664c51d4d73c010eebdf3d687a3e2779a1e92f1d26d3b5fbbaa1e8a1ec41a291b9a4f36b84709000080ee291b8091c888bf36fcea9afff2670e3cdc2e4d44460d55360c22ee699903865559bfd8fa8c5eaff7e3adcf18a57eb49d805a31adbb005d030000006340d9008c44455e34f4da8a075a66b9e8aa9b3646e4a5c3ac1de4fcb19659605847666ef942451d6a794646bef98aebaedbd8f28c513a79ba7fbceb0c23e1cd06000000d6016503302a970cbdb2f17b0d9b37f586be2a6622ce56363036aab2f574c3c6d373e7bea1f11923f3e03dfb662be2b1ae732c5bf3c9066d03000000dd533600239155434f366444d3b22107bda1ae50aa88134766f63dde320b2cc6d183fb6fa9d67f7f54fd48cbfd47aff1fb2e2bc16403000000eb80b201188dcce11f88aef8cf0d934445be78c895f7b7cc014b91d5f6ed86cc7cd92a7b287af53f12edcd06000000d6016503b06c97be66efa6c5acaf6cfce1610ef73874347e3b0296e2c9d9d95faba8b996674cf47a3fd672ff51ca5a036583c906000000d6016503b06c67cf0d2e58ccfa1cb4bd16252386bb4629e38f5be680a5b8ffb3b73f9615bfdbf28c8a7cd3d61b6ed8d0f28cd1c9af749d60d91a4f1e64196d000000a07bca0660d97a13b5b8b2a15fc71b4589cb5e7de34511b979c8e5261b184b83cc7fdd72ff8cd8b4e18917bcb1e519a35251ab7eb2a1b2f1e881c906000000c680b20158b6c120862e1baa2aee1d9c6c36d9d05fe80f77855244f42abdd9c0583a3ab3ff0f2be248d34356c943d195b9eacb066f36000000b01e281b8065cb1cbe6c888887626666be55968adef065c3c293ca06c6570ddedf72fbcc7cf9b6574e5fd6f28c515888355036349e3c28a30d0000008c016503b06c598b281b32dbbed790f5e261d655d563ffe9537f70b26516588e938f2ffc56549d6a79466f22dfd672ff5138f564ef78d71996adf5e4411a6d000000a07bca0660f9b2be73e8b5d5eebd8688888cb87ca87599f7b5cc01cb75e2f3b79d8a8c0fb43c23b3ded472ff5178f09e7db351b5aa8bc16cdd36e81a0000001803ca0660d92a7211930dd174b2a122b60db5aecae3d08cbdcadebf6a7b426e9edcb9fbf56dcf58be8a58dd5729b5bee5c82d4a0000008c0165033002b588371bea2bad525c3675d3f919b961c8e5de6b60ec1db9fbc347aaea534d0fc9de5b9aee3f126daf5f6bce03d1000000ac03ca0660142e1c7a65c3371bfa0b13970ebbb632bfdc2a078c5266fc4ae3fdafffae574c2fe691f79597261b3add1f00000086a06c00962d63110f4457352b1b6aa2b765e8b531708d12abc29fc59ffe5e44b47c28ba77f6861cebb71b2ae2bf749d61594c36000000b00e281b8065b9eaaaabfa11b979d8f5f9e459cdca86ac187ab2a13f28d728b12a1c9f99998daadf697a48d50f37dd7f997ad1aea45c11d978f4c064030000006340d9002ccbd7beed85c35fa154317bf89e7d8fb6ca9251df35e4d2c1bd873eb2baaf65615da9dea0f1554a3939b9f37557b63c63392a6b75fffd6a17bd59fe0000200049444154b2010000807540d9002ccb590bc35fa154194daf2eaacc2dc32dacfb5ae680513b72f747fe63541d6b7946f6063fd872ffe5189cced55d3678b3010000807540d9002c4bf6068b7858b6ed55288bb84669757f70c9ba54d1f6a1e8a87843ecdd3b96ff5cf0f8427f755fa364b20100008075602c3f54005691ec0d7f8d5264db0f0c33b60cb3ac2256f70797ac4b7383fe6f44c57cb303322fd8f1df166e6cb6ff323c78cfbed9aa6876055b73d9b80d30d9000000c018503600cb9251c34f36547ca5558e6d53bbb7c4b07fa6e52abf928575e9fe4fee7b24a26e6d7a48d65b9aeebf0cb99adf6d30d9000000c03aa06c0096a52abe63e8c5396836513051bd2dc3aead68577a404b83eafd6adb13f2e6ef7ee5f76e6e7bc692addeb2c19b0d000000ac03ca0660793286bf46a9ea78ab1815b56511395ca3c4aa74f4d0873f16510f373b20a33fe86f7863b3fd9761555f7fd67cb241db00000040f7940dc032e5d0d728d5c444b30f0b33e3af0fbb76a256f17748b3ee55e46fb53d207fb0e9fe4b55f1c75d475832930d000000ac03ca066079aa869e6cd8f8b5af9c6897232e1d76e9c9d3fde3cd72406399f5c1b607c44b775cf3dac9a6672c41567ca1eb0c4bb6126f36ccccb47b3c1c00000086a06c00962533869a6ca8aac73efff9cf37fb30ac32b70cb9f2e483f7ec9b6d95035a3b7cf7812f56d5919667546fe2075aeebf14870f1db82b223ed7758ea5a86c3c7a60b20100008031a06c0096a56ab8b22122dbdd331f115935d46443b9428935a0227ebdf11163f96ec3934f3c716d45fd7c547da2aa3e55118f779d69288d271b740d0000008c837ed70180d5ebbb5e317d410ef91dbb99d1ae6c989aea0fff7644aede4766e18cb9d3f11b679f55ef1bf6efbfc5ca8c4b76ecdaf3d2c307f78fd524c1fd9fbdfdb18878c7337f6cdbced75edecbde4b23f2ea887a63669edb51bce7d472b0a1aaedfe000000302c6503b0641b360c3bd51011550fb5ca71f9e07fb8b0869dd3ca1a79d9b0636afa1f45e5d5957132234e56c557b33738960b79e4de43078e8dfa3cf8f2670e3cbc63d7f42722e235adcea88cef8f55706dd1b1431fb93722ee8d880f4c4e4d4f45c465dd267a0ead5a81a7b79c9aea7bb7010000802e291b8025cbac0ba286fbf0ac1a4e360c26e2a21cf29a928af82fa33ebf2afe6a66ec7efa77223322aa17d58b98dc35fd7866ecafac0f1eb9fb969988188cfa7cd6a741c56ff6b25dd91015df1711ffb0d9fe0d64c5e6b1bd53a855ae6ab8370000002c82371b8025cb85de858b58ddac6ca8ca8b865e3c18fd9b0d19f9d5e7fcef32cf8dc83767f5ee9cdcb5e74bdb774ebf39f6eef5672fcbf644ef4f7faf229a3d769e19976cdb35fdf256fb3791c35ea7d68156ef363cddb49a6a000000a0633ef002966cd01bfe1aa5aac17f6d9523a3377c8edee8af51aaac47865997195b7bbdfce08e8717fe78c7ae3d53a3cec1fa727c666636a27ebfe519134f5da5b42a6cbde1860d5d67785e2d271b22cebc5d03000000dd5136004b9615df31ecda5eafe103d1117f75e895f37962d48767e45065c3337ec2a59171f78e5dd31f9c9cda3b768fd9b27a0c223ed472ff8a7c7dcbfd47e9055fef6dec3ac3f36a36d970e63f4d36000000d0316503b00c35f4354a35a8766543c5d039e64fcf8efea1ea8ac5950d4fcb7c73c4fcc1ad7fe3864d234ec43ad17bb87f47553dde6aff8cb870fbce3d3b5bed3f4a4ff4cf1eefe2ce64030000006b9cb20158b2ccc55ca3d41ffd87fc7f6eb8b2a162f6fecfdefed8a80f1f0c798dd2b3c9c8979c7dce0b3eb9e3eabde78d3213ebc39123fbe622b3e9554abd8cffa5e5fea3724e6f30ded728b59e6c000000808e291b806518fe31d6277a0b4bfe40fe5ba6c818ea81e88a6853782c2cf21aa56f9671456c58b8db954a2c450d725fd3fd23ded072ff51999fcbf1fecefed6930d000000d0316503b0641575feb06b8fcfdc72b25d90e1ae73ca8c91bfd7101171f493fb975f62645c11b170e7c557ef3d67049158478e1efaf0c7a2aad9df5f9971de8e9dd3af6eb5ffa864af37e83ac3f3aa466d83371b0000001813ca0660e92a862d1b1e6c9a2387bd46a99a5de55455cbbe9e29235eb6e9ec85df1c451ed6978ad8df74ffccb1bf4a69a2bf30de6583371b00000058e3940dc09265e650d7fe54b57b1cfab2a99bce8f18f6fa946c5636642cf32aa56fec13df373935fda3a3d88bf5237bbd0f353ee2fb62efdeb1fe678627e7c63a9e371b00000058f3c6fcdfcc817175f9b5370ffd5e43cb0ff927a23fdc5443440c32fe6bab1c9531c23729f217774cddbc7574fbb1d61dbefbc37754c5a3adf6cf8cf3763c32784dabfd4761a23f58df930dae51020000a063ca0660496a2e877eaf21b39a3d0e1d35e4154a4f6938d91023bb333f23cea9e8fff6a8f6637dc8acb657290d06637d95d2b8bfd950ad461b9e2e315ca304000040c7940dc092d444efbce117b79b6c888a8b865fdaeecd86a81ae9779567c4cb26a7f6bc75947bb2b60d2ada5ea5947173d3fd9769627eccdf6c68758dd2d3fb7efbb78ff7af1f000080354fd9002c4dc6d0654365fcb756317abde1271b2a16da950d91239b6cf8868af76efd1b376c1af9beac49472fe8df358a87ca9f4b469ebf7de79e9dadf65ff35a5da3f4f4befbf6291b000000e894b201589ac1f06543c4a0d903d151f19d43af3d1d279ae518e99b0d67b6cc386fc30bcef9a951efcb1af5d487cd4daf52caacd7b6dc7f59fab9a1eb08cfabd9648317a2010000180fca06606932867eb3613088666543450ef5507555c5973e7d6bb3b2a1a2bed666e7fc89cb5e7de3d05745b1be0d323edcf684dcd376ffa5abea2de6fd9695d776b2e154a3dd0100006068ca0660692affcad04b6ba2ddc3cc43971ed9ee91ea8888418cf4cd86a765c439672d6cf8b9167bb3f61c9b39f0d18a78bcd5fe99b165fbd4f4e5adf65f9ec178970dad26102a22a2e6da6c0e000000c35336004bb388371b26267a0d271b6ac8b2a1e1e3d01151994dca868888c878d36553afdbd66c7fd694acfa68e323c6f2a1e85ac463f19d68d435e4536d83b201000080ce291b8025c9186ea2a0aae2c8ccbe76930d15435da3948d271b7a11a37f20fa19ce8ac1bb5aeecf1ad2ab7d6db7cfe996fb2f55c67f67effee3e4accb7bffbfaf7b26cb12620c694ca987c3c9893124bb91e28f22226407442ab6427631d6d35a6d2db6d653ed696dbf1e6b3d3eea2fda5aeba955d4fab3d6b6d66d76434041be4066c34ffd0aa5909d040ed2946f0e27058c318d613399b9aff3c74cc22624bbf7eedc9fb9ef99793ddb717767eff97c2ec226e171bfe7fa5c967c7e4b1602cd6c7033b9db5498d50100000000488eb001c03c79b2ce060b73bcd0b40d121d9de2f2b0c728451ef49fd3ddde3058ba6255c83dd01d7e34b5e05b7285bbf96c7ad9d9afbc22775d0493e5f1f74d96c72caa1d3a5d663febeedfc8baa663849ad9d0384689b001000000009039c20600f3e3962c6c7005eb6a38e7b2cb16ca544c72adc9821de524495e3d1cb4b3c14c9154f850c83dd01d76df3d3a25e9a6907b44c52897472949d283777c73dfe4d64d375726c67fc1a54f655dcf11e6815a1b1a2106c72801000000003247d800607e92cf6c081636d47edc97705e83e4a6a09d0d7545813b3824c9deb8a6b46145f87dd0f15c618f52b2289747291dcf5db7665dc351013b1bcc38460900000000903dc20600f37566928bcc14aca320ee2b260e1b4cfe6fa1ea90a487eedc7220e4fa47143cfacd76ec83ce56abd7b6845cdf5da5e7bff4750b43ee9186c87274bc50a0c606994b4e670300000000207b840d00e6eccc576cec4f7aad7bb8b0a1e0966838b424c50a3d3b42726fc31ef2b7afbafcf2bed0fba0b335c3af9b43ad6fa6be25a7157e3ed4fa5d29e8cc06c2060000000040f6081b00cc59ff29f5c41d059205eb2870f95cea083b205a9299079ddbd0d8c3162f78fad43785de079dcfe5e34137b0e8caa0eb779b609d0d92e7a9830300000000d0b3081b00cc59a19e7038b424b770331b5c89e74628320f3a205a925c0a1e364892c9dfd98e7dd0d90e5535167403d3cf6be346fe3b22293a1b00000000005d8e9b0400e6ac1879f29bfc5e0f7693dfdc7e32e9b587ed70f0ce06b52d6cb073074a1bce6dc75ee85cdfbf6bfc0997ee09b5be498bd73e59bf24d4faddc63d50da60925c743600000000003247d80060ee4c898f2ff2d802761458e23a9ef3a3ff13bcb341b2e0331b8e72fbd5b6ed858e65818f5232f7d7855cbfab04ec6c30199d0d0000000080cc1136009833f7387167435c083720da12ce6c70f703f7de7b6f2d541dd3ea694b67832499e9cd2f7de94b8bedda0f9da92eff46c8f5cdc490e8a402ce6c10331b00000000003940d800601ea2c461c369fffeffef0e55854bcb935d197e38b424b9b7e718a5065b32b5f83f5ed1befdd089769637ef92fbce703bd8cac1d215abc2addf452c50dac0cc0600000000404e103600983bf39f487259e88e0253d2e39cc20f876eb01fb6679f06f7e897dbb91f3a932beca068f7e26b42aedf3502763638331b00000000003940d80060ee5cc93a1bccf6842d434b9295a1f67436b46940f411266d18286d5cd4ce3dd179e2c83705ddc0fce782aedf2d02ce6c10331b00000000003940d800601e920d66360f37af41924c96286c90b7677073a4b87d03a28faa71941266b473ebe6fbdc3d64f077c9aacb2fef0bb87e77083ab3414f075a1d0000000080c4081b00cc9d79a2ce06b7a0614324537fa23ae46d0901daddd9d0d8d47ea1ed7ba2e3982cd8514a26ebeb3b78ca25a1d6ef1a413b1b9cce060000000040e6081b00cc5dd2639414eeddd42fb86038e1bc06c9a41f84aae318517b428de9cc74c5d9afbc82a39430238fe2c04729451ca5349b809d0dc6cc0600000000400e103600983bb3646143c063941644c9e63534ca684fc741cd8bfbdbb1cff18a0b18d08b9955962d28bb7bb09f4f73bd36d4da5d2358678329666603000000002007081b00cc47d2c1ccff16aa80c83c71d8206b4fc7415151fb8f519224f9ebb2d9171d63743496ec8660eb9b56ae5d7fd5aa60eb7783509d0d72c9e86c0000000000648fb001c09c0c0c6cec33259b952059b0ce86d8e6d0d960515bc286837a3293b0c1c5bbca91848f875cdd2ce6e7702616a8b5c12493133600000000003247d800606e96279dd720b9d783cd6c881276574892d7eb6d09017695cb53aef6bfc3d864cbd60c0d9fdfee7dd159f6578b37b82bd8713b66c6dc869904ea6cb0c6ff718c12000000002073840d00e6a4a638f14dfeb81e05eb6cf0285a9cb88ea8d8bec1cdee99743714a4cbb2d8179d63f7dda353667e73a8f55d5e5a75f9e57da1d6ef78011a1b8ee6175ea7b301000000009039c20600731279f2b06181aac1c20679f2990d7d85c36d0b1bac4dc3a84fb0f1c599ec8b8e12cbae0bb5b6c9fa16fc78e1a5a1d6ef78213a1b9a6bd69dce060000000040f6081b00cc8d7be28e8207eff866b01bef91fcb949afdd7eeb9670a1c7713cabb0c18d639430abba0e6f760f36a95851147394d2490419d97064cd82d1d90000000000c81c6103803929285a96e43a770f36afa1214a3a3be260d0329ec5da7764d331dbaa7fcdc5c3eb33d91b1de3e1f2f54fc9ec9e805bbc26e0da1dcfd36e6f682e67743600000000007280b001c09cc4966c30b399827613b825ecb0706fefcd7f6bf37ed31462236cc0ec5cd7875bdc56bef0c29195e1d6ef706937955863418be96c0000000000648fb001c0dc58b259092e0b7b74915bc2ce8676771a5836c7284972d350567ba38344b639e4f20b0a31731b4e26eda3948e7636d4e86c0000000000648eb001c09c98747aa20b3d6c6783295987859bb7f5e6bf799c59d860ae0bc59feb984565eba68abb7685dbc15e1d6eed0e977a674323bdb00574360000000000b2c74d29007392f4267ff8639412d6e1eded6c882dfa413bf73b86a97ff0e2e17599ed8f8e61a680dd0d7689f8ef8b134b7b4a7433bc988a233a1b000000000099e3660080394a767c91bb9e0c5c48c2ce06b5b5d3205276331b24298efd822cf74767a82bbe2ed4da665abaf6a2917343addfd102cd6c50bd406703000000002073840d00e6c495706643e0ce86c41d16dede6394146737b3419222d92bb2dc1f9d61e7f3166c73697fb00d22bf24d8da9d2cd0cc06550fd0d90000000000c85c31eb02007416932d4e725d14870d1b242d4c78dd0f835671bc829e4afdddcb73e0268e51ea422b4aa5fefef8b9aba468b5995646a6b35db642f2a5265b286991e48b243b268473698fdc1f93e9cb95f2f8678f7e6374345669788b646f0a516f24bd5ad29f8558bba3b9d20d1c8eacb554743600000000003247d800604e5c5a92e45e59dd3c58d8b0e655c34b554f766ddce601d1aad5f7a95068eb96d3996b4d669b2355675f74d5398542fc5ab9ae34d9f9c7f722dab4ffd5b33e3ffacc19323b43d279034323ffa532313674f47be6e3f23061839bad0fb16ec7b394d386e6728fdc78239d0d0000000080cc718c1280b971259ad9502c840b1b8a9eec2827498ad4de638d6a719bc38de3992d5c7bd1c81999d680795bbb7e64fdc0d0c85f0e0c8dfc6bb1e0ff6cb26bccecfc34d636d3fa81d2f0db8f7cedbee0e634d63de15e52ffe0d04829d4fa1d2bf5990d92bb081a0000000000b940d800604ecc92850d71bc2058d8503f1c250e1bda3d43e1a13bb73cdecefd4ea45eb0e4bf3ec8dcd9175fb17ab034fc9181d2c8bf469126ccf45b663a2bc45e26fde691cf2be5d103ee7e53887d24c9e5af0eb576c70a32b3c1091b0000000000b9c0314a00125bf5f2cb13cd6b7069aa521e3d10aa0e2bc64be4c9b2d27a21834e03f783324b3a532275c57a3dd1bf27646b6068c36b24fb8079a37321edfbd027e2b295c73c61362ee935413633bb54d2fb82acdda9c2cc6c605e03000000002017e86c0090585fb190e81df3e6fe54c83ae27af277ee17a4b6870d2e0bfacf3f9bb890787836323050da70ee4069e4ff358b6e4ceb88a4e4fc9163beaa6b4ba89d4c3a6fe5a51b09bea60bd2d960743600000000007281b0014062f5e8944437f9dd14ec0825498aa4c461436ced3d46a9216cd8322bd3fe4cf7c709adbd64e4ac81a1e17f3045ff64d2a559d4606e9ba67fbde3f6b13d727d2fd47ea7d40e5f126aed8e94f2cc0693644e670300000000201f081b002466c538596743e877f65bf2b0e15054687bd860d2de76ef790ccf787f3ccb4069f8bf47b1fed5ccde30af05dc9f70f7efba7c9be48fceb38c83f5a25f7bfc93b1f9f83cd79b95297a55a8b53b92a5dcda6012331b000000000079c1cc06008925ee2870df13b20e939f9ef43c92476f19cde25dfe997636f8e138dbce0a1cb56668f8fcc8ec8b260d247d8dbbdf26d38d2ebbc30e571fafdc79c363d3bf3f3034fc2b66faf25c6b71e9cf76de3afeac202aae47374405ffc85cd74b22ab0e8edc4a7b66834b6e74360000000000f281b00140625ed7124bd00f15fa182557b424c9fd3a770f36a47ac67d654fb563d8ef8937f77d0fddb925937f6e1c6ba034f29726fd56a28b5d0fc4d2e70e2d287c6da6806cb034f27a691e4183fb6d9589f10f9ce87b0fddbee98181a191c7cc74d65cd74d60cdda8b46ced871fb58d000b263a4fd078349cc6c0000000000e405610380c422d3d224d799f464d042cc9724b96b67190c876e6e9cdd3146a6bb32db1b92a435af1a5e5aa8d9f5922e98e93a97a6ccfd1b1ec59fae94affbee6ceb0e96863fe2ee7f60733c8ac7dd1fb76a71e38c17993f225988b0412a7849d2d783acdd69dcd33d4aa93103a29d9d0dbb247db08dfba175a17e3ebe2ce9b6406b237d77675d000000007a03610380c45c3a3d594741d8ce06735b92e41dc29e55d8e07a32f57730273791d9ced0e045570ea86edf96e9cc192f74ffaac7f69ecaede3b3bee37f4d69c38ac8a3bf96b47eaef7a9dd7dbfc7f6bacadda3330660e67a22d4cf6ce47691081b1a52fe35763399b76f668335c2861376c8a0b798f4a5ac6b00000000903f840d00e6c01275367864818f51f22596ecae5d2661839b3f95b0be007bc7e54c3686062fbeea328fe34d262d3ad935eeda65917e69b23c9ea803656d69e4bf99748d99fae75c90fbee9a45af7ef8f64d3b67bd547a22d44fac9baf0fb474e70930b341cc6c0000000000e44482d3d701a0c1120f880e7e8c50a23acc94c57068c9b31910edae5d95adb31fc783f4ad2d8dbc41eedf36b393060d721f93155e34b9756cd6a061cdfa2b2f18181a7e30923e619a7bd0e0aefb0f5bedc50f97670f1a062eda709e4cabe7ba4752265b37f88a8d8982caaec7cc06000000004017a3b301c05c240b1b620b7ab33d69e891d5314aeef11e59a1fdfb4a9f69fba6d04069e4576c96a1cdeefa566562fcaa99ae39f3151bfb9fb3a0f60633bdcdcc2e9c6f3d2effb383f6c3f7ef2a974ffa8ef7c1576c5cea7db5f7c9f42b96b063a915f5536a1748ba21f43eb917a0b3c1db3bb301000000008093226c009058d2e38ba2c351d0ce06979624b95f676e997436d4bc6f4f41f5b6ef5b3dec5f69fba63d6ea034f2eb267d6ed60b4d8f9e748d8b369c6751f416b7fa9b4d337446cc6e672cfdea8ef2f83d27bb60ed45232fb182bf4daabfd9640b5bd86b4e22d790081bc27436b4716603000000000033216c003017893a0a26671946dbaa198faa9926abce86476e1f7d6ab034d2de4dddbff0fdbbc683cecac0b1064bc3ef90f4e94417bb5eb376fdf09b23b3c7dce2335dd18ac8f57297ce37d332a9b5fbd0eefae3cac4d87b4ff6fd55176d5c764a54bb46a6abd3bfe39d8019731b246636000080540c0c8dfcad997e31eb3a908ccbb754cae357a6bdeed9eb5fb7a2182df897b4d74538758b5fba73ebe6fbb2ae030889b0014062498e2f7279d0a0a171f67bb2ae0133ff61c85a66e2ee8f9bd9f3dbb4d9bec3563be98d66a46f4d694349b26441832433ad32b3bf962453d43c6abff5fbce2ebf2f8ee3b7ecdc76ddf6935db3b634fc07a6fa7bd55ad7444b4cfe9215a552ff4c473bf584009d0d26d1d90000000000c805c2060089253abe28f070e46aa1bea42fe1b5b17b3603a21bf6486a4bd8e0f2f73c5cbe3e93a1d4bde8ec575eb1a8a0e86fb2aec3a57757cae37f3ed33583a5e1cf4b7675bb6a3a392b9eaaa5174aba25eb4a3215a2b341d6db010e000000002037a2ac0b00d039121d5f6416b4b3a1680987544b8a3cca326c68cf9146aeef552636ff555bf68224a9b8a0f00e4967665983bbefa994c7660c1ad69686ff201f414383b95f94750d99b3945b1bcc25c5743600000000007281b00140228de38b6667818f518a222d4e7a6d3dcabcb321287755cdfd9743ef8363b9ebe2ac6b905499e99b2b4a1b96982c57476b9989b90d9efe7ab1d9d329af0a00000000c0bc10360048a45aa827eb28087c8c92479e386c2804eeb298c5e3a13770f9fbb66f1bdf197a1f1ccb4c710e6a98b173e654b7ab4dca6c46c389b8ec7c954abd7d7c23331b00000000005d8cb00140227338be28e80d7ef3e4c728d56a7620642d33b3ff13727577ffee8e89f13f0bb9074ec2f59dac4b90ec8d2fb86078f949bf2b7b713bab49c2a4fe357efacbb2ae235b29b736b82467660300000000201f081b0024129927bac91f9b9e0c5947ac64754852213eb42f642d33310b7b8c92c5f1af865c1f27572fea539252ed2871694ad2f7247d43ae1b92bca67f81bd7b861557a65359ba0abd7e9452dac72899c4cc0600000000405e10360048a4ae641d0516bab34151e2b061ead453330b1bbc1e3f166aed587affe4edd7cd78663fc2d979ebf8deb8ae8bddfdb616963928f9b7dcfddd32ffe94a79ecd4c9f2d8cf4c96c77ee1c716ffb24bb376e5b8e91d2b4a1b4ef8fbc164991ff5741243591790a9b48f5172c98cce0600000000403ef4f6d9c900128b12860da1673698fc2792deb17bf496d1ec064417163c26d5d35fd77de78e89f10fa7bf30e662c7ed637b24bd6a60fdf05b15d9e572bdcc4c2b4e76bdbb57246d97ec9f627979e7c4f83d27bb765779f3be81a1e1cfcaecf766aac1a4450b15bd4bd2079fb59ffc714bfdce76ebdc7561d63564ca957ae01033b301000000009013840d00924938b3c13c6c6783cb1627b957e7ee19ce6b902ae5d13d83a591f4178eecd7d25f14f355d936fe25495f92a4335fb1b1ffb4530ead33458b2c8e6245beb75ad513dfbf6b7cc661ce27e2b17ddc0a9a316c685ca8df3efb9557fcf943776e39e6e7dd4c0fcf75cf7630b3c5ab4b57ad79b8bca937079b071810cdcc0600000000405e10360048c4e4a727b953e691070d1be45a9ae8869d59765d0d47f9a392a57876be7f7572ebf85de9ad8734edbe7bf4c8dc8596edb87d6ccf6069f80b925d3dd375665a1a158bef90f4a7d39f8f65ff92d773128bf2f395f2cc8b8ee1966ee0d018104d6703000000002017f27a2f0240ce78c2590951ec418f5152c241d5e69e7dd8e096dadc0677edd5a1e2efa4b51ef2af66f58fb9cf3e51d8a4df1f18d8d877cc93eebb0295d53ad72bb22e2133013a1bac50a7b30100000000900b74360048c412ce6cd8fbe338f080e86475b85966c3a19fa941bbd2bab7e8a6dfacdc3d1ab66b04b9f2d0d62d0f0f9646c624cd781e979996f9f2c3bfae8a3e75f4498f76c9660f2ab260d2f959d79099b46736b824b5afb3c11b7ffe9edbaefdd03a93ca21d6f5c6cf41b2594ec883dd263d927511000000e87e840d00929af5a682bbaa8fdf7bfdc19045b86c49a2539472d1d9e08fc9d2b8b3e8dfda511eff460a0ba1d3b8ae91cd1c3634aeb3f7aa54faaccae59a24ed887eb06bc04f97a5f2f3972e97d69df98a8dfdcd63a77a4b88ce86f6ce6c3847d2d636ee8716b9f43c9342741cfea5d4e303df3bcb2725fd76d645000000a0fb11360048c4e54b6cb63b6516e486c6715bf8e244b323a4ecc306e95fd259c65e3b581ac9e7dbd47324965ebda33c764bd675a4697262ec7b03a5915b4cba74a6ebccecf9037efa9b2ad2572449e5724d43c38f4b7a7e1bca9c133345cf5d50bb60b7745bd6b5b49dbbd209201b4ca6ba738c1200000000201f98d90020a9593b1bccc3870d92259bd960cac1314ab63beb1a7a49146b79d63584e0ee7f92ec4a7bdf315fc9760528271571d4a34729a5d8d970347d8c23064403000000007281b001402289662598079d29b0a2b421f9f9d0ae03014b49248e0f733e721bc551bc2ceb1a42d831317e8be40fcc769d99560d0c0dbffe99273cb501e5698bd4a343a2d3ec4f6aae657d6d3d4609000000008093226c009088271a046941c386fe390ca374b3cc8f517a68dbf5bbe41e7486059e616e3f990a4a1d4a0000200049444154750dc1b85f93e83ad307a67d95dbb0c15debb3ae211369ce6c680e00b7b8406703000000002017081b002462668b66bbc6e541df615b305b9cf45a73ff61c85a9272e9beac6be821b3fe8c76aac989cd5f779f3d3c30d9ba81a10daf91244f6d6648facc6cf160e98a5559d7d16eb3cebd998b666743a17690ce0600000000402e10360098d5e02b362e4d78691cb28efa1c3a1be21c74364892cceecfba849e61da917509817d2cc94566d1fb2549eebb4216d3aad88b3d39b7c1d33a4ba93968fa074f33b30100000000900f840d0066552dd4930d65f6b06143a19e6c38b4244516673e20bac1efceba825ee175fb6ed63584b4efc0e12fb92bc95165170c5e3c7241e4f91d102df5f2dc8694ba1b9a99c5e32bfbe96c0000000000e40261038059152d6147419ae7919f402c4f1c36d4ebd90f8896a4b8a09bb2aea127b81fdc71fb58571f59f5f8bdd71f94fc5349aef5d8dfbfef707157e0925ae2d20559d79089b4fe9c3cb2cee868d090170000000080a4081b00cc2ab26437f95d16f6a657943c6cb028cac5314a3b6f1ddfebee5dfd8efb3c70d3b6ac6b688742bdfa8924d799d96b9e734a6d95cb9f0a5d530bce39f3151bfbb32ea2ed523a45492e31801e000000009027840d006615479e6c30b3a77517edc4229fc3314af57a2ec2064972d37559d7d0ed5cf6edac6b688707eff8e63ec9af4d726d24fb23c91e0d5dd37c99295ad45f3b2feb3ada2eb5ce06974bb594560300000000a065840d006665b1e56240b4a4d3935e588b3d27331b24afe91fb3aea1db45aadd90750ded1247f627092f1d91ab2f68312d8adc5e96750d6d976667838ce1d00000000080dc206c0030bb84331bccc20e6d70259c1d21e9dfa7f21336ecbc63fc61c91fc8ba8e6ee5ee95c9f29647b2aea35d76dc36f698cbff2ec9b5663a37743dad30f9cf645d43dba538b3c14c0c870600000000e406610380599959c28e020fdbd960c98e517257dc18a69b1f2e7d26eb1aba959b7d3eeb1adacda56b3cf0b165ede0a2b3a1b5759cce0600000000406e103600985dc2a358dcc30e88364fdcd9b037641df351ecfbf157dd3d377324bac9a162e14b59d7d06e3bcae3db4dd6f1474799b46a456943e28ea5ae6029a50d26b9d3d90000000000c80fc20600b38acd7f94e8c2b0a728cde518a5dc1ca174c40337df7cd04c5fcbba8eeee35f78f496d19e0c71eaf28f645d431a4e8bed2559d7d056a975369898d90000000000c813c20600b38aa4ddc9ae0c7c8c52c2b0c172183648731aec8b84e238ead95fd39d13e3f7b8fb1d59d7d1aad87aec28a514673688990d00000000801c216c0030ab388eee4a729d853e46499eb0b3213fc3a1a7db71dbd86392fe67d675740df7afefd8b6a96706439f887b744dd635b4aae7864433b30100000000d0a5081b00cc6ac7b64d8fb87b25eb3a921ea3e466b90c1b2449870a1f9294abe1d59dc8dda538fe50d675646dc7b64ddf72f9f6aceb6885a9c78e514ab1b3c198d90000000000c811c20600497d6eb60bdc3cd89f292b2fddb8d82cd95d3af37c763648d2e4dda37bddd5f337c95b65d2d7276fbf2ef3002c0fcc3b7c768369654f0d894eadb3c1c5cc0600000000409e10360048a45eab7f49b3bd8bd66d71a8fd4fa9d5ce4a7aadcb72fd6edfcac4d81fbb7c57d675742cd7d4e1c2e177675d465e4c4e6cfeba4b8f655d472b4ef51e9adb905a6783c999d90000000000c811c20600893c74e7960332ffc08c179987bb61e87e61d24bcd7c65b03a52e2f2dfc9ba864e159b3ef2f06d373c9e751d79e21e77f4ec06530f850dcc6c000000000074a962d60500bdcca5c59296aa318b60b1b20b00ef31cdfe0ed9c9f2f89f0e9446de66d2aa137ddf64ab0787863fef1e7dbab26dd3fd6914b6a6b46145c1ed5297cde1a8187bedc0d0c81fc416271a6c9d0597f649fea864b90f4672e6a0597cd7c0451bce534155ab7b5505afc651b1aac3aa7a9f577daa5e7de8ce2d07b22eb49d9eb67d5f39cd4fff23992dcfba96f9e8a921d1098f839b7d1d69d66e330000000000da88b00168a366b8f05a49574a7a8d120e3c6e83fb5dfa59939e98f54a8b7f431edd7af2efdbd5667ef5606924bdea6cee278f98e923059ab7bad142f3e856159a5f353f4671f3f3ba490b8a3af2f3e7d27eb9f6ca7cafb9b6c7b2f1a76def4dbbcae5aeba49bbab5c9e1a280d7fc2a48eec7070eba5ce064f2570306636000000000072863b71401bb8b4cea5bf91f4a4a4bf97f446e5276890a47325fd934beb66bbb0b275f36d92c6c29704b4cea4c5665a61b297c8eccd9169fc345ffac381a191bf5db3feca597fde3bc954b178ad4b1dd9d161d2593d33243ab5990d9298d90000000000c811c20620209796b874a3a40725bd49525fc625cde4f992bee3d2ead92eb4b8fedb1cdf818e65ea37d32f16a2c2838343235bcfbee8aa73b22e290d8fde32badfe4d7665dc77c9d263b3feb1ada82990d00000000802e45d80004e2d21a49ffa4c671499d62a1a48fcf76d1f66dd7ed76e9436da80708cb542a16fc9f078636fc7ad6a5a4c155fc44d635cc57dc2b43a253ec6c70425f00000000408e1036000178e358a2ff4fd28a8c4b998f9f7769fd6c175526c63eda18700c743eb3e87383431b3a3e40ab9447f7c8f5d9aceb988f9e19129d6a67831d4a693500000000005a46d800a4cca533d4383a6951d6b5b4e03349ee87d563ffcde09500ed62d11fae2d8d5c9a7519ad8a0b9d39245ab273b3aea02d98d90000000000e852840d40fa6e542370e8640392ae9eeda29ddb36dfecee9f6c433d405b98ebef5f70c1f0f2aceb68c58edbc61e73f9d7b2ae63ae4c3aeb9ccb2e5b98751dc1a5dad91033b30100000000901b840d408a5c1a51e308a56ef0719796ce76d1a9071e7bb7e40fb4a3202034332d3b658175fc714a2efd897b5a77b5dba7563ded2559d7105c4a9d0d2ec9dce86c0000000000e406610390aef7665d408a164bfadc6c17dd7befbdb5bafc4a773fd0869a80e0cc74f5d9175fb13aeb3a5ab1a33cbedd6437645dc75cb9db3959d7105c5a199049b18bce0600000000406e1036002971e942492fcbba8e94bddea59f9feda29de5cdbbdcfc97db5110d00651312efc7ed645b4caa37ac7756898f98bb2ae21384bb1b521a2b30100000000901f840d407a7e2eeb0202f9a2271876bda3bc79b3bb3ed58e8280d0dcd4f183a22b5baffbaee4e5aceb980ba3b321399398d90000000000c813c206203d97655d4020cb25fd45920b4f3df0afbfc3fc06740393ad78e185232bb3aea355b1eb2359d73027d635336f4e2ea5c606b9642e3a1b0000000000b941d800a4c0a52592ba79b0e95b3d419872efbdf7d66a71ed4a97f6b7a32820a4bea25f98750dadda31317e8bbbdf97751d73b0f0ecf5af5b91751161a5d4da60922266360000000000f283b00148c78aac0b6883bf6d862a337a68dbf5bb24ff396770293a9d77c7ef6b8bbca3ba1b8a5ad0dd4729a5758c929be4c69fb30000000080dc206c00d2b134eb02da6099a4bf4e7261a53c7e87b936ba2b0e5c13108c9b7e2aeb1ad230b975f398bb3f9c751d49c591ba3b6c48eb182593cc19100d00000000c80fc206201dbd103648d2152efd7a920b27b78d6d71d3db42170404f4fcac0b488dd93559979094b9ff74d63504955a6783548be96c0000000000e4076103908ec55917d0469f7129d159f63bca635f72f91f872e080864d663c33a45457bbfe6ee8f675d471226adcbba86a052ec6c50f1309d0d0000000080dc206c00d2d14bbf972249d7b97466928b2be5f1f7bafb3f06ae09489fa775573807cae59ad419dd0d2e5b3d30b0b12feb3a8249ebe7ca5de6119d0d0000000080dce8a51ba400d2b354d28d2e2d4a7271c57ef85fdcfdb6c0350198c1fe6ae10b9dd0dd60a628fec9c3dddbdd905a6783c9ea119d0d0000000080dc206c00305feb248d7b923f47cae55af1941fbf4eae72f0aa009cd0eebb47a7247d3ceb3a928862ebde21d129ce6c886a053a1b0000000000b941d800a015974afa74920b1fb8f9e683931363174b1a0b5b129016efbabf23f7578bd7ca7d5fd675ccc6a4ee1d129de2cc86c2737e446703000000002037baee460a80b67bbb4bbf97f4e2c9f2d85572ff42c882805474d1c886239add0d9fc8ba8ed9b8a98b3b1bd2696d30490f54ab743600000000007283b001401a3ee6d2eb935e3c3931feb658febe900501ad325957fe1d19d5ab9f74f70359d73123b773b32e219814422c3f721653b95c6b7d350000000000d2d19537520064e2ef5d7a6dd28b7794c73f2af95bdc15872c0a98b7b4ced6cf9907eff8e63e935d9b751d3331d3d281d2c633b2ae2388347eae5c928b23940000000000b942d800202d453506465f9af40593e5f1afc6e657ba9ca3408036b2622df783a2dd6bebb2ae2188348ee73249e6840d00000000805c216c00d2c1efa5863e49d7bbb43ee90b7696c76f501cbddc5d8f05ac0b9833efc201d1476cbf75cb1372e5babb41e60359971082a5738e922411d2020000000072a56b6fa400c84cbfa41b5dba2ce90b2adb36dd3fb5a0f022976e0958173037d68513a2a7a95bfc31c9737be6bf291accba86505a3e49c92477a3b30100000000902b840d00425828e99b2ebd31e90b1ebd65747fa53cf6ea587a3f731c90135dfd77e4cef2e65d92fe2eeb3a4ecabbb3b34152eb69039d0d00000000801ceaea1b29003255546368f46fcde5453bca631f8e23bfd85d7b03d505a0e9b0a26bb2aee1a44cdd1b36b4da34c3cc0600000000400e11360008ed2f5dfac85c5eb073ebf8b65aa1fa2277ff6ea8a2805979cb87dde4dec3e54d3be5da9c751d2762b2a5ab2edab82ceb3a8248e7478bce060000000040ae10360068873f7069d41bdd0e893c7cdb0d8f5726c65feeee1f0d591880b98581edb4c0eaddd9dd602da60d2e19331b00000000003943d800a05d5e2fe9569716cfe5459589f1f7c9fca7257f20505dc00999ac27fe8e9c9c18fb9e5ce5aceb38118bb426eb1a8268b5b3a1710c139d0d00000000805ce9891b29007263bda4efb874d65c5e34b975fc8149fdf0a5b1fc7deedc60439bb47aae7e07a97b9ccfd90dee8359971044ab3f5b2e39331b00000000003943d800a0ddd6487ad0a537cce955e5726d4779fca3f5a8f62297df17a634e0192eef99bf23776edb7cb35cb9eb1e3275e990683a1b00000000005da8676ea400c895c592fec1a5bf7169d15c5ef8d0d62d0f57cae33fe3eeef968b77f60229718f7337bbc1cdba336c68b9b3c1c49f7f0000000080bc216c0090a537499a74e9bc39be2eae4c8cffb979fd85eefa3bf756df260c9c408ffd5855b66dfe4777edcaba8ee94c7afe4069e39c02c98e90426783c9e86c0000000000e40a610380ac9d25e94e977e77ae2fdcbeedbadd9589b15f92f98b5dfa6e80dad0d37a6340f434b14cf99bdd60d5eeeb6e4861668398d90000000000c8995ebb9102209f8a923eeed275de3862694e2ae5cdf757ca632f8f150fbbeb9100f5a117598fb53648d21385afc8fd89accb388617ba2f6c68356d606603000000002087081b00e4c9156a1cabb47e3e2fde51debcb9627bd7baeb9d2edf9b726d40d7ab5446ab327d3ceb3a8ee13e987509a96b35c7729733b301000000009033840d00f2e64c4913cde1d1cbe6fcea72b9569918fbd454b1f89fe5fe01c9f7a55f227a81f5e8df91b5c3f56bddfd40d6751c61a63559d790ba56bb66cc246636000000000072a6276fa400e8086f92f47d97dee1f3f8b3ead15b46f74f4e8c7ff047878a3fe58adfe9d263016a4437f3560fd6ef4c0fddb9e5804c9fcaba8e69baef18a5963b1b24999e4ea3140000000000d242d800a483df4b612c96f469490fba74de7c16d87df7e854a5bcf95395f2d87f92fc2d72df996e89e85abd38b3e188c3873f937509cfb0952b4aa5feacab4855ab39964992d3d90000000000c8156e9002e8040392bed33c5a69f97c17992c8f7f7572627cad7b7cb9bbb6a5581fba907beffe1d3975eaa9b93a7eec343b7d75d635a4aad55394dc65cc6c0000000000e44ccfde4801d091de24e95f5cfabd5616a94c6cbea9323136e48a5fecd2575cdcb4c309f4e6294af9147b771da594426743cccc060000000040ce103600e8340b257dcca5ffe5d215ad2c54296fbebf521efb553b54f80fb1eb3d2edf954e8900d2e416adcdba8654a533b381901400000000902b840d003ad52a49d7b934e1d29a56169abc7b74ef8e89b13fad94c7ffb32cbecaa55b52aa111dcd7af6efc8530f55cfccba8663b856655d42aa52e86c30c57436000000000072a5676fa400e81aeb254dbaf4d72ead6875b1c9ad9bc72ae5b157c7b1bdd0dd3fe9eefb5b2f111dc97b7340f49a570d2ff5a87063d6754c672666361cff7a373a1b0000000000b942d800a01b4492deacc6d14a5f74e9ac5617dcb16dd3239589f1dfde5f2dfea462fd92cb6f9214b75c2990632b4aa5fea866b79ab5fe7b284deede5d6183b5d8da609239331b0000000000f942d800a09b1425bd55d2bfbaf4f9344287dd778f4e4d6e1bfbbb4a79fcf2a9aaff94dc7fc75df7b75e2af2ce7aedefc88d1ba3853a7ddc4ce7665dcaf1cc6cf10b2e185e9e751da949a3b3a140670300000000205f7aeb460a805e72b5a4efa7d5e92049dfbf6bfc89c989f1ff5999187b71bde6674bfea79276a7b13672a8d5779f779881276a5f34d96bb2aee364fa4fb1ee99db90c2cc86bad7e96c0000000000e40a6103806e36bdd3e1cb2ead4b6be19d778c3f3c591e7fcf6479ec3fbac5af92ebb32e7f2aadf581761a181ab9c6cc7e25eb3a66e271171da5d4e23c109798d90000000000c81dc20600bde257243de8d2ed2ebdc11b41442a2a5b37df363931f69b95f2f8f3dcea2f77d71fbb54496b7d64c3e53df177e44069f8ed66faef59d7313b3b3beb0a52d36a67834b1633b30100000000902fa9dd6c03800e7161f3f1844b9f95f4794bf128a4cad6ebbe2be9bb92debbf69291b3aceeaf97e94a935d2802deced2eab9fa1d607068c31bddf599966f7eb78199baa8b341ad050e265991ce060000000040be70e30b40af5a2ee97fa871c4d2b75d7a7d9add0e92b4e3b6b1c72a13e37f5e298f0f45b5433f114bbfe6aebf73f73d69ee8350acabff8e5c5b1ab95416fdad75ca6c0a17331b8e70c9fc309d0d00000000805ca1b30140af8b245dd67c3ce5d257257dcea487d3dce4c13bbeb94fd2979a0fad5d7fd52ab3fa256676b1a44b245b9ee67ec04cd6acbf725d245da70e7ad3819bafc9ba86d4a4d1d910d3d90000000000c817c2060078c63249bf2be9775dba47d2e7257ddda483696fb463dba647243d22e9af2469ddfae13575b34bcc74b15c25332d4b7b4fcc5187bce17faed6bdea8ae55e8f6e95b430eb5ae6c2647dab4a23673e521e4bedd8b3ccb4dcd9607aba16d1d90000000000c815c2060038b1f39b8fbf70e9eb6acc76f86ea8cdb66f1bdf2969a7a46b2569f0a22b07dca2f32db257bafc3c93ad0bb5374eccba7440745c2bdc68d6999d34a7348e52eafcb0c1ade5ce065f58a4b30100000000902b840d0030b34592ae9674b54bdb257d51d2574dda1b72d3c9dbafab48aaa879ecd2ca4b372e3eb556bb40eeaf74b30b243bcf1ab501890d0e0dff0f99bd24eb3ae6cb1b43a2cb59d7d1b2146636c4b527e96c0000000000e40a6103908eae7c07349e659da44f48fa984bdb245d2f69b349bb426ffce82da3fb25ddd47c489206d65f75ae2c3e57662f32f773dc6c9d496784ae059d69ed45232f91f9fbb3aea325ee67675d422a5298d9b0ab5ca6b30100000000902b840d003077454997341f9ff0c630e91bd4081fee30a9d68e222adb36dd2fe9fee9cfad286d58d26f764ec1b5ce653f6dae756e5a67d2e276d4d44ddcadab42c428d29725ebe8bff74db63aeb1a52d16a6743dc9e3f630000000000988b8ebee9000039b15acdc1d292f67ba3fbe07a49df0a7ddcd2f1769537ef53a3eb62dbf4e7d75e347286177d7521d66a379d2db7d5665aedae9566ea6b678d1dc33ceb0a523330b4e1d7653a27eb3a5ae5e6dd1136b84b36ffc4c123d1d50000000000c81dc2060048d762496f683e6297ee512378b8c11a331f32b1e3f6b13d92f6e8b8104292064b57ac922d58e971bcce642f907cb59bad36e9acf6579a1fe616675d435accec4359d790063a1b9adc99d70000000000c81dc206000827927441f3718d4b8f49ba59d2ad926e31e9a92c8b3b62b2bce511498fa851db5103031bfbec27aaabe282ad96dbaac874b64babe55a6d665d3f1bc2a5ae081bd696366c906c79d675a4e585178eacfc5f778c3d9a751d2d69756683e86c0000000000e40f610300b4cf5992ae6e3ee45245d22d6a840f6593f66758dbb3542aa355356aac9ce8fb6b4a1b5698a233e43a438acf30d94f49768649cf977486e467c8ecccb6169d229376675d431a228f7eade577d2e784bb761516c44bb2ae236b66a2b30100000000903b840d00909d81e6e35d6a1cb9749fa4dbd4081fee30e96096c5cd666779f32e49bb66bb6ecdab869746717486c5bedc3d5eeea6a591a265327f9e4b4b252d936c89b996bb7c9999e56298b59bff43d635b4ea05170c2f97e9e767bbcea529b90e9ae9a0cb0fcaeda0e4076427eeee3057d5cd0ea871ed01931f94fc805b94bc1bc47548f203721df0c80ec874c03d3ee1cfbc5bfcf8435bb73c9c78edbc6b21fc71b924c2060000000040fe103600403e44925ed67cfc3f92aacd790fb7aa1140dc63522dc3fae66de7ade37bd518947dc20e891319286d3c43162f555c5b6ad212375be21e2d3669b1994e936b999b2f3669b14b8b4d5ae26e8bd5f8fed2566b76f9d72ae5f1cfb6ba4ed61614e3e5f2e86d8aa2c7ea5eaf5a3dda5f2fd8c1e2e14307abd1a907179efaa3830fdc7c73ae43adaee436ffc0c12593718c12000000002077081b00209ffa24ad6f3efe488df061bba4fb25dddbfcf8804907b22b319c4a79f4c840eb795b512af59f727871b1189fd2670b0f15a7eac5bea2e2a2c58562e4b53e15a362cdeb7de68562a4b8189b150b16557fec7befdb552e77c5cddc9ddbaedbae0c0793e3245a39d6ca24399d0d0000000080fc216c0080ced027e925cdc75b8f3ce98dc1cef74bfaa7e6c7fb4d7a3c930a73a65b020374a1560644bbe4e6fc6c03000000007287b001003adbaae6e3f5479e70e9293583073542889dd6980701200f5aed6c606603000000002087081b00a0fb2c937469f321a9f1466a498f49da29e961493b8e7c6ed2eeb65708f4b056b286c66f6666360000000000f287b001007ac759cdc765d39f74e9a01a01c4f420e261491593b8a90904e072d97c6207938c990d00000000801c226c00002c94746ef3710c97f6aa31a8f9f1698fff7ddcd78f9b546b5bb5403768656e03331b0000e869b1fba6c8ec91aceb4032de783357ea0e45857d05e98321d64618568b98af88ae47d8000098c9d2e66360a68b9aa1c4f40062b7a427253dd17c3c25e9096b0417005a18102da3b30100805eb673dbf898a4b1aceb40b6769537ef93f481aceb0080e9081b00006938124aac9be9a2e6ec887d6a04107bd408219e6a7efd6fd33e3fa8c6114e53d33f37697f88e2bb8d4b8b24f59fe0f1b01a9d2c471efdc77d7dfc73a7ea99b58ebfa64f8dff8e38f2888efb98e4b985b3fca3dca7c6bff35b4dfaf0bc7f41f268be9d0d26b933b30100000000903f840d403aa2ac0b003ac892e663f55c5fe8cf7c7ac230a2f9794d5275dac7ea0ccf4d49aa27b8eef88f476e9647013e5fa067c281857a7660d07792e78f5cdf4d5ed2fc5872e96d925e6a8d40aaf3b5d2d9203a1b0000000000f943d80000e84447de618fde7196a4f748fafdac0b49450b9d0d12331b0000000000f9c3bbb1010040a718c9ba80d4d83c5b1bdc64743600000000007288b0010000748a95de3882abf3f9ec979c9049727b3acd520000000000480361030000e82467655d402a6c9e69834b319d0d00000000801c226c0000009d6459d605a4a295ce068b99d90000000000c81dc206201d71d60500408f58947501a998e7c806b9cb64743600000000007287b0014807377e00a03d16665d402a5a9ad9203a1b0000000000b953ccba0000008039e8cbba8054ccbbb3c1644ec00d00000000c81f3a1b00004027e98eff7699676783c9a502331b0000000000f94367030000e824dd1136ccb3b3c1cd14d3d90000000000c821c2060000d049ba6766c37c02077799329bd9f080a48b33da1bf360d25381967ea7a42581d646fa76675d000000007a036103000068c541356e42ef95b44fd27e356e70feb8f9f9f4c7c2933c7e4ad26a496b249d39cb7e8b125766512c9fef24e6c06cbe431b245336c72859e3df6f398bbd912f26dd9f750d00000000f287b0010000ccc55d92be2de93e49db4dda95f6062e9d2b6955f3519374408db0e2801ac1462275af570b793d7569be9d0d6692718c1200000000207f081b0000c04ca6247d4bd226493759a38321a8e6bba65b7ee77454d7411552282888f9a60d92dc081b0000000000b943d80000008eb747d20d92c625dd62eacc77d29bfc40d6359cd43c730673d7612b6435b301000000008093226c000000522350d82ce98b926e9eff4481fca8c5beaf98d7ce86791fa32479cd3b32fc0100b4eeec8baf586d1e3d3feb3a9050ec4feddc76ddf6b497e5e7a0b378bdb0f7a1db37253e0a34a915a5527fbf969c9ff6ba0827d282ef55caa3f97d43149002c20600007adb1e49d748fa6a730070d7f8717ccadee7aa9e75192736df139424595f95ce0600e85185b8f01e337b6bd67520198ffc264997a7bd2e3f071da6e0374bfad9b4973d257ece198528da9af6ba08a76e875faac6ec3ba06be5746a220000086c9fa4f748fa4f267db2db820649da7df7e894dc77675dc709790baf8b99d90000000000c81fc20600007acb01491f552364f8d34e9dc79054cdeac3ee7a2aeb3a9e65dee754998aeaa7b30100000000903b840d0000f48e0f4bfa0f26bdcfa4fd5917d30e0f95b77ccfaa85b3e5ba21eb5a8e31dfce0673e989ee0e8800000000009d89b0010080ee779ba4179af4fe5e0919a69bbc7b74efe4c4d8eb247f8bbbe7e39fdfe63f82bb5219256c0000000000e40e61030000ddeb80a45f30e955263d927531599b2c8f7f55b5c32f92ebaeac6b696166034103000000002097081b0000e84edb25bdc8a46f645d489e54eebce1b1c989b157c6d2fb332d649e8d0ddee5333600000000009dab987501000020755f31e957dbb9e1baf5579e59b3e8cc483a53d2596676ba5c4bdd7cb1a4c5722d92a92ad901b91f90ec8099f6b9fc7f9bdbce5aadf6f043776e79bc5df5ee288f7d78edc523f7996b9349fdeddaf728d77c0307c2060000000031b08ffc0000200049444154402e11360000d03d6a927edba46b436eb2eaa28dcb1644f50bcdfc9526bb40d2052ea970fc8526d9913bead36fac4f9b57608d8b545c50d4e0d0c8949b1e90fb3d8a746bbd5abfeda13bb71c08f5cfb163ebd8b7d65e34f24a15fcdb265b166a9f13b2f9a50d264da55f0c0000000000ad236c0000a03b3c25e97526dd1362f1d5a5d72d2ba8f08ba6e8974cf5f31acfce7fc8f10999fa4d3a4f66e7c9f5aee282a2068686bf6b66374bb5bf9e2c6f497deec48edbc7ee5bb7feca17c7167ddbcc06d25effa4e6d9d940d80000000000c82bc20600003adf03922e3729f56388068736bcd1cdde62b2d7a4bd761266769ea4f3a4e21f0e9486ef50ac2feffb71edeb8fdf7bfdc1b4f6d8beedbadde75c76d9cfd40f2dfaa64ca5b4d69dd17c673630201a000000009053840d003ad15e497b9a8f279a1ff74ffbfe22498ba77d5c2c698da4f61e9302b4c7b7246d3429b59bef2b4a1b962c94bddd5cff556667a6dcbf306f26bb50912e3cfd390bfef2f4a191afc405fdc98edbc61e4b63ed076ebef9a0366e7cd5e013f54d326d4863cd19cd776683199d0d00000000805c226c009067536abc63fb3e49ffdcfcf8c07c8f11f146f8b04e8de0e1a7255d22e99c744a053271ad49ff35adc55e70c1f0f25316e87d267b97a4d44f494ad14299de11c57ac76069e41bf5b8fea19ddbaedbdef2aaa3a3f1a474d5e0d0f09765f6e614ea3cb979fcdaba9cb00100000000905b840d00f2a622e92649d799b42dcd854d3aa0c679f647cfb4f746b7c325927e56d215a2fb019de3afd20a1a5694362c394df65e97bdcba4fe34d66ca33714a2c21b068646be1515e2776ebf6df3a32dae174f4e8cbf657068b82ab3ab53a9f044dce61e38b824738e510200000000e4126103803cd82ee98b92c64c4ae54894a4ac3154f71bcd875c1a91f46b925edbce3a80391a33e937d25868a0b4e1b7e4768dcc16e5b7916176667aadc7d16b074b231f9e2c8fbdbfd5f52627c6df36501a9932e9b7d2a8ef59e6331cda4ceebe7e7068e469994fc955955955f26ae37355dd3525d3d1afa5699f4fff9e54b5c6e787dc54b569df8b5d5545aa7aacaa156c4ab1573d52d5dcaaaaabaa8257bda6aaf5d9940eabea7d5e8deac5aa9e50b55219250c01000000801e45d800204b5f93f41993eecaba90234c1a9334e6d21992de2ae9dd9296665b15708cb24957b5bac8da8b46ceb082fec6a44b737c5cd27cfce1e0d0c82fcafd6d93dbc66f6b65a14a79ec9d8343c33599fdb7b48a3b6a9e331bcc4c92fa25eb7fe6f5cf7449983df39474dce727f99e1df7bde8c8e7d1913aadf151920acd8b8a92e2e6d775935497964b83cb471a43ac8f861ade08448e3ee75347be3679f339ab3e139e1c1f907835367bbaf1b5574d5655acaa22afca6d4a91aa8abdaaa8b94eddab2aa81ac536a5a25755f3ead3b5a85aeff36af5dfebd5c757f64f6974349efbaf3c000000006036840d00daed29491f97f4856657412e5963e8f4475dfaa4a4df552374589c6d55802a92ae6c7591c1d2c8eb25ffbc644b52a8297f4c2b6576eb4069e40395f2d8075b596a7262fc77064a23eb4cba34adf224e5791e46cbccd427a9ef9814c39ef9e6335f1ff7f90903125374fcf5d1b4eb9f158634aef148526c5224f5f735ae3fed39914e7fb22e1f1a894fd0f55135d309038f63ba454e1c9e1c7ae67bde5ccba6e4cd1024f66addede8e72ad894ea5ef58257cda3aa1f8eabbec0ab76d8a6ea8b0f571fb9f146ba43000000007424c20600edb247d247d408193a66c06973cec3079ba1c37b25bd4b9d77a63dbac353922e3769ff7c1758512af52ff4d33f2de9ad5d7db7bbc9a43f1a2c8dbcf2d0d34f6f7ce43b37cefbd7adfaf4d357f5f59ffaa099ce4aad38f7696d0868a7667ed12fe999ee90193a428eed16992d3cb163bfd7ec60291cdf2d72e4a3242d889a1fa5e2d3450d96461a5fbb1f9c7eecd591cffd24a148f3e3d1ef99546d7699fce0486748e36354b558cdf0a3d12552974f45eeb55851cdad5e2b5aa1aa5a5cab7b54f3a856ad470b6afd855ab5a642ad7660aa36152daaeebe7bb463fe2e07000000d01e840d0042db23e943265d9b7521ad30699fa4f7b8f4176a3c5e9f7149e83d97b732d364e5a51b179f5aab7f47a6356916d5012eebeb3ff59f072ebeeae72a5b3755e6b3c023dfb971ffdad2f0cf49bad7647da95445ce80d9982d94b470c663afa67f7e82c0e45941c9f4d0e3e84753a1f9bd8224a9d808420a85e6d70b5494e4f5a20a920aa79eaa5354d7734b23727799ac2679d5cd6a92d724ab9a7bcd9bcfabf17cd56435f7c6f7655e3bf23ab9d55c5e95ac66e63549cde7d4789da92659d5a5c37235ae35ab99e29a1455157bcdcdaa91e29a2caab979d56535afc7b5824555b7462d6e71d56b85da028bab7545358feab538aa55eb530b6afd5eacd5a243d5430bf6d7763def79558eda02000000e687b00140487f25e9ddcdee80ae60d2e39236ba7489a4cf485a9d7149e80def34e97bf37df1aad2c8997db5daad92f5e4cfab9956b8fb77064bc31b27cbe337cd678d1de5f1ed83431bde22b3bf4fa5a879ce6c00f2a43943a42859b1f1e3fc4c3bc8315f1ff9ea594345acf9ffc73d7f341779e637c93379c971894974e499c6d7e6cdafa3e6d7475ee1915470b94c51b3bda410f769419f24d5555451452dd5e09375f9d0f049439446f0e1b5a3214a232c391aa248aa9a540b12a2d4a39aab7e344491c5d558563b12a27854afd51511a20000002033840d00427844d25bf234f8396d26dd26e96c973e24e90fb3ae075ded06933e35df170f5c7cd580dc6f35d9196916d5694c5ae46edf1c1c1afe8dc989f12fcc678dc989cd5f1f1c1a1992e9ed2dd7c3114a406ecd14a234be9a252c39faad944394c89ff95a2679b3fba419a248cdee93138428034fd6a76c6878bf9bf6c9b557b2bd32df27b7bd32ed75c53f30696f2cdb5730db6b75df1b47c57d95f2e89ef9fd2a020000a01711360048db1f5b63b6414f30e9fd2eddaeffcbdebd47c95597f9fe7f3fbb3a1763c498410e3f4e161331034955440611b984ee0a20724bd25531a878434541b9a88378194416830cc3784550461ce5368810e8ee245c945baa9b3bc34d48573731272b72f2e370841f86a60da1d3b59fdf1fd581109274edaa5dbdabbb3fafb5b202dddfcba743d261ed677fbf0fdc008ccd66bb92a4e7804f573b39333f7f88bbffc1606a8c992273f747b0a15e2dcefe6696489ef25dfdf6ab4c36f7beee42fb57ab59e3b529af7e75d2ab938f02db2bee7c22225bd9e8e51e3dfd38fd0cfdb319fde07de58f797f88bd5cfe187d18fd56a21fb33e73efdf14587fd894ea5b7bd7d27e40a71a44444444a4ee546c1091b8bc082c3128d47ba37d9a17cc4c054d3330a67b68bb9885d31cdbc5dc42873e33df601ef695085e6cf270fdaaae65ebeb99c7e00e870cd00e1c58cfbd64dcf9dc50bf90c8f6396cf1be0d506868a3543ab778efb2d77b25a4b34ba63a83a7e2f61d33a62713cbceccb4b4f67577769c1b75e69adb6f1fd827bbf063296f7a78a8d170d5caef22eb8483c868e7e586effdb8bf5e14c0e837182a0ad0efd087593ff032d06f21fd58a90f52fd8336d88fd1c700fda5c1cdfdb534b4171111111149928a0d2212872ee063566e061dabd9cd8be606965a88f947acfc26f18cd73fe95b6e3408b6e97d6960e5ab05dc5264b2791c9ec57d8d637f087df38dcf74ad581767cea15e0e1f72f81570729c6bcbb8d56170473513e7342f9e65e62b932c3494f005bd85f65bb6fd78b1b0b41ff861e6e025bff149a5270cf64c201e58f0dd7436d7532cb4ff36ead4670acb1f4d6773ff0ef6ed1a43d4365d44aae24e08decfeb4501dba62830747a007b05f772d100ef2f99f563f4d9a0f5bb7bbf99f5592ad55fec5c3a667a538988888888d442c50611a9d5bf1b7c2bce05d3d9dc3c60116e27986d791059db4339833d31dbd3e0f0c0265c9cc9e67bdde92028b517572e7ba4f6d4afeff345873f53eee52052ad4dc019d54c9cdbbc684668e1bd6696d0a901007ebabd42c3d6ba1f5cfad2ec6ceeb414b662a4426dcbb0eb32f3f3ebba57b645ee2ff3b6579e3d77d3d43d5b319b5d7500358916a954e86c3929e0fd60fd8e0f150586ae1072fa0d7b19bc3f2c9f20e823b47ef07ec3fa2cd8dcef4cea6f9af872df5377dcb131e1af4744444444644c52b141446af10583dfc4b1d0ec6c6b36c03e06d66a506e645bdf8770b3cdf8369efa76a625b7deb18e10bfaeb7b3fda15a1736f8bec3b3c0d531e494f1e95c83c8d77fcdccb64e730f3acd48b61974a9f4ab4a86f516da6fc964736b93ec7fe0212b66675b3fd05be8581765de638f3d36b8cf61333fd6940a1f03abeeffa754689031cb07df7a7d90f783f5d956fd0742e31508fb6ca82880bd313608e87b7593f5bfe64d7deb1f5cba29e12f4844444444442aa06283885463139033f87dad0bcd6ecee553817d0738a0f65855329b61707a0a3b3dd3927fa0647ed1706f650fbb245ce3f017e0f69852caf8f1acc10fab9938c583eb30126d5cecd0b7758f86e1590192cb6cc6f400bb19f840d4b9cfdc7bf3539996fc15185fa96a737ffd2e38916439836f5c1f542e06d836fd071cfa707b65e8faa13edb524030eb1b1cb47e6ca0afe493fb07532ff4af2b14541c10111111111987546c1091a85e043e6cf0642d8ba4e7e71612f20333db3ba65cf1300e49612b322db9de9271762d450783df3b1c07dc1a634219fbceae66d29c6ceb9906c7c61d262ac35f8c32deddd75bc20fdc0ddb3fdd92bfb4d8d916f9ea2ab7d40578e964332656b3b348c59c4d437d04fab1adae12624b6362eb3763833b7fc3c27e08facdc23e0f833dc0fbcdac1fb3be5269b0dfbda91f1be8f380fed5851591fecc8a8888888888ec888a0d2212c5466a2c34bcf790dc6e9326dacfcdf968433f67339b9d8215996cfec6cd6c3eadda873106b739e4809b8120de9032063d697063d449e96ceb7e78f08306f93315b557c4b4baa488c88cd333d97c6777a1eda628f38a85a5cfa7b3f9ab802f45df554d1bc62e1f04fadf7495d0d0090178e31a21735e79bd17c19606c443d70939613f03f4970637f7af79f8f6be24bf1a1111111111914aa8d82022950a8105b5141ad2d9d64f9973290df270b1422734f98423332dada7757776fcae9a050c3a1c3e015c8f0a0eb273df893a618f0f2c9802d65edd9bf5f560d3d2f317a78b2b6faef42aa583ea1a270277bf72ce61f9fb7aee6d7b3ed2c4cd03173261c2e723f76e509da171b86f64ab62c0ebc5017f737100e3952d0d8731ef2f95e8df72ad9013f67b40ff00afe81a2111111111111997546c10914a7dd6e09e6a26a6d34b26f2eed29506278ec6876b664c87e0fa744b7e012fa43e572c2e1d88bc06dce8300bb8b00e11656c585d4d1f9469ef683adfb099b12470feabe4e1b5040c046e330dfba01bc71bec196519733f0bf8c270e3f6c92e3cc0b003a365f40d5e2ee05de7e68341c86e587098e1ad98cd88b4d636cc6caaa5f839b038cabce2fdb73c9bc9e6ae024e8eb4a10e365469e8d4c056d707f936d70b0d5d37f44af9f3fea693034e583e3960617ff8b7924e0d888888888888c444c50611a9c4bf18fc57351367675b67e2832bcc6c6edca1469a1927fabb07f79d9d6d5dd05be85817793efcabc361c0d1f1a793312072216acee1f93dadc4d76a7d60edb0a66483c73d5358be7a9b4f5d059c966ec99f6ec6a51196fc7c3a9b7fb85868bb624703661f919b1e0c727594eceefcb6d8d9fec9ed7cea46e08c4c36ff6be0f311726e4f3e93cd1ddd5d688f54f8f1cd9b2fb009134e8a74ba61bc141a2a3d3580bdb275af0148f56fdd5f40cd874544444444441a9b8a0d22329c5b0cceab66e2ece6d6a30282a566ec1277a8a498d9dcc0f9e3ec6ceba2de4247a18a253e013c0dd4f406b68c39cf1b5c13755210fac558c4ab7bb6e5fe9701b3f96b562e5fbfa321c5ceb6cbd22df95dcc2a2f8818fc3293cd7d10e3d2ee95ed4f6df9f8ac0f1db3cb8449935badc439511ac43b7ecf0e0a0dafeb2eb47d2193cdcf008eaa74ddedef65bf9c71f0927dd63fb8b4e287dae5d30df9e5403ec2468d587008d9a6e9b04e0d8888888888884825546c10919d594bf9e17864e996dc9966f613c6608f0233db25803fcc999fcff5ac6cbb2dd25cd830d430fa41f43d58deb0c313003b926e5ebc1ff8c76bddd8e1c23585b61d161ab6e81b48fd789789a5af9bb16be5abdbc93827675a721bddec29f001b0030d2647cf69e75434b054fa3aa95477d4f5b766b0e73b260dfe13f0af51e685c6af038f506c88a3d0e06c629b62806f532c78bd38a0530322222222222252477ad025223bb21138ceca575c4492cee62e37ecd43a64da2ec757831580e771f6336361bdf7346ca239b7ce69ce7db6a7ab3dd21be9068f3a5c009c5fa77832fa5c1e7946e0d1e76c4768bebc9271eb1f5cba2993cd758045eb4b006036c5e0a01a9eae6fec29b43d54c9c0ee7b9715d3d9fcb351fb4c6ccbe0eb330e5ef2e328a71b7a56b6dd966ec9bf18a520e338389881bb816d39eeb0d5cf6eafffca0d86bea894b2c70709fbd7153a3644faa244444444444444ea48c50611d991d30c7aa34ecab4e42f0746a4d0e0f05c18869febedeab863eb8fa7b34b7687c12b0dab7b6f8420b0abe7b4e4c39eceb6483d2d0cfec5cba74666d7299a8c1eb7193c1f6542a63977387050ad1bbb13f67656de7fc49d1e4be0da1f779e8b368127b15a8b0db6eb3b266e3e09f88f48f3cc7f03f6cd0af7d8f20f4373b7fa97ad7fdefad7bca9d4bbb32baf444444444444449232e6ae371191583c64e5c6b091645af2dfc546a8d0e0de3f180c7c70db420340b1b0f4f90daf0c2e2e9f78a8bfc0b836ddd25a4d61e30bb18791d1e8d75127786067c4b1b159c4ff0f3036c6b16f54660c461befb1bcf16f04df8a3aa7443c274e76c43c18a8e7fa22222222222222d552b14144b615029f8d3a299dcd9f8471411df2ecc879abefb965876f3b3ff7d88a8d60178d5418b3e0f6f461ad07469a030f50c55dfd32a60c0091fa7ecccae667e0f15d15963978c9f44ac79adb7be2da371adf3dda784bc7b1ab193333d9fc47a3cce92d74ac73f78aae7caa2a5329504f0511111111111169482a3688c8b67e6a10e944403adbba9fc195f50ab45d4178dff0434a778d449437360c6e2d5fe114c9b78097ea11474685df1b447a783cc93923f289849df0499b8fad78f008f443d9c1c6d3f6ce2eaee8cab17d9a17cc040e886d6bf72f469d62c6b5b1edbf8d267f4dc50611111111111169482a3688c8d65e04ce8b32619f43174e056baf539e1d0a025f37dc98555dcb46f45ef37253d8c11b22cd810dc085758a248d6f5994c1b38e3966a243f406cd3b65df9a99cd4e1e6e54ba25f75112ec3132c1bda2aba39a6c42bc27accc8edafbf0e3f78836a9f496ebdde2625336eb1a2511111111111169482a3688c8d67e60d01f65426a42ea3ac366d625cd4e84e1f07bee7bd45153dc09eb9fe60d8635675a72df8b36871f036af83a3e2d8f3278d2c64979332abef6a81286cd7dbb4f5fbab33173b2f913ccecea38f78dccf84aba2577d2ce86ccc9e64fc6f854dc5b3785133e13657c7761f91a779e8d3b07c05303032a3688888888888848436a4a3a8088348c7ee0175126ccc9e64f3012ba56254c1d083cb2b321a581b737c779dd4cc5cccecfb4e46febee6c7b34c2ac7380641fe6ca482b5af93451e5cc16d52589717c269bef71f7cbf1a0ab69f22bab370f4cddd7dc0fc4f8acc1fe75d9372233bb329dcd7dc88ccbbb57b63f0530bb79d1dcc0ec10b0cf191c54978d9dcf01ff16698ef96d60a7c69ea55088d42c5b44444444444464a4e86483886cf1d328a71ad2d92553cdfd926a377378ce09cfa054ca7417da2c0ced1f42f802ee1b2a5ce2bcf7cd3b6edace87d8b995e6099d6f512a655e7e2df5b6ee429b61fe7e879b2a9dbf1d9747196c700dd05bc37e32fa14228d5eb22470a7f2fe0ad1cd36b34b2cf0274a0353ff16c083667689610d5168d8c2b05371fb63269bf74c36efa920f5b459f04b33ab4fa10130b3bd33f373fb4699e3f81f620fe2d1fa7b888888888888888c249d6c10112837a8fd51b429a5f3cd2c6a33e432f7bb364d685abcf6aeb6be2d1feae9ba790db0669f4317febea929f50466bbed6c0933762d354dba7f76f3a28ff5762d5bb5f5e7d2d925bb9b0f5e0c1c52511cc27fece9ec7872eb8f0dbd35bd249dcd7dc3b01f54fcb5bd1e9003322db993bb3bdbff33c2ac4b8858a49051ad33cae0d92f6c6e360b76a957181946c8e1c053950e7ff995d21def7a870d82c5f7ff5ae62a3688888888888848c3d2c9061101b866a8517145f699bf706f837faa6e2bdf604da54faebd6b69dff63efbccfdcb9f7338ad92950cd2a920f574ba257f5d7a7e6e61a625f7bd4c4bee0f46e9ff6056d91debee3f2d16de5c68d85ab1d0fe4377bfafa2b5b65ddab87866b67598d3176f720d117b66c8a8d615657040b0a05e41eacd9d67ddfd21f0a71c8f767554c3b023a28c7eeeb1151bdd7928ce048ea9d8202222222222220d4b271b4404e0ca288353def49d6a3772ec37dd772fffcbcec6143bdb6fca64f315af69c689b89d8845cf3350b24b87df80eb807951d7366cfa14e76ccafd182a18cf462f171cbe12752f197536183c1f658251d72b9462e5ee7d66dc186237f414daeedaf6f39983974c0f27955a0dbe58b73e0b3173231b758e198f53c5f78e1d8740cda1454444444444a461e9648388ac362a7ffb769f4317ee617052b59b197e6725e37c98e6cfb1705fffa7fbdad6563072d5f04376c0ecccbdb30b768d30e32755ef25a3c9e35106eff181055380d975ca121b77ef73fc3ba5c1d2ffec2eb47f717b850680ee0797bed45368fb4db1d076301e7e02f79d16201b81c1d44c4bfe8028731ceb8e39868a0d222222222222d2b0546c10915f4519dc3421f5ad9a76f3b0a21355866fac699f4aa21883958c0badfaef95065327d0747684f16b801d5eeb246346c577ff03bc6b9709fbd52b487c7c6d90f27f2c16daffed99fb97577c1d587767c7ef36db60c6f148059844981f1865b88731377d57cf0611111111111169602a3688c835950e4c67974cc5ed4bb56ce696aae8de79c7f6ae659f4a1836739f4317ee31ecb890480f18dfc2397dc6c14b264798715b4dfbc968f0c72883dd7ddf7a058949ef6baf6efac755f774547252e82d561756bcb891bf1e0aded0bff7ddd927caf8cd9e2ac61c41271b444444444444a461a9d82032bead3288707dc9e0428c280fcdb7e7c4b9cd8b66ec6c4066fee2a30c862d02c4213521f5f5e1c698f1d99a36319bf2ce09a5ca9b50c0ed35ed27a3c1fa2883cded7df50a5233f78d1684c7ad79f8f6ed367dafd4ba4261d3cbaf352d76f7b81fd0c7c6225e65b5e6dea52f3afe526cfbbb1a448b888888888848e352b141647c2b441aed7cbad60d0da6864170fdcc6cebb4ed7d7ece61f9dd3d0c2335acae2d8f7d6376b635bba3cf67b2b94b0c9b5bf346817f22c2e8fb809a1edc4ac37b2eca60a7714f36846667547ba2615beb1f5cbaa9e483c7c5b1563db859357d33e22c9ee86483888888888888342c151b44c6b795950e9c7d446eba991d1dc7a686cd9be2d6936ec99f9e9ebf380d30e3e0259333d9fc472dc5c3663622a71ab64811ac9cd3d27aea9ce6c5b30066cfcbed9d6ece7d3e9dcd3d0176663cbbd8f19983974caf6864f9a7dfc7b3af34a848c506a8ea21f79b38beca9d73f0d28212e1fcd0f9b43b5db5adc9233d85b6dfd49a6d6bcf74ad58e770454d8b384fb9fb0fb170b15b7804f86771febdd66c067bcecc66239dee322ce27feb1d73f56c10111111111191065651a3561119b30a950eb492b5c6b9b199ed0e5c8a3b996c1e28953f1ee7261104165c8e6dc9521f3ea9b410b8aac2e12b8113ea164692b4c96043c4391515aab6c7f1171d3bada7d07ee3763efd5f99c316a53d08eeaca6c867a17fa7da5c3b13125e9422a8aa3f8c87fe856257fb760b20e96cebf5102c33d8b3da6c1306a7ef01547e92c3bd0f8bed3b9b4e3688888888888848c3d2c9069178844907a842d1a0e2bbc403f70fd733ccf8e0474418fc78dd6248d222bd9dbeef51474d31abfeefeb300c17f514dab6576800a0fbde65c5d0c38f445dd7e1f9eeaef67baacdb533bd858e750e0f45ceb493420340b1d0f16410fa4770df586db60916ee1a29539c57a279b4df3b222222222222222349c506917854fde02a4191ee1177ecc87a05a996c3f3eefcd6ddcfc2c2c5a1fb87ddc3531c2e73f7c6eb79e01c1e61f4e38cce22960c2fd27fd7c18177ee52fd567e5b6fd7b207861bd5dbb56c1570479495cde9a83a5625ebe3edd166f8533b2b346cb1aaabbd37c4ceaf3a57536abbfd6676381e5eae762f00776e73f71f871e7ed9022eac652d111111111111917ad2354a22f168bc07dbc3ebad74e0dce6dc6c3722bdcd5b4f0ecf819f5d2cb4ff7627c3cec864735fc1b910b3480f07ebc5ccf6c86417ceea2e2c5f33ec5818745805346c6360a95aa46243c95edba5c9abfbeb3a74ebac782c2c0de0a84ac7bbf1a7aa4255a814fa93a9a0f2eb87dced864ac7a652e14d1e06175717cca39e6ce8afe91225f38b8a85f6fb6a59424444444444446424e86483483ca2debfde087a2a1d580aec907a0689c29ddb065e7d75ce30850600ba0bedbf084a03efc1b96524b25522f4a683220c7fb46e412449918a0d4d6153d5271b028bd05ba05cdcaa98c3fa887122b1a6a0e2822880c3b3958e5d754fc75a8fdca47b681f8bd63fc36a2f46cfab71be888888888888c888d0c90691788ce9930de63e27c606a75573f7ab8a9ded9f8b32e7e9fb6edd002c48b7e42f35e3f43a45ab58603e27c2f0ff55b72092a4c951063ba5c946aaaa8d42c2c14ac796b00d011e65f5ba362b2e31301830b1e2f1e65ef9600077aafcbe16a9f813629b6a79b3c3e0d01aa68b8888888888888c189d6c10894794b7871bc5b057f96c61d8ec7a06a984e3f7442d346cadd8d976863bcbe3cc540d77f68e30bce237b5655489f4b0dac354d53d6102ace2df6f4d56da23d2e21e441b1f51d3e6a6199126181517f2de37efb8696656557eb7c83d7a6ae8b901ee16edd74144444444444424212a3688c4c0ca0da29f4c3a4744953f303366d5b291bb1723edb73d9b37575d68d862a3859fada571b43b2f3a3c04fe97aa4344fbb5aceb3535323aa42684d55fd3e67670a543cd830551960eccff67f44095f3543033ca7833f2958e2da526b6460eb4659f30daf790c07c6ab57b95797f6df34544444444444446868a0d22f17928e9005118547cbd0a50ddc906f76b4a61e97dc5cef64c77a1eded6ea50f395c15799960393e000020004944415419fc87c5fb6fa9f92dff75858e0d1817459ee8dc52fe3adade5d2cb41ddc5d68ff1f4ef88fee5514985cc506018f7095d2a6cd13aabfa6cd689dd39c6f1e6e58fad0e3f704be146569770eaf3a5705cc591471c65e9996dcc9c38ddae7d085530daa6b0e0d6091afcd7b67d57b95371c8dd7f4898888888888c838a46283487cee4e3a40232985e147ba3bdb3fdbdbb5ecf5a6b3c595cb1e2916da3e1712e6a2ac15047e796cb93697ae8932de9d7febee6c5bb0f5d701502c743cb9a17ff3a18eaf8bb29e9955fc96b345b8ea4a469d8a8b0d6bee5dfa522d1b05e6cb66372fda6193f759d9fc0c264cb8139812655d333b689f4317d6f12a253f3ef214b35fcdcee676386feee1ad7ba59a529d98ed566daa30fae9a89a4e3618d59fc61211111111111119492a3688c4a703a8fe7a9d91557163d77d8f3a2ad2034800dccfebedeab863479fee29747438fedbca9662cdaa7b3a62eb89f1ccfdcb9f037faab2bdfdf16267db7776f4f9e71e5bb1d1c3e0b4a819223ea0adedfa296954bb47181be26caa7a27b369a920757fa62577fd9c6cfebbb39b17cd05486797ec9e6ec95d38d1bdc722f476d85aaa29f5f5aa73ed44ba257fba9955d5eb2085ad48b7e42ed9f27502a4b3b979996cfe2761c9fe6866fbd7922d4879a46baddc6becd960547f8d96888888888888c80852b141242643d7125d92748e0a55fc007ba0f4f68adfc0dee235b3df0c3b28f465152d66fe7cd4fd87e36eab861f056e76ed70635e0dfebf7b22070826ec1a61b41e348e4d914e04b851d3e90600cc3e1ec005a920f574269b77a3f47fccec9fa39cb679cb92d8d7e61c9edfb3e66c5b9999cd4ec6fcfc5ad630b333b77c9de5afd5ee05be56cbd7ba451804514f1cd5faeba3ef01222222222222322aa8d82012afff80c8f77927a1e23ffb41a96962d4c5d714da86ed3510e00f54b29679fca745cc2abbfac8422b0c37665da1b0093cd2c90b6b0aa745183e1a7e3f4974911e409b7b4505b2116734052137cf3ae698c8df2776e4ed4cbfdab0e971ad172787fedebbdb23157e0caa3a35f2c69ef67f6b992f2222222222223252546c108991c14bc02792ce51818a1f0ca60637567f7dcb4e6c0a52158d738b768f7c658b7a58c930b3c119952d67518a07a4b028cdb9239f2c915121dac906a8e8eaaf841c30e9d5b75d1fc742e996dcf9c00971ac550f16f1bf433abd642266157d1fd9110ffdd95ae68b8888888888888c14151b446266701bf0e3a4730ca3e207d84fdf776be42b3cf6396cf1bec38d99600c3b0600b72877db57c82a7aabdc09e60f37263d7f71da8c486f610f0e5a7f84e175f8faa501fc7da4d1c61375ca11977c3a9beb9cf5a163aaeb4f90cd36a55b72579ad9f762ce152b775f1d69fc6e83359d6a00688262ad6b888888888888888c04151b44eac0e02ce0a749e7d81927da03f2289a52fed5e1c604ce172a59cb8cfdf63a72494d0d56b7e558738543bfb47776c1cefb2b84e1d99103d84094ab9174b2616c8a5644b2e0c93ae5888d61cd9326bfed89f4fcd6c3a3cc4bcfcf2d4cfbbb1e36b393ea142d4e4f471aed36ab96cddc796955577b6f2d6b888888888888888c14151b44eac4e0ebc0e792ce1107c7a336a7fd7cba2577d28e3e9969c97d0fc857bad8a4c1c16323eebf4399f9b97dcd9859c958339b3a81a64b77f4f939d9fcc9d53c206dda3c394ab141cd61c7a6487fff1657dedcebce40bdc2c4c6d8cb3cb83bdd925bbab3a2c3dcc35bf7ca6473df4c67734f9bdb3233db7f2463562b0cbc10657c601ee9baacb730bfb1a6f92222222222222223a829e900226399c1550ef700a7015f0222dded5f471b87fa4b54ea39229e8430b32b332df9c521e1ad81d9ba12be2970db15e33cb0b951d60adcbe03fc2eca9c1d71e76c8b34c33e9ec9e6f773f75f39b6d62ddc6004b3ccfdab0691be8e2dba1f5c1ae5d7fe0120b6628b348ca857e38456febd90ad4396d899d94771fb68a625b7c1b107cc78dedd9fc72c6d708087cc0088f66731590e7dbd2b3b1e8f36c703abf2ab74f77e0fedfcaa268b8888888888882440c506913a337816f816f02d87e381838143800380a909c5fa5994c1e6b606abe2c1ba717c40703c400aabfec9a2b16fba257752b1b3fdaa2a57006076f3a2430cfb543553cdec47e5f8432fa45b950f10f15511a79c02ac046aba8e451aca7dc045512739bec2b06cfc71eac86c9a0d15cbacca3f330de49e11dbc9fd776189f37aef6b7b7ec4f614111111111111a9918a0d2223c8e016ca3f00f072b1611ab0cbd0cf134720c626838722ce89d414b51eccece7739b17ddb5aa6bd9fa6ae6ef73e8c23d5241d01e77aea8cca3fd5a1aac07fec1611efa9e3d9a0d00eb878a8f5529f9605b934df8518c992492f0eea833cc8387303f0dec2fa1fb86c0d8c3610fb0b76d19e3b01967955bb801c0c3d2ba67ba56ac8b31b8888888888888c888d0832b910419f453fed1d042e3990668f032250c522be7342f3ea6a7ebe6355126ee337fe1dea930b5026cb77a85ab9443a466af4305a903ea144746ce44602f87bdb6fad8a0954f3954e499ae15ebd22db9d566b677fcf1ca1c6e027fd89d27dd7c3070f686e06cb3c63a59e3700516de103a2140ca39c2cdbe6258dd1adf875b158a2bd5ddd9f628f0681de288888888888888341c151b44c61087dd289f90983ef463da563fffdd561fbfdee0b795ae6b565a85a7e20f1c91c12c0bc2ff9e93cd9fd55368fb4d2573e664f39fb7d02f31b3a4aeac7a1337fb63c4294702899fc890fa70788fc1ba08536e01fe29f61cce93a5c1c1e39eb97ff973db7caa005c91cee6bf045c623039eebd23bac3370f7cb178ff2ddb9e1029a4b34b2e761f3cdfcce2fff5c1efeb2d74ac8b3687a5c047e3ce22222223ee0a2b5f6b2922222222c350b1416414187abb7d6fca6f45ef05fc033093371717a23c4cdf4084624371e5b247322db98d984d89b0479dd8b4007e9dc9e6beead8cf37bcb2f9bf9e7b6cc5c6ad47a40f3d7e4f9f30f128c34f33d8afdafe0af5e029bf2be2940fd62588348a8f023fac78b4d14eccc5068735039b5e6d59f3f0ed7d3b1a532cb45d91c9e6a6815d1ce7de91380f7477b67d64479f2e1696f60367a5b3b959862d8c776bbb3ada782652eed123222222222222326ea8d820d220caf778338b7231e1bd5bfdf32ccac58438ed1775829b3d60e5b7ec1b84ed6bf0cb77bd63c22fdfd5925b8fd9b3ee4cc1d8cb60977279a1718a0c00eebeaaf7eef697224ed3154a63db2222141b8a85f6fbd22db9a299a5e30ae0f8b93b2b346cf1f26b4d3fdb6562e96c33768d6bef2842e3bc8ac685e139a920155bb1c161d3e6575fbd31e2b42349fe1488888888888888c8886a806bd845c61787b443dee1028776876e875781ff17e804ae04be0b7c1c3890f80b0d0073bddc94ba62e67e6f1d72c4c36c06708819fb59c4af6b2499714f15d30e8a3d883492791ef5cfb871699c015e79ada9a39271eb1f5cba09f39be2dcbb52eededf5368abe854506fd7b2550e91fabaec7c73da2a29c66c63516cfb8b8888888888888c123ad920522743571f1d44f9cdf4f70373877e348a83803b2a1d5cf2f0ae94a5ce8f3581b3c9cd1fc17914e300c39a635d3f721e5fef460167b299c57ed77ae8ac8814a77c5556c3164f24360b81ab2a1dbce195c16ba64d6dbad8cc6afebde1eecfad7f70e9a6ca67d813b5ee590d83f511c7af85789a5a8741f8a328e3bdfc937a35888888888888c8b8a36283480cbc7c5dc6fe940b0b1f1afa79ef44430def4022141b7abb963d90cee6d61936338ecd1dffe186fec1f3b6eeb730e7b0fcee41e0576376541c7b44c8729f87764e4f577bd7968fcdccb64e9b829d63d83762d9c379b1a7b33d6abf8643e2d85b1ade6222141b9e7b6cc5c6776573570167d6bcb345bbeac73cecc346fe50a4431871fcc6382e5173f77b7a0b1d8f479c7610f5399126222222222222d2d0748d9248151ca63a1ceb70b1c383c02bc0fdc025c089347ea101e0b8e853ec9a587676ff62b1d07ef6b68d9d7bee6d7bbebbb3fd238e77ed686adc1c5fddf75ad3877bbadadeb4e7ba42c78662a1fd6cf7f09838f631f38a1b726f4557b18c0fc73acc8832210c8358ae52326cfa5e472ea9f884448845ca191b8bbaafc773aac1bd9a86d8a7c4b1b7888888888888c868a362834805868a0bad0e97383c46b9b8702bf04dca6fb18ec653420739ec1e654229dc7c65ad9bbad3d5ddd9fe9f3b1b334830620feb3c0cbebeb36b648a9d1dbf77aa2a146cb3915d1b6978f9fbf3d135ef2ba341007c35ca849eae9bd7b873451c9b4fde3c98af74ac59950530f78dc0a3ee1eb5f741795fd8654e365f51ff9239cd8b671956f39575ee3cd9dbd551f1e92f80a1fe1b27d6bab7888888888888c868a46283c87638040e073a7cd7cb27165e06da295f5bb27fb2e96215e95ef167ba56ac23c2d54bdb6370e7706356176eee75fcc55af6a9d4e6d736de37fc28bfbd963ddc7d557767dba311a76551bf86f1e44b43d7b1552c557aed5beede5ffbd676de8c83970cbb77baa5f568c3e64559d9a148c827bb3bdbdfde5d68fb60b1b3fd9d944a19dccf1b2a40549e123fafa271e6917a2cec88bb9d53c5b4d3818971ec2f22222222222232daa8d82032c461bac3890e4b81bf020f031750be377facfe59591c754289f0a25a360c2d5c55d140a7b7967d2adbc3d7af79f8f661dfb40e435f5bcb36e656cdaf99ae501a5f76014e8a32e1e9fb6edde0e6d53c107f133366ee3269b07dcee1f93d773426d392cf9a0537475ad8f98f62a12dd3ddd5f6a69341ddf72e2b7677b6ff4b18da61b86fa838277674269bbb7eefec825db7f7f9d9d9d69999967cbb190b23e5dcbeb69eae9b6f8b32c1cb27dc4e8b616f111111111111915169345efd22129ba17bd2f3941fbacf63ec161576a4d961bac14b954ee82d741432d9fca3949b605721a8f4addffa3758b5cade404ea56c77bcba2d1c5f57ec6aafe61aa6381e98cae8f255e03fa24ce879f784cbd27f193cc5ccd2b56c6cd8d116f2e74c4bee9a92f99501131e355edbdd3db59fc1628c8f4759cfdd6f2a76b67f79a7d9ef6d7b7c7673ebc752667f8890f4e34d4c383edd92bf8cc0ae1dd8b871fdc429930ec0ed0b869d480c5da11dfa4b9b07cfa862ea89c06eb52710111111111111199dc6db8355111cd20eff3cd47be17f536eeadcccf8fcf31010f16d6a0037bfa0da0d0dffe07063e61eb170b75a1f9e569866b73987e587ed5be16ec366def1dce80d661d8e026656bba78c5ab31d4e883463e9d230348fef6d7ab3cfa408561aa557a0e94f66b614b3488506004fd959958c2bf744f0a7224584a9667cdbdcbb27bded6d2f9b07771b165f9f04e73bcfdcbffcb9685308809a4f99888888888888888c66e3f1e1aa8c430efb3b5ce8d00374031732b67a2fd4e2eb1ef17b417165fb72777fa8baedecd4f4a1c7eff0ba16001f0c22bc55ecb7854eee6f84effa1b2fbdad7c1f3ce7569c26d87963de59d9fc0c9cd32bcfb35532f7624f6747a437d58754f4a056c6a48ba2fe79ec2d7414dcfd87f50a14953b4ff6dcd3f66cc5e3b1bbea99270a77ba8a9d6d975531f52460ef98e3888888888888888c2aba4649c6a4a11b6fe651be1e290fecf4e1f63837036805daa24cb2805370fe18753383a9344d5c913978c9fcee0797bee5faa67436772ad8772b592b24fc6a4fa1e367db7cb80814332df9fb30560e9bc7f8763a9b7fa15868fbf1b69f9bd3bc789611de6066532bc9f396b5b1cf469de3e507964755b39f8c097b517e70fd9b28938af6d7efa47dfa9166ec5797545118519bbb3f53971c11b9f32296fa58e479e5ff973abf0e91444444444444444615151b644c197a507b1ae5bbb3b7db4454b6eb2c22161bba57b63f95cee62f33aa78ebdfd8978983ff3bd392bb2934bb36300bdcfd50f0858655f4b0d4dd1fe9e97c4ba1e18d7c9d6d854c4bfe17185f193e0e3f4ab7e44ec1588e71afbbed66f87cc34fa4ca4be0ddfdc7c5cef647ab98aa530d72bec335068315cf2814064bcd0b72299a9eaeb638161bf75da24d0827267dd0d29d30b470496fa1edf92aa67f8572d156444444444444645cd3354a32ea394c76f88cc3fd94df903d13151aa23ac489fe46f446c273ddbd9a8773603605b3cf047027ee7f30f85ea585060037fbd170634a41f8ebcae3d8de867dc3dc9605f0ab5aee80777c75df4053e4fbdbbddc14fb33d5ee2b63c60c18be48b6ad67ba56acb3c0239fa6899fcd8a363e785f7d7254cecdcfed2d741422cf8329c079f12712111111111111197d546c90516ba8d1f3cf81ff0b5c0d1c9270a4d12e72d3e775858e0dee16f9da91386c8607861bd3bbb2e371dc378e449e37b120b7fec1a59baa98793e3039ee38322a5de055144dbb5776b4b9fbbfd62350a5cc983ebb2577508429c7d72d4c051cff6d4fa1bdda5fb37329170945444444444444c63d151b6454193ac5f079878729377afe0a10f1ca0ed981e3bddce722929eaeb62e877fa947a09d99486a4345038d813a47799310be585c797331ea3c2fdfd51ff96d7619b37601aead6662b1b3fd1cc7ab694c1e9b002eac645cba2577a1c11ef5ceb3637e5bb1d0fec9aa66c2fec037630e24222222222222326aa9d820a3c236a7187e0d1c9870a4b1ea27d54c2a16dace032fc49c65a7dc4b470e3766d6614b76059b3612790070feaba7d0f69f55cebe147d4f96373bdae1f3d54c2c16dabf8cfbefe20e5429333b3cd392df69b124dd92fb8199fdf34865da96c3432fbfd6b4b8cab99381a5e8cfac888888888888c8ebd4205a1a9ac3a7802fa32b9246ca010e0b0d96479d180c0ee4c2a6490f02b3eb90eb2dccfc14a06367632605839faab6c173548effbed8d9fee9eae6320f3836e64832365cea709b41e4de28ddbb357d32f3c2e054b064ae29323e95c9e60f08092f0f425b855918423a303ee0ee479b5962271adcfdf14d139a3eb2be50d575670017513e8d242222222222222243f4469e341c87e90ee77bf914c3b5a8d030d27ee0557c6f78fabe5b375858fab0c373f508b52dc38e9e93cd9fbca3cfa75b16cd03bb6824b2e03cda34f16f55bd213de497b16591b1660a555ea7c4d2a561377fcdb9fb55b1268a667640700981dd8db132307e0e7c3ec94203f040d3a4bf1db6f6aea57dd54cf6f2df495f8b3993888888888888c8a8a7930dd2301cd2c059c089a8496e92f606fe19f87ed489abba96adcf1cb6e8c304c1fd58fdaf2f0ae057e996dcfb4a61f0eb57360eac993265f29449563a046309c6a7eabd3f80e3abc2263ed27dc71d5535a276f801e5dffb223b72a4c3f906e7459e59280c16e17373b2ad4f04043f61dcbf64e0b7bcf6b64d8bd7dc7e4755bd5c869a76df1c73281111111111119131619c3f749046e0e57bc9efa4dcf0f9f3a8d0d008ceafa6593440f7bdcb8a8341e943ee1ef9da976a98d9994d29ffe3bbde31e16f9352a517085836628506f7473635351dda7b77fb4b55cd2ff71ef946ccb1646cfa9ed770d5564fa1e367217c24ce40a38fff6777a17dc19adb6fafb6d0d004dc0aec1e6f2e11111111111191b141c506498c43abc37f03b703c336fb951115004b1daa3a9df0cccae5ab07cc3ee8b026e65c8dc3fd8e8df6d7961aae62998ade9096686ef0f2c9a3aaf414daee0ae160775e8c3354c373069df08cee42fb176b5ce9d7940b8422222222222222b21d2a36c88872081c4e70f823d00e1c907426d9a1dd81ebaa9dbca6d0b67ea0943ad8e1a11833350487cbba3bdb3fb2ae50a8b6b92c94fb34cc882b938c0b5381db1d76a976819e42db43a5c1c1f7038fc617ab71b9fbf3a17158b1d071594debc0a9c067628a252222222222223226a9d8202362a8c8f029ca5725dd00ec9b7024a9ccb10edfac76f29a7b97be58e4a5c3dcfd6771864a8cb3090f3f512cb49d51db329c4ab9378948547b01cbbc86ebe69eb97ff973dd85b60f3ae119ee5ed5c99cd1c10baf6de6fd3d85b69a0a9e0e59e0f27832898888888888888c5d2a3648dd397c14e801ae0566271c47a2bbd8e1a8aa67170a83c5cef6af96425fecd01f63ae11e5f8ead0fc83dd9d1dbfab6d1d9a819fc7144bc6a72c706b2d05078062a1e332ac691f77bf319e588dc19d17ddfd73dd85f6f9ffeb81f6bfd4b456f9d7fa0ff12413111111111149c69c6cfe847f9897df2be91c32f6a9d82075e3d03cd493612935dc332e0de16687742d0bf476b5b70dc01cf09a1ed68f34873e773fabc85f333d85f65535ae350b5881bef74aed0e07eeacbde0b0f4f96267fbc74ae62d406f3cd192e14ee870c5460bffa1d8d97e55cdebbd51689858eb5a222222222222490a9cf91352f4a4b3b98bf6f8c0822949e791b14b0fbc24760efb39dc0974a29e0c63c554e00f0ebbd6b2c89a42dbfaee42fb274238d8f1c763ca5647fe9f836c7e6fb1b3fdc7140a8335ad546eb67d2735dcb72fb28d79c4507000e85dd9ded55d689be3ee5f1d9d572bf9efb0f003c542db29eb0a1d1b6a5e4d850611111111111963cc9868d8b7a74d6dfa533a9bd3d5ce52172a36486c1cf672b81e78023832e93c12bb1994af6ea9b902de53687ba85868ff00218b1c1e89215bccfc160b7d4e77a1fd8bab0b2b5eac79b57281e10fc0cc9aa389bcd93ce0eea16256cd8a9ded3f0b9b780f1e7edff197e258b3ae9cff1818e4bddd85f64f140b1d4fc6b324c7022b51a1414444444444c62033dbc3b0ebd2d9fcc399f939f5549558a9d8203573d8d5cb77d03f037c3ce93c52570702f7c6f560b3bbab6d79b1d0f621423fc2e1ae38d6ac853b5d18877617da17acea6a8fe54a1987e9c0bd947fed44eae110e0318fa998d57b77fb4bdd9d1de7160bed7f07fe59c76bba3e2c7ebe3674bef55a29f5eeeeceb62fffe9beb6b5b1ad0c6752beea4c4444444444644c3338d0437b22dd92ff65e6e025d393ce23634353d20164f41a7ac3fd1bc0d994afd991f1617fe07e87c30c6279f3b9bbabfd1ee09e3987e7f70c4ae117c14ec26c461c6b0f23c4e9c27ca9d3d456ec5cfa7c9c8b3bec4eb9d0302bce7545b6632fe00987e30c1e886bd1ee42fb35c035739b73b34bc6f1862d30f343c046f4ff1fdcbddfcc6ec4f875f7caf6d8bebed7d72fbf7cf14be0e4b8d716111111111169546604c09798347842ba257f6e71b7d42f58ba344c3a978c5e2a3648645efe7d7332703eb05bc271241969e061871683e7e25ab4e79eb66781738173332df92ce61f7668366c5e5c7b0cf58ab8c7cd568603835dcfdcbfbc3faeb5dfbc0f3329f72dd9b31eeb8b6cc734a0d3e1930637c6b9f0d0499f5ee0877b1db964978903834706c6a198cdb33a9dda717804f7bb0cbbb3d8d95ea8c71e43fb4c056e068eaad71e2222222222228dcda6997169e685d269a5f9b9537a57b677259d484627151b24122f377cbe16989d741649dc2ce04187c5068fc6bd7877675b01286cf9f7d9f373cde6be5f40f07e87b9c0beb6bdc6b8ee1bdcd860d0e7f02258d1dcff189aad7a95979e5c57286c8a3beb5b22c041c0ad94af501219494dc00d0e2dc0d70d06e2de60ed5d4bfb80b6a11f00a4b3b979c05c8339eecc35632e58a5c5e8f5eebedab0d58effc9e129b3a6878a85a57529046ecdcb7f972da5fc3d45444444444464bc9b9d72ebcc64f36dafc157d714dad6271d484617151ba422436f7efe003835e92cd250f6a47ca5d2d9063fabe7464355f586afac3b9c04fc0a7d7f95647d05c83ae40c56d77bb362a1fd3ee0be7aef13172ffff40de042d4085a4444444444645bf949ceb1e96cfedf37f2d24523f1e2a68c0d7a1826c372f8287009b047d259a4214d042e713802f8b4415fd281923074e7fb25c0e94967111992a6dcc7e13483ab920ed328bcfc77d9f54073d259444444a22a05a58bcd836b93ce21150afdc57a2cabdf07a38b9752b1f43adcd66bc12bcf1bd3e6d7636da98fc027d4fd45b05819930dbe3785e92765b2f9b3ba0b6d37251d491a9f251d401ad7d003995f02c7279d4562d507bc08ac0706877e0c6cf3f3f63e36c0f057b2fcd9e037f589ddd81cb280fe474f1ad5528355498768040eff04bc33e91c2222326afcb7c12d4987101111a945a6257f3956f36d250f6cc6beb0ba70736f2ca1644c52b141b6cbe14ccad74b4c4d3a8b0ceb49ca0f11ff046c1cfad1bfcd3fbf04bc68f07c5221454444444444444464e4c5546c0008ddf9c5a609a97386faf989bc89ae519237f172d3dfeb29378296c63148f9def555c0d3433faf02d61a844906131111111111111191712130e3f4c983831f4fb7b49e53ececb822e940d258546c1000bcfc7be19f817350b3cc2485c05aa0c89b0b0bbd562e3888888888888888888824c6b05d31fb65269b3bcd2dfc6271e5b24792ce248d41c506c1cba718ae0566279d659c59cf1b2714b614158a069b124d252222222222222222322cdbd73cf570ba25ff5b0f39abe7de365ddf3dcea9d8308e394c062e02be96749671a00b788a378a0a4f59b997828888888888888888483dd5f50a6e334eb4807cba257f41b1b3ed5febb9973436151bc6298779c075c09e4967198342e051e02ee06ee03e838164238988888888888888c83815d47d0763b2c185e96c6e71882fee2d74acabfb9ed270eaff1b4d1a8ac354875f01f7a242439c56013f031601ef34f890c13906f7a8d0202222222222222222e38161fb07044fa79b5b4f483a8b8c3c9d6c18471c8e06ae04764f3acb18d007dc44f9e4c21d062f269c4744444444444444442471065309821b322df9056ea92f170b4b7595f838a1930de3804393c3e5c0eda8d0508b6781cb80238077197cc1e0b72a348888888888888888886cc3f8140c3e3d7b7eebfe49479191a162c318e73013780c3835e128a3d52ae0fbc0070cfedee08ca1ab91eada5847444444444444444464b4336c662a0c1e9ed392ff66d259a4fe748dd218e6d00a5c0dec92749651e601a01d6833589b741811111111111111119151cb680ae0e24c4bfe186b1afcd8aabb97ff25e948521f3ad930060d5d9bf473ca0fcc5568a8cc5ae05f289f5e38d4e0872a34888888888888888888c4c4c886a554f79cf9f963938e22f5a1930d638cc39e948b0cba0b6d78fdc06f81eb0cba920e232222222222222222329619b6ab39b7a65bf2970d4c79f5ac35b7df3e907426898f4e368c210e47034fa342c3ce84c06dc0c780bf33384585061111111111111111919163c6e9935e9dfcdfb3b2f919496791f8a8d83046385c00dc8eae4dda9175c0d9c0ff3038cee04603554e4544444444444444441261fb4ec4ff986e59342fe924120f151b4639875d1d3a81ef269da541dd011c07bc67a80fc38b490712111111111111111111306cba59b0724eb6f5cca4b348ed546c18c51c0ea47c6d5273d2591a4c1f228dbbed00002000494441547019f05e838f18dc66492712111111111111111191edb0a680e0924c367fc3ac638e9998741aa99e8a0da394c389c0fdc0ee49676920ab813380ffc7e00c83b54907121111111111111111918a9ca03e0ea39b8a0da390c345c0754053d2591ac4ef810f1bec637099c1c6a4038988888888888888884854eae3309aa9d8308a384c76b815f876d2591a441b903138c6e0aea4c3888888888888888888486dd4c761f452b1619470d80d78103836e92c090b81df513ec5b0d8a09874201111111111111111118993fa388c462a368c020e73812780fd92ce92b06b2817193e61e5fe0c222222222222222222b27361d2016a70c2c48d6f7b78efc38fdf23e920323c151b1a9c4333e5130de3f50fd4007005f0f7069f35589374201111111111111111915164543f033663bfa6d284c7f6ce2e9e9d7416d9b951fd1b6dac73c8039dc0d4a4b324e417948b0ca7183c9b7418111111111111111111197966b6fb04c207d387b51e987416d931151b1a94c3a9c0cd49e748c803941b3f9f66f07cd261444444444444444444246936cd82a0737673eb51492791ed53b1a101395c0c5c9e748e04ac0396181caac6cf222222222222222222f226c6e45460b7cec9e63e9e7414792b151b1a8843e0b014f866d25946d846e05ccacd9f6f4a3a8c888888888888888888342a6b32e7fa74b6f5f4a493c89ba9d8d0201ca6007f003e9a749611f63be0bd06dfb7723368111111111111111111911d32338ce0d24c367771d259e40d2a36340087e9c0fdc091496719414f011f32f884fa328888888888888888884874f6cd4c3677357acedd10f41f21610e7b02ff0dec97749611d2079c06bcdfe091a4c3888888888888888888c868669fc96473cb661d73ccc4a4938c772a3624c8cb0586c780bd92ce32426ea2dc97e1179674121111111111111111111923ecf849afbe6de5cc6cebb4a4938c672a3624c4617fe05e60d7a4b38c80f5c011064b7465928888888888888888c8c8d99c1ab8c0f1df279d63041cf276ac73efec82f1f0bcb521e905f30438cca5dca36197a4b3d4d920f053e05c834d498711111111111111111119afd2d9fc4986ff046c4cbffdeff8ea41060f5d5d58f162d259c61b151b46d850a1a1937253e8b1ec71e0d306c5a48388888888888888888808cc3d62e16ee160ea6a333b3ae92cf5e4f8ea20553a6cd5ddcbff927496f144c58611e4309bf28986b15c68e807ce32b822e920222222222222222222f256e96ceba7f0e012b331fc9cd2596b4d8307abe03072546c1821438586b1dea3e15160b1c1b34907111111111111111111911d4b6797ec8e976e30a339e92c75e3acdd9c1a386cf53db73c977494f140c58611e0300b7890b15b6818042e00be6f10261d464444444444444444442a9369c97dcd8d8b0d9b9874967a707876301838580587fa53b1a1ce1c66522e34ec9e70947a594bf934c393490711111111111111111191e8e636e766bbd18ed9eca4b3d483c3b31e7058cf3d6dba91a58e82a4038c654385867b19bb8586df00ef53a141444444444444444464f45ad5d5defbda944def07ff45d259eac1604f0b7970cee1f93d93ce3296e964439d38cca07ca26146d259ea6003f069835b920e22222222222222222222f199333f7facb95f6dd898bb12dee1b9cd831cf6a7fbdad6269d652c52b1a10e1c76a35c68d82be92c75f0089033d01d6722222222222222222263d0de871fbf475369e2ad66ec977496f8f95f2cf08357ddd3a18243cc748d52cc1ca6022b199b85861f0387aad02022222222222222223276adbee796e77821f521872b92ce123fdb2d2c052be71eb170b7a4938c353ad9102387c9c0ddc021496789593ff04983e5490711111111111111111191919369ce9fe8815f69d8c4a4b3c4c9f1551bf1c3d6153a36249d65ac50b121260e4dc0adc051496789d92a6081c1baa483888888888888888888c8c89bddbc686e60a95bcd18530d96ddfd918df6d7967585c2a6a4b38c05ba46293ed731f60a0dd718bc4f8506111111111111111191f1abb76bd9aa4d1352ef73f7df279d254e6676e014ded5ce92257a4e1e8354d201c602879f0327259d236667197c2be91022222222222222222292bcbfae2dbef6c29f7baf7bf7dfcfd90ccc371b1bb7e618366bb78de17b5e58d7db917496d14ec5861a397c1bf84ed23962d4071c6fe5931a22222222222222222222af7be1cf3df7ee3a73f60340de6cacf471b0f7eff6f7fb34bdf0e7de95492719cdc644f529290e9f02ae4d3a478cd601c718f4261d444444444444444444441a5726bb709693bad3b0990947898d7b784ab1b3e38aa4738c562a3654c9e170e04ec64edf8b2e609181baaf8b8888888888888888c8b0de37efb869616ad2ad1887249d250eee84eeb6a0a7ebe6db92ce321aa9d8500587fd817b8129496789c92f0c4e4b3a848888888888888888888c32d9ff9fbdbb8fb2eb2aef3cffdba5b22214c55114a1e5a815b910b22ccb8a0063dc60c016e6d5bcda023784bc9034094392ee218445b21886b0e8a43b4d5e9ab032e990e9a44308740804cb388049064c611b428ced1863c942d8a6101ac7231b631c4728a2547bfe38b750a974dfefd9fb79f639dfcf5a5eb2e5d2d98faaeebdfb9ce7d9fbd9bba777e887fe3c28bcda3a945a441d5b58d0d3efbaf1eadbac43290dc5861145698ba42f4a5a671d4b4dde12a4ff6a1d0400000000000080729d77e99e5f0dd26f85507e2798a8f860d089a7ed9bbdf66eeb584a42b16104b12a307c5155c1a1095e13a4f7590701000000000000a07ce75df2f2174e85850f2b84f23bc244ddfb9d33563ce9de4f7df811eb504a517c952997587daff6aa198586e3aa0e82a6d000000000000000a01677ddf0914f2c04fddb18e37dd6b14c2c68cbaaf9f9bd22873e34be51c37ba7a44bac83a8c123922e0dd227ad0301000000000000d02c77cdeebd736afac493a262f1671e0485cbcebff4cadfb38ea314b4511a4294f648fa88751c35b85f55a1e1a07520000000000000009a6bc7eeabd68478e26f1574b1752c938bafd937bb972e3103506c18204a3b25fd83a4d2fb8cddabaad070d83a1000000000000000cdb7e96957adfac1ef9bbf4e0abbad639948d47c5c5878fafe1bafb9d93a14cf2836f411a533257d59d266eb582674bba46707e921eb4000000000000000b4c7d6cb2f5ff97d47577d5c213cc73a9649c4a807e3827eecae1bafbedf3a16af38b3a187ce81d01f51f985861b243d9d420300000000000080dceebeeebae3fb3ebbf7b98afa98752c930841ebc38af871eb383ca3d8d0db3b24155d6d93744da85a271db50e04000000000000407bed0b0f5da9a86bace3984450b8e0fc4bf7fca1751c5ed146a98b28ed96f419eb3826f449492f09d2bc752000000000000000a0abae9a3aff81f90f48e155d6a14c222e2cbc72ff0dd77cc83a0e6f28362c13a58daace6958671dcb043e29e965413a6e1d08000000000000002c75fea557feb942f869eb38c616e35185134fd8377bedddd6a178421ba525a2342de96f5476a1e17a516800000000000000e0d4becfee7d8d62fc13eb38c616c2ea18577c7466f7ee55d6a17842b1e154ef947481751013b85ed28b283400000000000000f06cdf67f7fe7c94de6b1dc7b842083bbe5feb38bf618915d6017811a5174bfa03eb38267093a41704e99875200000000000000030c80373777d74c3ccf6ed52d8691dcb989ef4d89973ef7960eec01dd68178c0ce064951da2ce92fade398c04d929e4fa1010000000000004049f6e95b3f25c58f59c731aea0a93f3ef79297cc58c7e141eb8b0db1fa65afa435a6818cef66558586a3d68100000000000000c0486667e7e391e9974b71d63a9431ad5e11ced8bb63c7552bad03b1d6fa6283a45f55b9e734dc2ce9d9141a00000000000000946afffe0f1fffd63fcfbf4851b758c7328e10f4c4f0d8f9775ac7612d580760294a3b24edb38e634c77487a7a901eb50e04000000000000002635b3fb8ab5dfaff05929ecb28e651c0bd273ef9abdfa53d67158696db1214ad3926e9554e20bf73e494f0ad211eb4000000000000000a02edb9f7de5baa979fd7d08619b752ca38a8a0fce6bfebc83b37ff3a0752c16dadc46e96d2ab3d0f0a8a467516800000000000000d034073ebdf7a113f3279ea5180f5bc732aaa0b07e5a67fca5751c565658076021564586ffa5f27676cc4b7a6e90fed13a100000000000000048e19bdff8ca3faf3bfb9cbd214cfd6450586d1dcf2882b465fdcc79df7e70eeae2f58c7925b69c9f6894569a5a42f49da6e1dcb18ae0ad25f5b070100000000000000a99d7fe99e0b63889f0b0a2bad631949d43185f91fdb377bedddd6a1e4d4c6364abfa5320b0d6fa5d000000000000000a02df67df6ea5b14f513d6718c2c68558c2b3e601d466ead6aa314a58b25fd89751c63787f907ec53a0800000000000000c8e981af1fd8ffd899f3a68274a9752ca30821fc9b0d676ffff6035f3fd09a764aad69a314a5d592ee92b4d93a96115dafea9c8605eb4000000000000000c0c28e4baffc7008e115d6718ca465ed94dad446e9f7545ea1e176492fa1d000000000000000a0cd8eaf3ef6138abac53a8e91b4ac9d522b8a0d517a8ea4d75bc731a243aa76341cb50e04000000000000002cdd7ddd75c7ff7561c5e58af1b0752ca308215c74fea557feb2751c3934be8d52945649faaaa44dd6b18ce098a4a704e94eeb4000000000000000c08bf39ff9b21d71c58a7f08d21aeb588616752cc413e7dc79c3478b2a948caa0d3b1bfeb3ca2a3448d28f5368000000000000008053edbbf1a3fb43082f8fb1a0d6f341ab16c2d4ffb00e23b515d601a414a56d92deafb27670fc6e90fec03a0800000000000000f0e881b9bbee593fb3fd6808e179d6b10c2b84b075c3d9db6e7de0eb5f39681d4b2a2525e14716a5bf97f454eb384670bdaa731acaa9ca0100000000000080811d97eef978087aa1751c438bf1f0b78f4f9f73f8ef3f7ccc3a94141adb46294aff5e65151a0e4bba924203000000000000000c76342cfc84aabc6a1942d874e6f7cdbfdd3a8c541ab9b3214a6b257d4dd5af25e040680000000000000018d18e675e715158113e278569eb588612353f3f357ffe573e736de3da29357567c3efa89c4283c481d00000000000000030b2fd375e737394de661dc7d082a6a717a6ffcc3a8c141a774074942e90f4c7d6718ce0b783f47f59070100000000000000257a60eec04d8f9dd97e4950789c752c4309fad10d679ffb9507be7ea0510bd01bb5b321567f9f3fb78e6304d74b7a8b75100000000000000050b279cdbf324af75bc731aca8f0ae8d4f7ec96aeb38ead4a86283a4ff2069a7751043e2406800000000000000a8c1c1d9bf79508a57c55846be358470d60ffdc0198d5a88de98364a513a4bd23592565ac732a49705e92bd6410000000000000040133c3077e0d08699f316147499752cc3888a4f7decbfd9fabe07be71f0dbd6b1d4a1493b1bde2d698d7510437a4f9066ad83000000000000008026d9f7d9ab7f332a5e6f1dc73082c2ca30bdf2ddd671d4a511c586285d26e9df59c731a439496fb20e02000000000000009ae85f8febc7638c8f58c73194a02bcebb64cf25d661d4a111c50655bb1a4af113413a6a1d040000000000000034d13d9fdf7b4421fe92751cc30a21fe91aebaaaf85c7df17f8128bd5ae51c0afddf82f479eb2000000000000000a0c9f6cf5ef3fe18e327ade318460861c779474ebcde3a8e4905eb002611ab62c93d92668c4319c6bd92ce0bd271eb4000000000000000a0e91e7ff1951bbeef8c7057085a671dcb60f1c8bfe85b67cfcdce1eb38e645ca5ef6cf84595516858907415850600000000000000c8e39ecfef3d12837ec13a8ee1840dabe3ba5fb18e6212c5ee6c88d26a49df904aa84ae9bf04e9add6410000000000000040dbecd8bd676f90aeb08e6390283d726c7ac58fdefba90f9771b8f53225ef6cf815955168b843d2dbad830000000000000080360affbae2b531ea21eb380609d299abbe3bff36eb38c655e4ce86581519bea16a778367f3927e2c4807ac030100000000000080b63a6ff715574c696aaf751c8344e9d8d48af9b3effcf4b547ac631955a93b1bde2aff850649fa6d0a0d0000000000000060ebaed96bae518c1fb48e639020ad8a2756fc67eb38c651dcce86286d94f47549d3d6b10c7058d2e339141a00000000000000eccdecbe62edf72b7c450a1bac6319e4c47c3cf7c04d7b0f5ac7318a127736fc86fc171a24e9e7293400000000000000800f73b3d73cac85f046eb388631351d8adbdd50d4ce86286d937497fc1749ae0dd2cbac8300000000000000009ceafcdd7b3e27e962eb380639b170e2c70edcf0d13bade31896f7a4fd72ef94ff988f4bfa25eb200000000000000000a7fbaec26b15356f1dc72053532bde651dc328bc27eebf274a174abac23a8e21bc2354e73500000000000000009c3938fb910331c4dfb58e6390203de7fc4bf7ecb68e6358c5141b24bdcd3a8021dc2be9b7ad830000000000000000f4f6f03fcfff468cf17eeb38060af1edd6210cab886243e7ac86975ac73184d706f9df7e03000000000000006d76dfad7f73742196d00e3fec3effd23d175a47318c228a0d927ecd3a80217c2848b3d6410000000000000000063b70c3deaba3e2f5d6710ce1add6010cc37db1214aeb25fda4751c033c2ae90dd641000000000000000086f7ddf9f0f351f1b8751cfd44c52bce7dd64bb759c73188fb6283a4374a5a691dc4006f0b92fffe5e0000000000000080eff9ea4d57dfaba8ff6a1d473f21044dc769f7dd7f827500fd44698da47f52f5ab5787253d8eb31aba8bd29724edb28e63486f09f2fdc1d24d94b64bbacb3a8e113c2648c7ac8348254a9f91b4db3a0e499f0cd2e5d641a410a59d92be6c1d4746473bff3cbae4d787241d90748fa4bb25dd1daa5f1b2b4a0fa8daed5882d704e97dd6418c2a4a9749fab4751c437a38483f641d444a51faaaa4add671487a6f907ed63a8814a2f40249d759c791d1e21cb2743e39a293f3c94155f3c961b3081b2e4a67a97abef5e06783f45eeb205289d25fc8ae43c26d417ab2d1d8ae45e90f25fd62e6610f05e9ec14178ed2af4a7a678a6b4392f49b417a5bafff19a58d92fedf8cf16038ff2948c51c66bcd4cceeddabbe3faedba7a02dd6b1f4b370423f72d78d57bb5df43e6d1dc000af93ef428324bd954243639c631dc098dc6fa16a998bac03e878aa75000995b02baf4eab3bff2c4fb4bf60e97f44e9b8a4cfab2a785d2fe9e650fd1ef23bd73a8031319f3811abf7bc874283245d601d006ab3389f6c58f6fb2f5dfa1fb12a68cfaa2a3e5e1faa6204eae1e9fdf42435b8d80000c0a8e666678f9db77bcf5ba6a4bfb28ea59fb022be49d29bade3e8c56dc2265685903759c731c04149efb70e02b52935c9e22519d17a51daa2ea21de83b59d951e4db4601d80532b55edaa7987a41b257d3b4ad745e955a651b553a9f349a945f726bad03a80254ad9a18afaac93b447d50ae4bba2f44094fe2c4a2f348eab099e681dc0129e620100c085bb66affe9014efb08ea3afa8d79ffbf497ba5d9cefb6d820e9d5f29f28fbb540d2ab494a4d0e95ba82b6893cad56939afb10e979eef26495aadd0f7f19a56f46e90fa2b4d63aa8099434df965a042e691e2ce9f5300e579fdfd1dffc86bcd64bfa19491f8f5521fb2fa2f41ce3984af514eb0096f054d40400c08d8510de621d433f2184352ba6a7ff77eb387af19cb079ab750003dc12a46bac8340ad3644ff6dbbba292939d474de7ab3921cc2a27592fe83a46f44e99db19cb30f96f27ccfb2dc0eeb00c654d27c52d2eb611cdee61357c50f983a53551ffcff274a9f8b24ac47e5e9de6c7567572e000058e2aecf5cfd8918e3cdd671f41314dfb0f5f2cb575ac7d18dcb07b5ce616dde1f78df681d0092f0febaeba6d415b44de4e90152aa7af1024bad517590dd03517a57f4d3f6ab6956760e012d4d89736053319fa004174bfa62ac76d0cd5807e35d6777e166eb3896a190080040173106b76722489242d870c6771ef393d66174e3b2d820e9d7ac0318e0fa20dd641d0492282ad112ab1eed9bace3c0f778391c7a110f90e8e797257d855618c994369fb0bad589ceb965de76c7782b7ec09757a93adbe175d68138e7f17de46d171500002edc75c3d53744c54f5ac7d14f88d1e559c7ee8a0d51daa9ea804bcfbc174330bed276096cb70e009558157dbcf5c3dfc2ca750cb049552b8c3f2bfc3c078f8a2a36a8bc789bec02f9bb47a7788d415649fae328ed2db42d690e1e8b0dbcb70100e82104dff9df10c28ef32ed97389751ccb797b9091fc27f2af0ed22dd6412099d20e5b2639e487d787357a2963183fa36a55aac744c8a2d20e043ec73a801195566c2fedf5300a8ff3c9ea58de6b0436ae90f465e7f389158fbb08f8390100d0c3becfecbd43315e6d1d473f53537a83750ccbb92a36c4eac0b17f671d471f0b925c9f488e899596bce7c1df0faf0f6b1e9356f0e92c493776ce4df2c8d53dcb104a9b4f4a2bb697f67a1885c784a4e4779e833f33aa0e8fa64ddfa93cbe87ce6267230000bd7d374cbd3546bf0b9d62d4153b2f7999abf6eade1ed4febdaa1ef45ebd3f4807ad834052a525ef4b4b0e3599d7e490d7b8e0d36a491f8fd2ebad036980d28a0da5c5db641e13921287446334ab24fd6d945e6d1d88079db6965e3f67bd9d390600801b07673f722028bedf3a8e5e42d0d44258f14bd6712ce5add8e0ea9bd3c5dbad034072eb0aeb33ebf5a1a58dbc2687d8d980514d49faa328fdba752085f376c0ef20a515db9bcc6bfb3be6138c6a4ad207a2f42bd68138e0f9fde3f51e16000017425c78ab7cb7717dddd6cb2f77b378df4db1214acf90ef07ddab8334671d04b228294144b1c181cef67357dbd696d819a569eb2050a47744e9a7ad83285994365bc7308c58dd0f6eb18e0352947659c7d0c753ad0340b17e2f4a7bac8330e639a1cfae250000fab8f3868f1e8e31becf3a8e5e42d0ba954757b9d94deaa6d820e97fb30e6080dfb20e00d91491c0efecc0586f1d0724f9de7e3e25dfc92bf8f6a7d1f7ebdbbb22e6139513671b784e48ae8dd5d92ec038fe224a3bad8330e4b9ada5e75d170000b83015f54eeb1806f805eb0016b92836147030f44d41bac53a086453ca3908dbad03c0f7787f48f31e1ffc9a5675860309c6f178deb1b914c5063f3c272425dfc510f8b67826d099d68118f1fcded9d63953020000f470e70d7b0fc4183f691d472f21848bce79c61e17bbd55d141b24fd8c7c1f0cedbd7a857a911cc2a8bc2787bcc707dfd64bbace3a88429d631dc0904a99f7dac07b71d87b7cf06db3a40f5b0761c4fb2e53dedb00000c10a27ec73a867e564ec7d75ac720f92936fc47eb00fa3828e963d64120ab5292f82487fcf0bc5a4de20112937b2207468fa594f9a4941d7d6de07d3ea1b73b26f5bc28fd9c75103945bf87be2fc5bd22000003ecbb61eff551f176eb387a0b2ece5c342f3644e962f94e9afe56b08e00b9911cc2d03adbce3d7f86493c40a21e6f8bfe5febde94329f941267a3c5eae7e0bd9589f76208caf07b51da601d444625bc6fd8050b00c010c242f0bcbb61d37997ecb9c43a08f362837c1f0cfda0a4f75b0781ecd614f2004472c8871256abad8ebc5e30b969491f88d65194656bf471af35089f0f3e949090dc426f77d4e04c497f6a1d444625ec0862610a000043d837f5d087241db68ea397a9a9f853e631580ede3920ec5596310cf03b419ab70e02264a48bc7040b40f252487241e22518f8b24bdce3a88824c499ab10ea29f28ad92b4d13a0e482a67657129f31e7c7b71945e6c1d442625bc677615521c0700c0d6ecec7c94de651d462f51e1554f7ef293a72d63b0bea17895fc1e0cfda8a4f758070133ae8b0db13ab0758d751c9054c66a35a99c38e1dfdb63b5cb01c3713d9fc87f7c6d524242522a274ef8f776eb0052eb24f04b78cf4c4bda691d0400002538f1ddf9ff3bc6f8a8751cdd0469cd77d66cbec23206eb62c32b8dc7efe73d417ac43a089839c73a8001480ef951c203a4544e9cf06fa37cef4af4c6fbe7b5f7f8daa494cf698ad7a8cb8551bacc3a88c476a89c023dbb60010018c2573e77eda30a7e17a80785d7588e6f566ce8acccf67c73e9764b0cb2f09e7cf11e5f2b745677efb08e63481759078046791b67370c8de235068ad266496bade3185229451194e1add6012456d2fba594566e0000983baef06e29fa6cbd1ff4c21f7bc68bcc9e2d2c7736ec311c7b904f04e93eeb20606aab750003784f5eb5c505b2df2136acb591beeca8cf36492fb50ea210de93f9cc273e949490dc492b35d4e8b2285d681d44422525f0d9d90000c090ee9ebdfa708ce143d671f430b530bdf2d566835b0d2ce92ac3b107f91fd601c09cf7c397bd27afdaa2a4e490c44324eaf5c6cce32d641eaf2ede8bd7a5ce27a5be1e7a29292139a57276f5a10c6fb00e20a192eebd9a5cf40100a076c171fe382afc94d5d826c586586d13f7da42e92149d75a0701732ba3b4c93a883e4a4d0e354d697dab4b7ae0857fbb337f4e96b28b68b92dd177eca5ce279ebfa7e328ad784d5212757a4594d65807914849ef95d551da621d040000a5d8f7d9ab6763d49c751cdd04e9a9e73d73cf5916635b3da8bdc270ec41fe24346fb51cc6e37935aaf79d176d515a72a8a495b328c34f5a0750089709fd4e726fbd751c9054de7c525ab11dbead92ef16bb6389d5b3c46aeb3846c4c2140000461083fed43a865ec2945e6131ae55c2df730ba53fb40e006e784d0e6d94b4d23a8eb6ebac542eed81acb478e19fd9d6ccc2782d5e53b876204a1b2499ac3a9a00f309ead6c4f9a4b422a24421110080912c7c77fe7fc618adc3e82a482fb718377bb1a1d342e939b9c71dd20d413a641d04dc38d73a801e5c16415a68a7ca3b20734b2c6f851d7cdb11493a0ec3ebe7b6d7b8daa6c484648931c3b7e7740a6f4d52e28e52dedb00008ce02b9fbbf6be10c2df59c7d155d025db9f7de5badcc35aec6cd86334ee30dc1eec01135e57a2921cf2a1d487b1927a07a30c3f6e1d4001ceb10ea007af45f5b629713e591dfdde27a15cafb20ea0662516e34b8c190000533146aff9e4a9a913e1a5d907cd3da0a4571a8c398c47247dc83a08b8e235a94f72c8871257ab493c44a27e2fb00ea0005ee713af71b54da9f349894512f876b9750035bbc83a80316cec7422000000437acca387ae91e2c3d67174157565ee21b3161b3a07117a6da1f4fe201db70e02ae784dc2b092d0875293f6f4e245dd7635b0f545dd984fd04fa9497be613d4edb2585e8bcaaea2b449e526ed4b2c92000060e6d65b6f93c4439800002000494441549d97f43eeb387a78c1a6a75db52ae780b97736786ea1f4c7d601c09da928cd5807d185d7a455db949a1c2a356ef8e6752181179ba2b4d23a882e3820da586705f18c751c632ab5e80ebf564a7a8675103529f97e8bf736000023faaea6fec83a866e42d0ca1ffcbe132fce3966eec4ffcb328f37ac3b837487751070c96362df634cad12ab9f41a9072def6ccaaa41b8f27ceb000ae0eab3bbb31b658d751c283aa9577232157e35653e29b53d9a5476ec0000983838fb910351f136eb38ba89995b29652b36c46a2caf7d9dffd23a00b8e5aac54467a785d7dd416d527282654ad22eeb20d0385ee7774f5c151be46c7e6bb192e7930d513acb3a08344e5376ca95fcde2eb9080a008019bf0745c717ebaaabb2e51273262d2f96df95c05efb6ac19eb7c398bd25abdaaaf4155f3c44a26e1ba2b425f1180b89af9f9ab7e47ee9f349e9af8745a59f7b40f11a75bb30fa7d661c45c9f75adb1af233000020abef047dd03a866e4208679effe042b6051d398b0d97671c6b14b705e9b0751070cb5b32c65b3c6d55f26a35a9fce4167c4afdbe287d5797b7e2b5b7784655faeb61d185d6014ca8f4f8e153c989fac5b3583659c731a1a27f06000058989bbde661c5f877d671741517b21d6d90f341cd6b8b055a28a11f6f2b514b4f0e3545e9c586d2e3874fa5eff849cd5bb1d85b3cadd359395cfacf81e2355228fd3ee522eb006a40b101008031c4a0bdd631741363785eaeb1b2141ba2b45e7e6f1a5d6e71811b5ba2afd593de8a1fad13a5cdaa56ac958c0748a4c0ebaa3f6f9fdfdee269a327cad73dc63878df2385d28b585e9f7b4751facf000000130b2bf4a118a37518a709415b773cfdc59b738c95eb01c7ebae862fd04209034cc95742a6f415904dd08407c8d5d1d7eb1acd40d2b1bfb3a2b4d23a8825b65b078046bc67b6d2db1d0994fede68c24ebf26dcef020090dd814fef7d2884f079eb38ba8967accc726e43ae6283d7f31a68a18461b848ca767658cc58c781463c404a3c44a27e674569837510ceedb40e409262d54bdc53e1a3ad984f80ee7639db593caa26bc274aff19000060264a1fb18ea19b29e9f999c649abb371e4c5a9c719132d94300c2fbb09b68a9b7e0f9af00029b13d1e6994be1a353517c56bf989a3ed9a329ff0be47dda625edb00e621c515a23698b751c3598969302390000a559d0c2d5d6317417b39cdb90237179a1a433338c33aa1b8274c43a0814e11ceb003abc143ddaae294995a6fc3de04b13122c2979f91cf712476bc52a91b7cb3a8e9a346587067c29753e694a1151e25e110080b11c98bd662e2ade6e1dc7e9c2daf39eb927f9bd4a8e6283d7f31afeca3a0014c34b52c64b1cadd56911b3d13a8e9a3cd53a0034d2e3ac0370ee5ceb003abcc4d166bbd49cdd8a242491c28c7500636a52b1815db000008c2944edb58ea19ba91531f9b90dd3a90790dff31aaeb10e00c5f092e4273964af490f906ba3745690eeb70e048d32631d80735eda177999d7daac49f3c9ce284d0769de3a10344aa9c5eb26edf429bd90b8601d00ba7a97a40f671ef358c26bf33a03d0d542d0d553d23bace3582e56e736fc76ca3192161ba2b45ad2c529c718d3c120dd671d048ab1394a2b8374dc380e2f49aa366b527248aa1e223f691d4481fe53a671564bba44d24599c6abc38c7500ce7949f2339fd86bd28ae1c5deee0eb78abbf6a8a4ff9669ac3325ed5659c9e319eb00c6d4a47bc592ee3fba69caeeb14609d2ddaafe690a5e6700baba6b76ef9d3b765f391714668c4359ee195b2fbf7ce5ddd75d972cc7997a6783d7361d24d730aaad92f61bc7e02549d5664d4a0e49d50371899f87a62b8882f4f6dc63c6eafdff54496f94ef64d18c7500cead8bd29a5025192d319fd86b524252aada42516c18cd23b9e79328ad527516c225aae613cf9f059bad031855e7fb5be4c1d63dac8ed24c90e6ac0301d05a7d9ffb82745f949e952b98217cc670ecdf97f451c3f1979ab30ec08b10c38714f4abd6712c1514569e7174d525923e956a8cd4c5068fbb1a24e93aeb00509c6d322c364469a5a44d56e3e37b2eb40ea066a5164f5ab78228480755fdf3be28bd4ad2bb559d21e2cd8628ad0a69b7ab976e87a49bad068f55a2b175ef214f62f5fd6fda7cf21449efb30ea230d9df879dcfe6fd92f647e93d925e2fe99daa763e7853e201d19e17038ceb02959b34a2bd0d72b07c9ddd21e90d86e3e73037e80b82349b3e8ce144dbe1bfe2e97b818e297d54d157b14192a6149eab828b0d4f4f7cfd711c9774bd7510288e75cb89edc6e3b75e94d6aa79abb69bb6b2b61582f4c158ed48f953497bace3e962a3a47b135cb7294983ad322c36c87e3eab4bc9af87edca736e5a4e4d4cb2a666bd4b4f92de13a56b25fd85a4cb2ce3e9626d81c5eb26be0f9e24e96aeb20c644611d3958bece1e26b9ecce82ec5e137ce639b42f3e74f30ead3b16aadd8f9e3c23e5c553bf1893063fa65907bdf7511eebc3999b921c2a59131f20b774ced6416142f570f17249bf691d4b17eb135db72937d0d6f389e7b629a328f9f5d0c4426f13ff4ea9b9780d77ceb17bb67cee4c49359fa4d2a4c3a11735f1fe1700803c6667e725dd641d4617173df9c94f4eb6f829d94d6eacda04ac4975fd09d04209e3b04ece588f8fe626524a7c882c794573ad82f43649bf6b1dc732ebac0370cefaf3dcbad88166262457c732dbde5872339785ea9fd748faa0752ccb94369f94784f354853ef7f0100c8222a5a9ee5d15dd0f4b1356727bb6f49b9a286c3a1d124d63b0b480ed92bf57c83419ad637bc7582f466f96a0f585a722837eb6283f5f8686642526aeedfab4d7e5686679475b1d63a801135f19e6a632cefe70000801b716161d63a866e62c2bc7dca6283c7f31aee0bd201eb2050a48dd1b6c79a75b103cd5dd9556211c545eb09677e4ad223d641749094e8cffa0c1ee6137b4d4c484ad521d1189ebbb9ac733ec25592e6ad63e928a6781d9b5d6cbbc83a0000004a7560eadb37479f67503d2dd58553dee45e9cf0dae3fa98750048ea70e2eb5bae064d39f6a184d76e84ceb9063bace348a4c4876337ad27bce8f4dc7ebb751c1dc52487fa48f9b9b83adaf6214fd9ea86f964804eab218f6d46eb50e27c62c9e55c16aa9d0dbf6f1d474749f349935fff4dfebb010090d6ecec7c88d1ddb90d21c4b2763674b65a5aafdcebe66fad034052f3aa126ea998141b629594d8907088d4459a26d8651d4042bba294ec60a0444c578346cbc1fbfb134947ad8390f4c3d601d4602ef1f5ade693d4e3329f0cd6d45d721209c951b9dbd9b0c4bbe5a3185252b1a18967b12c2a71172c00006e44854f5bc770bab0e5f1175f9924d798ea26d7e3ae06499ab50e00494d4bba37e1f5ad7636a42edc911c1aacc9c9a12995b76bc33401122c07ef23488f4a7aaf751c6a461ba52935b0789d615ce693c19a9c903c2ba65d1cd1341e92f95d85eabd7cad751c927ec83a801134f95eb1c97f370000925b509cb58ea19b3356a6699598aad8e0f1bc86b9203d641d04925aa9b4c58673125ebb9fd4fdb55326d49aa2c9c921a9bcfee1ec6ce8edcfad0350d576ac74a98bd7e726bc763f298b0d0fc9672f526f9a9eb46bfadfaf4e9e773648cc27438bd5cfb2c93b7bb6c5427e1600007874207ceb168fe736ac48746e439b76367cc13a002437adb4ad2f9ab812f5b01cafac73a4e9c993d2b6c7b3b3a18720dd2cfbbef92b8dc7af43eae2b5d521cd298b1cf7aa193ffbd49a7ed06a93db0ed6cdf5fd5790ae917d6bbe523e53b6aaf9c978dedb00008c6b76763e48375887b15c94929cdb90aad8e0f141ea73d60120b96949f724bcbe55b12175726855c2eb17af739ec14eeb38122b6d351e3b1bfafb3be3f19bf099d2d4f9246591e36e9593183411a58d6a469bb17e9e621d4041bcef6c90ec5bd096329f94b643741c4d5f780300405251f133d6312c176248b259a0f64341a3b4593e57767cde3a0024977a25eafa28ade9f445cf296572e85e957738706e3bd5fcef110f9023f0bcb3a1e3d3927ece70fc26249c53b7514a7d164f2f298b1cf78a95af83b4e1b3b6b4e2b5a5128a0d9f96f442c3f14b994f4adb213a8e36fc1d9141ac3e53fe6de661bf15a4dfcf3c26009c222accbacb2504adda79c995dbefbc61ef813a2f9b2281e67105f03149b75b0781e456296d7248aa1244b7241e63b99487f77e5576675194227772e87e4967651e737594b684f4ef9fbab86e3de18075dbc0542b5173fedc5317af57466963c878664ea7dff6a68443dca3bcab7b4bfc1cc83d9fdca76a37454e5b8d1666208da6ce2775cbfdde3ea2fc87b15348445d5e24e917338f7948141b00185bfdcf5fbfe53b6bce5e08c1d7829305c55d926a2d36a4f80b7a5cd5f68550e643294694217193b5cf7694d64b5a937008da280d967b25d787328fb78887c88608d5d9350f198690ea3325e74d59ea3380a4fcad9452cf5fb9cf6c7075933ea4dcf3c95f671e6f91c767018ce736e3f14bd9d990b3d87050363f9727c6323f77010070e1d65b6f9d57887758c7719a10ceaffb92296e189e90e09a93a28552bbd45a915b26777228f5781ce83958eed56a1fc83cdea2271b8d3b0eeb331b4a78d8bedb70ec267ca64c778ad7c7128ed1c4f984e2757f39e793a392fe36e3784bb5a15d542b84ea33f0b06108ee3f53a234a3bc67b1ec976491a89856daddd60000345e50b05ec8719a1042ed1d8a52244c3cb651e270e89688e95b29a53cacb99ba6ad442d51ce15fff7aa6af966b1138be450b31c321c3bd5192739df178b7f8794f349ee167649e79350bde6729e6f53d48ed528ad5375ae592eb749ba33e3784bd1dbbd599a389fd429f7fdd37e495fce3ce622ee15010098c0425cf8a2750c5dd4be98a0d6624367b5a7c7150f375807806c52f7d9ceda4649698b1b4783f4a0ca78903311ab333a721e787f67908eabda229f5b490f90a649c642daf25926878e1b8e5d97c5cfc5b9846334693e59fccc72bf0ad950f68464a700f448e671a5b2e6130cc67cd25feee2da974521110080228505f31695dd6cdb7af9e5b52e42ae7b67c38e04d79cd4dd1c52d72ad392be96f0fab98b6929db5e901c1a2c77c264b10598c543e48698ff60ea71d14669b06f1a8e9daaf550ceeffbe2cd56cae2f5f684d7ee26e57cb2f87de2cc86de72cf27fb3abfeecf3cae24ed2ce47312c3b13c0328652bbbba5c9879bcfd9d7f2c163e70be1700001378ccd16fdc16a3bbc58b53d3ffb2b2d667c5ba1f043c1e08e7eff00da434adb4c9a1359d439b73695a72a834b9cf31f8f2b25f73e321b239480e4d66f173f19e846334e9cc86c5f9849d72bde59e4fee5cf66b4ed3f2f94c80f1309ff497b390b820e9406717acc5d94cdc27020030815b6fbd753e8468b543b1a7303555eb910875171b3c1e0eedee8788a4a695fee63b67eb8b94632d7e9f480ef5967b25eae2e7955591b4948748da280df6b0e1d8a9924339bfef8b3bbe5216afa762a61efe513a53690be55fedfc9ab3785dc2fb7029abf9e44b99c75d44b1a139be6538b6eb62436747e8868c43de1d4eb696b2b8575cdb39101b00008c2946dd621dc372530ae7d77bbd7a793c1cdaea210b36562a7db121cb6ad4286d54daf30216db4db1b3a1b7dcc9f7c576175645d2dc2b6fc7451ba5c18e1a8edd84364a8be6125f3fd7ee86d4e3d046a98f58cde539172a3c14a4239d7f673ec1a49a389fd4c5aa8828b10b1600802245855bad63384dac379fdf86364aec6c6897e9503d983c98708c94876c2e953a39b45894a1d8d04594b6485a9b71c8efad560bd5cfc6e250441e209b83e4d0843a45a5d487b5536c6807cb84e4ed99c75ec421d1cdc17cd25bf683df97fc3b854400000a14a64eb8dbd910156b3d9fb6b66243678bfea6baae5797903e51005f165b02a56c7d916b7562ea712836f467b5ab6191c5f6f8ad515a6330eea868a33418c9a1c935a9789d6b3ea12d5f776609c950b554bb3ff3f812c5eb2679d4706ccbb96c1856677b49b4dc0400a0488f79e4b0bb43a243085bb75e7e796db9c13a7736e4dc1e3eacdbac034076398a0db956a2a64c422d483ad4f9778a0ddd591de6d9ebbf7329e12192364a8359beaf9b526c58fc1e36a1789d723eb93f9cfc99339f74679990946ce693359d1d8228dfaac15f92ccbf1a8e3d0ccb9d0df78a5db0000014e7d65b6f9d0ffebaf04c4dffcbcada729d75264c666abc565dac567cc04e8e6243addb8bfa4859d4b877c9ea6c9243dde57e80dcb7ecbfe9c5eb17c586fe2c57c1d669f1e7dc84e275d2f964c9bf339f7467d94649b2bb1fa695523358ee58723b9fc4aad5e6e69c632e4d4c74eee32d12159b62de36a3000034505cded9c2dcd48aa9da160a35bdd86095ac839dc507a2aff5fdaac9ac8cd25909afbf28577288b617dde54e922c4f065925874ae8c56bdd4669de72fc2159267dffc970ec3ae5d8d9b025d34e99ed09af7daf2445e692ae3adf975c8b14162d7f78b1ba1f7e82d1b8a897e57c62d1026c5896bb1a1659dd2b5e68342e00000d11ef1efc3579c51867eaba569d0fb867d778adbab0b3a17d722487a43cab5159896a244a1b256dc838e4824e3f5f86364abd59b7512a21a97aa6e1d8f7198e5da71cc5eb29256e3513a5f54a7b160b8743f77781f27e663d144e3f67c46a3e2121d95f09bbe424db55ec9ee7130fc586e5bb627361d7120000135888e1abd6312c37a5a9c7d577adfaccd478adba506c689f1c6d94a4c47db663f57e4af910baf4838d04d1e9723f44dd1d96f5dd0dd56abe8733c721493b0b49a6a3bff586631f4e74dddc3b5a163f8353af3a495dbc4e7dfdc5f924f7e786ab43d5fac85dc0bdbdcbef71902c26f1c38663a79a4fea907b27a8a79d0d4f321a17008046885af0b7b3a1c6bc7e938b0d0f07e9887510c86e5a928234a7b4898894876d4ae993434b8b319607ff79953b41d26bd569b7a4516a162d3f46451ba5c12c93439e57a28e62b1103b97789cd48744a7be3e3b1bfa334f48768ad9160f346745dbc2a777a514ccd6198eed793ec97dafd8ad1d1a854400000af4ddf92977c506c9671ba55c871c0e2bf5ca76f8b47465e55cc2714a5f89cafba33ff3e4508755eb0befdbe369a334d826c3b1e7125d37f7cfbd29c5ebf3125fdfaad8504a0b9adc9fa7bddaaad04ac99f525ec356f3c9c3413a6a34765f515aadb467e174d3ad9078bf6cbe47db3adf03000030867b3ebff788a28e59c7b154f0b6b32156bd3cbdad8e9eb30e00269626015326d453af143d27f1f5979f0f80537958ad26495fca1ac549deb7c7b3b36130cbe45009df9f612c4d9ecf251c27757139e57c752c9c3cc0b584225c569dc3bf73cf27de8ad7ac802edf8cd1b89e7735e42e222e483ad0e3ffdd9233908e2949bb0cc60500a0316288bde6762361eda6a75d554b6ebfae153533355da74e73d601c044ae6243c93b1b8e0455155456259d2e56ed0266320feb2d39e47d6703069b311ad7737268544d295ea79c4f966effa58dd2e9762a7f11a6d7bc6155bc7e82d1b82528a58dd266a3713dcf27b98b680742efd70b854400008a14dcb552fac155f3b53c3bd6556cb0ba09ede76bd601c0c4d287fa7b128eb332a67ddda74c0e2d4d9a911c3a9dc56ab55ec506ab5ebcde8b0db451eaa3135fea04762f9e0ff31c55ae62c34c4cfb9a4ed9ea63e9f7c5f5fbc248eecfd223417aa8c7ffa38d923feedb28c56a97dc1aa3e13dcf27b9db6df67bfff6da1d9b5aeeef0100000d13dd151bea3a249a9d0d689a5cc921296d326f4bc26b931cea2f7772e860afd56a9d5ec58732c72349aba35db21a93db25bb2456ca166db957012ffd1ea62c5e4b890acc51daa8b445e5a537c8b9e793125685e76e49d72f217950d541d1b96d651765d12c57af7fc570ec41bc9cc522b1b3010080224585af5ac7b05c8cf51c125d5732e271355da74e1c80db4eb90e8896d22587721e0e4db1e1749e924392ddee061e227b28e04c02cb9d29ff98f0dab90b28b9ce6c90d27deea79e4f96ee22e580e8d3e57e2ff6da25a7d07f175d6acc27e5b2fcd9dd6e38f620b9cf2be877af68f57d7a62e25d790000345a0cfe76364c69aa96fc7e93db28cd59070013397736a43ac43975726869f594364aa773931ceab05ab1e6fd906833dedb2849bad470ecdb0cc7ae5bcef9a4d46283e5ce8612e49e4f06b553e11c208cea5986637fde70ec9ea24d6bb07e85c44765d3726a5ad20e83710100688485f05d77c5864e0bcd89d5556c38aba6ebd4e5c14efb11b4cff7921d9dbec5c7128e556a72889d0d3d745a3da4fefe2fd76f6bbc64d78b97e450b99e6734eebcec929929e42c369c5bd875177106500f9d5d8ab9db070d2a5e5b1d124df1ba409dc2fa338c86bf3f488f188d3d48eefba3e31adca290564a000014e6e0f51fbbcf3a86d3446da8e33275151bd6d7749dbacc59070033cb93e707128e952a299d6ac7c4229243bd5924d869a384dac4eae756cb0dc218ee2ca0c5d4287216af539d9192faec157636f466319f0cda59c4ce068ce279b2bb4ff4bc4b2e77f1ace7d95e4b58dd2b72483400001388d1e48cce9e82a2ab62c3ba9aae539739eb00606679b223e56ad4ad897a95a65c597f2c484baba7f45a3d55f6047b18b01235d82587ce8afe0ac98b4c0f86759e507fa5e1d8a99343b97fee398bd7a98a0229e79343cb1260b99392de0f88ce9d90bc6f885dbd5609c99df476efcafbf7c4723ef17c5e43eee2d930f78156bb6059980200c00442d011eb18968a0ab5e4809abab3c155650859e52c364c499a4970dd94c9a1e5df0f76369c2af70aad610feb64352a86f5938663a73c1c5aca9f98cb399f6c8a693e8f73ce27b97736784fd4e6eeeb3e703ee92c367838432ccb4d4bda69302ec614a53592f6188670abe1d883e43e1c7a984202bb60010028508cbe8a0d52f4516c88d2da3a02a9d937ad038099e5c98e7b128f576b22a7936caae540961eac9343de793b1c7a11c586539926191325852716a5572bede7c7204ddbd9b0fc7596fadc86ed755e2c56c5f094ef15ebf9c4fbce86dc49b861e709929218c6eb54151cacb86ca314ab039157651e769842a2d5fb7a6d4cb3f00a00807670b6b32184a0edcfbe72e2ee45753c847adbd520490f5a070033cb931d7389c7abbbf545cec3a1258a0dcb795cad36cad7d5cdeba19ed66d948e5b8edfc75b0cc73e2ae90b89c7c85d645a5e54fa5ae2f1eafefc4f3d9f2c2fe6b3b3a1234a9b95bfc5e8be21bfceaa78ed753e41776f361cfb50f0db12d7e3d95e8b52b6faeb8742220000630a8aae8a0d92b470626ae2731bea7850f3765e83541de48876cad9f64292ceadf97a4d4f0eb915f3b7bc90d8d9302e76362c13a59f936d9b924f0d7180656972cf27a515afef5ef6dfcc2727597c760e3b9f5815afbdce2758264abf2ee92cc3103e6138f6204fc93cde710d3ff750480400a03031eaffb38e61b9e9383ff1a682a6ee6ca0d8d05ecb931dcb9321752b6d252a3b1b7af3bc5acd6a7bfcd628ad361a1b43eaaca2fe3de330ae331e3f85d28bd7755f6f39e693de729fff230d7fa0ae5542d2a2a08f11c5ea5ee8adc661789e4f72afe2df3f42219f42220000a509fe763644ad70516cf0b8b381364aed75c6d2ffe8dca01f4e385edd2b51cfa9f97acbb112b5b7ec2bb3c2905bde3bed048ea68da627b6c72fe3a98d52ace6e0eb249d691ccab5c6e3a7507af1baeef969398a0dbde54ebe1d0ec3cf11c31625eab63a4a5b8cc6c6106275e6cf5ed9efdebbde78fc7ebc9eed25711e0b0000c58931dc6f1dc372410b2eda28b1b3019e744b76a45c8dba25d6dbd225f5ce86b965ff4d72e8a4dc0f90a33e14f2107952d3daf58ca59318fa9caa032b2d1d0cd27dc631a470cae76381c5eb94f3c923e1f47b2de69393dc262483f4a8a4430963e9c7e37c0249b13aa0feef55ed94b3747de735ea4ea75896fbd0ec51762b58ed5ada14a5b54663030050b4a9295f074457a626cef3d7f160f8c3355ca36eec6c68af6e89ff7b255d9270ccad920ed678ad54ee0bd2b165bf47724852a760e43639d471a7a4a7a60864008b762083989fd960bdbba173c6c8c7254dbceaa0069fb40e20915ef3c9a644e36d88d29a1a136d29579177dbe5e1f6c0e69c62b5082777bffb51938c77ca26a9fc6449571b8c8b3ea2f41c491f91fd0e3949fa5beb00faf07cb697827477acee4d2c76a65c209f3b52589c821c2c5f674f8cd2670dc7af45902eb58ea14696f7c37ce61568613e1c995a611dc5a942d06327bd461d89466f3b1b8e7749a8a23dbadd602f3f14b96edb5443b12156aba5522628baedf0a0d850d9aefcdf8b7d237efd9792443198c75ebca6375296858658159cde24e915563174e1b9bff6247aed944b59bcde2ee996492fd259a59c52b7f9c4baf58a171609c951e7933b25bd30452003ec3218133d44e93255f389c56ba117cf87435b1c843cce2e588bcf20afc5068ae0c8c1f27576a6d2de976611a5e920cd5bc7519305d9bd26f8cc2bd05d375e7dfff9bbf7588771aa38799ebf8ee49ab7331b1c6e414146b9db2849f5b5aa48dd42a9db4a548a0d158b07b37156a25aa0ed85b15825e82e93f4b3f297ac7b30e4dbd990bbc8d4edf33175f17a8b6a2836287d6f7c0f3b1bbcaedeb228d08e9a90a478dd529d5d7197497aadd2df778eeaee6077af338cdcafdf63e1f4f6a783dc299b7b5a8fbb6001002842547c282838caadc7d5935ea18e44e3c441d48cf31adaaddb6b7a2ef198751dea9cfaa1af5b928cea77c5e22169d4076aab331b14a55dc170fc2eacdb28fd86d2273a175b7b5d2cdfbd90ff67c6b172ffdc2de693ba7624a4ded9f0b52ebf97bb78ed75feb2984fc669cb67616394d67539efa3ad5647e91d19c699967491aa9d71b9cf1c18c51f58073040ee24fea8ef6b69b4331eeac4c2140000c614148ec8d142fe1826cff3d7f160e86d65340f30edc6ce86de68a3d45beed56ac735e2eb32480fc56ae796458ffe0be4abd860edffb40ec011efc9a14958cc277515afcfade93abdb053aeb7dcf3c9a1201d1df1cf1c90dd36ff0b25fd9dc1b81ead92f4ebd64138715cd27bad83e8255667f5e44e028c536cb02a246e6b581b140000b28951c742b08e628918262e36d4f190b1aa866bd4c9f4d04e983b2dd911a4fb95f61c8fba8a047525997aa1d8d05beee4d08130deca78ab87488b3ec5f0ef13413a6c1d44422517afb7d6749d5e984fba88d52ea499ccc38e9c90ec9c3b33f1595363a29512ba795f901eb10ea20f8bd7ed38bb14acee13a764d3be090080e28db17028a9504307a33a8a0dde1e2e5951d16ebd5e8f2913449b623d0763726683815825e572b7831bf761d06a7701dbe3d1cd1f5a0790d819cb7f2343f17a474dd749399f2cf4e823defaf944369f95a5cd2714afd1cd6f3216c50000200049444154bbac0318a084f6680ad27d921e4e10cb30b8570400600c31f82a36d4d146a98e62431d49d63ab1b3a1dd2c8a0d523d899dba924cdd1c0bd2835d7e9fe45039abd526f9739362252a963b14a44f58079198c57cb2264ed8aa23563b4e37d5144f37bdfefea715675a88f96430129258ee0b61bc96413959bcb729240200d00221265dcc36ba48b1a11b7636b45b91c58628ad57da43fb7ab54ba0d850c86ab50eabedf16ba2b4c5686cf8e47d156a1d8a9c4f64d34249623e91ca9a4fac1292db62fedd84f0edddd6010c217791ec688f1d64c3b07a6fb330050080314445573b1ba438f171094d2c36b0b3a1dd7a253bee493ceea4c91d9243762c1e8e4a2b36483c44e2a4fb24fd77eb2032e8f5f9389778dc498b0da95bf2319ff4c67c321c763760d1fe207dd03a887e3a67b1a4dc2dd6cd243b3dcc762d459b43e70100285a08ce763684c99feb38b3014dd3eb359d7a25eaa4873ba75e35deedbc06c9dffbd742ee03ed8e87de3f8fbe3a0707a57e2df7c2f6782c7a73b029ec8f73a8fa24ac8ad7dee793aff6f8fddcf349eed7435f9dd5fadb330f3b37ee8172a19a4bac5651516cc0a25fb00e600817198c3949b1c1aa9038adfc9f810000142f465f79ec50c3731d3b1bd034bd5e8f7389c79d7425e979b544d15bafe458ab8b0db15aa9b636f3b0933e045a6d8fdf65346e37ae928c2d734b90fe97751099f4ba471aab5838824977ba9d5b4b14bdf52a78b67d45abc567e4a47deead929216eda6e0cf2782748375104328e92c1649babdb62846e7ad90c8fd2272e075066022c1d9e7488c141bba7155114276563b1be8b15da6925a5e2cb24a0ee5de01d24fdb939a96de681d4046566d94265d19ca7c62a3a40364ebfaf3e3f29690447e0b92de601dc4904a3a8b657117ece11a631985b74222f78bc881d7198089c4e02b8f1d14283674c1ce8676ebfa7aecdc781f4938ee5971b2f7023db66d583c14ed9bf0cf5bf5e23d2be6df05025fae0dd24d86e3e77e98ebf5999e7a67c38e09ff7cea3616077bfc7eeefb416f0ff725ce275faa258ad1eda2b77bebfdc9b82d250d945848e4906800008a115c151beab84fe7cc06344dbfd763eadd0d93248876d6164577bdfeee67241ed7bb121f202d0ff5b4e85b0c3fde641d40665de793201d53dae2f5ca286d18e70f76ce0d38abe678963ad2f9fb77d3f6e431f3c9f0a695febe077e3d22e96dd6410c234a6b94fe1c9ce58e06e9d084d760d712000085088aaeda28c9c9990dde8a0dec6c6837cb62c358bb136295184ab92274ae4f0f386fefdfdc4a6ca37440769f73ac586baf5f2868156a5d8a9b4f947e5743bfbfb7b79daed944bbe4f9a409c5db6a89623c2425dbebc743da826d9d4a2c224a76bb60d74669b3d1d8000014c9dd01d1c1c7ce066f1598d63eec4252ffd774ea44d9b8c921ab164a528b57a2765a026dcc3cecf1306192b253383a50533ca37a92d1b8b0756d90de631d84f2df6ff4fb7cf45a6cb03aaf41ca3f9f78baffdca9fcc5fb7bc38485e7203d2cbba4afb7deeec8e33d41fa847510232871518a64bb0b96852900008c22045779ec18275fdcdac462436b93a790d4ff61ff6b89c73e6fcc3f67991c6af3ce068b9640753dfcb13d1eb9dc2fe935d64174e49edffb7d3ece251e7bdcf9c4b2789d7b3ef174bf77a1c19875242425e613e473b7a4375a0731228ba2581dbb12f6cb6e172c0b530000188dab6243a8e1c0ea3a1ed45c6df750bb93a7b06d7b316e4fd7736b8de2745fedf3ff3c256b722b756bbc6477a8e7b64e4f78b4c72b3bab9f3dc8bdb8a1df7cd2ef73b50ecc2783795aec62915cabeb0058ab6283458106768e497a599f335fbc2a72674367d793d52e580a8900008c224657c58658439ebf893b1b2836b45bbfd7f45ce2b14b6c7bd1e6f74ba9abd5a4fa924ce3f0f010e96dde69aadf0cd20dd64118b29c4fc69d17dad446c9138b84e4be9aae6355bc5e1df31fbc0b3b6f0af5edc6c9a273164bea7370ba297d172c6d9400001845f096978b2eda2879dbd9d0e6875df4499e07e990d22629d745e9cc31fe1cc5061b45ae56abf93ae3f0f010c9e77c7a1f93f476eb2096f1d44629f54eb971135c96f349ee15392e3e076215076d94c6e3a1788df4de1ba4ff6e1dc4182e54fecf99a3413a5cd3b5ac0a899b3ae7a201008061445f6d9454c381d5141bd034837efe1e0ff54cbd6aaadfc1d8ad7cbf745a0159aca8ac2539d4299c1dade35a63a0176ff3cd4a7a79600749cfcfc70cc5eb9571c403ec3bc5eef589e291a46341baafcfff6fe57ca26a0eb728dc37a1d8c07cd27c574b7aad751063b22886d5b9739543a20100284090af03a2a5e0626783b76404fdc4db6dd0037fea62c348ab4aa37496d2ae067d38488ff4f9ff6dddd960b10af568a8b7f5caed355e6b14ac446db63b24bd28d81d2ce94951f3c9185f3faab901ffbfadf3894552edeebadea3a12a5ca77e2df74242b2d966559dfbe3ed59715816ed36ebdcb94ab101008012045f673684105dec6cf076d017c58676b3ded9e02d39d46f5783d4de95a8251f0ebdc8eadc061e209beba0a46705bb5d33de58cf27a3eebe4abd5b8bf9a43b8bd5f94d994f76198d8bf46e5655b8f6b6037e14168b2bea3adb8b5db0000094c25b1b25273b1bbc25252836b4dba0d7f43d89c73f67c4af4f9d1c1a940c6beb4ad4d257ab49353e908e2a92206aa2fb253d3b480f5907d247eed5b1d6c5867347fc7acbf31aa4fcc5062faba54b3eff6791d50a687abb37d34149cf2fb970dd398bc5a2d850f77bd16a172c0b5300001896b303a263f4b1b3e1d11aae51278a0ded669d1c1a35d9336a326954de92435e583c04d55d1ce0504fd4695a555b37cf727f5e0d1aef6b89c7f7369f0c2ad6e7be49f6327f5d643066ddf38959f15a36df3fa4b54ad206eb2026b44b659fc5b2c86ad7d2b6d8de054d00008c242aacb28ee114214cbc60849d0d681a7a6c9f6a5072c84bb2269b583d04ef3018ba290f9092fdf6782f2b9a9b64bda41ba3748575207db46d67c3a8f343dbda28997f0ec4ea7b6e71dfd994364a12c5eb26da2ce98b51bac43a9009582c4a391aa4fb6abea65521714aec6e0000603831aeb30e61a91063bf735f87c2ce06b44deae4d08628ad19e1ebdb961cf2c02ab1516b7228480fabfe87d261593f40b6f1759bc32a497ba3f4cbd6813831e87536e8f37552db46fc7aeb364a6d64329f84fa8b0d07657728bc455b43a477a6a44f47e915d6818cc96251458a96471c120d00807bc155b14121b8283678dbd9b0de3a0098eabbb321488fa84ad2a6344ac267d464d2a868a3743a8be4d0d1201d4e705dab87c80b8dc6451eef8ad23bac837060d04eb9b9c4e3af8e43b62289d5428b8d298309d281015fd2c6f9c422513ee8e730b250ed12a97bf7ddb03803a8b9a6257d384aafb30e640c4d38af41926e4970cd6159ef820500a010d1551e3bc63871ceb48e07c363355ca34eae7e48c86e98d7b48bd617515aa76ae55732413a34e04bccdb5018b0480ea53aa0cfaaf5c5ea987e574e3f6d7cdde6f6eb852688ead4773ee9ec2ef252bc4efd7e1ca658dac66243130e875e6455bcde1ed995dc747f14a5975a0731228bf7f6beba2fd839a4db6a172c2dd2000018e0dca7bf744d08c13a8c5304273b1b260ea26e515a6b1d03cc14536c18e1ebc695bac547a92c1e206b5f89da6179a8a7e543641b939a16bc2588bc1d102da5dfdd30ec3c61bd4b4ef277a6460e4f35183355b1a1adf309d29b52b5c3e119d6810c234adbd58cb35816592d4cb920faf89c0600c0ad155af0d5424952ac21cf5fc70dc0376bb846ddd8ddd05e1e8a0de70cf9751e8a0df3896370a5f3d063d1b2215512c7b2172f7db69b6f4ad25f45e922eb403a3c26b3531775879d4f52ef6c1866decc3d9f98ee708a55db2a8bc52d5f4a745d0e89464a2b257d3ca62f8cd6c1eaf5d8b45d4bd3aa0a370000a087b0f20c7f8be563fcf6a497a8a3d8f0500dd7a89bbbca10b219d4635b92ee491cc3b0491f0f87795a1d086965a7867b8dd42dd5839e558f6d89e4505bac92f497d64174e45e2139cc67c55ce218869d4f862d4a8c6b987933f77c62bd62d6eaf0d3a62524257abbb7c599923e601dc4109e6230e6d120dd9fe8daa90a94c3e05e1100803e4ec4e82e7f1d9db451f2586c6067437b79d8d9505272a86d1a951c0ad5993907535c7b083c40b6c79628fd1fd6411818663ef152bcf6d046a96d2ce69305256acb17aa73398ea6b8f610ace666e47761947ec63a88012cee6f6e4b786d76c10200e0d54270576c084e0e88f6586c70f7c34236ab86f89ad44993cd437e9d879d0d6d63f1d07334a43d9ccfea217223e7e3b4cadba2b4c938068f0783a76ea3346cb121751b258f670059bf1e2c56e31f0869ffde29139efdeca2b77babfc4e94d65807d18745f12be5bddc7ed97d5eb2300500803ec2547097530953532e76363c58c335eac6ce06f4143224e1e370891f0f6736b48dc503e4ed89af6fb962cd4b2f7fa4b74ad2bbac83c8cc431ba50d71b8834a872d728f8be2f5e92ce693d4adf32c7bbbef301a1bf9ad97f44eeb20ba89d28c6c1652ec4b75e150b5b8b3da05cbae250000fa08511bac6358ee844e4c9ce7afa3d830f1f68a047ec43a00981976e5cea1a4510c2836c4eaa0bcd445318a0da7b35861953a39442f5ee4f28a68fb33cfbdf2d9435b3e69f07c92ba85d2b1e0736189d94af8ceaeaed4059e6e52cf275f4e7cfd7e484ab6cbeb1dec96ebc6ea7598bad06755485c1b6d3e2b01002842907ed43a86e516c2fcc4e74835756783c79b57e431ec6bdafadc86ed89c73fd2e9e78f8e587dcf8759215cb7d4c91b7af122a7375a0790d1c0f9a4d3d2e670e23806cd27a95b2859ad88f5ec42a37153cf277724be7e3f1c12dd2e5392fea375105d58ddd7b03005008016f2b6f822c6a883d77f6ce236e013171b4275989cd58172bdb8fa61c1a5d4c586c70ff8ff6decaf6dad5187432f71b7aa2df21678806c9f9f8e76ad0aad7bf4f7627d6ec34ce2f1bdce2796af87a6ae7eb63ab3416267431bfde2906de272b2781d3e14a42389c760610a00002e455ff9eb50cf8682bab6a0a73cfc741cbe7e58c82a0ef765f7a48dc27c25ea5ce2eb97c86ad564d207bcceca6aab87c86d0e130548cf6a35aac7364a52facfdb41c5eb41ff7f525ecf6bb03c50d82279b6a0c4bb4c3a0b8852efd4e9c56ab708ecac91f4d3d6412cd3b4c3a1738ed10b0b530000e821f8cb5f4fdc42496a6eb181de90ede6a1cff6a06242eae490d795a8962c1e208f869a3eac07e0211239fda27500990c7b8fd4f4e2f557135fbf44268743873cbb39ace693d531fd2e1df8e3a6955294ce924c0e694cfe9e0bec820500c09fddbba7a3cdbd474f21526ce867dab0cd03ca605d6c489d1c4a9dfc2a91457228574b0acb433d79886c9ff5517a8675108e347d3e994b7cfda27476736d35183a754bbe4596c56b5a29b5cf0e47bd8aad5e7ffb328d637526cbe628ad351a1b0000b7ce5df8814d2104eb309609141b06f072e38afc3cec6c583be0c63a7572c86bdb0b139dd592160f3ab9924396877ad28bb79d2eb70e208361ef91527fde6e1dd01e903380f26a7a42d2f220590e896ea7975a07d0d1d4b3581659de2b5248040060991561ca5dde3a2aba2a36fc534dd7a993bb1f1afc08d283928e251e6666ccff57078a0da7b27ac8c9b5e380364ac8ed390663e63e1078d8f1527fde4eab6aef719a4e51fbcc948307bff389d501d12424d3613e69a7e75a07d06155eccaf59e63172c00008e04058f79eb5af2fbd3755c44ec6c802fc316d1ee96b433611c5b24ddbefc373b3d6157261cf758f0f99eb464f500f9f4283dd668ec5c58add64e17456955485fb45d2af781c043dd2305e948acbe0fab12c6b255ddcf7f69f32e39ab03a2ad76733d3f4a4fc8304ecafb9341984fdae912eb003aac5e7f6f1cb07bad2edbf20cd315bb6001005866416193d5034d2f31d4934bacabd870b8a6ebd4e95ceb0060230c7f00dabd4a5f6ce86626e19892efe49015ab07c857198d9b55947605dbd5b0b07191a41b328e67b5927d18a98bd733926eeaf2fb9b138e29f99e4fdab6b3e17546e3e6b4314a6b83f4b07520c86a5d94b606c3966d9d5d623346c3ffbad1b839b1b30100806542d0e3ad63582e2e2c1caae33a751551e66aba4e9db65b07001b71f8d5a5a993288febf1fb6d5e896ae542eb001a8e87c876bac83a0047527feef62a2aa43ea898f96489cefd45caa21298afdbca7a3e61574d5adb637d8b1c01006884e0306f3d35b5b296e7bfba26fd4392e66bbc5e1d523f80c3af618b68f7248da2772baf99c4e3921c5aa2d3b66a83751c0df72449efb30e02d99d9f793c976d943ae65205d171768fdfef55d4ae4bea79721216bb8e77198cd9361748fa947510c82ef77cb21cc586b4a6547d8f6fb60e0468984392de6b1dc4a442954b6c0a6f5d71e05854d81eac8358222a1edf3ffbe15a0e88aea5381024c5ea832ef58aed516c89d254f0dd7601690cfbbab65a899a7aab94e7e490051e20d36bdbf7f8bfa8fe9be2b5aae6d02daa0a92ab6bbe7e0a3bac03486c947ba4d49fbbbde61376cae5c52eaef4acce58b2704cd26f27b8ee7a9d9c4f2cfbf48fc27a3ee14c81f49e288a0d40dde682f476eb20708a055170c01076ecbe6a4dd089b3ace33855a8ada5659d3b11ee95af62c394aadd0d07ad034176c37eb85b151b52bf4fcc7ade3ad5b644b885b6b5bdf88d940723770e8abc50d2cb24bd547e57535b2787521be54121f57cd26ba71cf3495e2424d36bd39c7d2c759228569f6317ebe47ce2b5f8603d9fb4e9756785cf4f00001685e33b14575847718a10eb7ba6adb3e2e671f59bd71b6aa4356c116d2e6510aa0ebceb767ec44ce2713dbe172db56995a495d5d1ee60c5c609d53fb704e96d417a82a4e74b3a621c56376b3a6dca9a6a94051956c5ebd4f7392cd8381509c9f4b6c53276761521480b41ba29486f0ed2b9925e29e911ebb8bad8128d06eebcde78664c8f9d61000074c41353eece6b50882e8b0d5fabf15a75e1c6b19d867a5d775626df9738965312449d1566bd924675994b7cfdd2901cca83ef732241fa3b55fdac3f611d4b1733d60124e46967c399cb8bd751da9878cc87827434f118c5e8ccdf24cbf2f0ba9bab7841fa90aa22f617ac6359665ae9ef8f7be17d9dc70591d622000048924208e759c7b05c8cf5b5066eface8673ad03807b7389afbffcc169b3d2de68df97b2bd4b6962d5077fc63a8e9660074942417a50d28b247dd03a96653cb54f34d3f9dc4dbdfb64f9f77a26f1781eefeb2ced54bded47d11bc5eb844275effb4c55856c4face6135e6f794c4bf2b78a13000003c1e19cb8107cb651f2d8d797952a1824779f6dfa6be7c503643e7caf130bd52f3f21e963a6819c6ac63a004772b752623ec98bcfb87c285e2716a47955e738dc621dcb123346e37296403e3c9b030020498aee8a0d2b4e2cb82c3678ecebcb0d0d06c99d1c9a493c1e2b514f4572281f3e6f33e8f4df7e89a4dbac63e9f851eb001c613e693612e0f9309f64d0d991f55cf979af2f5fa0930bf78af9f0390a00802485e0aed8f02f2bbeedafd810a447251daeeb7a35591939b701fdd5d693ac87b397fdf7e3138f97faef531a56abe5b3b1d3b60a79bcc13a808e261f103daad409bbe5851de693bc4848e6f3447abbe711a48725bdd93a8e8e1fc93d60ac5afbeccc3d6e8bf1390a0068bd739ff97287e793c57be766676b6bc95ef78dfcfe9aaf57075647a19fdc6d9466128f37eadf672149147ef0fecfebc24ce334fd753b50906e9274ad751ca2d8b054eae43c3b1b6c9124cba72dbddd5dcc6541ba5a3e76cb59cc27bb44612b273e470100adb7626ac1dd7c1863b8b3ceebb5a1d8c076cdf619e5e1ad69c586517b6c37f6012b4aabd58e648527b926cdc6be6e47f40eeb00943739e42231d7076700e595edf5d0d925bb3ad77890d48ea4a4a7b9ecedd601c8a6d8d086d799276be3e9857300005a25043dc53a86d345d7c5867d355faf0e0eb7a720b1a15fd741ba4f691316cb93413309c7925889ba14bb1af2a3b89b51a856a27ec1388c9cc9214f89b96e729fd990346113fcb5c65c2ee7eb8184647eb441cc28481f9334671c8645b181d7597edc9f03005a2d2ae4ea0831b41043adf9fcba1fd40ed47cbd3a70438341521e6ebe6ab18f7da72fecc684631d0bd28309af5f1a9243f9f13dcfefcf8cc75f15a555c631b8d049cea72c5ecf2cfe4b8695a129e7c5129190cc8ffbf7fcace79375066372df921fef6d00409b4d85e8effe63de791ba55a83abc9c66873f38a72cc25befee665bfa64272e8542487f2db16693592db5f5b0720e6d8a552ee6e988ed2facebfa79e4fd825772a9263f9f13dcfef1ae3f1d7e63c18bc3396bb87fd16e0fe1c00d05ae73ef3e53b15346d1dc752316a61c537a76add3c50eb0d5d901e96747f9dd7acc953ad03806bb95a5f901cca8b44850d5ad76514a487645fe8a7d8705253e613efe735e4e66eab730bac8de95b4f628920dda16a4eb1b436e3583b245f0ffb2dc1fd3900a0b556840577cf1521e8e0fefd1f3e5ee73553ac1eb923c13527f574eb00e0da3d89afbf78a827c9a1bc7898b1c12ac1fc668dc7a7d87052538a0da9e7c562745a56e54c80e224e6f1fcae371e3fe77b8dd7978dcd91cf5400404b85103ceef0db5ff70553141b6e4b70cd49b1b301fda44e0e9dddf995e450269184b7250e89ceefef8dc727697052aee2f5d97dbf6a7214af4f623eb1e3f161ace9ace7939cc56b5e5f76f85c0500b4520cfe764cc7049d1252141bfe31c135277571ce1ea0284eae95a8a99343b4513a8987183b7ceff3fb82f1f86b8cc7f7a429c56be693934848da61e5797e6d9a4fb85fb1c37b1b00d056eeda4ec7587f1ebf2d3b1b5649da691d04dc4a7db072ae364a24874e2239646717c5ddbc42f5de7fd430048a0d2735a58d12f3c9492424ed9090ccef16e3f173ce27ee5616b608bb600100adb3fd92975d1caafcb42b2be289daefff6a4f08856aebfdd1baaf5b035a29a1ab201d93f460c2211693423309c790480e2d4572c8ceb4aa43179157ed7d164740b1e1a4d49fc38bc5ebad09c7b8bf332fa242c2dbce267abbe715a4e3920e198690653e89d567e8ea1c63a12beed30100ad3335357589750ccb45c507efbce1a387ebbe6eaad5a71e77373ccd3a00b896324134d3f935e54ad4b9202d8cf1e7c6f9332570b735ad655227e79afaba9d04c5060782f488a487120eb178b066ca153114ae3ba2b441d246eb385aaec94949af73d901c3b173cd2714116d6d8fd5e2140000dae452eb00960b312469a199aad8707ba2eb4ee262eb00e05ad2e44aac567aa74c0e8d7b9867e3dadd64f85e63b0d46dac1af7baad81e54ad41f301cdba394f3c926a56fa1c4e1d0273539d15d8a26ff0cbcce65738663e72a363c25d338e86e4acd7e6f0300b0dc94149e611d4417ff90e2a2a96e72bf98e8ba93d816a5f5d641c0add42b39537fa8b012f5241e5eecb16230bfaf1b8e4d2b8a53a5fe3c4ebd78e29ec4d72f09f3893dce60caaf0df309f729f6f81900005a63fbb3ae7862f0d81120c424e775a52a3624d9865183e7590700b75227579e99f8fae3c6ef750bff24484cd8a38d527e963b1bd84974aab9c4d77f7ae2ebb3b3e124e6137b4d4e487a9dcb6aefdb3b82c7641a8742a23d0e890600b4c6d442d86d1d4337fffa9d639f4f71dd24c586201d54da0377c7f55ceb00e0565b773678ddc23f091e20edad8d690f446fe2eb7652f71b8ecdce8653a52e5e7b9d4f9a88f9c4deb6d8dccf18af73d97d866327ff59c7aa1d1dbbddedf1f90a00688fe0efbc0645dd7bf73f5cf7488a4ba7bcc94d521d99d00bad03805b7389af3f93f8fa24874ebad03a00486af66a548f2836f891faf37826f1f5994f24750ee29eb18e039a92b4cb3a8896396238768ef98424b70f1744bf05370000ea151d9ed71094a48592947682bf31e1b5c7b5214adbac83804b87e4773bfb30687b21294a5b44e2d30bda8fe465b99b90364aa79ab30e6002c7826da2d1130aa67ef0b3c8cbb2789d633ee1fec48769f15c0e006881ed97bc6c67085a671dc77231c62487434beddbd92049cfb10e00fe84aad030671dc7981e0e5292ad4f0562b59a1f2487320ad52f5649620a7ca72a79670085eb93984ffc20399c9765f19a9d0dedc2cf0200d0785361ea32eb18ba9a5ab829d9a5535d58d2cd92e6135e7f5c9cdb805e4a4d104d921c2a793747372424fc48596c68daebb62e8f1a8dbbc6685c973ac56bcb03bb2751ea3c9802f3891f4d2d5ebb9ccb3a9f61c78c86cf319f34f5f554220e890600345e905e621d431747f77fe6a337a7ba78b26243a80a0dc9029fc0f3a27504f06ace3a8031911c3a8907483f3645f9db2ad87056c506da289daed4cf6576369cc48a5b3f388b29bfa346e3269d4f627530f4a694636024dcb703001a6de3935fb25a21b8dbd910156f4879fdd4873225db923181d5922eb60e022edd631dc09826496a35ed60b6a75a078053a44ad635ed755b97e346e3526c385da9c58652e7c15ac5ea5e915ee28e4469a7750c09789ecbac7636a49e4f2822fa42211100d068677efff40be4f09e2fc6f09994d74ffd174e1afc045e661d005c6a6372c8e516fe714469a3a4b5d671e014a956ac35e6755bb346ae442d54a9497b76365476c9e14341cbedb20e2001cf7399d57cb232f1f55949efcbdac84e130040834d05972d9414161666535e3fc7ce068fe736bcd43a00b8546ab16192e450939229ac56f32755cff326bd6eebc4ce063f4a9d4fe6ac037082f9c49f269ea1e1792eb39a4f521f10fd94c4d7c7e8f8bc05003457d08bad43e8e2e8fe1baf497aec41d29bdc50f58fbe25e51863da1ea519eb20e04ea9c9a152e3ae1b0f2bfeb08230afa6b6bd28d19c750063626743a58989edd231c7e7d5d4f984d7913fdc2b02001ae9fc4bf75c1814d65bc7b15c8c9a4d3d468e1535b319c618c71eeb00e04b901e92ddc3d5b8168274c83a0827480ef9b33da65fa58893d8d9e0478945e043c1775b979c4848fa4342322fabf924591ba5cefdc89654d7c7d89e641d000000294445972d941462f2230f72141b38b7012539601dc0884a4c68a54272c8a726f6d9f6ca2a39944b3189f0201d51b5bbb324a5ed6a48f97a20b1edcfda286db60ea2669e3fd39ab8b381c3887de2fe1d00d0541e5b28e9844ecca61e2347b1e106f93cb7e192289d691d04dc292d795f5a72288928ad1307cc7945d22e1fb39d59515a936118cffdcdbb99b30e6044a5cd7f495e0f91c497674dfbd978fe4c6bdcce0635eff5d3149ba3b4d63a080000ea74de33f79c15427077ef11a547be327bedffcfdefd47d955d7f7fe7fbdf73919c69d434416e5b25829df7c5341fa561c00002000494441542e2443e47285ab88120645548a4082a94ab5566db5b6b5d56aafe5ebd7baf85aaf9765adb7b555abb7d6fadb4612c41f28b5304444ab4811c91031602e972f976f64452e0d63323973dedf3ff699fc62263967e69cf3feec7d9e8fb5664d3239cc7e0d73cef9ecfd79efcffbd3f7ed0efa7e926bc5e4475f379e5804368ac6e1764407e852d92687fa25b93771ec477babc1892cecf77382a8accaf6fe7c7f74804450204d17ed5606276a3ce9e7ca06ce47d255c5f7dd67b8e443f4715af4ff7000488965fe6bd119e671d3200e32a83b6abe39a0e3746b43740024a76c932d65cbdb2f141bd255c50bc85445b651a2d8f064652b36942d6fbf3021992ec6fac16165030689df0d00a05acc5e111d614e2dbf7110871954b1e1cb033a4eb72e1950eb079447d9265b169b37e57ec1dde06ec774ade9c3f7accaf3b6d72237b86793e8272b5b31b86ce35fbf30e995aeaa15af531ecb22c7939ef3628c1a8bce8179711e0f00a88c53c7d72f37e9dce81c736966cd1b06719c81141b4cba43d2a383385697ea925e1e1d024929db64cb62f76c48b95f7037d8f42f5da3defb8243559eb7bd461ba5b40cdb785215559bd0ae92e515ebed9ef25816369ef4e946b033fbf03dd13bbcef02002a6344fecae80c73f3bbef9bf8f240e6e60779927bfd008fd58d5f8f0e80a4946db2a56c797bcea55cd2a9d13970445c440e06c586b4ec880ed085c74d7a2c3a44342fee7c66954edab8b96030aa369eb062296d635edc04080040e999a7d942c9a5af0dea58832c36a4da4a69dca513a343200d562c697f283a4787765ac596b92f101790e9a307fa60ec0d3c36c586272bd3ca86a12f5cb7319ea48fe2f560546d0f20ce43d29689d73600a002fefd73d7af94a5b9a2b2651ac87e0dd2608b0d5f57ec89eb915c151d004929cb04515972f61b9343e9e3027230aa76276aa9b58bc18f44e7e810e34981bee1e9e377341891e3493f561771ae983e7e470080d21ba9b55e139d614eee53db4ea8df36a8c30d6cb9a249d32e7d53d225833a66177e5dd27f8b0e81643c20696d74880ef4627228e5cd093b1579b7dae392ee0a3c7e2796297eb2bfd7c7afc2f3b61f22573a0da2d850c6dffb03924e8a0ed18132ae6ce8c7f32172b26ba7a46d81c7efc48992560567a8d28464caef69555bd910f9bcb94fe9179e4f53fc58d58f4262caafb1aa19e6ffd7c3fcb30378922cd59bd9bfae8d1b07f67e35e8de885f509ac586735c5a65e95fe461307e1a1da043bd2836a4bc3961a72297a8dd64d286c0e31f954ba748fa1fc1318e736985f5ae877d159eb7fd10393944afe5b96d93745e74880e9465dcebb7c809c94f98f4f6c0e31f95173762dc1a1c63954ba3b491ecbba9c063f7743cf1f8cda1ffd08a15fec972e91a497f1a1ca31fefbf9c2f0ece30ffbf1ee69f1dc041569fbffe1932ad8cce318f81b5509206ffc6b849e9567e7f3b3a0092519676123f890e10adbd995ce445e464e0b13b62d2838a9d349855a5bb5153451ba5f4946512bf2ce35edfb8b442c54ab0283f0a3c76a7ee890ed0163d793c0c22afd77a3d9e449f7fa4f2ba39921f460790f40c67d2160050629629c9164aee2e4dd7370df298031dd04dda2de9a6411eb30bbfe1dc99894259265dca92b39fce54ec854919268724e9cee800a2cff62044161b1a033846192721caf23e5d969c07ebf5f3e19c1e7fbf6e95a178bd4bd2c3d139143f79dc2b29bfa7ed0b3c76dee3ef17d96e73caa487028fdfa9bba303a8b80e3f2d3a0400000b71f6d967d765fa8de81cf3b86deb7736ee1ae401234e7237061cb3132748ba343a049250964997b2e4eca7e8098732dcad26a5711119bd6fc430a8da869e555086f7e9967ad7e2accc22272425c6936e50bceebf2a8d2791e78a29bc5e8eca8a7d7b58050b00c002ed39f6ffb8c2625749cfcba4eb067dcc8862c3f54ab795d2eba203209e159bb8a5de0b788fa5717761b4c8c9a1968a4dffca2089e5f1d1018640952687aa624774800eecb074cfcb0629b220fa80c5eeb9d28d14264f194ffaaf12e349bb2d4fe46b3bf9154b0749e1b54d21110050529e640b2549f2e6be81b65092028a0ded25d8370ffab81dbac48b150e40ea77a3a69e6f5022271c264b344197c205e4c92e1d171da2e22a3139542525295e339e14ce0d3c7699262453285e9f456ff7beabca78729a7adf96a91b5b038fddad14ce15292402004a676c7cc349eef6a2e81c7371f73b27bffd9507077ddca813f5545b2965925e1b1d0249487df225f57c7dd79e6888bc28294bcb0b298d0b48497a6674808aabcae450d5a4fe7e9d7abebe73e964c51643194fba539734161da2e2aa329e444f5e97e9b59d422131faf7050040f7bcf946b3346f8471d917228e1bf53f63e04b38baf086e8004842ea932fa9e71b8431c56eea5e9abbd5ace8c39bc273867d1bfaab2a93435593c26bef48ee8f0e9080e809ae1f051fbf1b934aa3e513e3497f55653c612f96cea550483ccea553a2430000d0854c66af8f0e319f7da6cf461c37a4d860d2a34ab795d24a972e8a0e8170a94fbefca447dfa72c6d80e6123dd150a60b4849ba2b3a807ad78bb7cccfdb7e8a6cd7f394011ca3acbff7d48b0ddba3032c502f9f0fd1c586d28c27edf68129b47daa426ff794dfd3220b4abd6c7b14f9da7eac64fbabdd191da02dfafc1e00808e8d5db8ee52934e8ace3127d7eddb27363d1471e8c8651ea9b65292a43f8c0e80703ba2031c45af26af925cead5a1e8bbd552986ce9469596c797f979db4f9177a20ea2054d597fefa917af532f86cca797cf87c8f1a425695be0f11722853ba0a30b44bd90f27b5a64b161590fbf179b4377a8bd0a76e03d9de740b10100501e2dbd313ac27cdc5a9f8b3a76e449ee3f061efb682e7569797408844a7df225f57c831039d130adf2dd0d9cc2e4d0691ebb5163d5556572a86a527fbf2edb44773f448e27db2d8db644dd48a178cd84647f453e279fda8b6fe2d24ab1174bb75238578cbe990800808e8c3de7d253ccd2dc185a526befb485cdbb87151b4cda25694bd4f13bc0ea86e196fa44f27dd10112704ee0b1272dedf6077349e102526282a89f2836a429e562c32e8b6dbf15ce8bc9c8c81b4c4a75f7735b0ae3c9712ead880e516191e349af0a04d1ab5f4ab3b7d74152786d739e080028055bb2e4add119e6e3d2cdf7dfbe7967d4f1a397ef862de9e8c06ba303204e7bf225ec8579140f9570a2bba75c3a55b177c8976e72c88a09cfa9e81ce222b29faade46a9ac522e36a45e581f8467061f9fbb9f178ef1a47f22c7935e15afa3ef902fe36b3b85554ba738e7140080c43dfdb9bf7a9c3cdd8da14dfea9c8e347171b3ea974978e1fefd26f458740a85427887a99abac458be8bbd57e147cfc854a6182a8179b7a96f579db6f9177a8b3b2611eede2f523d139e691ea3837488c275db2e2668c146ec8889e4c5eac94c7b22a8c27d1c5a832161b52384f94e2df97010038a266fd98df9769343ac75c5cdaf3847e1eba754168b1a1bd11d5e723331cc55ba2032054aa9330bdcc155d705ca8e80986325e404a695c44f6e202b2accfdb7e8b9c1c3a3ef0d865b0233ac03c521de706a91705d0c528dd4ab9b614c693e8c9e4c54a792c8b1c4f4ee8d1f739b747df672176591a05b96edda7346e04a4d8000048d6d8d88611f3745bef9bfc1f774c4c84b6ca4de124f763d1018e60cca5b5d1211026d549989f44074840f4454859278752581e7fa6a731f65451e409c54981c72e03c69374458e272d95773c49a1d8107d2e506591e3c9898bfd065eecc3c2e6d05d6ab7694de1b51d5d040600607e27365f6bd6b39b237acfedefa323844ff898749bd2deecf6edd10110e6fee800f34875d26a902237879eb6f2fe0e52b880ac4b5a131da2a222f7e41871a91178fcd4a5fa9e916aae81f062ef9f530323dc57e23d9852285e9f4c6ff7be891c4f4eeec1f7882e4495b58828a571ae58f6554b0080eaca94f03cb1bb3fbcf5d64d13d139c28b0d6d29af6eb8c4e34f581123d5499854730d844ba728767221858bb085ba333a401b1791fd11ba5452ac6e38128ad7698a2c5c4b25bdfbb92d95b130fa77585591e3c948bb10b818d1e719a5db8be520291412577971730a00004939637cfd7a93ad088e312f937f3c3a83944eb1e113929ad1218ee09ae8000891ea24ccb06f101d7d0159dac9a1f63e393ba27368f1cbe3cbf8bced3b8bbd1355ea41eb8b0a4b713c6999f450748860d13793947642d2a4bba233b445ff0e1723e5b16c77f0f1173b9eb0b7d7c2a55048cc54eed73600a0ba925dd520494d9ff9bbe80c5222c506931e957443748e23b894d50dc3a73d0993da85e09ef6eba55792780fe852f405e4d6e0e32f560a17c08b7d3f2de3f376502227887ad1faa2aa522c36a4dcc27250a2c79332b75a91d2c85fe6deee298f65d1c586e58bfcefa3afdb5238d75a280a890000cc61d5f815e34a7955adfb4d3fdef2e51dd131a4b44e72536ea52449ef8a0e8010a94d106d8b0e9080e88b8f1426571623853bd6d21da0cb2f72826845e0b1939668f13ab5f12d42f47852e60949298df124fa775849165f6c58b1d0ffb0bd8fc7628b158bb1d3a45d81c75f14931e93f470740e95bb900800a8a0cc2de9550d9ee96fa233cc4aa9d8f075498f44873882cb5c1a8b0e81814b6d3226b53c11a22716ca3e39f4afd10124e52ead8c0e51518f071efbff0c3c76196c8f0e7098a11e4fdafdc057054668a9fcab4b52184f4eeb417f7fccadacc5eb67f62ac40295fd3c51a2900800c021563d77dd6966f6a2e81cf3f39d93b76cfe4a748a59c9141bacf8f4d1d81447f59ee80018b8d426637a3d5995da9db647e4d2098a6dd5f2b8490f061ebf1752b8809416b7f746a99eb70316596c581178ec32486d3cf949748060e728f63c78d2caff5e96ca7872667480054afdf7ff58e0b11753bc8e9ea4a6d8d01b67794273150080e196d5d29e0f6ec93ea884ce2d531bc03f1c1de028ae6075c3d0b93f3ac0617a9d27b5f780a3896ebf53853656db254d4787d0e27aa597ed793b4891ad1b58ad7264a9151b52cb33688b2978f6021392bd133db9bc50a98f6591c586c58c27d17bb1947d6f2f49fa617400c5af3e03004092b46aede56bcceca5d139e6e7cd6c6fed43d1290e96d449ae156d946e8ace7114ef8d0e80814a6d3226b53c83163da150fac9a1f69db4294c10454ff4555564b181762647f6d3e8008719f6f1247a42f247c1c75f342bfaba474e48cfa2b77b7f448e278b3947e05c71f152384f94e27f97000028cbb2f745673812776ddafa9d8d49ed179554b1a12d990d2de67199c7df5d8dc1496d3226b53c83c6e4506fa47011c905647f449e6464a2887424a9bd7fa79667d0a2df8326838fdf2b77450750fcefb2aa22c793e37c01adf9da9b4347afb24be135b158934a63152c85440040a8b1f175cf35a5bc5783d44a6863e85929161b6e50fa1be65d1b1d000393d2644c4bd28ee810c1a22714aa323994c2f2f893da9302e8ad47838f1ffd1a4d594ae3c9c326ed890e11a5bd3974749fff2adcfd2ca551bc3e93deee7d51c6f124bae0fdb04953c11916adbd0a3685d6a19c5300004299ec03d1198ec87ddbb65b366f898e71b8e44eccdb1b45a73e99ff3c97d6468740ff59b1d96a2acb9176546033c9056b4f4caf088ec1e4506f9d1b1da0827e167cfcf3838f9fb214266e66a554f888b04645c121cab415fbe754410ac5ebba8adf297a2bbad8b090f1247a72ba2a37a54869acd0882e1e010086d8196bd75fa6c43bdbb4cc926cf1945cb1a1ed9392764687388a247fa1e88b54266552c91125fa0272aadd9fba0a52b88094b888ec8747828f7fb1070748557b25412ac56bc69358559a904ca578cd78d27bff2bf8f8172fe0bf896eb759959b52a4340a890b6aa70500400f649e79d2f3be2e4ddacedaa7a373cc25c96283494da53f99ff4c972e8b0e8181d8111da06dd82787a227125299a05f342b36f44ca170422fdede8b2e361ca7f889dc94a5f23e7e7f7480604c48f6cedd4a63d525e349ef458f27632e9dd8e57f133dfe54656f2f8942220060888d8d5f7195c94e8bce7124d6d27b262737a6b0c7d29324596c68fb88a4ddd1218ee25a7ac40e855426877e121d20189343bd95c24564f4a44015454f0e49d2aba303242c95f1a42a2d7c162afabd676bf0f17bc68a4d6453783e45ff4eab2885f1e4b59d3ed0a55c52f4a400ab967a8f42220060b0366cc8e4d9bba3631c894b0f6eddb2e9f3d139e693ec44b91585860f45e7388a5592ae8a0e81be4be50ed05426a9a2444f24546672a82d858bc853db9303e89d1456acbc9ecdbfe795cafb782a3906ae7d93089b43f7560ae349d2fd744beaa1e80092deead248878f3d4bf1d7b629bc167ac28a96c68f45e750fcf93f0060c8acde39f33b6669b7f173d7b54a6375f19ca24fc88e26ed5dbf0bef890e80be4b655226951c03d79e905e151ca36a934329f4e295b888ec2993a614bfa9e7a8a40f07674815c5eb78ab145fe4643ce9bddca595d1212ae6c1e800924e50e7d75ad1e7130fb6c7e02ab9233a8068a3040018a015e3e3a399f9bba2731c89cb1fb59fd5fe7b748e2349bad860c5f2dda4ff074a3ac5a53f8d0e81be4a6552665b748040295c68546d7228953d2852f8dd564d0a13442f77e992e810094a613c996adfb13aaca2df73a62c9dbda07a85f1a482da7be8a5d04ae96dde592121badd4ed5ce13a534566a2c67b52400605096faf16f93acdb3da306edfda9eed5302be962435b19560ebcc3a553a243a06f76440790f4a8497bfaf07d935d767598e809845d559b9cb374fa0a2f6472a02ccfdb283ba203b49d1c1d20413ba203288dfefa91a2f7ff49e5bdb79752989094e2279bbb5586b12c85e2b5d4d97812bdb2a18ac58614562d49b44903000cc09ab5972f77f37746e7381297764bf5bf8ece7134c9171bda777f6d8ace7114232a47cb272c801517833b8263f4eb6ed8e4df03dafe53f0f1ab780129a57137ea422607caf2bc8db2233a00e6b543f1138c29acae88c484648f5931219d42fb98e8df6db7ca309695e2fdc2a5bae2f762a9dade5e523a85c4b2bdb6010025d4b2ec6326eb74afa810e6fad0e4c4c6ddd1398ea60c27b992f4dee8001d58efd2dae810e89be88bade8e3478bbec8a8dce4505b0a17916bda9304e89d9f4407c0dcdac5ebe83b85877d3c7966f0f1ab3821294977460750fc2ac82a2acb4aa833157f5d5bc5554b938a2f904be55bb504002899d517acbfc2cc5e149de348dc35bdcff6bd2f3a4727a24fca3a62c5e65413d1393ac08698d5153d3953968bbd9e6b4f44af098e51d5c9a11496c7a7f0fbad9afba203e088a2c793a12d46b537106673e8fe48a1787d32bddd7beec7d1013a147d538a94c66ba0a74c9a561a7bc651480400f4cdf2676f18cde41f8cce7154a64fdc37f1e547a36374a214c586b63f8e0ed0813197fe203a04fae2a7c1c7bfbf4fdf3785bb958e2685bbd5aa3a3994421b25a9fbd6076578de464a616200f38b2e36441f3f520a139255bcfb594aa3782dc5af5ce94619c6b2b28c27d17bb13cd09e98afa214ce1557797ca1180050514f1d99b94666cba3731c89bb5a9e95624f6349f113781d6baf6ef84a748e0ebcc7a513a243a0e7a227678679cf86142687aa5a6c48a1ed85d4fd9e1c6578de8631e961498f45e7c0bcfa553cee54f47816297a4272cae2db68f54b2a7775a770ced0a9328c6577a91c4591e8df7b558b88523a85c4e83d3900001574fa85979d26e98fa2731c95e993f7debca934d7116538c93dd85b95fe096f43d2b5d121d073d1933343db4649f193433b4dda159ca12fac9890de199d432c8fef87540a4978b2e8f124faf891a22724539990ef87547e367abbf790494d25de9acf8bebd9e8d776556f4a91d2796d47ff8e010015546fd5ff5e96f81e92ae66339b7e47748c6e5874806eb9f42949af8cced181ff68692c3b0de5d2392a0a3003637dd8dfc3a55149e7f6fafb76aa1f3f9324b9749aa493fbf1bde7d3edcfe2453fffc8d5428f5b85276ebdb8785b161c638f49dfedf4c1eda5f461ad32faf57aec25972e91f4ace0185feae56bc7a5f3248df4eafb75a069d26dbdfea6ed9ef25105b669936eefc737f6e2aed3e3fbf1bde7d1f5cf12714e72989d56e13ba0035ea37379ac9bf36f2f9eb351774cf7edf5d84b2ebd5cd2eae0189fb123143d5c1a1f6096b9dcd75e555839d1e75c0779d0ba2c96bbb44ad2497dca83437dd7a43d9d3cd0a553250dba5d4957d71addf0e26739b51fdfbb035d8d79e83f97d62aeea6eeca8e45fdb2fa82f5afcc4c9f8ace7154eeff6debad9bdf121da31b652c362c57d13f3fedca93f43d8b9fe80100000000000000483afd3997356a4b6a3f3559ea6df0a7b4b7f6cb5bbfb3b154dd36cad64649263d24e943d1393af04c975e1f1d020000000000000020d597d4ae2d41a14172bdb76c8506a9842b1ba4fd4b9effa78a659d299b92f4f46e977c02000000000000007a67d5dacbcfcb2cfbb659da53e2eeda553f66f72fdf7dd34d53d159ba55ba950d92d4deacf5cfa373742097b4d14bfaff1900000000000000ca6ec5f8f86866b5cfa55e68902459eb5d652c3448e59e04bf5645d12175cf90f427d1210000000000000060182dd5d3de6fa653a2731c8d4b0f3fe5dffee747a2732c54698b0d56b428ba263a4787ae71e9cce81000000000000000304c568d5f312ed9ef46e7e84cebed3ff8c10f9ad12916aa04eb46e6e7525dd24f252d8fced2816d92fe8349d3d14100000000000000a0eacebcf8e2bcb977e9fd6676527496a371f93d93139b9f1e9d63314abbb241924c6a4a7a47748e0ead52d1fa0900000000000000d06733d38d0f96a1d020496ef6f6e80c8b55ea950db35cfa1749cf8cced1a10b4d9a880e01000000000000005575c685575e2cf76f44e7e888ebf6adb76e7a4e748cc52af5ca8683bc213a40173ee7d2b2e8100000000000000050452b2fdab0ccddff213a47a766e46f8dced00b952836987497a48f47e7e8d049923e181d0200000000000000aa68b4d9fcb015f3b0e9737d7adbad9bbf1b1da3172a516c687bbba4ddd1213af41b2ead8f0e0100000000000000553276e1bacb4c7655748e4eb8b47ba6ee7f189da3572a536c30e951495747e7e8c23fb8b4223a040000000000000054c119cfde70bcb5f4b1e81c9d726ffdf1b67fdebc2b3a47af54a6d8d0f6214993d1213ad490f42597ead14100000000000000a0e4321f99d92cb313a38374c2e577de7bebf51f89ced14b952a3698d492f4c6e81c5d3853d25f46870000000000000080321bbb60ddb5665a1b9da313ee2e975e1d9da3d72a556c902493b648fa7c748e2efcae4b9745870000000000000080325a7de1fa4bccec6dd1393a65a60fdd3bb1f99ee81cbd56b96243db5b244d4587e8c267d8bf0100000000000000bab3e67957ac34d717a27374cae5bb5cf5b747e7e8874a161b4c7a44d235d139bac0fe0d00000000000000d08593cf7e49eeadecab56ccaf96c59b262736ee8e0ed10f952c36b4fd85a4edd121bac0fe0d00000000000000d0a1a735ea9f92b42a3a47a7dcfdbb93139b3f1b9da35f2a5b6c30a9a9726d162db17f03000000000000001cd5eaf1f56f96d9fae81c9df3e64c3653b94da10f56d962832499f44d49d747e7e812fb3700000000000000c03c568faf3f3793de1f9da31beef6e73fbee586fba273f453a58b0d6d6f94f45874882ecceedf301a1d040000000000000052f22be7ad3b3173ff92ca35b7fdd0e3d3b532ed31bc2065fa852c487bb3e8df8bced1a53355ac700000000000000000b48d8ed866999d189da31b6ead573ff49d8d7ba273f45be58b0d9264d26755be764aeb55b2a54000000000000000d02f6317acdb28e9bce81cdd70e9a393b75c7f73748e41188a6243dbeb24ed8a0ed1a53f72e977a2430000000000000040a433c6d75d6b662f8dced10d773d581fd9fd96e81c833234c5062b0a0daf8bceb1007fe3d2a5d1210000000000000020c2eaf1f5af95ec3f47e7e856cb675e71f74d374d45e71894a12936489215ad943e1f9da34b99a48d2e9d131d040000000000000006e98cf1752f32d7c7a27374cbddff6adb962fdd1e9d639086aad8d0f606493ba343746954d28d2e2d8f0e02000000000000008330b6f6cab35cb6d9ac6cf3d8fec094fdfcedd12906ad64bfa4c533e97149af8eceb1002748fa279796450701000000000000807e1a7bcea5a7286bfdb31537629786bb6bc67cc38e89893dd159066de88a0d9264d2d7257d3c3ac702ac92f46597ead14100000000000000a01f568c5f719c2d59728bc98e8fceb2007fbeed96ebef8c0e1161288b0d6d6f92f470748805582be91fa2430000000000000040af8d8d6d18c9ddbe21d9cae82c0bb04d3fabbf233a4494a12d36983425e955d13916e82a97de1f1d02000000000000007aea9766369ad933a36374cb5dade68cbd6c7272e374749628435b6c9024936e96f4a1e81c0bf4472ebd273a0400000000000000f4c2d805ebfece4c9745e7580833fd971f7febbabba37344b2e800d15c1a91f44315fb2194d1bb4cfa7fa24300000000000000c0421585067b6d748e05dab655bb9eae89896674904843bdb241924c9a96f41249bba3b32cd0352ebd2d3a04000000000000002cc41917acff70690b0dee53fb64eb86bdd020516c902499b45dd22ba2732cc2fb283800000000000000289b332e58ff61997e273ac742cdb85e75dfc475dba273a48062439b495f91f457d13916e17d2efd7e740800000000000000e8c419e3eb3f50e64283e47fb56dcbe64dd1295241b1e1506f957467748845f8a04bbf151d02000000000000008ee48cf1f51f90f4e6e81c0be5d277b7fe52fd2dd1395232f41b441fcea59325fd48d2f1d15916e1b74dfaefd12100000000000000e07063e3ebde6bb23f89ceb150eedab5779fafbefff6cd3ba3b3a484950d8731e961495746e758a48fb9f4cae8100000000000000070b0b1f1f5d794bcd0d072d73a0a0d4f46b1610e264d487a57748e45fa944be5dcc11d00000000000040e58c8daffb1393fe343ac762b874f5bd5b366d89ce9122da28cdc38b4fb7481a8fccd103ef30e9bf44870000000000000030bcce185f77ad64ff393ac7e2f8d7b64e6cfed5e814a96265c33cda55982b55b4552ab3f778b17134000000000000000c5a3636beee331528343ce0aabf2c3a45ca58d970142e3d43d2bf48aa476759a4cf4b7a9549cde82000000000000000aa6fc5f8f868ee4fdb6c662f8aceb2182e9f6e2afb0ff74d5cb72d3a4bca58d9701426dd29e9add1397ae0e592beea521e1d0400000000000040b5adbc68c3b2a53afe5b652f344892b5ec35141a8e8e950d1d72e96f25bd3ee9d6f40700002000494441543a470fdc25e9f926ed8a0e02000000000000a07a569fbffea4aca65b24ad8aceb268ae0f6dbd75d3ef45c72803563674ee8d92be161da207ce92f42f2e2d8f0e02000000000000a05ad63cef8a95594ddf57050a0dee7ef3d6136b6f8ace5116ac6ce8824ba392bead621f87b27b44d28526b1fc07000000000000c0a29d3e7ed93935af7fc34cc74767592c77dd553f66f773eebee9a6a9e82c6541b1a14b2e9d20e9fb92560447e985c724bdd8a4ef460701000000000000505eabc7d75f64d297adb861bbd4dcf560abeeff71db3f6fa6157d1768a3d425931e95f4021513f565779ca45b5dba2a3a0800000000000080721a1b5f775526fd53250a0dd2e3eef67c0a0ddda3d8b000266d97f46249d3d1597a6044d2675cfa80f37c00000000000000d0b96c6c7cfdfb4df699e820bde0d21ecdb45e70ef96ebb647672923da282d824b5748ba4ed599a4df22e972abc6aa0d000000000000007db262fc8ae372b7ebccec79d1597ac15d2d33ffd5ad139bbf1e9da5acaa32491ec2a4eb25bd313a470fad95f4af5e819de201000000000000f4c7e9175e765aaeec8755293448929b7e9b42c3e2506c5824933e2ae92fa273f4d00a49df77e992e82000000000000000d2b26a7cdda575afffab49a74467e91577fdd77b27367d3c3a47d9516ce88db7aa58e550150d495f76e94fa2830000000000000048c3d8f8fa6b32d79725e5d1597ac5ddbf3879eba6aba37354017b36f4904bdf91746e748e1efba2a4579b34151d04000000000000c0e09d79f1c5f9ccf4d22f48766974965e72f79b27ede72fd4c444333a4b15b0b2a1b75e28e9cee8103df65249dff60a2d8b02000000000000d099d3d7be64c5cc74e307552b34c875b7ac7e398586dea1d8d043263d2ee90592b64567e9b1b324fdc8a5974707010000000000003018abd75e79492d5bf24349aba2b3f492cbefd174edc2c9898dbba3b354096d94fac0a51354b4543a353a4b1f6c92f49a76610500000000000040c5ac181f1fcdf5b40f98ec77a2b3f4c1b6bd33b5f3b77f6be3a3d141aa8662439fb87492a4ef4b5a1e9da50f1e96f40a93b6440701000000000000d03b636baf3c4be61bcdaa7723b54bdba7676acfa6d0d01fb451ea13931e9174be8acf5573b2a45b5cbad6a57a7418000000000000008b96ad1e5fff7f9bf9f7ab5a689058d1d04fac6ce8332f5a297d47456ba52aba47d23a93b6470701000000000000d0bdd5cf5b7f4a36a3cfc9745e74967e982d344c4e6cace28de1c96065439fb527e1cf5775f73858a362f3e8df8d0e02000000000000a03b63e3eb7fd3667c6b750b0dbe8342c360b0b261405c7a86a45b2535a2b3f4d1cd2af672d8191d04000000000000c0fc568c5f71dc52b7bf93d9fae82cfde2f21dd3b2f3b74f6c7a283acb306065c3809874a7a417489a8aced247cf93f463975e1b1d04000000000000c0dc568fafbf2877db5ae54283dc1fca5a2d0a0d03c4ca86017369ada47f9234129da5cf6e93f41af67200000000000000d23036bee12453f30392bd3c3a4b9f3d34a3d6f9db26aedf111d6498506c08e0d28b24dd189d6340de69d29f45870000000000000086d6860dd9ea9fcdfc81b95f6366cba2e3f4934b8fb4d47a368586c1a3d810c4a57324fdb3a44abfb8dbb6a958e5f0dde820000000000000c03059b5f6f2f3b22cfb5b93ad89ced26f2e3d9865ad0befb9f9fa07a2b30c238a0d815c3a4d45c16179749601f988a43f3669777410000000000000a0ca563d7fddf15953ef97f49b6643310dbc6dcfb45f70ffed9b774607195643f12c4b994b27a928388c456719908725bdc9a44dd141000000000000802a1a1b5fff7ab9de6ba6e3a3b30c82bb7f6fcafc853b26ae7f2c3acb30a3d890002f5a297d59c5e6d1c3e20649bf6712bbc1030000000000003d70faf9579e59cb5a7f6f66cf88ce3230ee37fdefe9fae50f7d67e39ee828c38e6243225caa4bba4ed265d15906688fa4bf92f41e931e8f0e0300000000000094d19ae75f76626ba6fe6e935e1f9d65a05c9fde7aeba65745c74081624342bcf8f46149bf131a64f076497a8fa4bf36693a3a0c0000000000005006a73fe7b2467d49ed6ab9de2cb33c3acf20b9f4d793139bde149d0307506c48904b7f24e9fdd13902ec90f40e499fe58909000000000000ccedecb3cfae4f1dfbcbbf6bb2779aec84e83c83e6aeab276fddf45fa373e050cce926caa5974afa9c8af64ac3e61e15fb396c890e02000000000000a4e48cb5ebaf92e9dd32ad8cce3268ee6a99f96bb64e6cfe6474163c19c5868479b161f4572535a2b304b949d25bad283e00000000000000436bd585ebd666aebf34d959d15922b87cba255db96d62f357a2b3606e141b12e7d21a49374a5a1e9d25d067255d6dd283d14100000000000080415a3dbe6e4de67abfcc2e8ece12c5dd775b662fdc7acba6dba3b3607e141b4ac0a5e3257d43d239d1590235257d5ad27b4cda1e1d06000000000000e8a733cebf7c4cb5ec9d92bd3c3a4b24777fc432bd70eb2d9bef8ece8223a3d850122e8d48fa7b4957456709d692f48f92de6dd2647418000000000000a097c6d65e7996b2d635725d6636dcd3b7eeba6bef3e7fe1fdb76fde199d054737dccfd61272e96d92ae9594456749c0f592ae31e9aee820000000000000c062ac1e5f7f6ee67ecd30b74b3a98bb7f71ca7efeaa1d13137ba2b3a033141b4ac8a54b247d41c3bb71f4e1beaea2e8f0dde8200000000000004037ceb8f0ca8bbdd57aa7993d373a4b0adc5d267be7d65b37fd5974167487624349b9b44ac5c6d12b82a3a4648b8aa2c3cdd1410000000000008023593d7ec51599b27768b8f7693d844b7b64feb2c95b36df109d05dda3d85062ed8da3374b5a1b9d25317748faa0a47f3489655600000000000048c619175cf17297bdd3ccc6a2b3a4c51f684997df3bb1f99ee82458188a0d25e7525dd2c724fd667094143d26e913923e6cd27dc15900000000000030a4ce38fff231d56abfedf2579aec84e83ca971d70d33cde6affff8db37ec8ece8285a3d850112efdbea4bf141b47cf6742d287255d6fd274701600000000000054dce9cfb9ac515b527ba5b9bd4e46aba4b979b3e5bafade5b37ff7974122c1ec5860a71e922491b251d179d25618f4afab88ad50e3b82b3000000000000a062ceb860fdb89bbfcedc5e2ad368749e54b9f448ab3573e5b62d5fba3d3a0b7a836243c5b87492a42f887d1c3a71938ad50e5f31a9191d06000000000000e574daf32e3db9d61a79adb95e67a615d17992e79ad8dbaa6dd8fead8d8f464741ef506ca8202f3ebd59d2b5924622b394c44e499b541469b698d40ace03000000000080c4adbc68c3b2639a33bf96491b245d1c9da72c5cfec79313b44daa228a0d15e6d22a499b557c4667764afaa20e141e000000000000004945816174baf95265da606e17c9548fce5416eedadef29975dbb67ce99ee82ce80fe6522bce8b950def93f407d1594ae8111d283cdcc68b05000000000060f8acbc68c3b2d17dcdf5925e66a2c0b0102effc8947efe961d13137ba2b3a07f983f1d122e3d4fd2e7249d189da5a4660b0f9f93743b2f1c000000000080ea5a79d18665c74c37afb04caf30d98ba2f39495cb77b9d9abeebd65d3d7a2b3a0ff98331d222e1d2fe91f245d1a9da5e41e95f44d49ff24e926931e0ace03000000000080455ab5f6f2f3b22c5b6baee7cbeca2e83c65e7aeaf65f5e66beef9e71b764667c160506c18422ebd56d20725e5d1592ae23e1d283e7cd3a4ddc1790000000000007004679f7d76fd17c79e72ae4b6b33d785323b4fcc95f5ca947beb2d93b75effd1e820182c8a0d43caa59592ae93745674968a6949fa9e0e141f6e37a9191b09000000000060b88d8d6d18f11366cecdccc75dbac064e7c9341a9dab725c774ccfe8653fb96dd303d1513078141b869c4bff97a4f744e7a8b03d926e93f45d493f9074076d97000000000000fae7d467bd78d9c85346cf94b446aed5929d65a6b5d1b9aaae25bdf3de894d7f169d03712836402e9d2ae95392ce8dce3224764abaa3fdf17d49dfb5621f080000000000007468f9b3378c2e3d66ef9a9aea6b243ddda4352ead31e9e4e86cc3c4e577b55aad576ddbf2a57ba2b32016c506ece7d2ef4aba5652233acb107a58078a0f77487ac08abd2000000000000086dad9679f5d7f62e9f25535b3352e7bba646bcc7c8dbb569a31bd19c67dca4def9a9cd8fc172a5a8b63c8f16ac4215c5a2ee9ef245d1c9d05928a55103b243dd8fef869fbf30e490f9af4585832000000000080deca563d77dda9cab4a6665ae3d2d3258d99e934c9ead1e17010d744aba657df7bf3a607a3a3201d141b302797ae92f497924e88ce8223daada2f8f0908a564c8f4afa59fbf3ce83bef6a8157f07000000000008f12be7ad3bf19863b2135a6a9d50733bd1e527b8ec04939f2e698dc9ce8ace882373f7c725fde1e4ad9b3f119d05e9a1d88079b974bca4f74bfacde028e89dc754141d764a9a9ae7633a2cddf0f8858acdc30fff7f3fe7d758c10200000000bdb5fcd91b469f2ae57b8f99c9eb4dcfb3bae72db7d12cf3dc5a9ebb5bae2ccbdd959b796e6ea36ebe54aedc4cb94bb9b9e532e52e1f956c44ee23328dc8f5a4cf261b9169b45f3f8f4bbbcdbd29695a66d3ee6a4a3e2dd3b4dc9a924f9b5953aee9f6d79b729bf6d93fcba6e59a36f3fd7f9679d3654dc947da3f5fbdf839bc2e69c4ddea928f98ac5e7ccd46dc8b7f93ac21f3dc64b9bb72997253ff7e7e0c864b1f6d6adf3bee9bf8327b8f624e141b70542e8dab68adb432380a30cc9a7a7231e268058b273a7cdc217f37fa2c020000000872f2d92fc91bc72aafeff3bcb9e498bcded2a8d53c6fb53cb74cc5e47f4bb932cfdd6dd4cc72732df562323b977beea6dc5cb99b468be2407bc25bed42816bd44c59f4cf0a9485cbef34d36bb6deb2f9eee82c481bc50674c4a51149d7487a9b247ae401d536adce8b14b35f7be2288f9b6fd50600000080d46dd8909dfef0de7cc9a8f27dfb3caf7b96376b9e67ad7a9e65c58a80e2eeffe28e7f9972735fea96e5e61a752b8a00b32b02f6af0e70cbcd34ca9def40a2dc77b6ccaebe7762d3c7a3a3a01c98e741575c1a93f43e49974467015009b345884e575fec56d1866af71c8f9f9aebeb56fc7700000040e58c8d6d18993a715f7eccbe56bee4986cb4d9f43cab29b7562d6fb9158580f68a00738db68a3bfe979a947bb122a06803e41a35f383dbddb4ffbcff31dc74080c1977fdf59e25b5773cf0cd8d8f47674179506cc082b8b456c506d26cdc0320752dcd538838c2d7ffadc3c74d49da4deb290000001ceef4e75cd65832aa7cefde7aa35ef7dc663cb72ccb5b99726b792eb3c681fd0094cbb4b47da77fbb15908d5abb2590bc5d0030dbbf2a40521efd3302a81e976f692a7bc37d13d76d8bce82f2a1d88005f3e2d3cb25bd57d28ac02800106db6f5d4910a13077fed890e1f77f00a0d000000f4c8c967bf24cff3d17cc99299bcd6f47c5f36d3986d0924f3bcd5ca722b5a01e52db386b9969a792e15ad7fda6d821adabf17801fd817c0bc61b291e89f1100bae27aa025bdf5de5b375d1f1d05e5c5dc057ac2a53f90f42e49c7476701808a9a6d2b75703162b70eb4973abc40f1c41c5fdf71f8e3683305000052b3627c7c74b4f6b4bcbeaf95efab799e35eb8dfd1b045bb67f2540bb08909bf95269ff447f7b958035dcbddd12e8e07fb386cb47cd980e0100497269b75cef9dce7ff1e7db6fbc713a3a0fca8dd1153de3d232496f97f466b19c1300ca64aef65047fa387c43f0a37dd06a0a00800a79fa737ff5b8bd239667d34b1a597d764f805a51046879deb2ac7dd77f7b9360cdae0498ab08e087fc9bb89604808171e9133ea3abeffdd6a647a2b3a01a2836a0e75c3a51d2bb25bd56621329008024a9a9fe173568370500187a2b2fdab0ec98bd3379566b369a334bf2ace6b959ab5d04a8e5d6f28632cfddb3dc4c4b25cfcdadbd2f80378afd022c77cd16012c97797b6f016b44ff7c0080c573d70d99fbdbefd9b2997d19d0535c93a36f5c5a29e95a492f8dce0200181ab3eda60edf07e3f03654bbdb1f87ef9f31ef672b3e0300d02bd9ca8b363496fc626f23ab2dc92d9b699865b9648d999956c3cc72336f48964b6ac8fd58537be25f964bde90ab5809606ad8ecd764c745ff60008064ddee36f396c95bbef4bde820a8268a0de83b979ea1623f87cba2b30000b0481d1526da9fffad9bc7d36a0a00d274fa732e6bd4961cd3c8b27df9be7db58659b3280a149b00e7726f48d66817028ef5fd5f53512838e4712a0a056c200c001824d7dd2db7abefdd72ddd7a2a3a0da283660605c5aa3a2bdd215d159000048d05cab2fe6fbfc44878f9b92f438850c005577e6c517e74fec5edaa8d79bb9296b58566b98b5729bc91ab2562e59a365d668b70c3a56f25c52c3da5f53b16970b182e0c0e31a328d46ff6c00002c9cdfedae774fdebaf98bd149301c283660e05c1a53b1d2e1a592b2e03800000c83a63a2f4e7455ccb0a248020047b5fcd91b46f363f63432d51a99d57235671a9665f98c79c3daab00ac5825909bf9b152bb45901f580d201d280e987cff66c3665cda0200b09feb0ecffcdd93b76cbe213a0a860b676408e3d26992de29e995d1590000c082b5d4dff6520006ece9cffdd5e33cab37a4ace1668d99cc73b99699acd85cd866db00e958b5db031d2806b45b07b9cfb6156a17089447ff5c0000549eeb7657ebdd93b75efff5e828184e5cbf219c4b2b54141d7e43523d360d000048cc1e2dae90f1f841df63ff071b7ea30a66f71230ed6db8b2f6be016ac88a3bff55ac0c684876ec813d04343bf97fa06d900e3cd64cec23000040c9b8eb06933eb0f5d64d13d15930dc283620192e2d97f47649bf25d11b150000f4554b8715208ef0f16f9d3e96936bcc65f9b3378c8ed6d5a8d99e4696d50f9adc6fb5db0765ed497f35a4a27d90ed2f1678c3670b01b25c6a170dcc58290000c030739f72d3274d33efdf3a71c3f6e8388044b1010972e9444957ab283a3482e30000007463764545af0a186cf03d481b36644fff5f53cb0e692164ad032b06f617093c6fb7103ab05a60ffca8103450249b9640d33f629030000bde1ee8f48f6c1daccde0ffde8b6af3e169d073818c50624cb8bd50d57497aa3a47382e3000000447a4c0b2b629ca4a295d463877d7edca45d83fd117aebd467bd78d99291a7e4b2d9d641cda22860597b25c0fe2241b1af800e6e23a446d166e8b0d642464b4f0000902697df26e9c393139b3f1b9d05980fc50694824b6b24bd4945f181d50e000000bd31a5c38a103ab430f1bf8ff0ef8f4b7acc8a3d31bab67aed95a79a354f32ab9de4ae9324ff25ed9ff47ff2fe023a687f01a3e52600001806ee8fc9f44969e683b44a4219506c40a9b4fbd5fe86a4df967456701c000080b2daa3a2d030fb31fbf7dd3a72b1e1e042c3a28a0d73c8568c5fb1acaeac91c91a4bf6b7259a69c86bcbdc5a0d5976d0be06b64cf243562898b44c5243b6bf50c14a0500005046b7b75afeb7fb96eef9fcf61b6f9c8e0e03748a62034aabbddae1f754ac7658161c070000a017f6a8b77b3eacd0a14585292b3e0f85535ffce291ec17f565996a0d9335dcd530a9e1ae6545eb256b64e60dc98e957cd9ec2a0af7fded968ae285bc21b386dc1b665c42010080de73d72e33ff74d366fee6c7b7dc705f741e6021385346e9b5f77678b9a437483a37380e0000180e2df5673368246e6c7c437b15c5de86b796ecdf2b42ae6592353cf3fd7b45ec5f69e1075a42f96c51c39c96500000402edf22e96fb5b3fec5c9c98dac6240a9713d834a71694cd2af4b7aa5a45382e30000803434d5d9647fc78581615a1d80bedbdf3e6ab4e50db7f61e155e142a0e6d1fa5a76a76a545bb7d94cdb693a27d140000a5e1ee8fc8ecb3deb20fdfbbe53af6624065506c406579b1a7c3cb24fd9aa495c1710000c0911dbc67c0d13e3fd1e1e3a65414069a83fc4180682bc6c74747746c2353ada1963764d921eda3b26c7f51627ffb28773f6833eec3f6bea07d1400008be77ac04dd7b75a33d76ddbf2a5dba3e300fdc0192386824be7e840e181150f00002c4ca7c58029152b043a7ebc156d890024eacc8b2fce9fd8bdb451af37f32cab37cc5ab9640d9bc91ab256deb2ac21b5bfe676ace4b9cdaed290e7726bb83cd7415f33b7868c36520080ea7269d2bcb5c94dd74d4e5c7f57741ea0df283660e8b8f44c49af90f45249cb83e30000d06bb3ad7e6627f21fd7fcab06e62a08ccfef9f0d501b40d02d017b3fb6064d9be7cdfbe5ac3b256bb50d16a982c977bc36479cbac91c98ff5f6d724e5b3fb5fcc3ece65b9a4d9af8d04ff68008021e3ee92f43d335dd76a659b6891846143b10143cb8b4fe7e9c08a879302e3000086c7b4fab442c08aef0d002864a73eebc58d25234fc965d6b06ca66196e53333ad8659964b6a58b151776eee0d978e35592e6b172ddc67db4ae532ed2f6814050eb12f0600a0cd9beeda22f3cd33fb5a9b7efced1b1e8e4e0444a1d800687fe1e12c4917497abea4b592f2b8440080607bd49f7641bb6917040015b06143b6e267fb968d64cd3c9b5ed2b0a298919b650d99e7ad196b142da33c372bda4a496a58b1b1772e6bb795926637fb2e0a22f29c0dbe01207deeda25f90d6efa46bd39fdf51fddf6d5c7a2330129a0d800ccc1a5baa47325bd40d2f3da7fe6a41f00d2d2e904ffe3927ed1e9e3adf833000021568c8f8f8ed69e96677bf635b2da927c5f36d330abe5266bd84cab212b565f48d630d9d227b78fd20a77cb8b428772c98e8bfe9900a0fcbce96eb74bfa86b7f4f57bbfb5e9cee844408a2836001df06295c3b88a550f17493a33341000944353fd6b17b467903f08000025979dfe9ccbf225a3caf7eead37ea75cf6dc6f3564db959965bab284cb4dc1a669e9b2b976ca99b72797bb36f57eee679d1764af9ecbfc9ac61ae9cd65200aac65d77497e73cb744ba6fac4e4c4466e4a028e826203b0002e1daf62c5c30b55ac7a58139b0800166c5afd691734c5fe0100000c910d1bb2953f57e398bd33796d492bdfb7afd6c86a9e672dcf65adbc65b5dcdc8b3d313ccbcdb454f2dcdcf203450d3534fbf743ffad6166b9a42cfac7045055de74d79d92b67866b7b4a69b5b7efced1b282e005da2d800f480171bc79dd3fe7856fbf38ac84c004aa5a5e24efda9833e0efffb5c5f7ba2c3c7cd7e6da50e5d1df0f8407e3a0000801e181bdb30523b7e2adf3b6279ad794c6ed94ca3d5f2dcb25a6ee6b9b53c6f5956accc306f98fb52b7ac5db850eed6dee4db541432e479f16715fb68b846cd28680055e7ee92d97673bf43d2bfb8e98ec7f7d6ef78e83b1b593d0d2c12c506a04fdaab1f9ea9430b1027858602d0ad8327ed3b2d063cd1e1e3f6ff9d15000000006958313e3eba74ef2fe5b6643adf57f3bc36b32457d66a1735945bbb8d54cb3c37cf1a66be54aedc65b9cc0f6a31a5c66c21e3907f937233a662804172f93d26dde3d20fdd75c7be3d7bbeb7fd5f6ee4c62ba00f18e180017269b9a467487ab68ae2c369924e090d0594cfb43abb9bffe0bf3f31cf638ef8350649000000f4da99175f9c4ffde2a979bdb6af519bf1bc59f33c6bd5f32cf3bce5369ab9f256a6d1d9e244261f9569a9bb464d4531c35ca345e142a35e1440468bf653cad57e9c4ca3d13f2b3048eeda6ed23d32ddd3927ed49ab16d3ffed6757747e7028609f328403097ea2a5a2e9daaa2c5c9af1cf4e7952a36a706caa2a50313f6bbf5e449fcb9bef66f737c6ddeffde8a6300000000388a15e3e3a3c736978e4e7b2d5f724c363ad3b23c731b9dc93cafb90e2d6ea895b7f7d31835f9c1c58dd103ab320e2a6e14058dfdc50d978fb26a03fd56b440d20e932625dde3f21fa955bb677ae9d4e4f61b6f64c538108c5100489c4b27eb40e1e1dfb73f9fa2a225d3899296c5a54309ed51e74580dd7a724ba0b91ec786c000000000f61737f68e58bea495e5332d1bcddcf256dd466bae7ca6a53ccb0e2d585851cc585afcd98baf1d56cc9094cbacf8ec1a2dbe4e71a36a5cfea85c3b253d22d923327fd865ffafb55a0f5b2d7b687a9f1ef9c96d9b1e88ce09607ebc2b0325d75e1971e21c1fff4ed209737c9d9512e99a56e74580835b031db50830fbc19b3e00000080aa58feec0da34f95f27d4ff9c5e8925696376796e4b57a73b4e59667aee273f6a495194b0f2a74e4075670f821c50cd3c1ff66a326da5275c3dd25d92e59514030b39d2edf59fc59ff9fb7fcd156a69d99d5764e37b39ddbbfb5f1d1e8cc00168f792700f2a228717cfb239513a84c4521e5e08f9139be36d7c7920167dda7a250d06c7f3ed29f0fdf6f607645009b530100000040c2cebcf8e27ccff431f9482b1b6db6b2bcb6a42868b85aa95c470f54cdb269973de64ddf75efb7363d129d0700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000f0ffb70787040000000082febff684110000000000000000000000404dc23c000006fc494441540000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006012f7f2470d14aad3860000000049454e44ae426082	image/png
\.


--
-- Data for Name: stok_kartlari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stok_kartlari (id, sirket_id, kategori_id, marka, model, aciklama, birim, birim_agirlik_kg, olusturma_tarihi, mense_ulke, gtip_kodu, standart_alt_metin, silindi_mi, silinme_tarihi) FROM stdin;
7	1	\N	JAC	SETAKERS 1,5 TON-3 MT 20 Ah		ADET	865.00	2026-07-08 06:40:13.058495			\N	f	\N
10	1	\N	JAC	3 TON ELEKTRIKLI, 4.5 MT, SIDESHIFT, SOLID TIRES		ADET	\N	2026-07-14 12:26:16.466378			\N	f	\N
6	1	\N	JAC	3 TON DİZEL, 4.5 MT, SIDESHIFT, SOLID TIRES		ADET	\N	2026-07-05 19:49:22.074247		8427.20.19.00.00	\N	f	\N
8	1	\N	JAC	STEAKER	1.5 Ton 3m Elektrikli	ADET	\N	2026-07-14 12:21:34.02724			\N	t	2026-08-21 12:42:24.657003
9	1	\N	JAC	TRANSPALET	24V Elektrikli	ADET	\N	2026-07-14 12:22:27.621104			\N	t	2026-08-21 12:42:27.266898
11	1	\N	JAC	JAC CPCD30		ADET	\N	2026-08-21 12:43:10.09048	ÇİN			f	\N
12	1	\N	LONKING	LONKİNG LG30DT		ADET	\N	2026-08-21 12:44:27.23009				f	\N
13	1	\N	JAC	JAC CPCD35		ADET	\N	2026-08-21 12:44:53.454214				f	\N
14	1	\N	ZOOMLİON	ZOOMLİON FD35		ADET	\N	2026-08-21 12:45:39.405146				f	\N
15	1	\N	YALE	YALE4 TON		ADET	\N	2026-08-21 12:46:04.883922				f	\N
16	1	\N	ZOOMLİON	ZOOMLİON 2,5 TON		ADET	\N	2026-08-21 12:46:35.665712				f	\N
17	1	\N	ZOOMLİON	ZOOMLİON MANLİFT 8+2		ADET	\N	2026-08-21 12:47:03.692301				f	\N
18	1	\N	ZOOMLİON	ZOOMLİON ZS0607HD		ADET	\N	2026-08-21 12:47:37.413246				f	\N
19	1	\N	GENPAŞ	GENPAŞ MANLİFT 10+2		ADET	\N	2026-08-21 12:49:30.164716				f	\N
20	1	\N	DOLPHİN	DOLPHİN DPD35 2026		ADET	\N	2026-08-21 12:50:28.457041				f	\N
21	1	\N	HELİ	HELİ ZSM470		ADET	\N	2026-08-21 12:50:51.984836				f	\N
22	1	\N	ATTACK	ATTACK CPCD35		ADET	\N	2026-08-21 12:51:12.813693				f	\N
23	1	\N	JAC CPCD30	2024.4	\N	ADET	\N	2026-08-24 08:21:28.972581	\N	\N	\N	f	\N
24	1	\N	JAC CPCD30	2020.03	\N	ADET	\N	2026-08-24 08:21:29.071773	\N	\N	\N	f	\N
25	1	\N	JAC CPCD35	\N	\N	ADET	\N	2026-08-24 08:21:29.141281	\N	\N	\N	f	\N
26	1	\N	ZOOMLİON 3 TON FD30	2024.4	\N	ADET	\N	2026-08-24 08:21:29.232559	\N	\N	\N	f	\N
27	1	\N	JAC CPCD30	2024.6	\N	ADET	\N	2026-08-24 08:21:29.272002	\N	\N	\N	f	\N
28	1	\N	LONKİNG LG30DT	\N	\N	ADET	\N	2026-08-24 08:21:29.347351	\N	\N	\N	f	\N
29	1	\N	ZOOMLİON 2,5 TON	\N	\N	ADET	\N	2026-08-24 08:21:29.428352	\N	\N	\N	f	\N
30	1	\N	ZOOMLİON FD30	2024.3	\N	ADET	\N	2026-08-24 08:21:29.465498	\N	\N	\N	f	\N
31	1	\N	ZOOMLİON ZS0607HD	2024.07	\N	ADET	\N	2026-08-24 08:21:29.536041	\N	\N	\N	f	\N
32	1	\N	ZOOMLİON FD35	2021.10	\N	ADET	\N	2026-08-24 08:21:29.571144	\N	\N	\N	f	\N
33	1	\N	YALE4 TON	2008	\N	ADET	\N	2026-08-24 08:21:29.638305	\N	\N	\N	f	\N
34	1	\N	netlift	2021	\N	ADET	\N	2026-08-24 08:21:29.72021	\N	\N	\N	f	\N
35	1	\N	JAC 3 TON	2025/5	\N	ADET	\N	2026-08-24 08:21:29.752804	\N	\N	\N	f	\N
36	1	\N	jac cpcd35	2025/11	\N	ADET	\N	2026-08-24 08:21:29.827802	\N	\N	\N	f	\N
37	1	\N	DOLPHİN DPD35 2026	2026	\N	ADET	\N	2026-08-24 08:21:29.865419	\N	\N	\N	f	\N
38	1	\N	ZOOMLİON MANLİF ZS1212	2024/9	\N	ADET	\N	2026-08-24 08:21:29.945381	\N	\N	\N	f	\N
39	1	\N	HELİ ZSM470	\N	\N	ADET	\N	2026-08-24 08:21:30.02748	\N	\N	\N	f	\N
40	1	\N	ATTACK CPCD35	2020	\N	ADET	\N	2026-08-24 08:21:30.06263	\N	\N	\N	f	\N
41	1	\N	BAOLİ CD30	2007	\N	ADET	\N	2026-08-24 08:21:30.144667	\N	\N	\N	f	\N
42	1	\N	JAC CPCD30	2026	\N	ADET	\N	2026-08-24 08:21:30.228054	\N	\N	\N	f	\N
43	1	\N	JAC CPCD35	2026	\N	ADET	\N	2026-08-24 08:21:30.262004	\N	\N	\N	f	\N
44	1	\N	ZOOMLİON MANLİFT 8+2	2024	\N	ADET	\N	2026-08-24 08:21:30.341331	\N	\N	\N	f	\N
45	1	\N	YALE4 TON	\N	\N	ADET	\N	2026-08-24 08:21:30.375521	\N	\N	\N	f	\N
46	1	\N	ZOOMLİON 2,5 TON	2021	\N	ADET	\N	2026-08-24 08:21:30.439019	\N	\N	\N	f	\N
47	1	\N	zoomlion 2,5 ton 2.el	2021	\N	ADET	\N	2026-08-24 08:21:30.520453	\N	\N	\N	f	\N
48	1	\N	10+2 manlift genpaş	\N	\N	ADET	\N	2026-08-24 08:21:30.556719	\N	\N	\N	f	\N
49	1	\N	JAC DİZEL 3TON	2024	\N	ADET	\N	2026-08-24 08:21:30.628993	\N	\N	\N	f	\N
50	1	\N	GENPAŞ MANLİFT 8+2	\N	\N	ADET	\N	2026-08-24 08:21:30.664432	\N	\N	\N	f	\N
51	1	\N	ZOOMLİON ZS0607HD	\N	\N	ADET	\N	2026-08-24 08:21:30.731951	\N	\N	\N	f	\N
52	1	\N	ZOOMLİON 3,5 TON FD35	\N	\N	ADET	\N	2026-08-24 08:21:30.766725	\N	\N	\N	f	\N
53	1	\N	8+2 MANLİFT	\N	\N	ADET	\N	2026-08-24 08:21:30.852222	\N	\N	\N	f	\N
54	1	\N	ZOOMLİON MANLİFT 8+2	\N	\N	ADET	\N	2026-08-24 08:21:30.927816	\N	\N	\N	f	\N
\.


--
-- Data for Name: stok_kategorileri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stok_kategorileri (id, sirket_id, ad) FROM stdin;
\.


--
-- Data for Name: stok_maliyet_kalemleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stok_maliyet_kalemleri (id, stok_seri_no_id, tip, aciklama, tedarikci_cari_id, para_birimi, tutar, kur, tutar_try, belge_no, tarih, odendi_mi, referans_usd_kuru, tedarikci_fatura_odeme_id) FROM stdin;
602	215	SATINALMA	\N	\N	TRY	450000.00	1.0000	450000.00	\N	2026-08-27	f	\N	\N
\.


--
-- Data for Name: stok_seri_no; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stok_seri_no (id, sirket_id, stok_karti_id, seri_no, sasi_no, uretim_yili, kaynak, siparis_id, durum, tedarikci_cari_id, satinalma_maliyeti_try, nakliye_maliyeti_try, gumruk_maliyeti_try, antrepo_maliyeti_try, millilestirme_maliyeti_try, leasing_maliyeti_try, diger_maliyet_try, satis_fiyati_try, satis_tarihi, musteri_cari_id, giris_tarihi, olusturma_tarihi, garanti_bitis_tarihi, barkod, satis_cek_id, sahiplik_tipi, ardiye_maliyeti_try, ilave_gumruk_vergisi_try, damga_vergisi_try, tse_ucreti_try, gumrukcu_masrafi_try, banka_masrafi_try, kdv_try, satis_odeme_tipi, satis_kayit_zamani, sigorta_maliyeti_try, satis_yontemi, silindi_mi, silinme_tarihi, bakim_periyodu_gun) FROM stdin;
216	1	24	200318431	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:28.666362	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
217	1	26	6011460461	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:28.76313	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
218	1	27	240688974	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:28.839192	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
219	1	30	6011359955	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:29.026342	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
220	1	31	0775303002R000344	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:29.064026	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
221	1	32	6011148258	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:29.134083	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
222	1	32	6011148259	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:29.17086	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
223	1	33	F813B02433F	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:29.249669	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
224	1	34	322030515367	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:29.29391	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
225	1	35	250404250	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:29.351961	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
226	1	36	251114716	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:29.426572	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
227	1	37	25004986	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:29.468508	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
228	1	38	0775603001R000183	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:29.53326	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
229	1	40	12994612	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:29.65591	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
230	1	41	7071851	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:29.720081	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
231	1	42	260115323	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:29.761754	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
232	1	43	260115298	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:29.832165	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
233	1	44	SERISIZ-4	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:30.042611	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
234	1	44	SERISIZ-8	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:30.266488	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
235	1	46	SERISIZ-9	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:30.332754	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
236	1	47	SERISIZ-10	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:30.377517	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
237	1	47	SERISIZ-11	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:30.45844	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
238	1	44	SERISIZ-13	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:30.625654	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
239	1	49	SERISIZ-15	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:30.738055	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
240	1	25	240689041	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:07.782174	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
241	1	28	L97113054P2000976	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:07.929373	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
242	1	29	6011255273	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:08.029556	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
243	1	39	GC-30	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:08.126064	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
244	1	28	SERISIZ-1	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:08.160079	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
245	1	29	SERISIZ-2	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:08.257136	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
246	1	28	SERISIZ-3	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:08.340087	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
247	1	45	SERISIZ-5	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:08.427125	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
248	1	45	SERISIZ-6	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:08.458446	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
249	1	28	SERISIZ-7	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:08.540831	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
250	1	28	SERISIZ-12	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:08.623943	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
251	1	48	SERISIZ-14	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:08.662417	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
252	1	50	SERISIZ-16	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:08.741467	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
253	1	51	SERISIZ-17	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:08.836839	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
254	1	52	SERISIZ-18	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:08.867779	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
255	1	53	SERISIZ-19	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:08.951457	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
256	1	54	SERISIZ-20	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:09.039177	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
257	1	45	SERISIZ-21	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:09.126469	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
258	1	54	SERISIZ-22	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:33:09.16065	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
215	1	23	240485634	\N	\N	YURTICI_ALIM	\N	DEPODA	\N	450000.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-24 08:22:28.553673	\N	\N	\N	OZ_MAL	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	0.00	\N	f	\N	\N
\.


--
-- Data for Name: taksit_detay; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.taksit_detay (id, plan_id, taksit_no, vade_tarihi, tutar, odendi_mi, odeme_tarihi, tahsilat_kaynak_tablo, tahsilat_kaynak_id, odenen_tutar, ilk_taksit_id) FROM stdin;
\.


--
-- Data for Name: taksitli_satis_kalem_urunleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.taksitli_satis_kalem_urunleri (id, kalem_id, stok_seri_no_id) FROM stdin;
\.


--
-- Data for Name: taksitli_satis_kalemleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.taksitli_satis_kalemleri (id, plan_id, stok_karti_id, miktar, birim_fiyat) FROM stdin;
\.


--
-- Data for Name: taksitli_satis_planlari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.taksitli_satis_planlari (id, sirket_id, musteri_cari_id, stok_seri_no_id, toplam_tutar, para_birimi, pesinat, taksit_sayisi, baslangic_tarihi, notlar, silindi_mi, silinme_tarihi) FROM stdin;
\.


--
-- Data for Name: tedarikci_fatura_odemeleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tedarikci_fatura_odemeleri (id, fatura_id, tutar, odeme_tarihi, odeme_yontemi, banka_hesap_id, kur, dagitim_tipi, siparis_id, stok_seri_no_id, maliyet_tipi, olusturma_tarihi) FROM stdin;
\.


--
-- Data for Name: tedarikci_faturalari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tedarikci_faturalari (id, sirket_id, tedarikci_cari_id, fatura_no, tarih, tutar, para_birimi, aciklama, olusturma_tarihi, varsayilan_maliyet_tipi) FROM stdin;
\.


--
-- Data for Name: urun_sahiplik_gecmisi; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.urun_sahiplik_gecmisi (id, stok_seri_no_id, eski_cari_id, yeni_cari_id, aciklama, tarih, olusturma_tarihi) FROM stdin;
\.


--
-- Data for Name: yedek_parca_hareketleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.yedek_parca_hareketleri (id, yedek_parca_id, tarih, yon, miktar, birim_fiyat_try, ilgili_cari_id, aciklama, olusturma_tarihi, birim_fiyat_orijinal, para_birimi, kur, maliyet_birim_fiyat_try, odeme_yontemi, banka_hesap_id, ilgili_stok_seri_no_id) FROM stdin;
\.


--
-- Data for Name: yedek_parcalar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.yedek_parcalar (id, sirket_id, ad, birim, mevcut_miktar, birim_fiyat_try, min_stok_seviyesi, notlar, olusturma_tarihi, silindi_mi, silinme_tarihi) FROM stdin;
3	1	forklıft catalı	ADET	0.00	12000.00	0.00	\N	2026-08-14 13:41:41.539428	t	2026-08-21 11:55:55.151402
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2026-07-01 07:55:53
20211116045059	2026-07-01 07:55:54
20211116050929	2026-07-01 07:55:54
20211116051442	2026-07-01 07:55:54
20211116212300	2026-07-01 07:55:54
20211116213355	2026-07-01 07:55:54
20211116213934	2026-07-01 07:55:54
20211116214523	2026-07-01 07:55:54
20211122062447	2026-07-01 07:55:55
20211124070109	2026-07-01 07:55:55
20211202204204	2026-07-01 07:55:55
20211202204605	2026-07-01 07:55:55
20211210212804	2026-07-01 07:55:55
20211228014915	2026-07-01 07:55:56
20220107221237	2026-07-01 07:55:56
20220228202821	2026-07-01 07:55:56
20220312004840	2026-07-01 07:55:56
20220603231003	2026-07-01 07:55:56
20220603232444	2026-07-01 07:55:56
20220615214548	2026-07-01 07:55:56
20220712093339	2026-07-01 07:55:57
20220908172859	2026-07-01 07:55:57
20220916233421	2026-07-01 07:55:57
20230119133233	2026-07-01 07:55:57
20230128025114	2026-07-01 07:55:57
20230128025212	2026-07-01 07:55:57
20230227211149	2026-07-01 07:55:57
20230228184745	2026-07-01 07:55:57
20230308225145	2026-07-01 07:55:58
20230328144023	2026-07-01 07:55:58
20231018144023	2026-07-01 07:55:58
20231204144023	2026-07-01 07:55:58
20231204144024	2026-07-01 07:55:58
20231204144025	2026-07-01 07:55:58
20240108234812	2026-07-01 07:55:58
20240109165339	2026-07-01 07:55:59
20240227174441	2026-07-01 07:55:59
20240311171622	2026-07-01 07:55:59
20240321100241	2026-07-01 07:55:59
20240401105812	2026-07-01 07:56:00
20240418121054	2026-07-01 07:56:00
20240523004032	2026-07-01 07:56:00
20240618124746	2026-07-01 07:56:00
20240801235015	2026-07-01 07:56:00
20240805133720	2026-07-01 07:56:01
20240827160934	2026-07-01 07:56:01
20240919163303	2026-07-01 07:56:01
20240919163305	2026-07-01 07:56:01
20241019105805	2026-07-01 07:56:01
20241030150047	2026-07-01 07:56:02
20241108114728	2026-07-01 07:56:02
20241121104152	2026-07-01 07:56:02
20241130184212	2026-07-01 07:56:02
20241220035512	2026-07-01 07:56:02
20241220123912	2026-07-01 07:56:02
20241224161212	2026-07-01 07:56:02
20250107150512	2026-07-01 07:56:02
20250110162412	2026-07-01 07:56:03
20250123174212	2026-07-01 07:56:03
20250128220012	2026-07-01 07:56:03
20250506224012	2026-07-01 07:56:03
20250523164012	2026-07-01 07:56:03
20250714121412	2026-07-01 07:56:03
20250905041441	2026-07-01 07:56:03
20251103001201	2026-07-01 07:56:03
20251120212548	2026-07-01 07:56:04
20251120215549	2026-07-01 07:56:04
20260218120000	2026-07-01 07:56:04
20260326120000	2026-07-01 07:56:04
20260514120000	2026-07-01 07:56:04
20260527120000	2026-07-01 07:56:04
20260528120000	2026-07-01 07:56:05
20260603120000	2026-07-01 07:56:05
20260605120000	2026-07-01 07:56:05
20260606110000	2026-07-01 07:56:05
20260616120000	2026-07-01 07:56:05
20260624120000	2026-07-01 07:56:06
20260626120000	2026-07-22 14:19:01
20260706120000	2026-07-22 14:19:01
20260707120000	2026-07-22 14:19:02
20260709120000	2026-07-22 14:19:02
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at, action_filter, selected_columns) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type, versioning_status) FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_analytics (name, type, format, created_at, updated_at, id, deleted_at) FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_vectors (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-07-01 06:14:54.544815
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-07-01 06:14:54.584174
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-07-01 06:14:54.590681
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-07-01 06:14:54.633416
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-07-01 06:14:54.64929
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-07-01 06:14:54.654924
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-07-01 06:14:54.661156
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-07-01 06:14:54.667171
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-07-01 06:14:54.676184
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-07-01 06:14:54.682973
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-07-01 06:14:54.688989
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-07-01 06:14:54.696095
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-07-01 06:14:54.702676
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-07-01 06:14:54.708535
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-07-01 06:14:54.714595
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-07-01 06:14:54.741477
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-07-01 06:14:54.747827
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-07-01 06:14:54.754059
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-07-01 06:14:54.760779
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-07-01 06:14:54.769076
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-07-01 06:14:54.775676
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-07-01 06:14:54.784493
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-07-01 06:14:54.801944
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-07-01 06:14:54.8132
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-07-01 06:14:54.819138
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-07-01 06:14:54.824979
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-07-01 06:14:54.831489
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-07-01 06:14:54.836899
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-07-01 06:14:54.842462
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-07-01 06:14:54.848488
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-07-01 06:14:54.853947
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-07-01 06:14:54.862526
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-07-01 06:14:54.869308
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-07-01 06:14:54.878546
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-07-01 06:14:54.884017
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-07-01 06:14:54.889914
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-07-01 06:14:54.898026
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-07-01 06:14:54.90626
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-07-01 06:14:54.915319
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-07-01 06:14:54.928978
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-07-01 06:14:54.934347
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-07-01 06:14:54.940876
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-07-01 06:14:54.946097
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-07-01 06:14:54.951998
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-07-01 06:14:54.957513
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-07-01 06:14:54.963592
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-07-01 06:14:54.975783
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-07-01 06:14:54.982602
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-07-01 06:14:54.987926
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-07-01 06:14:55.005576
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-07-01 06:14:55.011773
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-07-01 06:14:55.030147
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-07-01 06:14:55.032264
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-07-01 06:14:55.043013
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-07-01 06:14:55.046335
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-07-01 06:14:55.04855
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-07-01 06:14:55.05498
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-07-01 06:14:55.061826
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-07-01 06:14:55.067425
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-07-01 06:14:55.073705
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-07-01 06:14:55.07942
61	mark-filename-immutable	fe0096517ae9d60aaec1d110172ba9036dc66bb7	2026-08-14 08:08:16.310635
62	object-versioning-core	0b855f00ff3be0bfca91efee02a9858912491a9a	2026-08-20 07:00:50.690493
63	fix-search-name-relative-to-prefix	c7485e417624f795ce8bb2da21927f48e088904d	2026-08-23 18:22:51.328461
64	fix-search-by-timestamp-sqli	0af424ecd388a39bb1645184b222185a12149675	2026-08-23 18:22:51.3638
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata, archived_at, is_delete_marker, is_versioned) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata, metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.vector_indexes (id, name, bucket_id, data_type, dimension, distance_metric, metadata_configuration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: -
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: -
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 1, false);


--
-- Name: akreditif_kalem_taksitleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.akreditif_kalem_taksitleri_id_seq', 1, false);


--
-- Name: akreditif_kalemleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.akreditif_kalemleri_id_seq', 20, true);


--
-- Name: akreditif_maliyet_dagitimlari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.akreditif_maliyet_dagitimlari_id_seq', 47, true);


--
-- Name: akreditifler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.akreditifler_id_seq', 7, true);


--
-- Name: bakim_kayitlari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bakim_kayitlari_id_seq', 1, true);


--
-- Name: banka_hareketleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.banka_hareketleri_id_seq', 70, true);


--
-- Name: banka_hesaplari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.banka_hesaplari_id_seq', 5, true);


--
-- Name: belgeler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.belgeler_id_seq', 1, true);


--
-- Name: borc_odemeleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.borc_odemeleri_id_seq', 1, false);


--
-- Name: borclar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.borclar_id_seq', 1, false);


--
-- Name: cari_acilis_bakiyeleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cari_acilis_bakiyeleri_id_seq', 1, false);


--
-- Name: cari_hareketler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cari_hareketler_id_seq', 1, false);


--
-- Name: cari_hesaplar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cari_hesaplar_id_seq', 413, true);


--
-- Name: cek_hareket_gecmisi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cek_hareket_gecmisi_id_seq', 3, true);


--
-- Name: cekler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cekler_id_seq', 12, true);


--
-- Name: demirbaslar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.demirbaslar_id_seq', 2, true);


--
-- Name: doviz_kurlari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.doviz_kurlari_id_seq', 1, false);


--
-- Name: duzenleme_kayitlari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.duzenleme_kayitlari_id_seq', 17, true);


--
-- Name: fatura_detay_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fatura_detay_id_seq', 9, true);


--
-- Name: faturalar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.faturalar_id_seq', 6, true);


--
-- Name: gumruk_beyannameleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gumruk_beyannameleri_id_seq', 1, false);


--
-- Name: harcama_turleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.harcama_turleri_id_seq', 38, true);


--
-- Name: islem_loglari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.islem_loglari_id_seq', 1, false);


--
-- Name: izinler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.izinler_id_seq', 35, true);


--
-- Name: kasa_hareketleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kasa_hareketleri_id_seq', 6, true);


--
-- Name: kdv_manuel_girisler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kdv_manuel_girisler_id_seq', 1, false);


--
-- Name: kiralama_kalem_urunleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kiralama_kalem_urunleri_id_seq', 5, true);


--
-- Name: kiralama_odemeleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kiralama_odemeleri_id_seq', 5, true);


--
-- Name: kiralama_sozlesme_kalemleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kiralama_sozlesme_kalemleri_id_seq', 5, true);


--
-- Name: kiralama_sozlesmeleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kiralama_sozlesmeleri_id_seq', 13, true);


--
-- Name: kullanici_sirket_erisim_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kullanici_sirket_erisim_id_seq', 3, true);


--
-- Name: kullanicilar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kullanicilar_id_seq', 2, true);


--
-- Name: leasing_kalem_urunleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leasing_kalem_urunleri_id_seq', 1, true);


--
-- Name: leasing_odeme_plani_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leasing_odeme_plani_id_seq', 48, true);


--
-- Name: leasing_sozlesme_kalemleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leasing_sozlesme_kalemleri_id_seq', 2, true);


--
-- Name: leasing_sozlesmeleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leasing_sozlesmeleri_id_seq', 4, true);


--
-- Name: personel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.personel_id_seq', 2, true);


--
-- Name: personel_odemeleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.personel_odemeleri_id_seq', 3, true);


--
-- Name: pos_taksit_detay_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pos_taksit_detay_id_seq', 6, true);


--
-- Name: pos_taksit_planlari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pos_taksit_planlari_id_seq', 1, true);


--
-- Name: proforma_detay_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.proforma_detay_id_seq', 14, true);


--
-- Name: proforma_faturalar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.proforma_faturalar_id_seq', 11, true);


--
-- Name: roller_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roller_id_seq', 1, true);


--
-- Name: sabit_gider_kategorileri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sabit_gider_kategorileri_id_seq', 6, true);


--
-- Name: sabit_giderler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sabit_giderler_id_seq', 6, true);


--
-- Name: siparis_detay_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.siparis_detay_id_seq', 27, true);


--
-- Name: siparis_odemeleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.siparis_odemeleri_id_seq', 1, false);


--
-- Name: siparisler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.siparisler_id_seq', 17, true);


--
-- Name: sirketler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sirketler_id_seq', 4, true);


--
-- Name: stok_kartlari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stok_kartlari_id_seq', 54, true);


--
-- Name: stok_kategorileri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stok_kategorileri_id_seq', 1, false);


--
-- Name: stok_maliyet_kalemleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stok_maliyet_kalemleri_id_seq', 602, true);


--
-- Name: stok_seri_no_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stok_seri_no_id_seq', 258, true);


--
-- Name: taksit_detay_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.taksit_detay_id_seq', 26, true);


--
-- Name: taksitli_satis_kalem_urunleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.taksitli_satis_kalem_urunleri_id_seq', 1, true);


--
-- Name: taksitli_satis_kalemleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.taksitli_satis_kalemleri_id_seq', 4, true);


--
-- Name: taksitli_satis_planlari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.taksitli_satis_planlari_id_seq', 3, true);


--
-- Name: tedarikci_fatura_odemeleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tedarikci_fatura_odemeleri_id_seq', 17, true);


--
-- Name: tedarikci_faturalari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tedarikci_faturalari_id_seq', 16, true);


--
-- Name: urun_sahiplik_gecmisi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.urun_sahiplik_gecmisi_id_seq', 1, false);


--
-- Name: yedek_parca_hareketleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.yedek_parca_hareketleri_id_seq', 8, true);


--
-- Name: yedek_parcalar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.yedek_parcalar_id_seq', 3, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: -
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_identifier_key UNIQUE (identifier);


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_client_states
    ADD CONSTRAINT oauth_client_states_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: akreditif_kalem_taksitleri akreditif_kalem_taksitleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditif_kalem_taksitleri
    ADD CONSTRAINT akreditif_kalem_taksitleri_pkey PRIMARY KEY (id);


--
-- Name: akreditif_kalemleri akreditif_kalemleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditif_kalemleri
    ADD CONSTRAINT akreditif_kalemleri_pkey PRIMARY KEY (id);


--
-- Name: akreditif_maliyet_dagitimlari akreditif_maliyet_dagitimlari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditif_maliyet_dagitimlari
    ADD CONSTRAINT akreditif_maliyet_dagitimlari_pkey PRIMARY KEY (id);


--
-- Name: akreditifler akreditifler_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditifler
    ADD CONSTRAINT akreditifler_pkey PRIMARY KEY (id);


--
-- Name: bakim_kayitlari bakim_kayitlari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bakim_kayitlari
    ADD CONSTRAINT bakim_kayitlari_pkey PRIMARY KEY (id);


--
-- Name: banka_hareketleri banka_hareketleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hareketleri
    ADD CONSTRAINT banka_hareketleri_pkey PRIMARY KEY (id);


--
-- Name: banka_hesaplari banka_hesaplari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hesaplari
    ADD CONSTRAINT banka_hesaplari_pkey PRIMARY KEY (id);


--
-- Name: belgeler belgeler_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.belgeler
    ADD CONSTRAINT belgeler_pkey PRIMARY KEY (id);


--
-- Name: borc_odemeleri borc_odemeleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.borc_odemeleri
    ADD CONSTRAINT borc_odemeleri_pkey PRIMARY KEY (id);


--
-- Name: borclar borclar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.borclar
    ADD CONSTRAINT borclar_pkey PRIMARY KEY (id);


--
-- Name: cari_acilis_bakiyeleri cari_acilis_bakiyeleri_cari_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_acilis_bakiyeleri
    ADD CONSTRAINT cari_acilis_bakiyeleri_cari_id_key UNIQUE (cari_id);


--
-- Name: cari_acilis_bakiyeleri cari_acilis_bakiyeleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_acilis_bakiyeleri
    ADD CONSTRAINT cari_acilis_bakiyeleri_pkey PRIMARY KEY (id);


--
-- Name: cari_hareketler cari_hareketler_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_hareketler
    ADD CONSTRAINT cari_hareketler_pkey PRIMARY KEY (id);


--
-- Name: cari_hesaplar cari_hesaplar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_hesaplar
    ADD CONSTRAINT cari_hesaplar_pkey PRIMARY KEY (id);


--
-- Name: cek_hareket_gecmisi cek_hareket_gecmisi_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cek_hareket_gecmisi
    ADD CONSTRAINT cek_hareket_gecmisi_pkey PRIMARY KEY (id);


--
-- Name: cekler cekler_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cekler
    ADD CONSTRAINT cekler_pkey PRIMARY KEY (id);


--
-- Name: demirbaslar demirbaslar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demirbaslar
    ADD CONSTRAINT demirbaslar_pkey PRIMARY KEY (id);


--
-- Name: doviz_kurlari doviz_kurlari_para_birimi_tarih_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doviz_kurlari
    ADD CONSTRAINT doviz_kurlari_para_birimi_tarih_key UNIQUE (para_birimi, tarih);


--
-- Name: doviz_kurlari doviz_kurlari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doviz_kurlari
    ADD CONSTRAINT doviz_kurlari_pkey PRIMARY KEY (id);


--
-- Name: duzenleme_kayitlari duzenleme_kayitlari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duzenleme_kayitlari
    ADD CONSTRAINT duzenleme_kayitlari_pkey PRIMARY KEY (id);


--
-- Name: fatura_detay fatura_detay_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fatura_detay
    ADD CONSTRAINT fatura_detay_pkey PRIMARY KEY (id);


--
-- Name: faturalar faturalar_fatura_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faturalar
    ADD CONSTRAINT faturalar_fatura_no_key UNIQUE (fatura_no);


--
-- Name: faturalar faturalar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faturalar
    ADD CONSTRAINT faturalar_pkey PRIMARY KEY (id);


--
-- Name: gumruk_beyannameleri gumruk_beyannameleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gumruk_beyannameleri
    ADD CONSTRAINT gumruk_beyannameleri_pkey PRIMARY KEY (id);


--
-- Name: harcama_turleri harcama_turleri_ad_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.harcama_turleri
    ADD CONSTRAINT harcama_turleri_ad_key UNIQUE (ad);


--
-- Name: harcama_turleri harcama_turleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.harcama_turleri
    ADD CONSTRAINT harcama_turleri_pkey PRIMARY KEY (id);


--
-- Name: islem_loglari islem_loglari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.islem_loglari
    ADD CONSTRAINT islem_loglari_pkey PRIMARY KEY (id);


--
-- Name: izinler izinler_kod_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.izinler
    ADD CONSTRAINT izinler_kod_key UNIQUE (kod);


--
-- Name: izinler izinler_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.izinler
    ADD CONSTRAINT izinler_pkey PRIMARY KEY (id);


--
-- Name: kasa_hareketleri kasa_hareketleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kasa_hareketleri
    ADD CONSTRAINT kasa_hareketleri_pkey PRIMARY KEY (id);


--
-- Name: kdv_manuel_girisler kdv_manuel_girisler_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kdv_manuel_girisler
    ADD CONSTRAINT kdv_manuel_girisler_pkey PRIMARY KEY (id);


--
-- Name: kiralama_kalem_urunleri kiralama_kalem_urunleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_kalem_urunleri
    ADD CONSTRAINT kiralama_kalem_urunleri_pkey PRIMARY KEY (id);


--
-- Name: kiralama_odemeleri kiralama_odemeleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_odemeleri
    ADD CONSTRAINT kiralama_odemeleri_pkey PRIMARY KEY (id);


--
-- Name: kiralama_sozlesme_kalemleri kiralama_sozlesme_kalemleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_sozlesme_kalemleri
    ADD CONSTRAINT kiralama_sozlesme_kalemleri_pkey PRIMARY KEY (id);


--
-- Name: kiralama_sozlesmeleri kiralama_sozlesmeleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_sozlesmeleri
    ADD CONSTRAINT kiralama_sozlesmeleri_pkey PRIMARY KEY (id);


--
-- Name: kullanici_rolleri kullanici_rolleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanici_rolleri
    ADD CONSTRAINT kullanici_rolleri_pkey PRIMARY KEY (kullanici_id, rol_id, sirket_id);


--
-- Name: kullanici_sirket_erisim kullanici_sirket_erisim_kullanici_id_sirket_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanici_sirket_erisim
    ADD CONSTRAINT kullanici_sirket_erisim_kullanici_id_sirket_id_key UNIQUE (kullanici_id, sirket_id);


--
-- Name: kullanici_sirket_erisim kullanici_sirket_erisim_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanici_sirket_erisim
    ADD CONSTRAINT kullanici_sirket_erisim_pkey PRIMARY KEY (id);


--
-- Name: kullanicilar kullanicilar_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanicilar
    ADD CONSTRAINT kullanicilar_email_key UNIQUE (email);


--
-- Name: kullanicilar kullanicilar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanicilar
    ADD CONSTRAINT kullanicilar_pkey PRIMARY KEY (id);


--
-- Name: leasing_kalem_urunleri leasing_kalem_urunleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_kalem_urunleri
    ADD CONSTRAINT leasing_kalem_urunleri_pkey PRIMARY KEY (id);


--
-- Name: leasing_odeme_plani leasing_odeme_plani_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_odeme_plani
    ADD CONSTRAINT leasing_odeme_plani_pkey PRIMARY KEY (id);


--
-- Name: leasing_sozlesme_kalemleri leasing_sozlesme_kalemleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_sozlesme_kalemleri
    ADD CONSTRAINT leasing_sozlesme_kalemleri_pkey PRIMARY KEY (id);


--
-- Name: leasing_sozlesmeleri leasing_sozlesmeleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_sozlesmeleri
    ADD CONSTRAINT leasing_sozlesmeleri_pkey PRIMARY KEY (id);


--
-- Name: personel_odemeleri personel_odemeleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personel_odemeleri
    ADD CONSTRAINT personel_odemeleri_pkey PRIMARY KEY (id);


--
-- Name: personel personel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personel
    ADD CONSTRAINT personel_pkey PRIMARY KEY (id);


--
-- Name: pos_taksit_detay pos_taksit_detay_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_taksit_detay
    ADD CONSTRAINT pos_taksit_detay_pkey PRIMARY KEY (id);


--
-- Name: pos_taksit_planlari pos_taksit_planlari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_taksit_planlari
    ADD CONSTRAINT pos_taksit_planlari_pkey PRIMARY KEY (id);


--
-- Name: proforma_detay proforma_detay_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_detay
    ADD CONSTRAINT proforma_detay_pkey PRIMARY KEY (id);


--
-- Name: proforma_faturalar proforma_faturalar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_faturalar
    ADD CONSTRAINT proforma_faturalar_pkey PRIMARY KEY (id);


--
-- Name: proforma_faturalar proforma_faturalar_proforma_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_faturalar
    ADD CONSTRAINT proforma_faturalar_proforma_no_key UNIQUE (proforma_no);


--
-- Name: rol_izinleri rol_izinleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rol_izinleri
    ADD CONSTRAINT rol_izinleri_pkey PRIMARY KEY (rol_id, izin_id);


--
-- Name: roller roller_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roller
    ADD CONSTRAINT roller_pkey PRIMARY KEY (id);


--
-- Name: sabit_gider_kategorileri sabit_gider_kategorileri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sabit_gider_kategorileri
    ADD CONSTRAINT sabit_gider_kategorileri_pkey PRIMARY KEY (id);


--
-- Name: sabit_giderler sabit_giderler_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sabit_giderler
    ADD CONSTRAINT sabit_giderler_pkey PRIMARY KEY (id);


--
-- Name: siparis_detay siparis_detay_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparis_detay
    ADD CONSTRAINT siparis_detay_pkey PRIMARY KEY (id);


--
-- Name: siparis_odemeleri siparis_odemeleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparis_odemeleri
    ADD CONSTRAINT siparis_odemeleri_pkey PRIMARY KEY (id);


--
-- Name: siparisler siparisler_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparisler
    ADD CONSTRAINT siparisler_pkey PRIMARY KEY (id);


--
-- Name: siparisler siparisler_siparis_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparisler
    ADD CONSTRAINT siparisler_siparis_no_key UNIQUE (siparis_no);


--
-- Name: sirketler sirketler_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sirketler
    ADD CONSTRAINT sirketler_pkey PRIMARY KEY (id);


--
-- Name: stok_kartlari stok_kartlari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_kartlari
    ADD CONSTRAINT stok_kartlari_pkey PRIMARY KEY (id);


--
-- Name: stok_kategorileri stok_kategorileri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_kategorileri
    ADD CONSTRAINT stok_kategorileri_pkey PRIMARY KEY (id);


--
-- Name: stok_maliyet_kalemleri stok_maliyet_kalemleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_maliyet_kalemleri
    ADD CONSTRAINT stok_maliyet_kalemleri_pkey PRIMARY KEY (id);


--
-- Name: stok_seri_no stok_seri_no_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_seri_no
    ADD CONSTRAINT stok_seri_no_pkey PRIMARY KEY (id);


--
-- Name: stok_seri_no stok_seri_no_seri_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_seri_no
    ADD CONSTRAINT stok_seri_no_seri_no_key UNIQUE (seri_no);


--
-- Name: taksit_detay taksit_detay_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksit_detay
    ADD CONSTRAINT taksit_detay_pkey PRIMARY KEY (id);


--
-- Name: taksitli_satis_kalem_urunleri taksitli_satis_kalem_urunleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_kalem_urunleri
    ADD CONSTRAINT taksitli_satis_kalem_urunleri_pkey PRIMARY KEY (id);


--
-- Name: taksitli_satis_kalemleri taksitli_satis_kalemleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_kalemleri
    ADD CONSTRAINT taksitli_satis_kalemleri_pkey PRIMARY KEY (id);


--
-- Name: taksitli_satis_planlari taksitli_satis_planlari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_planlari
    ADD CONSTRAINT taksitli_satis_planlari_pkey PRIMARY KEY (id);


--
-- Name: tedarikci_fatura_odemeleri tedarikci_fatura_odemeleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tedarikci_fatura_odemeleri
    ADD CONSTRAINT tedarikci_fatura_odemeleri_pkey PRIMARY KEY (id);


--
-- Name: tedarikci_faturalari tedarikci_faturalari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tedarikci_faturalari
    ADD CONSTRAINT tedarikci_faturalari_pkey PRIMARY KEY (id);


--
-- Name: urun_sahiplik_gecmisi urun_sahiplik_gecmisi_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.urun_sahiplik_gecmisi
    ADD CONSTRAINT urun_sahiplik_gecmisi_pkey PRIMARY KEY (id);


--
-- Name: yedek_parca_hareketleri yedek_parca_hareketleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yedek_parca_hareketleri
    ADD CONSTRAINT yedek_parca_hareketleri_pkey PRIMARY KEY (id);


--
-- Name: yedek_parcalar yedek_parcalar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yedek_parcalar
    ADD CONSTRAINT yedek_parcalar_pkey PRIMARY KEY (id);


--
-- Name: messages messages_payload_exclusive; Type: CHECK CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages
    ADD CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL))) NOT VALID;


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_vectors
    ADD CONSTRAINT buckets_vectors_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_created_at_idx ON auth.custom_oauth_providers USING btree (created_at);


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_enabled_idx ON auth.custom_oauth_providers USING btree (enabled);


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_identifier_idx ON auth.custom_oauth_providers USING btree (identifier);


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_provider_type_idx ON auth.custom_oauth_providers USING btree (provider_type);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_oauth_client_states_created_at ON auth.oauth_client_states USING btree (created_at);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_created_at_desc ON auth.users USING btree (created_at DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_email ON auth.users USING btree (email);


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_last_sign_in_at_desc ON auth.users USING btree (last_sign_in_at DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_name ON auth.users USING btree (((raw_user_meta_data ->> 'name'::text))) WHERE ((raw_user_meta_data ->> 'name'::text) IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_expires_at_idx ON auth.webauthn_challenges USING btree (expires_at);


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_user_id_idx ON auth.webauthn_challenges USING btree (user_id);


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX webauthn_credentials_credential_id_key ON auth.webauthn_credentials USING btree (credential_id);


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_credentials_user_id_idx ON auth.webauthn_credentials USING btree (user_id);


--
-- Name: idx_banka_hareket_hesap; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_banka_hareket_hesap ON public.banka_hareketleri USING btree (banka_hesap_id);


--
-- Name: idx_banka_hareket_tarih; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_banka_hareket_tarih ON public.banka_hareketleri USING btree (tarih);


--
-- Name: idx_cari_hareket_cari; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cari_hareket_cari ON public.cari_hareketler USING btree (cari_id);


--
-- Name: idx_cari_hareket_tarih; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cari_hareket_tarih ON public.cari_hareketler USING btree (tarih);


--
-- Name: idx_stok_seri_durum; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stok_seri_durum ON public.stok_seri_no USING btree (durum);


--
-- Name: idx_stok_seri_no_arama; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stok_seri_no_arama ON public.stok_seri_no USING btree (seri_no);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_selec; Type: INDEX; Schema: realtime; Owner: -
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_action_filter_selec ON realtime.subscription USING btree (subscription_id, entity, filters, action_filter, COALESCE(selected_columns, '{}'::text[]));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX buckets_analytics_unique_name_idx ON storage.buckets_analytics USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name_lower ON storage.objects USING btree (bucket_id, lower(name) COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX vector_indexes_name_bucket_id_idx ON storage.vector_indexes USING btree (name, bucket_id);


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: -
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER protect_buckets_delete BEFORE DELETE ON storage.buckets FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER protect_objects_delete BEFORE DELETE ON storage.objects FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: akreditif_kalemleri akreditif_kalemleri_akreditif_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditif_kalemleri
    ADD CONSTRAINT akreditif_kalemleri_akreditif_id_fkey FOREIGN KEY (akreditif_id) REFERENCES public.akreditifler(id);


--
-- Name: akreditifler akreditifler_banka_hesap_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditifler
    ADD CONSTRAINT akreditifler_banka_hesap_id_fkey FOREIGN KEY (banka_hesap_id) REFERENCES public.banka_hesaplari(id);


--
-- Name: akreditifler akreditifler_siparis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditifler
    ADD CONSTRAINT akreditifler_siparis_id_fkey FOREIGN KEY (siparis_id) REFERENCES public.siparisler(id);


--
-- Name: akreditifler akreditifler_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditifler
    ADD CONSTRAINT akreditifler_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: bakim_kayitlari bakim_kayitlari_ilgili_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bakim_kayitlari
    ADD CONSTRAINT bakim_kayitlari_ilgili_cari_id_fkey FOREIGN KEY (ilgili_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: bakim_kayitlari bakim_kayitlari_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bakim_kayitlari
    ADD CONSTRAINT bakim_kayitlari_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: bakim_kayitlari bakim_kayitlari_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bakim_kayitlari
    ADD CONSTRAINT bakim_kayitlari_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: banka_hareketleri banka_hareketleri_banka_hesap_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hareketleri
    ADD CONSTRAINT banka_hareketleri_banka_hesap_id_fkey FOREIGN KEY (banka_hesap_id) REFERENCES public.banka_hesaplari(id);


--
-- Name: banka_hareketleri banka_hareketleri_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hareketleri
    ADD CONSTRAINT banka_hareketleri_cari_id_fkey FOREIGN KEY (cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: banka_hareketleri banka_hareketleri_karsi_hesap_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hareketleri
    ADD CONSTRAINT banka_hareketleri_karsi_hesap_id_fkey FOREIGN KEY (karsi_hesap_id) REFERENCES public.banka_hesaplari(id);


--
-- Name: banka_hareketleri banka_hareketleri_olusturan_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hareketleri
    ADD CONSTRAINT banka_hareketleri_olusturan_kullanici_id_fkey FOREIGN KEY (olusturan_kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: banka_hareketleri banka_hareketleri_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hareketleri
    ADD CONSTRAINT banka_hareketleri_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: banka_hesaplari banka_hesaplari_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hesaplari
    ADD CONSTRAINT banka_hesaplari_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: belgeler belgeler_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.belgeler
    ADD CONSTRAINT belgeler_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: belgeler belgeler_yukleyen_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.belgeler
    ADD CONSTRAINT belgeler_yukleyen_kullanici_id_fkey FOREIGN KEY (yukleyen_kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: borc_odemeleri borc_odemeleri_borc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.borc_odemeleri
    ADD CONSTRAINT borc_odemeleri_borc_id_fkey FOREIGN KEY (borc_id) REFERENCES public.borclar(id) ON DELETE CASCADE;


--
-- Name: borclar borclar_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.borclar
    ADD CONSTRAINT borclar_cari_id_fkey FOREIGN KEY (cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: borclar borclar_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.borclar
    ADD CONSTRAINT borclar_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: cari_acilis_bakiyeleri cari_acilis_bakiyeleri_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_acilis_bakiyeleri
    ADD CONSTRAINT cari_acilis_bakiyeleri_cari_id_fkey FOREIGN KEY (cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: cari_acilis_bakiyeleri cari_acilis_bakiyeleri_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_acilis_bakiyeleri
    ADD CONSTRAINT cari_acilis_bakiyeleri_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: cari_hareketler cari_hareketler_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_hareketler
    ADD CONSTRAINT cari_hareketler_cari_id_fkey FOREIGN KEY (cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: cari_hareketler cari_hareketler_olusturan_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_hareketler
    ADD CONSTRAINT cari_hareketler_olusturan_kullanici_id_fkey FOREIGN KEY (olusturan_kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: cari_hareketler cari_hareketler_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_hareketler
    ADD CONSTRAINT cari_hareketler_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: cari_hesaplar cari_hesaplar_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_hesaplar
    ADD CONSTRAINT cari_hesaplar_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: cek_hareket_gecmisi cek_hareket_gecmisi_cek_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cek_hareket_gecmisi
    ADD CONSTRAINT cek_hareket_gecmisi_cek_id_fkey FOREIGN KEY (cek_id) REFERENCES public.cekler(id) ON DELETE CASCADE;


--
-- Name: cek_hareket_gecmisi cek_hareket_gecmisi_olusturan_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cek_hareket_gecmisi
    ADD CONSTRAINT cek_hareket_gecmisi_olusturan_kullanici_id_fkey FOREIGN KEY (olusturan_kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: cekler cekler_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cekler
    ADD CONSTRAINT cekler_cari_id_fkey FOREIGN KEY (cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: cekler cekler_ciro_edilen_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cekler
    ADD CONSTRAINT cekler_ciro_edilen_cari_id_fkey FOREIGN KEY (ciro_edilen_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: cekler cekler_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cekler
    ADD CONSTRAINT cekler_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: demirbaslar demirbaslar_kiraci_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demirbaslar
    ADD CONSTRAINT demirbaslar_kiraci_cari_id_fkey FOREIGN KEY (kiraci_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: demirbaslar demirbaslar_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demirbaslar
    ADD CONSTRAINT demirbaslar_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: duzenleme_kayitlari duzenleme_kayitlari_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duzenleme_kayitlari
    ADD CONSTRAINT duzenleme_kayitlari_kullanici_id_fkey FOREIGN KEY (kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: duzenleme_kayitlari duzenleme_kayitlari_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duzenleme_kayitlari
    ADD CONSTRAINT duzenleme_kayitlari_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: fatura_detay fatura_detay_fatura_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fatura_detay
    ADD CONSTRAINT fatura_detay_fatura_id_fkey FOREIGN KEY (fatura_id) REFERENCES public.faturalar(id) ON DELETE CASCADE;


--
-- Name: fatura_detay fatura_detay_stok_karti_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fatura_detay
    ADD CONSTRAINT fatura_detay_stok_karti_id_fkey FOREIGN KEY (stok_karti_id) REFERENCES public.stok_kartlari(id);


--
-- Name: fatura_detay fatura_detay_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fatura_detay
    ADD CONSTRAINT fatura_detay_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: faturalar faturalar_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faturalar
    ADD CONSTRAINT faturalar_cari_id_fkey FOREIGN KEY (cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: faturalar faturalar_olusturan_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faturalar
    ADD CONSTRAINT faturalar_olusturan_kullanici_id_fkey FOREIGN KEY (olusturan_kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: faturalar faturalar_proforma_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faturalar
    ADD CONSTRAINT faturalar_proforma_id_fkey FOREIGN KEY (proforma_id) REFERENCES public.proforma_faturalar(id);


--
-- Name: faturalar faturalar_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faturalar
    ADD CONSTRAINT faturalar_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: stok_seri_no fk_stok_siparis; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_seri_no
    ADD CONSTRAINT fk_stok_siparis FOREIGN KEY (siparis_id) REFERENCES public.siparisler(id);


--
-- Name: gumruk_beyannameleri gumruk_beyannameleri_gumruk_musaviri_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gumruk_beyannameleri
    ADD CONSTRAINT gumruk_beyannameleri_gumruk_musaviri_cari_id_fkey FOREIGN KEY (gumruk_musaviri_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: gumruk_beyannameleri gumruk_beyannameleri_siparis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gumruk_beyannameleri
    ADD CONSTRAINT gumruk_beyannameleri_siparis_id_fkey FOREIGN KEY (siparis_id) REFERENCES public.siparisler(id);


--
-- Name: gumruk_beyannameleri gumruk_beyannameleri_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gumruk_beyannameleri
    ADD CONSTRAINT gumruk_beyannameleri_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: islem_loglari islem_loglari_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.islem_loglari
    ADD CONSTRAINT islem_loglari_kullanici_id_fkey FOREIGN KEY (kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: islem_loglari islem_loglari_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.islem_loglari
    ADD CONSTRAINT islem_loglari_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: kasa_hareketleri kasa_hareketleri_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kasa_hareketleri
    ADD CONSTRAINT kasa_hareketleri_cari_id_fkey FOREIGN KEY (cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: kasa_hareketleri kasa_hareketleri_olusturan_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kasa_hareketleri
    ADD CONSTRAINT kasa_hareketleri_olusturan_kullanici_id_fkey FOREIGN KEY (olusturan_kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: kasa_hareketleri kasa_hareketleri_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kasa_hareketleri
    ADD CONSTRAINT kasa_hareketleri_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: kdv_manuel_girisler kdv_manuel_girisler_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kdv_manuel_girisler
    ADD CONSTRAINT kdv_manuel_girisler_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: kiralama_kalem_urunleri kiralama_kalem_urunleri_kalem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_kalem_urunleri
    ADD CONSTRAINT kiralama_kalem_urunleri_kalem_id_fkey FOREIGN KEY (kalem_id) REFERENCES public.kiralama_sozlesme_kalemleri(id);


--
-- Name: kiralama_kalem_urunleri kiralama_kalem_urunleri_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_kalem_urunleri
    ADD CONSTRAINT kiralama_kalem_urunleri_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: kiralama_odemeleri kiralama_odemeleri_sozlesme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_odemeleri
    ADD CONSTRAINT kiralama_odemeleri_sozlesme_id_fkey FOREIGN KEY (sozlesme_id) REFERENCES public.kiralama_sozlesmeleri(id) ON DELETE CASCADE;


--
-- Name: kiralama_sozlesme_kalemleri kiralama_sozlesme_kalemleri_sozlesme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_sozlesme_kalemleri
    ADD CONSTRAINT kiralama_sozlesme_kalemleri_sozlesme_id_fkey FOREIGN KEY (sozlesme_id) REFERENCES public.kiralama_sozlesmeleri(id);


--
-- Name: kiralama_sozlesme_kalemleri kiralama_sozlesme_kalemleri_stok_karti_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_sozlesme_kalemleri
    ADD CONSTRAINT kiralama_sozlesme_kalemleri_stok_karti_id_fkey FOREIGN KEY (stok_karti_id) REFERENCES public.stok_kartlari(id);


--
-- Name: kiralama_sozlesmeleri kiralama_sozlesmeleri_kiraci_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_sozlesmeleri
    ADD CONSTRAINT kiralama_sozlesmeleri_kiraci_cari_id_fkey FOREIGN KEY (kiraci_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: kiralama_sozlesmeleri kiralama_sozlesmeleri_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_sozlesmeleri
    ADD CONSTRAINT kiralama_sozlesmeleri_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: kiralama_sozlesmeleri kiralama_sozlesmeleri_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_sozlesmeleri
    ADD CONSTRAINT kiralama_sozlesmeleri_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: kullanici_rolleri kullanici_rolleri_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanici_rolleri
    ADD CONSTRAINT kullanici_rolleri_kullanici_id_fkey FOREIGN KEY (kullanici_id) REFERENCES public.kullanicilar(id) ON DELETE CASCADE;


--
-- Name: kullanici_rolleri kullanici_rolleri_rol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanici_rolleri
    ADD CONSTRAINT kullanici_rolleri_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES public.roller(id) ON DELETE CASCADE;


--
-- Name: kullanici_rolleri kullanici_rolleri_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanici_rolleri
    ADD CONSTRAINT kullanici_rolleri_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: kullanici_sirket_erisim kullanici_sirket_erisim_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanici_sirket_erisim
    ADD CONSTRAINT kullanici_sirket_erisim_kullanici_id_fkey FOREIGN KEY (kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: kullanici_sirket_erisim kullanici_sirket_erisim_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanici_sirket_erisim
    ADD CONSTRAINT kullanici_sirket_erisim_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: leasing_kalem_urunleri leasing_kalem_urunleri_kalem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_kalem_urunleri
    ADD CONSTRAINT leasing_kalem_urunleri_kalem_id_fkey FOREIGN KEY (kalem_id) REFERENCES public.leasing_sozlesme_kalemleri(id);


--
-- Name: leasing_kalem_urunleri leasing_kalem_urunleri_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_kalem_urunleri
    ADD CONSTRAINT leasing_kalem_urunleri_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: leasing_odeme_plani leasing_odeme_plani_banka_hareket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_odeme_plani
    ADD CONSTRAINT leasing_odeme_plani_banka_hareket_id_fkey FOREIGN KEY (banka_hareket_id) REFERENCES public.banka_hareketleri(id);


--
-- Name: leasing_odeme_plani leasing_odeme_plani_leasing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_odeme_plani
    ADD CONSTRAINT leasing_odeme_plani_leasing_id_fkey FOREIGN KEY (leasing_id) REFERENCES public.leasing_sozlesmeleri(id) ON DELETE CASCADE;


--
-- Name: leasing_sozlesme_kalemleri leasing_sozlesme_kalemleri_leasing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_sozlesme_kalemleri
    ADD CONSTRAINT leasing_sozlesme_kalemleri_leasing_id_fkey FOREIGN KEY (leasing_id) REFERENCES public.leasing_sozlesmeleri(id);


--
-- Name: leasing_sozlesme_kalemleri leasing_sozlesme_kalemleri_stok_karti_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_sozlesme_kalemleri
    ADD CONSTRAINT leasing_sozlesme_kalemleri_stok_karti_id_fkey FOREIGN KEY (stok_karti_id) REFERENCES public.stok_kartlari(id);


--
-- Name: leasing_sozlesmeleri leasing_sozlesmeleri_leasing_firmasi_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_sozlesmeleri
    ADD CONSTRAINT leasing_sozlesmeleri_leasing_firmasi_cari_id_fkey FOREIGN KEY (leasing_firmasi_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: leasing_sozlesmeleri leasing_sozlesmeleri_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_sozlesmeleri
    ADD CONSTRAINT leasing_sozlesmeleri_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: leasing_sozlesmeleri leasing_sozlesmeleri_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_sozlesmeleri
    ADD CONSTRAINT leasing_sozlesmeleri_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: personel_odemeleri personel_odemeleri_personel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personel_odemeleri
    ADD CONSTRAINT personel_odemeleri_personel_id_fkey FOREIGN KEY (personel_id) REFERENCES public.personel(id);


--
-- Name: personel personel_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personel
    ADD CONSTRAINT personel_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: pos_taksit_detay pos_taksit_detay_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_taksit_detay
    ADD CONSTRAINT pos_taksit_detay_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.pos_taksit_planlari(id);


--
-- Name: pos_taksit_planlari pos_taksit_planlari_banka_hesap_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_taksit_planlari
    ADD CONSTRAINT pos_taksit_planlari_banka_hesap_id_fkey FOREIGN KEY (banka_hesap_id) REFERENCES public.banka_hesaplari(id);


--
-- Name: pos_taksit_planlari pos_taksit_planlari_musteri_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_taksit_planlari
    ADD CONSTRAINT pos_taksit_planlari_musteri_cari_id_fkey FOREIGN KEY (musteri_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: pos_taksit_planlari pos_taksit_planlari_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_taksit_planlari
    ADD CONSTRAINT pos_taksit_planlari_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: pos_taksit_planlari pos_taksit_planlari_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_taksit_planlari
    ADD CONSTRAINT pos_taksit_planlari_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: proforma_detay proforma_detay_proforma_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_detay
    ADD CONSTRAINT proforma_detay_proforma_id_fkey FOREIGN KEY (proforma_id) REFERENCES public.proforma_faturalar(id) ON DELETE CASCADE;


--
-- Name: proforma_detay proforma_detay_stok_karti_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_detay
    ADD CONSTRAINT proforma_detay_stok_karti_id_fkey FOREIGN KEY (stok_karti_id) REFERENCES public.stok_kartlari(id);


--
-- Name: proforma_detay proforma_detay_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_detay
    ADD CONSTRAINT proforma_detay_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: proforma_faturalar proforma_faturalar_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_faturalar
    ADD CONSTRAINT proforma_faturalar_cari_id_fkey FOREIGN KEY (cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: proforma_faturalar proforma_faturalar_olusturan_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_faturalar
    ADD CONSTRAINT proforma_faturalar_olusturan_kullanici_id_fkey FOREIGN KEY (olusturan_kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: proforma_faturalar proforma_faturalar_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_faturalar
    ADD CONSTRAINT proforma_faturalar_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: rol_izinleri rol_izinleri_izin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rol_izinleri
    ADD CONSTRAINT rol_izinleri_izin_id_fkey FOREIGN KEY (izin_id) REFERENCES public.izinler(id) ON DELETE CASCADE;


--
-- Name: rol_izinleri rol_izinleri_rol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rol_izinleri
    ADD CONSTRAINT rol_izinleri_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES public.roller(id) ON DELETE CASCADE;


--
-- Name: roller roller_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roller
    ADD CONSTRAINT roller_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: sabit_giderler sabit_giderler_kategori_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sabit_giderler
    ADD CONSTRAINT sabit_giderler_kategori_id_fkey FOREIGN KEY (kategori_id) REFERENCES public.sabit_gider_kategorileri(id);


--
-- Name: sabit_giderler sabit_giderler_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sabit_giderler
    ADD CONSTRAINT sabit_giderler_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: siparis_detay siparis_detay_siparis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparis_detay
    ADD CONSTRAINT siparis_detay_siparis_id_fkey FOREIGN KEY (siparis_id) REFERENCES public.siparisler(id) ON DELETE CASCADE;


--
-- Name: siparis_detay siparis_detay_stok_karti_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparis_detay
    ADD CONSTRAINT siparis_detay_stok_karti_id_fkey FOREIGN KEY (stok_karti_id) REFERENCES public.stok_kartlari(id);


--
-- Name: siparis_odemeleri siparis_odemeleri_cek_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparis_odemeleri
    ADD CONSTRAINT siparis_odemeleri_cek_id_fkey FOREIGN KEY (cek_id) REFERENCES public.cekler(id);


--
-- Name: siparis_odemeleri siparis_odemeleri_siparis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparis_odemeleri
    ADD CONSTRAINT siparis_odemeleri_siparis_id_fkey FOREIGN KEY (siparis_id) REFERENCES public.siparisler(id);


--
-- Name: siparisler siparisler_kopya_kaynak_siparis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparisler
    ADD CONSTRAINT siparisler_kopya_kaynak_siparis_id_fkey FOREIGN KEY (kopya_kaynak_siparis_id) REFERENCES public.siparisler(id);


--
-- Name: siparisler siparisler_olusturan_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparisler
    ADD CONSTRAINT siparisler_olusturan_kullanici_id_fkey FOREIGN KEY (olusturan_kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: siparisler siparisler_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparisler
    ADD CONSTRAINT siparisler_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: siparisler siparisler_tedarikci_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparisler
    ADD CONSTRAINT siparisler_tedarikci_cari_id_fkey FOREIGN KEY (tedarikci_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: stok_kartlari stok_kartlari_kategori_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_kartlari
    ADD CONSTRAINT stok_kartlari_kategori_id_fkey FOREIGN KEY (kategori_id) REFERENCES public.stok_kategorileri(id);


--
-- Name: stok_kartlari stok_kartlari_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_kartlari
    ADD CONSTRAINT stok_kartlari_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: stok_kategorileri stok_kategorileri_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_kategorileri
    ADD CONSTRAINT stok_kategorileri_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: stok_maliyet_kalemleri stok_maliyet_kalemleri_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_maliyet_kalemleri
    ADD CONSTRAINT stok_maliyet_kalemleri_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id) ON DELETE CASCADE;


--
-- Name: stok_maliyet_kalemleri stok_maliyet_kalemleri_tedarikci_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_maliyet_kalemleri
    ADD CONSTRAINT stok_maliyet_kalemleri_tedarikci_cari_id_fkey FOREIGN KEY (tedarikci_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: stok_maliyet_kalemleri stok_maliyet_kalemleri_tedarikci_fatura_odeme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_maliyet_kalemleri
    ADD CONSTRAINT stok_maliyet_kalemleri_tedarikci_fatura_odeme_id_fkey FOREIGN KEY (tedarikci_fatura_odeme_id) REFERENCES public.tedarikci_fatura_odemeleri(id);


--
-- Name: stok_seri_no stok_seri_no_musteri_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_seri_no
    ADD CONSTRAINT stok_seri_no_musteri_cari_id_fkey FOREIGN KEY (musteri_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: stok_seri_no stok_seri_no_satis_cek_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_seri_no
    ADD CONSTRAINT stok_seri_no_satis_cek_id_fkey FOREIGN KEY (satis_cek_id) REFERENCES public.cekler(id);


--
-- Name: stok_seri_no stok_seri_no_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_seri_no
    ADD CONSTRAINT stok_seri_no_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: stok_seri_no stok_seri_no_stok_karti_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_seri_no
    ADD CONSTRAINT stok_seri_no_stok_karti_id_fkey FOREIGN KEY (stok_karti_id) REFERENCES public.stok_kartlari(id);


--
-- Name: stok_seri_no stok_seri_no_tedarikci_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_seri_no
    ADD CONSTRAINT stok_seri_no_tedarikci_cari_id_fkey FOREIGN KEY (tedarikci_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: taksit_detay taksit_detay_ilk_taksit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksit_detay
    ADD CONSTRAINT taksit_detay_ilk_taksit_id_fkey FOREIGN KEY (ilk_taksit_id) REFERENCES public.taksit_detay(id);


--
-- Name: taksit_detay taksit_detay_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksit_detay
    ADD CONSTRAINT taksit_detay_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.taksitli_satis_planlari(id) ON DELETE CASCADE;


--
-- Name: taksitli_satis_kalem_urunleri taksitli_satis_kalem_urunleri_kalem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_kalem_urunleri
    ADD CONSTRAINT taksitli_satis_kalem_urunleri_kalem_id_fkey FOREIGN KEY (kalem_id) REFERENCES public.taksitli_satis_kalemleri(id);


--
-- Name: taksitli_satis_kalem_urunleri taksitli_satis_kalem_urunleri_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_kalem_urunleri
    ADD CONSTRAINT taksitli_satis_kalem_urunleri_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: taksitli_satis_kalemleri taksitli_satis_kalemleri_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_kalemleri
    ADD CONSTRAINT taksitli_satis_kalemleri_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.taksitli_satis_planlari(id);


--
-- Name: taksitli_satis_kalemleri taksitli_satis_kalemleri_stok_karti_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_kalemleri
    ADD CONSTRAINT taksitli_satis_kalemleri_stok_karti_id_fkey FOREIGN KEY (stok_karti_id) REFERENCES public.stok_kartlari(id);


--
-- Name: taksitli_satis_planlari taksitli_satis_planlari_musteri_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_planlari
    ADD CONSTRAINT taksitli_satis_planlari_musteri_cari_id_fkey FOREIGN KEY (musteri_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: taksitli_satis_planlari taksitli_satis_planlari_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_planlari
    ADD CONSTRAINT taksitli_satis_planlari_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: taksitli_satis_planlari taksitli_satis_planlari_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_planlari
    ADD CONSTRAINT taksitli_satis_planlari_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: tedarikci_fatura_odemeleri tedarikci_fatura_odemeleri_banka_hesap_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tedarikci_fatura_odemeleri
    ADD CONSTRAINT tedarikci_fatura_odemeleri_banka_hesap_id_fkey FOREIGN KEY (banka_hesap_id) REFERENCES public.banka_hesaplari(id);


--
-- Name: tedarikci_fatura_odemeleri tedarikci_fatura_odemeleri_fatura_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tedarikci_fatura_odemeleri
    ADD CONSTRAINT tedarikci_fatura_odemeleri_fatura_id_fkey FOREIGN KEY (fatura_id) REFERENCES public.tedarikci_faturalari(id);


--
-- Name: tedarikci_fatura_odemeleri tedarikci_fatura_odemeleri_siparis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tedarikci_fatura_odemeleri
    ADD CONSTRAINT tedarikci_fatura_odemeleri_siparis_id_fkey FOREIGN KEY (siparis_id) REFERENCES public.siparisler(id);


--
-- Name: tedarikci_fatura_odemeleri tedarikci_fatura_odemeleri_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tedarikci_fatura_odemeleri
    ADD CONSTRAINT tedarikci_fatura_odemeleri_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: tedarikci_faturalari tedarikci_faturalari_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tedarikci_faturalari
    ADD CONSTRAINT tedarikci_faturalari_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: tedarikci_faturalari tedarikci_faturalari_tedarikci_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tedarikci_faturalari
    ADD CONSTRAINT tedarikci_faturalari_tedarikci_cari_id_fkey FOREIGN KEY (tedarikci_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: yedek_parca_hareketleri yedek_parca_hareketleri_banka_hesap_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yedek_parca_hareketleri
    ADD CONSTRAINT yedek_parca_hareketleri_banka_hesap_id_fkey FOREIGN KEY (banka_hesap_id) REFERENCES public.banka_hesaplari(id);


--
-- Name: yedek_parca_hareketleri yedek_parca_hareketleri_ilgili_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yedek_parca_hareketleri
    ADD CONSTRAINT yedek_parca_hareketleri_ilgili_cari_id_fkey FOREIGN KEY (ilgili_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: yedek_parca_hareketleri yedek_parca_hareketleri_ilgili_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yedek_parca_hareketleri
    ADD CONSTRAINT yedek_parca_hareketleri_ilgili_stok_seri_no_id_fkey FOREIGN KEY (ilgili_stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: yedek_parca_hareketleri yedek_parca_hareketleri_yedek_parca_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yedek_parca_hareketleri
    ADD CONSTRAINT yedek_parca_hareketleri_yedek_parca_id_fkey FOREIGN KEY (yedek_parca_id) REFERENCES public.yedek_parcalar(id);


--
-- Name: yedek_parcalar yedek_parcalar_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yedek_parcalar
    ADD CONSTRAINT yedek_parcalar_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_vectors(id);


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: akreditif_kalem_taksitleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.akreditif_kalem_taksitleri ENABLE ROW LEVEL SECURITY;

--
-- Name: akreditif_kalemleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.akreditif_kalemleri ENABLE ROW LEVEL SECURITY;

--
-- Name: akreditif_maliyet_dagitimlari; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.akreditif_maliyet_dagitimlari ENABLE ROW LEVEL SECURITY;

--
-- Name: akreditifler; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.akreditifler ENABLE ROW LEVEL SECURITY;

--
-- Name: bakim_kayitlari; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bakim_kayitlari ENABLE ROW LEVEL SECURITY;

--
-- Name: banka_hareketleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.banka_hareketleri ENABLE ROW LEVEL SECURITY;

--
-- Name: banka_hesaplari; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.banka_hesaplari ENABLE ROW LEVEL SECURITY;

--
-- Name: belgeler; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.belgeler ENABLE ROW LEVEL SECURITY;

--
-- Name: borc_odemeleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.borc_odemeleri ENABLE ROW LEVEL SECURITY;

--
-- Name: borclar; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.borclar ENABLE ROW LEVEL SECURITY;

--
-- Name: cari_acilis_bakiyeleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cari_acilis_bakiyeleri ENABLE ROW LEVEL SECURITY;

--
-- Name: cari_hareketler; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cari_hareketler ENABLE ROW LEVEL SECURITY;

--
-- Name: cari_hesaplar; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cari_hesaplar ENABLE ROW LEVEL SECURITY;

--
-- Name: cek_hareket_gecmisi; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cek_hareket_gecmisi ENABLE ROW LEVEL SECURITY;

--
-- Name: cekler; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cekler ENABLE ROW LEVEL SECURITY;

--
-- Name: demirbaslar; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.demirbaslar ENABLE ROW LEVEL SECURITY;

--
-- Name: doviz_kurlari; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.doviz_kurlari ENABLE ROW LEVEL SECURITY;

--
-- Name: duzenleme_kayitlari; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.duzenleme_kayitlari ENABLE ROW LEVEL SECURITY;

--
-- Name: fatura_detay; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fatura_detay ENABLE ROW LEVEL SECURITY;

--
-- Name: faturalar; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.faturalar ENABLE ROW LEVEL SECURITY;

--
-- Name: gumruk_beyannameleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.gumruk_beyannameleri ENABLE ROW LEVEL SECURITY;

--
-- Name: harcama_turleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.harcama_turleri ENABLE ROW LEVEL SECURITY;

--
-- Name: islem_loglari; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.islem_loglari ENABLE ROW LEVEL SECURITY;

--
-- Name: izinler; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.izinler ENABLE ROW LEVEL SECURITY;

--
-- Name: kasa_hareketleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kasa_hareketleri ENABLE ROW LEVEL SECURITY;

--
-- Name: kdv_manuel_girisler; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kdv_manuel_girisler ENABLE ROW LEVEL SECURITY;

--
-- Name: kiralama_kalem_urunleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kiralama_kalem_urunleri ENABLE ROW LEVEL SECURITY;

--
-- Name: kiralama_odemeleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kiralama_odemeleri ENABLE ROW LEVEL SECURITY;

--
-- Name: kiralama_sozlesme_kalemleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kiralama_sozlesme_kalemleri ENABLE ROW LEVEL SECURITY;

--
-- Name: kiralama_sozlesmeleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kiralama_sozlesmeleri ENABLE ROW LEVEL SECURITY;

--
-- Name: kullanici_rolleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kullanici_rolleri ENABLE ROW LEVEL SECURITY;

--
-- Name: kullanici_sirket_erisim; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kullanici_sirket_erisim ENABLE ROW LEVEL SECURITY;

--
-- Name: kullanicilar; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kullanicilar ENABLE ROW LEVEL SECURITY;

--
-- Name: leasing_kalem_urunleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.leasing_kalem_urunleri ENABLE ROW LEVEL SECURITY;

--
-- Name: leasing_odeme_plani; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.leasing_odeme_plani ENABLE ROW LEVEL SECURITY;

--
-- Name: leasing_sozlesme_kalemleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.leasing_sozlesme_kalemleri ENABLE ROW LEVEL SECURITY;

--
-- Name: leasing_sozlesmeleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.leasing_sozlesmeleri ENABLE ROW LEVEL SECURITY;

--
-- Name: personel; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.personel ENABLE ROW LEVEL SECURITY;

--
-- Name: personel_odemeleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.personel_odemeleri ENABLE ROW LEVEL SECURITY;

--
-- Name: pos_taksit_detay; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pos_taksit_detay ENABLE ROW LEVEL SECURITY;

--
-- Name: pos_taksit_planlari; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pos_taksit_planlari ENABLE ROW LEVEL SECURITY;

--
-- Name: proforma_detay; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.proforma_detay ENABLE ROW LEVEL SECURITY;

--
-- Name: proforma_faturalar; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.proforma_faturalar ENABLE ROW LEVEL SECURITY;

--
-- Name: rol_izinleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.rol_izinleri ENABLE ROW LEVEL SECURITY;

--
-- Name: roller; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.roller ENABLE ROW LEVEL SECURITY;

--
-- Name: sabit_gider_kategorileri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sabit_gider_kategorileri ENABLE ROW LEVEL SECURITY;

--
-- Name: sabit_giderler; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sabit_giderler ENABLE ROW LEVEL SECURITY;

--
-- Name: siparis_detay; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.siparis_detay ENABLE ROW LEVEL SECURITY;

--
-- Name: siparis_odemeleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.siparis_odemeleri ENABLE ROW LEVEL SECURITY;

--
-- Name: siparisler; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.siparisler ENABLE ROW LEVEL SECURITY;

--
-- Name: sirketler; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sirketler ENABLE ROW LEVEL SECURITY;

--
-- Name: stok_kartlari; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stok_kartlari ENABLE ROW LEVEL SECURITY;

--
-- Name: stok_kategorileri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stok_kategorileri ENABLE ROW LEVEL SECURITY;

--
-- Name: stok_maliyet_kalemleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stok_maliyet_kalemleri ENABLE ROW LEVEL SECURITY;

--
-- Name: stok_seri_no; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stok_seri_no ENABLE ROW LEVEL SECURITY;

--
-- Name: taksit_detay; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.taksit_detay ENABLE ROW LEVEL SECURITY;

--
-- Name: taksitli_satis_kalem_urunleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.taksitli_satis_kalem_urunleri ENABLE ROW LEVEL SECURITY;

--
-- Name: taksitli_satis_kalemleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.taksitli_satis_kalemleri ENABLE ROW LEVEL SECURITY;

--
-- Name: taksitli_satis_planlari; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.taksitli_satis_planlari ENABLE ROW LEVEL SECURITY;

--
-- Name: tedarikci_fatura_odemeleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tedarikci_fatura_odemeleri ENABLE ROW LEVEL SECURITY;

--
-- Name: tedarikci_faturalari; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tedarikci_faturalari ENABLE ROW LEVEL SECURITY;

--
-- Name: urun_sahiplik_gecmisi; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.urun_sahiplik_gecmisi ENABLE ROW LEVEL SECURITY;

--
-- Name: yedek_parca_hareketleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.yedek_parca_hareketleri ENABLE ROW LEVEL SECURITY;

--
-- Name: yedek_parcalar; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.yedek_parcalar ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.vector_indexes ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: -
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


--
-- PostgreSQL database dump complete
--

\unrestrict huA5hA60Sp7acBc5Ba1vQnW9627cjclOCIyGbcZO7XlvCL87EaiF9Hhd6HYOuMN

