--
-- PostgreSQL database dump
--

\restrict adgGEhyY9gTVnxknZ7o5bMkZ8OQcgX8c1OVfTWfb4cvLepWAFRH2XbmGMnNbEec

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.10 (Ubuntu 17.10-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA extensions;


--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql;


--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql_public;


--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pgbouncer;


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA realtime;


--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA storage;


--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA vault;


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


--
-- Name: bakim_tip_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bakim_tip_t AS ENUM (
    'GELIR',
    'GIDER'
);


--
-- Name: banka_hareket_tip_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.banka_hareket_tip_t AS ENUM (
    'GIRIS',
    'CIKIS',
    'HESAPLAR_ARASI_TRANSFER',
    'DOVIZ_ALIM',
    'DOVIZ_SATIM'
);


--
-- Name: borc_tip_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.borc_tip_t AS ENUM (
    'ORTAKTAN_ALINAN',
    'DISARIDAN_ALINAN',
    'ORTAGA_VERILEN'
);


--
-- Name: cari_tip_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.cari_tip_t AS ENUM (
    'MUSTERI',
    'TEDARIKCI',
    'PERSONEL',
    'ORTAK',
    'DIGER'
);


--
-- Name: cek_durum_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.cek_durum_t AS ENUM (
    'PORTFOYDE',
    'CIRO_EDILDI',
    'TAHSIL_EDILDI',
    'ODENDI',
    'KARSILIKSIZ',
    'IPTAL'
);


--
-- Name: cek_tip_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.cek_tip_t AS ENUM (
    'ALINAN',
    'VERILEN'
);


--
-- Name: hareket_yon_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.hareket_yon_t AS ENUM (
    'GIRIS',
    'CIKIS'
);


--
-- Name: maliyet_tip_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.maliyet_tip_t AS ENUM (
    'SATINALMA',
    'NAKLIYE',
    'GUMRUK',
    'ANTREPO',
    'MILLILESTIRME',
    'LEASING',
    'DIGER'
);


--
-- Name: para_birimi_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.para_birimi_t AS ENUM (
    'TRY',
    'USD',
    'EUR',
    'ALTIN'
);


--
-- Name: personel_odeme_tip_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.personel_odeme_tip_t AS ENUM (
    'MAAS',
    'AVANS',
    'PRIM',
    'SGK',
    'DIGER'
);


--
-- Name: siparis_durum_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.siparis_durum_t AS ENUM (
    'TASLAK',
    'ONAYLANDI',
    'YOLDA',
    'GUMRUKTE',
    'TESLIM_ALINDI',
    'TAMAMLANDI',
    'IPTAL'
);


--
-- Name: stok_durum_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.stok_durum_t AS ENUM (
    'DEPODA',
    'SIPARISTE',
    'YOLDA',
    'GUMRUKTE',
    'ANTREPODA',
    'SATILDI',
    'KIRADA',
    'BAKIMDA',
    'HURDA'
);


--
-- Name: stok_kaynak_t; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.stok_kaynak_t AS ENUM (
    'ITHALAT',
    'YURTICI_ALIM'
);


--
-- Name: action; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in',
    'like',
    'ilike',
    'is',
    'match',
    'imatch',
    'isdistinct'
);


--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text,
	negate boolean
);


--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: -
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
begin
    if not exists (
        select 1
        from pg_event_trigger_ddl_commands() ev
        join pg_catalog.pg_extension e on ev.objid = e.oid
        where e.extname = 'pg_graphql'
    ) then
        return;
    end if;

    drop function if exists graphql_public.graphql;
    create or replace function graphql_public.graphql(
        "operationName" text default null,
        query text default null,
        variables jsonb default null,
        extensions jsonb default null
    )
        returns jsonb
        language sql
    as $$
        select graphql.resolve(
            query := query,
            variables := coalesce(variables, '{}'),
            "operationName" := "operationName",
            extensions := extensions
        );
    $$;

    -- Attach the wrapper to the extension so DROP EXTENSION cascades to it,
    -- which in turn triggers set_graphql_placeholder to reinstall the "not enabled" stub.
    alter extension pg_graphql add function graphql_public.graphql(text, text, jsonb, jsonb);

    grant usage on schema graphql to postgres, anon, authenticated, service_role;
    grant execute on function graphql.resolve to postgres, anon, authenticated, service_role;
    grant usage on schema graphql to postgres with grant option;
    grant usage on schema graphql_public to postgres with grant option;
end;
$_$;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql(text, text, jsonb, jsonb); Type: FUNCTION; Schema: graphql_public; Owner: -
--

CREATE FUNCTION graphql_public.graphql("operationName" text DEFAULT NULL::text, query text DEFAULT NULL::text, variables jsonb DEFAULT NULL::jsonb, extensions jsonb DEFAULT NULL::jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: -
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
    -- Regclass of the table e.g. public.notes
    entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

    -- I, U, D, T: insert, update ...
    action realtime.action = (
        case wal ->> 'action'
            when 'I' then 'INSERT'
            when 'U' then 'UPDATE'
            when 'D' then 'DELETE'
            else 'ERROR'
        end
    );

    -- Is row level security enabled for the table
    is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

    subscriptions realtime.subscription[] = array_agg(subs)
        from
            realtime.subscription subs
        where
            subs.entity = entity_
            -- Filter by action early - only get subscriptions interested in this action
            -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
            and (subs.action_filter = '*' or subs.action_filter = action::text);

    -- Subscription vars
    working_role regrole;
    working_selected_columns text[];
    claimed_role regrole;
    claims jsonb;

    subscription_id uuid;
    subscription_has_access bool;
    visible_to_subscription_ids uuid[] = '{}';

    -- structured info for wal's columns
    columns realtime.wal_column[];
    -- previous identity values for update/delete
    old_columns realtime.wal_column[];

    error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

    -- Primary jsonb output for record
    output jsonb;

    -- Loop record for iterating unique roles (outer loop)
    role_record record;
    -- Loop record for iterating unique selected_columns within a role (inner loop)
    cols_record record;
    -- Subscription ids visible at the role level (before fanning out by selected_columns)
    visible_role_sub_ids uuid[] = '{}';

begin
    perform set_config('role', null, true);

    columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'columns') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    old_columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'identity') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    for role_record in
        select claims_role
        from (select distinct claims_role from unnest(subscriptions)) t
        order by claims_role::text
    loop
        working_role := role_record.claims_role;

        -- Update `is_selectable` for columns and old_columns (once per role)
        columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(columns) c;

        old_columns =
                array_agg(
                    (
                        c.name,
                        c.type_name,
                        c.type_oid,
                        c.value,
                        c.is_pkey,
                        pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                    )::realtime.wal_column
                )
                from
                    unnest(old_columns) c;

        if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
            -- Fan out 400 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 400: Bad Request, no primary key']
                )::realtime.wal_rls;
            end loop;

        -- The claims role does not have SELECT permission to the primary key of entity
        elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
            -- Fan out 401 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 401: Unauthorized']
                )::realtime.wal_rls;
            end loop;

        else
            -- Create the prepared statement (once per role)
            if is_rls_enabled and action <> 'DELETE' then
                if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                    deallocate walrus_rls_stmt;
                end if;
                execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
            end if;

            -- Collect all visible subscription IDs for this role (filter check + RLS check)
            visible_role_sub_ids = '{}';

            for subscription_id, claims in (
                    select
                        subs.subscription_id,
                        subs.claims
                    from
                        unnest(subscriptions) subs
                    where
                        subs.entity = entity_
                        and subs.claims_role = working_role
                        and (
                            realtime.is_visible_through_filters(columns, subs.filters)
                            or (
                              action = 'DELETE'
                              and realtime.is_visible_through_filters(old_columns, subs.filters)
                            )
                        )
            ) loop

                if not is_rls_enabled or action = 'DELETE' then
                    visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                else
                    -- Check if RLS allows the role to see the record
                    perform
                        -- Trim leading and trailing quotes from working_role because set_config
                        -- doesn't recognize the role as valid if they are included
                        set_config('role', trim(both '"' from working_role::text), true),
                        set_config('request.jwt.claims', claims::text, true);

                    execute 'execute walrus_rls_stmt' into subscription_has_access;

                    -- Reset the role on every FOR..LOOP batch execution.
                    -- The first batch of 10 rows is pre-fetched using the current connection role (PG internal behaviour)
                    -- then we have to reset it again otherwise it would use the role defined in the `set_config` above
                    -- to fetch the remaining rows when rows>10, which could be a user-defined role that lacks execution grants.
                    -- The flow is:
                    --   1. run batch with conn role
                    --   2. set_config working_role
                    --   3. execute walrus
                    --   4. reset role (revert)
                    --   5. repeat
                    perform set_config('role', null, true);

                    if subscription_has_access then
                        visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                    end if;
                end if;
            end loop;

            perform set_config('role', null, true);

            -- Inner loop: per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;

                output = jsonb_build_object(
                    'schema', wal ->> 'schema',
                    'table', wal ->> 'table',
                    'type', action,
                    'commit_timestamp', to_char(
                        ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                        'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
                    ),
                    'columns', (
                        select
                            jsonb_agg(
                                jsonb_build_object(
                                    'name', pa.attname,
                                    'type', pt.typname
                                )
                                order by pa.attnum asc
                            )
                        from
                            pg_attribute pa
                            join pg_type pt
                                on pa.atttypid = pt.oid
                            left join (
                                select unnest(conkey) as pkey_attnum
                                from pg_constraint
                                where conrelid = entity_ and contype = 'p'
                            ) pk on pk.pkey_attnum = pa.attnum
                        where
                            attrelid = entity_
                            and attnum > 0
                            and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                            and (working_selected_columns is null or pa.attname = any(working_selected_columns) or pk.pkey_attnum is not null)
                    )
                )
                -- Add "record" key for insert and update
                || case
                    when action in ('INSERT', 'UPDATE') then
                        jsonb_build_object(
                            'record',
                            (
                                select
                                    jsonb_object_agg(
                                        -- if unchanged toast, get column name and value from old record
                                        coalesce((c).name, (oc).name),
                                        case
                                            when (c).name is null then (oc).value
                                            else (c).value
                                        end
                                    )
                                from
                                    unnest(columns) c
                                    full outer join unnest(old_columns) oc
                                        on (c).name = (oc).name
                                where
                                    coalesce((c).is_selectable, (oc).is_selectable)
                                    and (working_selected_columns is null or coalesce((c).name, (oc).name) = any(working_selected_columns) or coalesce((c).is_pkey, (oc).is_pkey))
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            )
                        )
                    else '{}'::jsonb
                end
                -- Add "old_record" key for update and delete
                || case
                    when action = 'UPDATE' then
                        jsonb_build_object(
                                'old_record',
                                (
                                    select jsonb_object_agg((c).name, (c).value)
                                    from unnest(old_columns) c
                                    where
                                        (c).is_selectable
                                        and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                        and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                )
                            )
                    when action = 'DELETE' then
                        jsonb_build_object(
                            'old_record',
                            (
                                select jsonb_object_agg((c).name, (c).value)
                                from unnest(old_columns) c
                                where
                                    (c).is_selectable
                                    and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                    and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                            )
                        )
                    else '{}'::jsonb
                end;

                -- Filter visible_role_sub_ids to those matching the current selected_columns group
                visible_to_subscription_ids = coalesce(
                    (
                        select array_agg(s.subscription_id)
                        from unnest(subscriptions) s
                        where s.claims_role = working_role
                          and (s.selected_columns is not distinct from working_selected_columns)
                          and s.subscription_id = any(visible_role_sub_ids)
                    ),
                    '{}'::uuid[]
                );

                return next (
                    output,
                    is_rls_enabled,
                    visible_to_subscription_ids,
                    case
                        when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                        else '{}'
                    end
                )::realtime.wal_rls;
            end loop;

        end if;
    end loop;

    perform set_config('role', null, true);
end;
$$;


--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
/*
Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
*/
declare
    op_symbol text = (
        case
            when op = 'eq' then '='
            when op = 'neq' then '!='
            when op = 'lt' then '<'
            when op = 'lte' then '<='
            when op = 'gt' then '>'
            when op = 'gte' then '>='
            when op = 'in' then '= any'
            else 'UNKNOWN OP'
        end
    );
    res boolean;
begin
    execute format(
        'select %L::'|| type_::text || ' ' || op_symbol
        || ' ( %L::'
        || (
            case
                when op = 'in' then type_::text || '[]'
                else type_::text end
        )
        || ')', val_1, val_2) into res;
    return res;
end;
$$;


--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $$
declare
    op_symbol text;
    res boolean;
begin
    -- IS DISTINCT FROM / IS NOT DISTINCT FROM: infix, both sides typed literals
    if op = 'isdistinct' then
        execute format(
            'select %L::%s %s %L::%s',
            val_1,
            type_::text,
            case when negate then 'IS NOT DISTINCT FROM' else 'IS DISTINCT FROM' end,
            val_2,
            type_::text
        ) into res;
        return res;
    end if;

    -- IS requires a keyword RHS (NULL, TRUE, FALSE, UNKNOWN), not a typed literal
    if op = 'is' then
        if val_2 not in ('null', 'true', 'false', 'unknown') then
            raise exception 'invalid value for is filter: must be null, true, false, or unknown';
        end if;
        execute format(
            'select %L::%s %s %s',
            val_1,
            type_::text,
            case when negate then 'IS NOT' else 'IS' end,
            upper(val_2)
        ) into res;
        return res;
    end if;

    op_symbol = case
        when op = 'eq'    then '='
        when op = 'neq'   then '!='
        when op = 'lt'    then '<'
        when op = 'lte'   then '<='
        when op = 'gt'    then '>'
        when op = 'gte'   then '>='
        when op = 'in'    then '= any'
        when op = 'like'   then 'LIKE'
        when op = 'ilike'  then 'ILIKE'
        when op = 'match'  then '~'
        when op = 'imatch' then '~*'
        else null
    end;

    if op_symbol is null then
        raise exception 'unsupported equality operator: %', op::text;
    end if;

    execute format(
        'select %L::%s %s (%L::%s)',
        val_1,
        type_::text,
        op_symbol,
        val_2,
        case when op = 'in' then type_::text || '[]' else type_::text end
    ) into res;

    return case when negate then not res else res end;
end;
$$;


--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
    select
        filters is null
        or array_length(filters, 1) is null
        or coalesce(
            count(col.name) = count(1)
            and sum(
                realtime.check_equality_op(
                    op:=f.op,
                    type_:=coalesce(col.type_oid::regtype, col.type_name::regtype),
                    val_1:=col.value #>> '{}',
                    val_2:=f.value,
                    negate:=coalesce(f.negate, false)
                )::int
            ) filter (where col.name is not null) = count(col.name),
            false
        )
    from
        unnest(filters) f
        left join unnest(columns) col
            on f.column_name = col.name;
$$;


--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS TABLE(wal jsonb, is_rls_enabled boolean, subscription_ids uuid[], errors text[], slot_changes_count bigint)
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;


--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- Name: send_binary(bytea, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
    col_names text[] = coalesce(
            array_agg(a.attname order by a.attnum),
            '{}'::text[]
        )
        from
            pg_catalog.pg_attribute a
        where
            a.attrelid = new.entity
            and a.attnum > 0
            and not a.attisdropped
            and pg_catalog.has_column_privilege(
                (new.claims ->> 'role'),
                a.attrelid,
                a.attnum,
                'SELECT'
            );
    filter realtime.user_defined_filter;
    col_type regtype;
    in_val jsonb;
    selected_col text;
begin
    for filter in select * from unnest(new.filters) loop
        if not filter.column_name = any(col_names) then
            raise exception 'invalid column for filter %', filter.column_name;
        end if;

        col_type = (
            select atttypid::regtype
            from pg_catalog.pg_attribute
            where attrelid = new.entity
                  and attname = filter.column_name
        );
        if col_type is null then
            raise exception 'failed to lookup type for column %', filter.column_name;
        end if;

        if filter.op = 'in'::realtime.equality_op then
            in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
            if coalesce(jsonb_array_length(in_val), 0) > 100 then
                raise exception 'too many values for `in` filter. Maximum 100';
            end if;
        elsif filter.op = 'is'::realtime.equality_op then
            -- `is` requires a keyword RHS rather than a typed literal
            if filter.value not in ('null', 'true', 'false', 'unknown') then
                raise exception 'invalid value for is filter: must be null, true, false, or unknown';
            end if;
            -- IS NULL works for any type, but IS TRUE/FALSE/UNKNOWN require a boolean
            -- operand. Reject the non-null keywords on non-boolean columns here so they
            -- don't abort apply_rls at WAL time.
            if filter.value <> 'null' and col_type <> 'boolean'::regtype then
                raise exception 'is % filter requires a boolean column, got %', filter.value, col_type::text;
            end if;
        elsif filter.op in ('like'::realtime.equality_op, 'ilike'::realtime.equality_op) then
            -- like/ilike apply the text pattern operator (~~); reject column types that
            -- have no such operator instead of failing at WAL time
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = '~~' and oprleft = col_type
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
        elsif filter.op in ('match'::realtime.equality_op, 'imatch'::realtime.equality_op) then
            -- match/imatch apply the regex operators ~ / ~*; reject column types that have
            -- no such operator (e.g. integer) instead of failing at WAL time, mirroring the
            -- like/ilike guard above.
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = case when filter.op = 'imatch'::realtime.equality_op then '~*' else '~' end
                  and oprleft = col_type
                  and oprright = col_type
                  and oprresult = 'boolean'::regtype
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
            -- validate the regex eagerly so a bad pattern is rejected here, not inside
            -- apply_rls where it would abort the WAL stream for the entity
            begin
                perform '' ~ filter.value;
            exception when others then
                raise exception 'invalid regular expression for % filter: %', filter.op::text, sqlerrm;
            end;
        else
            -- eq/neq/lt/lte/gt/gte: value must be coercable to the type
            perform realtime.cast(filter.value, col_type);
        end if;
    end loop;

    if new.selected_columns is not null then
        for selected_col in select * from unnest(new.selected_columns) loop
            if not selected_col = any(col_names) then
                raise exception 'invalid column for select %', selected_col;
            end if;
        end loop;
    end if;

    -- Apply consistent order to filters so the unique constraint can't be tricked by a
    -- different filter order. negate is part of the sort key.
    new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value, f.negate),
        '{}'
    ) from unnest(new.filters) f;

    new.selected_columns = (
        select array_agg(c order by c)
        from unnest(new.selected_columns) c
    );

    return new;
end;
$$;


--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


--
-- Name: wal2json_escape_identifier(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.wal2json_escape_identifier(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;


--
-- Name: allow_any_operation(text[]); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.allow_any_operation(expected_operations text[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


--
-- Name: allow_only_operation(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.allow_only_operation(expected_operation text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


--
-- Name: get_common_prefix(text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.protect_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


--
-- Name: search_by_timestamp(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


--
-- Name: search_v2(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.custom_oauth_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_type text NOT NULL,
    identifier text NOT NULL,
    name text NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    acceptable_client_ids text[] DEFAULT '{}'::text[] NOT NULL,
    scopes text[] DEFAULT '{}'::text[] NOT NULL,
    pkce_enabled boolean DEFAULT true NOT NULL,
    attribute_mapping jsonb DEFAULT '{}'::jsonb NOT NULL,
    authorization_params jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    email_optional boolean DEFAULT false NOT NULL,
    issuer text,
    discovery_url text,
    skip_nonce_check boolean DEFAULT false NOT NULL,
    cached_discovery jsonb,
    discovery_cached_at timestamp with time zone,
    authorization_url text,
    token_url text,
    userinfo_url text,
    jwks_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    custom_claims_allowlist text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT custom_oauth_providers_authorization_url_https CHECK (((authorization_url IS NULL) OR (authorization_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_authorization_url_length CHECK (((authorization_url IS NULL) OR (char_length(authorization_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_client_id_length CHECK (((char_length(client_id) >= 1) AND (char_length(client_id) <= 512))),
    CONSTRAINT custom_oauth_providers_discovery_url_length CHECK (((discovery_url IS NULL) OR (char_length(discovery_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_identifier_format CHECK ((identifier ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::text)),
    CONSTRAINT custom_oauth_providers_issuer_length CHECK (((issuer IS NULL) OR ((char_length(issuer) >= 1) AND (char_length(issuer) <= 2048)))),
    CONSTRAINT custom_oauth_providers_jwks_uri_https CHECK (((jwks_uri IS NULL) OR (jwks_uri ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_jwks_uri_length CHECK (((jwks_uri IS NULL) OR (char_length(jwks_uri) <= 2048))),
    CONSTRAINT custom_oauth_providers_name_length CHECK (((char_length(name) >= 1) AND (char_length(name) <= 100))),
    CONSTRAINT custom_oauth_providers_oauth2_requires_endpoints CHECK (((provider_type <> 'oauth2'::text) OR ((authorization_url IS NOT NULL) AND (token_url IS NOT NULL) AND (userinfo_url IS NOT NULL)))),
    CONSTRAINT custom_oauth_providers_oidc_discovery_url_https CHECK (((provider_type <> 'oidc'::text) OR (discovery_url IS NULL) OR (discovery_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_issuer_https CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NULL) OR (issuer ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_requires_issuer CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NOT NULL))),
    CONSTRAINT custom_oauth_providers_provider_type_check CHECK ((provider_type = ANY (ARRAY['oauth2'::text, 'oidc'::text]))),
    CONSTRAINT custom_oauth_providers_token_url_https CHECK (((token_url IS NULL) OR (token_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_token_url_length CHECK (((token_url IS NULL) OR (char_length(token_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_userinfo_url_https CHECK (((userinfo_url IS NULL) OR (userinfo_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_userinfo_url_length CHECK (((userinfo_url IS NULL) OR (char_length(userinfo_url) <= 2048)))
);


--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text,
    code_challenge_method auth.code_challenge_method,
    code_challenge text,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone,
    invite_token text,
    referrer text,
    oauth_client_state_id uuid,
    linking_target_id uuid,
    email_optional boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.flow_state IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid,
    last_webauthn_challenge_data jsonb
);


--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: COLUMN mfa_factors.last_webauthn_challenge_data; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.mfa_factors.last_webauthn_challenge_data IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    nonce text,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_nonce_length CHECK ((char_length(nonce) <= 255)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_client_states (
    id uuid NOT NULL,
    provider_type text NOT NULL,
    code_verifier text,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: TABLE oauth_client_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.oauth_client_states IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    token_endpoint_auth_method text NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048)),
    CONSTRAINT oauth_clients_token_endpoint_auth_method_check CHECK ((token_endpoint_auth_method = ANY (ARRAY['client_secret_basic'::text, 'client_secret_post'::text, 'none'::text])))
);


--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: -
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: -
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid,
    refresh_token_hmac_key text,
    refresh_token_counter bigint,
    scopes text,
    CONSTRAINT sessions_scopes_length CHECK ((char_length(scopes) <= 4096))
);


--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN sessions.refresh_token_hmac_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_hmac_key IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN sessions.refresh_token_counter; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_counter IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    challenge_type text NOT NULL,
    session_data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT webauthn_challenges_challenge_type_check CHECK ((challenge_type = ANY (ARRAY['signup'::text, 'registration'::text, 'authentication'::text])))
);


--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    credential_id bytea NOT NULL,
    public_key bytea NOT NULL,
    attestation_type text DEFAULT ''::text NOT NULL,
    aaguid uuid,
    sign_count bigint DEFAULT 0 NOT NULL,
    transports jsonb DEFAULT '[]'::jsonb NOT NULL,
    backup_eligible boolean DEFAULT false NOT NULL,
    backed_up boolean DEFAULT false NOT NULL,
    friendly_name text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone
);


--
-- Name: akreditif_kalem_taksitleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.akreditif_kalem_taksitleri (
    id bigint NOT NULL,
    kalem_id bigint NOT NULL,
    taksit_no integer NOT NULL,
    vade_tarihi date NOT NULL,
    tutar numeric(18,2) NOT NULL,
    odendi_mi boolean DEFAULT false,
    odeme_tarihi date
);


--
-- Name: akreditif_kalem_taksitleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.akreditif_kalem_taksitleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: akreditif_kalem_taksitleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.akreditif_kalem_taksitleri_id_seq OWNED BY public.akreditif_kalem_taksitleri.id;


--
-- Name: akreditif_kalemleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.akreditif_kalemleri (
    id bigint NOT NULL,
    akreditif_id bigint NOT NULL,
    tip character varying(20) NOT NULL,
    aciklama character varying(300),
    tutar numeric(18,2) NOT NULL,
    vade_tarihi date NOT NULL,
    odendi_mi boolean DEFAULT false,
    odeme_tarihi date,
    odenen_tutar numeric(18,2) DEFAULT 0 NOT NULL
);


--
-- Name: akreditif_kalemleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.akreditif_kalemleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: akreditif_kalemleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.akreditif_kalemleri_id_seq OWNED BY public.akreditif_kalemleri.id;


--
-- Name: akreditif_maliyet_dagitimlari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.akreditif_maliyet_dagitimlari (
    id bigint NOT NULL,
    akreditif_id bigint NOT NULL,
    stok_seri_no_id bigint NOT NULL,
    yontem character varying(20) NOT NULL,
    kur numeric(18,4),
    tutar_try numeric(18,2) NOT NULL,
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: akreditif_maliyet_dagitimlari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.akreditif_maliyet_dagitimlari_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: akreditif_maliyet_dagitimlari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.akreditif_maliyet_dagitimlari_id_seq OWNED BY public.akreditif_maliyet_dagitimlari.id;


--
-- Name: akreditifler; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.akreditifler (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    siparis_id bigint NOT NULL,
    banka_hesap_id bigint NOT NULL,
    akreditif_no character varying(100),
    tip character varying(20) DEFAULT 'VADELI'::character varying NOT NULL,
    para_birimi character varying(10) NOT NULL,
    tutar numeric(18,2) NOT NULL,
    acilis_tarihi date NOT NULL,
    vade_tarihi date,
    durum character varying(20) DEFAULT 'ACIK'::character varying NOT NULL,
    notlar text,
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: akreditifler_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.akreditifler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: akreditifler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.akreditifler_id_seq OWNED BY public.akreditifler.id;


--
-- Name: bakim_kayitlari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bakim_kayitlari (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    stok_seri_no_id bigint NOT NULL,
    tarih date NOT NULL,
    tip public.bakim_tip_t NOT NULL,
    aciklama character varying(500),
    ilgili_cari_id bigint,
    tutar numeric(18,2) NOT NULL,
    para_birimi public.para_birimi_t DEFAULT 'TRY'::public.para_birimi_t NOT NULL,
    odendi_tahsil_edildi_mi boolean DEFAULT false
);


--
-- Name: bakim_kayitlari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bakim_kayitlari_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bakim_kayitlari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bakim_kayitlari_id_seq OWNED BY public.bakim_kayitlari.id;


--
-- Name: banka_hareketleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.banka_hareketleri (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    banka_hesap_id bigint NOT NULL,
    tarih date NOT NULL,
    tip public.banka_hareket_tip_t NOT NULL,
    tutar numeric(18,2) NOT NULL,
    aciklama character varying(500),
    karsi_hesap_id bigint,
    kullanilan_kur numeric(18,4),
    kaynak_tablo character varying(50),
    kaynak_id bigint,
    cari_id bigint,
    olusturan_kullanici_id bigint,
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    tutar_try_karsiligi numeric(18,2)
);


--
-- Name: banka_hareketleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.banka_hareketleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: banka_hareketleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.banka_hareketleri_id_seq OWNED BY public.banka_hareketleri.id;


--
-- Name: banka_hesaplari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.banka_hesaplari (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    banka_adi character varying(150) NOT NULL,
    sube character varying(100),
    hesap_adi character varying(150),
    iban character varying(50),
    para_birimi public.para_birimi_t NOT NULL,
    guncel_bakiye numeric(18,2) DEFAULT 0,
    aktif boolean DEFAULT true
);


--
-- Name: banka_hesaplari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.banka_hesaplari_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: banka_hesaplari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.banka_hesaplari_id_seq OWNED BY public.banka_hesaplari.id;


--
-- Name: borc_odemeleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.borc_odemeleri (
    id bigint NOT NULL,
    borc_id bigint NOT NULL,
    tarih date NOT NULL,
    tutar numeric(18,2) NOT NULL,
    aciklama character varying(300)
);


--
-- Name: borc_odemeleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.borc_odemeleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: borc_odemeleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.borc_odemeleri_id_seq OWNED BY public.borc_odemeleri.id;


--
-- Name: borclar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.borclar (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    tip public.borc_tip_t NOT NULL,
    cari_id bigint NOT NULL,
    tutar numeric(18,2) NOT NULL,
    para_birimi public.para_birimi_t NOT NULL,
    faiz_orani numeric(6,3) DEFAULT 0,
    alinma_tarihi date NOT NULL,
    vade_tarihi date,
    notlar text
);


--
-- Name: borclar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.borclar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: borclar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.borclar_id_seq OWNED BY public.borclar.id;


--
-- Name: cari_hareketler; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cari_hareketler (
    id bigint NOT NULL,
    cari_id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    tarih date NOT NULL,
    aciklama character varying(500),
    yon public.hareket_yon_t NOT NULL,
    para_birimi public.para_birimi_t NOT NULL,
    tutar numeric(18,2) NOT NULL,
    tutar_try_karsiligi numeric(18,2),
    kaynak_tablo character varying(50),
    kaynak_id bigint,
    olusturan_kullanici_id bigint,
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: cari_hareketler_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cari_hareketler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cari_hareketler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cari_hareketler_id_seq OWNED BY public.cari_hareketler.id;


--
-- Name: cari_hesaplar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cari_hesaplar (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    tip public.cari_tip_t NOT NULL,
    unvan character varying(255) NOT NULL,
    vergi_no character varying(20),
    vergi_dairesi character varying(100),
    adres text,
    telefon character varying(50),
    email character varying(100),
    otomatik_dolduruldu boolean DEFAULT false,
    bakiye_try numeric(18,2) DEFAULT 0,
    bakiye_usd numeric(18,2) DEFAULT 0,
    bakiye_eur numeric(18,2) DEFAULT 0,
    aktif boolean DEFAULT true,
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: cari_hesaplar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cari_hesaplar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cari_hesaplar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cari_hesaplar_id_seq OWNED BY public.cari_hesaplar.id;


--
-- Name: cek_hareket_gecmisi; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cek_hareket_gecmisi (
    id bigint NOT NULL,
    cek_id bigint NOT NULL,
    tarih date NOT NULL,
    eski_durum public.cek_durum_t,
    yeni_durum public.cek_durum_t,
    aciklama character varying(300),
    olusturan_kullanici_id bigint
);


--
-- Name: cek_hareket_gecmisi_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cek_hareket_gecmisi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cek_hareket_gecmisi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cek_hareket_gecmisi_id_seq OWNED BY public.cek_hareket_gecmisi.id;


--
-- Name: cekler; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cekler (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    tip public.cek_tip_t NOT NULL,
    cek_no character varying(50),
    banka_adi character varying(150),
    cari_id bigint,
    tutar numeric(18,2) NOT NULL,
    para_birimi public.para_birimi_t DEFAULT 'TRY'::public.para_birimi_t NOT NULL,
    vade_tarihi date NOT NULL,
    alinma_verilme_tarihi date NOT NULL,
    durum public.cek_durum_t DEFAULT 'PORTFOYDE'::public.cek_durum_t,
    ciro_edilen_cari_id bigint,
    ciro_tarihi date,
    notlar character varying(500),
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: cekler_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cekler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cekler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cekler_id_seq OWNED BY public.cekler.id;


--
-- Name: demirbaslar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.demirbaslar (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    kategori character varying(30) NOT NULL,
    ad character varying(200) NOT NULL,
    tanimlayici_no character varying(100),
    konum character varying(300),
    durum character varying(20) DEFAULT 'KULLANIMDA'::character varying NOT NULL,
    kiraci_cari_id bigint,
    maliyet_try numeric(18,2) DEFAULT 0 NOT NULL,
    alim_tarihi date,
    satis_fiyati_try numeric(18,2),
    satis_tarihi date,
    notlar character varying(500),
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    maliyet_orijinal numeric(18,2),
    para_birimi character varying(10) DEFAULT 'TRY'::character varying NOT NULL,
    amortisman_orani numeric(5,2)
);


--
-- Name: demirbaslar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.demirbaslar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: demirbaslar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.demirbaslar_id_seq OWNED BY public.demirbaslar.id;


--
-- Name: doviz_kurlari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doviz_kurlari (
    id bigint NOT NULL,
    para_birimi public.para_birimi_t NOT NULL,
    tarih date NOT NULL,
    alis numeric(18,4) NOT NULL,
    satis numeric(18,4) NOT NULL
);


--
-- Name: doviz_kurlari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.doviz_kurlari_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: doviz_kurlari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.doviz_kurlari_id_seq OWNED BY public.doviz_kurlari.id;


--
-- Name: duzenleme_kayitlari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.duzenleme_kayitlari (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    kullanici_id bigint NOT NULL,
    tablo_adi character varying(50) NOT NULL,
    kayit_id bigint NOT NULL,
    degisiklikler text,
    tarih timestamp without time zone DEFAULT now()
);


--
-- Name: duzenleme_kayitlari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.duzenleme_kayitlari_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: duzenleme_kayitlari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.duzenleme_kayitlari_id_seq OWNED BY public.duzenleme_kayitlari.id;


--
-- Name: fatura_detay; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fatura_detay (
    id bigint NOT NULL,
    fatura_id bigint NOT NULL,
    stok_karti_id bigint,
    stok_seri_no_id bigint,
    aciklama character varying(300),
    miktar numeric(18,2) DEFAULT 1 NOT NULL,
    birim_fiyat numeric(18,2) NOT NULL,
    kdv_orani numeric(5,2) DEFAULT 20
);


--
-- Name: fatura_detay_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fatura_detay_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fatura_detay_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fatura_detay_id_seq OWNED BY public.fatura_detay.id;


--
-- Name: faturalar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.faturalar (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    fatura_no character varying(50) NOT NULL,
    proforma_id bigint,
    cari_id bigint NOT NULL,
    tarih date NOT NULL,
    para_birimi public.para_birimi_t NOT NULL,
    ara_toplam numeric(18,2) NOT NULL,
    kdv_tutari numeric(18,2) DEFAULT 0,
    genel_toplam numeric(18,2) NOT NULL,
    odeme_durumu character varying(20) DEFAULT 'ODENMEDI'::character varying,
    notlar text,
    olusturan_kullanici_id bigint,
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: faturalar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.faturalar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: faturalar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.faturalar_id_seq OWNED BY public.faturalar.id;


--
-- Name: gumruk_beyannameleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gumruk_beyannameleri (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    siparis_id bigint NOT NULL,
    beyanname_no character varying(100),
    beyanname_tarihi date NOT NULL,
    gumruk_musaviri_cari_id bigint,
    tutar numeric(18,2) NOT NULL,
    para_birimi character varying(10) DEFAULT 'TRY'::character varying NOT NULL,
    kur numeric(18,6) DEFAULT 1 NOT NULL,
    tutar_try numeric(18,2) NOT NULL,
    notlar character varying(500),
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    kdv_tutari numeric(18,2) DEFAULT 0 NOT NULL
);


--
-- Name: gumruk_beyannameleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gumruk_beyannameleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gumruk_beyannameleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gumruk_beyannameleri_id_seq OWNED BY public.gumruk_beyannameleri.id;


--
-- Name: harcama_turleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.harcama_turleri (
    id bigint NOT NULL,
    ad character varying(150) NOT NULL,
    aktif boolean DEFAULT true
);


--
-- Name: harcama_turleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.harcama_turleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: harcama_turleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.harcama_turleri_id_seq OWNED BY public.harcama_turleri.id;


--
-- Name: islem_loglari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.islem_loglari (
    id bigint NOT NULL,
    sirket_id bigint,
    kullanici_id bigint,
    tablo_adi character varying(100),
    kayit_id bigint,
    islem_tipi character varying(20),
    eski_deger jsonb,
    yeni_deger jsonb,
    tarih timestamp without time zone DEFAULT now()
);


--
-- Name: islem_loglari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.islem_loglari_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: islem_loglari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.islem_loglari_id_seq OWNED BY public.islem_loglari.id;


--
-- Name: izinler; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.izinler (
    id bigint NOT NULL,
    kod character varying(100) NOT NULL,
    modul character varying(100) NOT NULL,
    aciklama character varying(255)
);


--
-- Name: izinler_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.izinler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: izinler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.izinler_id_seq OWNED BY public.izinler.id;


--
-- Name: kasa_hareketleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kasa_hareketleri (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    tarih date NOT NULL,
    yon public.hareket_yon_t NOT NULL,
    tutar numeric(18,2) NOT NULL,
    aciklama character varying(500),
    kaynak_tablo character varying(50),
    kaynak_id bigint,
    olusturan_kullanici_id bigint,
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    para_birimi character varying(10) DEFAULT 'TRY'::character varying NOT NULL,
    tutar_try_karsiligi numeric(18,2),
    cari_id bigint
);


--
-- Name: kasa_hareketleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kasa_hareketleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kasa_hareketleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kasa_hareketleri_id_seq OWNED BY public.kasa_hareketleri.id;


--
-- Name: kdv_manuel_girisler; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kdv_manuel_girisler (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    ay character varying(7) NOT NULL,
    tutar_try numeric(18,2) NOT NULL,
    aciklama character varying(300),
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: kdv_manuel_girisler_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kdv_manuel_girisler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kdv_manuel_girisler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kdv_manuel_girisler_id_seq OWNED BY public.kdv_manuel_girisler.id;


--
-- Name: kiralama_kalem_urunleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kiralama_kalem_urunleri (
    id bigint NOT NULL,
    kalem_id bigint NOT NULL,
    stok_seri_no_id bigint NOT NULL
);


--
-- Name: kiralama_kalem_urunleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kiralama_kalem_urunleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kiralama_kalem_urunleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kiralama_kalem_urunleri_id_seq OWNED BY public.kiralama_kalem_urunleri.id;


--
-- Name: kiralama_odemeleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kiralama_odemeleri (
    id bigint NOT NULL,
    sozlesme_id bigint NOT NULL,
    donem_basi date NOT NULL,
    donem_sonu date NOT NULL,
    tutar numeric(18,2) NOT NULL,
    odendi_mi boolean DEFAULT false,
    odeme_tarihi date,
    tahsilat_kaynak_tablo character varying(50),
    tahsilat_kaynak_id bigint
);


--
-- Name: kiralama_odemeleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kiralama_odemeleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kiralama_odemeleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kiralama_odemeleri_id_seq OWNED BY public.kiralama_odemeleri.id;


--
-- Name: kiralama_sozlesme_kalemleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kiralama_sozlesme_kalemleri (
    id bigint NOT NULL,
    sozlesme_id bigint NOT NULL,
    stok_karti_id bigint NOT NULL,
    miktar integer DEFAULT 1 NOT NULL,
    birim_fiyat numeric(18,2) NOT NULL
);


--
-- Name: kiralama_sozlesme_kalemleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kiralama_sozlesme_kalemleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kiralama_sozlesme_kalemleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kiralama_sozlesme_kalemleri_id_seq OWNED BY public.kiralama_sozlesme_kalemleri.id;


--
-- Name: kiralama_sozlesmeleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kiralama_sozlesmeleri (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    stok_seri_no_id bigint,
    kiraci_cari_id bigint NOT NULL,
    baslangic_tarihi date NOT NULL,
    bitis_tarihi date,
    aylik_kira_tutari numeric(18,2) NOT NULL,
    para_birimi public.para_birimi_t NOT NULL,
    depozito numeric(18,2) DEFAULT 0,
    durum character varying(20) DEFAULT 'AKTIF'::character varying,
    notlar text,
    referans_kur numeric(18,6) DEFAULT 1
);


--
-- Name: kiralama_sozlesmeleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kiralama_sozlesmeleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kiralama_sozlesmeleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kiralama_sozlesmeleri_id_seq OWNED BY public.kiralama_sozlesmeleri.id;


--
-- Name: kullanici_rolleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kullanici_rolleri (
    kullanici_id bigint NOT NULL,
    rol_id bigint NOT NULL,
    sirket_id bigint NOT NULL
);


--
-- Name: kullanici_sirket_erisim; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kullanici_sirket_erisim (
    id bigint NOT NULL,
    kullanici_id bigint NOT NULL,
    sirket_id bigint NOT NULL
);


--
-- Name: kullanici_sirket_erisim_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kullanici_sirket_erisim_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kullanici_sirket_erisim_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kullanici_sirket_erisim_id_seq OWNED BY public.kullanici_sirket_erisim.id;


--
-- Name: kullanicilar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kullanicilar (
    id bigint NOT NULL,
    ad_soyad character varying(150) NOT NULL,
    email character varying(150) NOT NULL,
    sifre_hash character varying(255) NOT NULL,
    telefon character varying(50),
    aktif boolean DEFAULT true,
    son_giris timestamp without time zone,
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    sifre_sifirlama_token text,
    sifre_sifirlama_son_gecerlilik timestamp without time zone
);


--
-- Name: kullanicilar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kullanicilar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kullanicilar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kullanicilar_id_seq OWNED BY public.kullanicilar.id;


--
-- Name: leasing_kalem_urunleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leasing_kalem_urunleri (
    id bigint NOT NULL,
    kalem_id bigint NOT NULL,
    stok_seri_no_id bigint NOT NULL
);


--
-- Name: leasing_kalem_urunleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leasing_kalem_urunleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leasing_kalem_urunleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leasing_kalem_urunleri_id_seq OWNED BY public.leasing_kalem_urunleri.id;


--
-- Name: leasing_odeme_plani; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leasing_odeme_plani (
    id bigint NOT NULL,
    leasing_id bigint NOT NULL,
    taksit_no integer NOT NULL,
    vade_tarihi date NOT NULL,
    tutar numeric(18,2) NOT NULL,
    odendi_mi boolean DEFAULT false,
    odeme_tarihi date,
    banka_hareket_id bigint
);


--
-- Name: leasing_odeme_plani_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leasing_odeme_plani_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leasing_odeme_plani_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leasing_odeme_plani_id_seq OWNED BY public.leasing_odeme_plani.id;


--
-- Name: leasing_sozlesme_kalemleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leasing_sozlesme_kalemleri (
    id bigint NOT NULL,
    leasing_id bigint NOT NULL,
    stok_karti_id bigint NOT NULL,
    miktar integer DEFAULT 1 NOT NULL,
    birim_fiyat numeric(18,2) NOT NULL
);


--
-- Name: leasing_sozlesme_kalemleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leasing_sozlesme_kalemleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leasing_sozlesme_kalemleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leasing_sozlesme_kalemleri_id_seq OWNED BY public.leasing_sozlesme_kalemleri.id;


--
-- Name: leasing_sozlesmeleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leasing_sozlesmeleri (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    leasing_firmasi_cari_id bigint NOT NULL,
    stok_seri_no_id bigint,
    sozlesme_no character varying(100),
    baslangic_tarihi date,
    toplam_tutar numeric(18,2),
    para_birimi public.para_birimi_t NOT NULL,
    taksit_sayisi integer,
    notlar text
);


--
-- Name: leasing_sozlesmeleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leasing_sozlesmeleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leasing_sozlesmeleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leasing_sozlesmeleri_id_seq OWNED BY public.leasing_sozlesmeleri.id;


--
-- Name: personel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personel (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    ad_soyad character varying(150) NOT NULL,
    pozisyon character varying(100),
    aylik_maas numeric(18,2),
    ise_baslama_tarihi date,
    aktif boolean DEFAULT true
);


--
-- Name: personel_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.personel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: personel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.personel_id_seq OWNED BY public.personel.id;


--
-- Name: personel_odemeleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personel_odemeleri (
    id bigint NOT NULL,
    personel_id bigint NOT NULL,
    donem date NOT NULL,
    tip public.personel_odeme_tip_t NOT NULL,
    tutar numeric(18,2) NOT NULL,
    odendi_mi boolean DEFAULT false,
    odeme_tarihi date,
    aciklama character varying(300)
);


--
-- Name: personel_odemeleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.personel_odemeleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: personel_odemeleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.personel_odemeleri_id_seq OWNED BY public.personel_odemeleri.id;


--
-- Name: proforma_detay; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proforma_detay (
    id bigint NOT NULL,
    proforma_id bigint NOT NULL,
    stok_karti_id bigint,
    aciklama character varying(300),
    miktar numeric(18,2) DEFAULT 1 NOT NULL,
    birim_fiyat numeric(18,2) NOT NULL,
    kdv_orani numeric(5,2) DEFAULT 20
);


--
-- Name: proforma_detay_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.proforma_detay_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: proforma_detay_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.proforma_detay_id_seq OWNED BY public.proforma_detay.id;


--
-- Name: proforma_faturalar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proforma_faturalar (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    proforma_no character varying(50) NOT NULL,
    cari_id bigint NOT NULL,
    tarih date NOT NULL,
    gecerlilik_tarihi date,
    para_birimi public.para_birimi_t NOT NULL,
    ara_toplam numeric(18,2) NOT NULL,
    kdv_tutari numeric(18,2) DEFAULT 0,
    genel_toplam numeric(18,2) NOT NULL,
    durum character varying(20) DEFAULT 'BEKLEMEDE'::character varying,
    notlar text,
    olusturan_kullanici_id bigint,
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: proforma_faturalar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.proforma_faturalar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: proforma_faturalar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.proforma_faturalar_id_seq OWNED BY public.proforma_faturalar.id;


--
-- Name: rol_izinleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rol_izinleri (
    rol_id bigint NOT NULL,
    izin_id bigint NOT NULL
);


--
-- Name: roller; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roller (
    id bigint NOT NULL,
    sirket_id bigint,
    ad character varying(100) NOT NULL,
    aciklama character varying(255)
);


--
-- Name: roller_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roller_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roller_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roller_id_seq OWNED BY public.roller.id;


--
-- Name: sabit_gider_kategorileri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sabit_gider_kategorileri (
    id bigint NOT NULL,
    ad character varying(100) NOT NULL
);


--
-- Name: sabit_gider_kategorileri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sabit_gider_kategorileri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sabit_gider_kategorileri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sabit_gider_kategorileri_id_seq OWNED BY public.sabit_gider_kategorileri.id;


--
-- Name: sabit_giderler; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sabit_giderler (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    kategori_id bigint,
    donem date NOT NULL,
    tutar numeric(18,2) NOT NULL,
    odendi_mi boolean DEFAULT false,
    odeme_tarihi date,
    aciklama character varying(300),
    kategori character varying(150),
    para_birimi public.para_birimi_t DEFAULT 'TRY'::public.para_birimi_t NOT NULL,
    kur numeric(18,6) DEFAULT 1 NOT NULL,
    tutar_try numeric(18,2) NOT NULL
);


--
-- Name: sabit_giderler_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sabit_giderler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sabit_giderler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sabit_giderler_id_seq OWNED BY public.sabit_giderler.id;


--
-- Name: siparis_detay; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.siparis_detay (
    id bigint NOT NULL,
    siparis_id bigint NOT NULL,
    stok_karti_id bigint NOT NULL,
    miktar integer DEFAULT 1 NOT NULL,
    birim_fiyat numeric(18,2) NOT NULL,
    para_birimi public.para_birimi_t NOT NULL,
    birim_agirlik_kg numeric(10,2),
    aciklama character varying(300),
    kdv_orani numeric(5,2) DEFAULT 20 NOT NULL
);


--
-- Name: siparis_detay_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.siparis_detay_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: siparis_detay_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.siparis_detay_id_seq OWNED BY public.siparis_detay.id;


--
-- Name: siparis_odemeleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.siparis_odemeleri (
    id bigint NOT NULL,
    siparis_id bigint NOT NULL,
    tarih date NOT NULL,
    tutar numeric(18,2) NOT NULL,
    notlar character varying(300),
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    odeme_yontemi character varying(10),
    cek_id bigint
);


--
-- Name: siparis_odemeleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.siparis_odemeleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: siparis_odemeleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.siparis_odemeleri_id_seq OWNED BY public.siparis_odemeleri.id;


--
-- Name: siparisler; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.siparisler (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    siparis_no character varying(50) NOT NULL,
    tedarikci_cari_id bigint NOT NULL,
    kaynak public.stok_kaynak_t NOT NULL,
    kopya_kaynak_siparis_id bigint,
    siparis_tarihi date NOT NULL,
    tahmini_teslim_tarihi date,
    durum public.siparis_durum_t DEFAULT 'TASLAK'::public.siparis_durum_t,
    para_birimi public.para_birimi_t NOT NULL,
    cikis_limani character varying(150),
    varis_limani character varying(150),
    konsimento_no character varying(100),
    gumruk_beyanname_no character varying(100),
    notlar text,
    olusturan_kullanici_id bigint,
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: siparisler_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.siparisler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: siparisler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.siparisler_id_seq OWNED BY public.siparisler.id;


--
-- Name: sirketler; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sirketler (
    id bigint NOT NULL,
    unvan character varying(255) NOT NULL,
    vergi_dairesi character varying(100),
    vergi_no character varying(20),
    adres text,
    telefon character varying(50),
    email character varying(100),
    logo_dosya_yolu character varying(500),
    aktif boolean DEFAULT true,
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: sirketler_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sirketler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sirketler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sirketler_id_seq OWNED BY public.sirketler.id;


--
-- Name: stok_kartlari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stok_kartlari (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    kategori_id bigint,
    marka character varying(100),
    model character varying(150),
    aciklama text,
    birim character varying(20) DEFAULT 'ADET'::character varying,
    birim_agirlik_kg numeric(10,2),
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    mense_ulke character varying(100),
    gtip_kodu character varying(20),
    standart_alt_metin text
);


--
-- Name: stok_kartlari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stok_kartlari_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stok_kartlari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stok_kartlari_id_seq OWNED BY public.stok_kartlari.id;


--
-- Name: stok_kategorileri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stok_kategorileri (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    ad character varying(150) NOT NULL
);


--
-- Name: stok_kategorileri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stok_kategorileri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stok_kategorileri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stok_kategorileri_id_seq OWNED BY public.stok_kategorileri.id;


--
-- Name: stok_maliyet_kalemleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stok_maliyet_kalemleri (
    id bigint NOT NULL,
    stok_seri_no_id bigint NOT NULL,
    tip public.maliyet_tip_t NOT NULL,
    aciklama character varying(300),
    tedarikci_cari_id bigint,
    para_birimi public.para_birimi_t NOT NULL,
    tutar numeric(18,2) NOT NULL,
    kur numeric(18,4) DEFAULT 1,
    tutar_try numeric(18,2) NOT NULL,
    belge_no character varying(100),
    tarih date NOT NULL,
    odendi_mi boolean DEFAULT false,
    referans_usd_kuru numeric(18,6)
);


--
-- Name: stok_maliyet_kalemleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stok_maliyet_kalemleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stok_maliyet_kalemleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stok_maliyet_kalemleri_id_seq OWNED BY public.stok_maliyet_kalemleri.id;


--
-- Name: stok_seri_no; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stok_seri_no (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    stok_karti_id bigint NOT NULL,
    seri_no character varying(100) NOT NULL,
    sasi_no character varying(100),
    uretim_yili integer,
    kaynak public.stok_kaynak_t NOT NULL,
    siparis_id bigint,
    durum public.stok_durum_t DEFAULT 'SIPARISTE'::public.stok_durum_t NOT NULL,
    tedarikci_cari_id bigint,
    satinalma_maliyeti_try numeric(18,2) DEFAULT 0,
    nakliye_maliyeti_try numeric(18,2) DEFAULT 0,
    gumruk_maliyeti_try numeric(18,2) DEFAULT 0,
    antrepo_maliyeti_try numeric(18,2) DEFAULT 0,
    millilestirme_maliyeti_try numeric(18,2) DEFAULT 0,
    leasing_maliyeti_try numeric(18,2) DEFAULT 0,
    diger_maliyet_try numeric(18,2) DEFAULT 0,
    toplam_maliyet_try numeric(18,2) GENERATED ALWAYS AS (((((((COALESCE(satinalma_maliyeti_try, (0)::numeric) + COALESCE(nakliye_maliyeti_try, (0)::numeric)) + COALESCE(gumruk_maliyeti_try, (0)::numeric)) + COALESCE(antrepo_maliyeti_try, (0)::numeric)) + COALESCE(millilestirme_maliyeti_try, (0)::numeric)) + COALESCE(leasing_maliyeti_try, (0)::numeric)) + COALESCE(diger_maliyet_try, (0)::numeric))) STORED,
    satis_fiyati_try numeric(18,2),
    satis_tarihi date,
    musteri_cari_id bigint,
    giris_tarihi date,
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    garanti_bitis_tarihi date,
    barkod character varying(100),
    satis_cek_id bigint,
    sahiplik_tipi character varying(20) DEFAULT 'TICARI'::character varying NOT NULL
);


--
-- Name: stok_seri_no_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stok_seri_no_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stok_seri_no_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stok_seri_no_id_seq OWNED BY public.stok_seri_no.id;


--
-- Name: taksit_detay; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taksit_detay (
    id bigint NOT NULL,
    plan_id bigint NOT NULL,
    taksit_no integer NOT NULL,
    vade_tarihi date NOT NULL,
    tutar numeric(18,2) NOT NULL,
    odendi_mi boolean DEFAULT false,
    odeme_tarihi date,
    tahsilat_kaynak_tablo character varying(50),
    tahsilat_kaynak_id bigint,
    odenen_tutar numeric(18,2) DEFAULT 0 NOT NULL,
    ilk_taksit_id bigint
);


--
-- Name: taksit_detay_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.taksit_detay_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: taksit_detay_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.taksit_detay_id_seq OWNED BY public.taksit_detay.id;


--
-- Name: taksitli_satis_kalemleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taksitli_satis_kalemleri (
    id bigint NOT NULL,
    plan_id bigint NOT NULL,
    stok_karti_id bigint NOT NULL,
    miktar integer DEFAULT 1 NOT NULL,
    birim_fiyat numeric(18,2) NOT NULL
);


--
-- Name: taksitli_satis_kalemleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.taksitli_satis_kalemleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: taksitli_satis_kalemleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.taksitli_satis_kalemleri_id_seq OWNED BY public.taksitli_satis_kalemleri.id;


--
-- Name: taksitli_satis_planlari; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taksitli_satis_planlari (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    musteri_cari_id bigint NOT NULL,
    stok_seri_no_id bigint,
    toplam_tutar numeric(18,2) NOT NULL,
    para_birimi public.para_birimi_t NOT NULL,
    pesinat numeric(18,2) DEFAULT 0,
    taksit_sayisi integer NOT NULL,
    baslangic_tarihi date NOT NULL,
    notlar text
);


--
-- Name: taksitli_satis_planlari_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.taksitli_satis_planlari_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: taksitli_satis_planlari_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.taksitli_satis_planlari_id_seq OWNED BY public.taksitli_satis_planlari.id;


--
-- Name: urun_sahiplik_gecmisi; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.urun_sahiplik_gecmisi (
    id bigint NOT NULL,
    stok_seri_no_id bigint NOT NULL,
    eski_cari_id bigint,
    yeni_cari_id bigint NOT NULL,
    aciklama text,
    tarih date DEFAULT CURRENT_DATE NOT NULL,
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: urun_sahiplik_gecmisi_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.urun_sahiplik_gecmisi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: urun_sahiplik_gecmisi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.urun_sahiplik_gecmisi_id_seq OWNED BY public.urun_sahiplik_gecmisi.id;


--
-- Name: v_ana_kasa_bakiye; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_ana_kasa_bakiye AS
 SELECT sirket_id,
    sum(
        CASE
            WHEN (yon = 'GIRIS'::public.hareket_yon_t) THEN tutar
            ELSE (- tutar)
        END) AS net_bakiye
   FROM public.kasa_hareketleri
  GROUP BY sirket_id;


--
-- Name: v_banka_bakiyeleri; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_banka_bakiyeleri AS
 SELECT bh.sirket_id,
    bh.id AS banka_hesap_id,
    bh.banka_adi,
    bh.hesap_adi,
    bh.para_birimi,
    COALESCE(sum(bk.tutar), (0)::numeric) AS bakiye
   FROM (public.banka_hesaplari bh
     LEFT JOIN public.banka_hareketleri bk ON ((bk.banka_hesap_id = bh.id)))
  GROUP BY bh.sirket_id, bh.id, bh.banka_adi, bh.hesap_adi, bh.para_birimi;


--
-- Name: v_cari_hareket_ozet; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_cari_hareket_ozet AS
 SELECT cari_id,
    sirket_id,
    para_birimi,
    sum(
        CASE
            WHEN (yon = 'GIRIS'::public.hareket_yon_t) THEN tutar
            ELSE (0)::numeric
        END) AS toplam_giris,
    sum(
        CASE
            WHEN (yon = 'CIKIS'::public.hareket_yon_t) THEN tutar
            ELSE (0)::numeric
        END) AS toplam_cikis,
    sum(
        CASE
            WHEN (yon = 'GIRIS'::public.hareket_yon_t) THEN tutar
            ELSE (- tutar)
        END) AS net_bakiye
   FROM public.cari_hareketler
  GROUP BY cari_id, sirket_id, para_birimi;


--
-- Name: v_seri_no_kar_raporu; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_seri_no_kar_raporu AS
 SELECT s.sirket_id,
    s.seri_no,
    sk.marka,
    sk.model,
    s.satinalma_maliyeti_try,
    s.nakliye_maliyeti_try,
    s.gumruk_maliyeti_try,
    s.antrepo_maliyeti_try,
    s.millilestirme_maliyeti_try,
    s.leasing_maliyeti_try,
    s.diger_maliyet_try,
    s.toplam_maliyet_try,
    s.satis_fiyati_try,
    (s.satis_fiyati_try - s.toplam_maliyet_try) AS kar_zarar_try,
    s.durum
   FROM (public.stok_seri_no s
     JOIN public.stok_kartlari sk ON ((sk.id = s.stok_karti_id)));


--
-- Name: yedek_parca_hareketleri; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.yedek_parca_hareketleri (
    id bigint NOT NULL,
    yedek_parca_id bigint NOT NULL,
    tarih date NOT NULL,
    yon character varying(10) NOT NULL,
    miktar numeric(18,2) NOT NULL,
    birim_fiyat_try numeric(18,2),
    ilgili_cari_id bigint,
    aciklama character varying(300),
    olusturma_tarihi timestamp without time zone DEFAULT now(),
    birim_fiyat_orijinal numeric(18,2),
    para_birimi character varying(10) DEFAULT 'TRY'::character varying NOT NULL,
    kur numeric(18,6) DEFAULT 1 NOT NULL,
    maliyet_birim_fiyat_try numeric(18,2),
    odeme_yontemi character varying(10),
    banka_hesap_id bigint,
    ilgili_stok_seri_no_id bigint
);


--
-- Name: yedek_parca_hareketleri_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.yedek_parca_hareketleri_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: yedek_parca_hareketleri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.yedek_parca_hareketleri_id_seq OWNED BY public.yedek_parca_hareketleri.id;


--
-- Name: yedek_parcalar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.yedek_parcalar (
    id bigint NOT NULL,
    sirket_id bigint NOT NULL,
    ad character varying(200) NOT NULL,
    birim character varying(20) DEFAULT 'ADET'::character varying NOT NULL,
    mevcut_miktar numeric(18,2) DEFAULT 0 NOT NULL,
    birim_fiyat_try numeric(18,2) DEFAULT 0 NOT NULL,
    min_stok_seviyesi numeric(18,2) DEFAULT 0,
    notlar character varying(500),
    olusturma_tarihi timestamp without time zone DEFAULT now()
);


--
-- Name: yedek_parcalar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.yedek_parcalar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: yedek_parcalar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.yedek_parcalar_id_seq OWNED BY public.yedek_parcalar.id;


--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea
)
PARTITION BY RANGE (inserted_at);


--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    action_filter text DEFAULT '*'::text,
    selected_columns text[],
    CONSTRAINT subscription_action_filter_check CHECK ((action_filter = ANY (ARRAY['*'::text, 'INSERT'::text, 'UPDATE'::text, 'DELETE'::text])))
);


--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: -
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_analytics (
    name text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_vectors (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'VECTOR'::storage.buckettype NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: objects; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb
);


--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb,
    metadata jsonb
);


--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.vector_indexes (
    id text DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    bucket_id text NOT NULL,
    data_type text NOT NULL,
    dimension integer NOT NULL,
    distance_metric text NOT NULL,
    metadata_configuration jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Name: akreditif_kalem_taksitleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditif_kalem_taksitleri ALTER COLUMN id SET DEFAULT nextval('public.akreditif_kalem_taksitleri_id_seq'::regclass);


--
-- Name: akreditif_kalemleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditif_kalemleri ALTER COLUMN id SET DEFAULT nextval('public.akreditif_kalemleri_id_seq'::regclass);


--
-- Name: akreditif_maliyet_dagitimlari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditif_maliyet_dagitimlari ALTER COLUMN id SET DEFAULT nextval('public.akreditif_maliyet_dagitimlari_id_seq'::regclass);


--
-- Name: akreditifler id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditifler ALTER COLUMN id SET DEFAULT nextval('public.akreditifler_id_seq'::regclass);


--
-- Name: bakim_kayitlari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bakim_kayitlari ALTER COLUMN id SET DEFAULT nextval('public.bakim_kayitlari_id_seq'::regclass);


--
-- Name: banka_hareketleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hareketleri ALTER COLUMN id SET DEFAULT nextval('public.banka_hareketleri_id_seq'::regclass);


--
-- Name: banka_hesaplari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hesaplari ALTER COLUMN id SET DEFAULT nextval('public.banka_hesaplari_id_seq'::regclass);


--
-- Name: borc_odemeleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.borc_odemeleri ALTER COLUMN id SET DEFAULT nextval('public.borc_odemeleri_id_seq'::regclass);


--
-- Name: borclar id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.borclar ALTER COLUMN id SET DEFAULT nextval('public.borclar_id_seq'::regclass);


--
-- Name: cari_hareketler id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_hareketler ALTER COLUMN id SET DEFAULT nextval('public.cari_hareketler_id_seq'::regclass);


--
-- Name: cari_hesaplar id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_hesaplar ALTER COLUMN id SET DEFAULT nextval('public.cari_hesaplar_id_seq'::regclass);


--
-- Name: cek_hareket_gecmisi id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cek_hareket_gecmisi ALTER COLUMN id SET DEFAULT nextval('public.cek_hareket_gecmisi_id_seq'::regclass);


--
-- Name: cekler id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cekler ALTER COLUMN id SET DEFAULT nextval('public.cekler_id_seq'::regclass);


--
-- Name: demirbaslar id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demirbaslar ALTER COLUMN id SET DEFAULT nextval('public.demirbaslar_id_seq'::regclass);


--
-- Name: doviz_kurlari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doviz_kurlari ALTER COLUMN id SET DEFAULT nextval('public.doviz_kurlari_id_seq'::regclass);


--
-- Name: duzenleme_kayitlari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duzenleme_kayitlari ALTER COLUMN id SET DEFAULT nextval('public.duzenleme_kayitlari_id_seq'::regclass);


--
-- Name: fatura_detay id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fatura_detay ALTER COLUMN id SET DEFAULT nextval('public.fatura_detay_id_seq'::regclass);


--
-- Name: faturalar id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faturalar ALTER COLUMN id SET DEFAULT nextval('public.faturalar_id_seq'::regclass);


--
-- Name: gumruk_beyannameleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gumruk_beyannameleri ALTER COLUMN id SET DEFAULT nextval('public.gumruk_beyannameleri_id_seq'::regclass);


--
-- Name: harcama_turleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.harcama_turleri ALTER COLUMN id SET DEFAULT nextval('public.harcama_turleri_id_seq'::regclass);


--
-- Name: islem_loglari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.islem_loglari ALTER COLUMN id SET DEFAULT nextval('public.islem_loglari_id_seq'::regclass);


--
-- Name: izinler id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.izinler ALTER COLUMN id SET DEFAULT nextval('public.izinler_id_seq'::regclass);


--
-- Name: kasa_hareketleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kasa_hareketleri ALTER COLUMN id SET DEFAULT nextval('public.kasa_hareketleri_id_seq'::regclass);


--
-- Name: kdv_manuel_girisler id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kdv_manuel_girisler ALTER COLUMN id SET DEFAULT nextval('public.kdv_manuel_girisler_id_seq'::regclass);


--
-- Name: kiralama_kalem_urunleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_kalem_urunleri ALTER COLUMN id SET DEFAULT nextval('public.kiralama_kalem_urunleri_id_seq'::regclass);


--
-- Name: kiralama_odemeleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_odemeleri ALTER COLUMN id SET DEFAULT nextval('public.kiralama_odemeleri_id_seq'::regclass);


--
-- Name: kiralama_sozlesme_kalemleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_sozlesme_kalemleri ALTER COLUMN id SET DEFAULT nextval('public.kiralama_sozlesme_kalemleri_id_seq'::regclass);


--
-- Name: kiralama_sozlesmeleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_sozlesmeleri ALTER COLUMN id SET DEFAULT nextval('public.kiralama_sozlesmeleri_id_seq'::regclass);


--
-- Name: kullanici_sirket_erisim id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanici_sirket_erisim ALTER COLUMN id SET DEFAULT nextval('public.kullanici_sirket_erisim_id_seq'::regclass);


--
-- Name: kullanicilar id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanicilar ALTER COLUMN id SET DEFAULT nextval('public.kullanicilar_id_seq'::regclass);


--
-- Name: leasing_kalem_urunleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_kalem_urunleri ALTER COLUMN id SET DEFAULT nextval('public.leasing_kalem_urunleri_id_seq'::regclass);


--
-- Name: leasing_odeme_plani id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_odeme_plani ALTER COLUMN id SET DEFAULT nextval('public.leasing_odeme_plani_id_seq'::regclass);


--
-- Name: leasing_sozlesme_kalemleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_sozlesme_kalemleri ALTER COLUMN id SET DEFAULT nextval('public.leasing_sozlesme_kalemleri_id_seq'::regclass);


--
-- Name: leasing_sozlesmeleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_sozlesmeleri ALTER COLUMN id SET DEFAULT nextval('public.leasing_sozlesmeleri_id_seq'::regclass);


--
-- Name: personel id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personel ALTER COLUMN id SET DEFAULT nextval('public.personel_id_seq'::regclass);


--
-- Name: personel_odemeleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personel_odemeleri ALTER COLUMN id SET DEFAULT nextval('public.personel_odemeleri_id_seq'::regclass);


--
-- Name: proforma_detay id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_detay ALTER COLUMN id SET DEFAULT nextval('public.proforma_detay_id_seq'::regclass);


--
-- Name: proforma_faturalar id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_faturalar ALTER COLUMN id SET DEFAULT nextval('public.proforma_faturalar_id_seq'::regclass);


--
-- Name: roller id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roller ALTER COLUMN id SET DEFAULT nextval('public.roller_id_seq'::regclass);


--
-- Name: sabit_gider_kategorileri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sabit_gider_kategorileri ALTER COLUMN id SET DEFAULT nextval('public.sabit_gider_kategorileri_id_seq'::regclass);


--
-- Name: sabit_giderler id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sabit_giderler ALTER COLUMN id SET DEFAULT nextval('public.sabit_giderler_id_seq'::regclass);


--
-- Name: siparis_detay id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparis_detay ALTER COLUMN id SET DEFAULT nextval('public.siparis_detay_id_seq'::regclass);


--
-- Name: siparis_odemeleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparis_odemeleri ALTER COLUMN id SET DEFAULT nextval('public.siparis_odemeleri_id_seq'::regclass);


--
-- Name: siparisler id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparisler ALTER COLUMN id SET DEFAULT nextval('public.siparisler_id_seq'::regclass);


--
-- Name: sirketler id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sirketler ALTER COLUMN id SET DEFAULT nextval('public.sirketler_id_seq'::regclass);


--
-- Name: stok_kartlari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_kartlari ALTER COLUMN id SET DEFAULT nextval('public.stok_kartlari_id_seq'::regclass);


--
-- Name: stok_kategorileri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_kategorileri ALTER COLUMN id SET DEFAULT nextval('public.stok_kategorileri_id_seq'::regclass);


--
-- Name: stok_maliyet_kalemleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_maliyet_kalemleri ALTER COLUMN id SET DEFAULT nextval('public.stok_maliyet_kalemleri_id_seq'::regclass);


--
-- Name: stok_seri_no id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_seri_no ALTER COLUMN id SET DEFAULT nextval('public.stok_seri_no_id_seq'::regclass);


--
-- Name: taksit_detay id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksit_detay ALTER COLUMN id SET DEFAULT nextval('public.taksit_detay_id_seq'::regclass);


--
-- Name: taksitli_satis_kalemleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_kalemleri ALTER COLUMN id SET DEFAULT nextval('public.taksitli_satis_kalemleri_id_seq'::regclass);


--
-- Name: taksitli_satis_planlari id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_planlari ALTER COLUMN id SET DEFAULT nextval('public.taksitli_satis_planlari_id_seq'::regclass);


--
-- Name: urun_sahiplik_gecmisi id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.urun_sahiplik_gecmisi ALTER COLUMN id SET DEFAULT nextval('public.urun_sahiplik_gecmisi_id_seq'::regclass);


--
-- Name: yedek_parca_hareketleri id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yedek_parca_hareketleri ALTER COLUMN id SET DEFAULT nextval('public.yedek_parca_hareketleri_id_seq'::regclass);


--
-- Name: yedek_parcalar id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yedek_parcalar ALTER COLUMN id SET DEFAULT nextval('public.yedek_parcalar_id_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.custom_oauth_providers (id, provider_type, identifier, name, client_id, client_secret, acceptable_client_ids, scopes, pkce_enabled, attribute_mapping, authorization_params, enabled, email_optional, issuer, discovery_url, skip_nonce_check, cached_discovery, discovery_cached_at, authorization_url, token_url, userinfo_url, jwks_uri, created_at, updated_at, custom_claims_allowlist) FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at, invite_token, referrer, oauth_client_state_id, linking_target_id, email_optional) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid, last_webauthn_challenge_data) FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at, nonce) FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_client_states (id, provider_type, code_verifier, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type, token_endpoint_auth_method) FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
20260625000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) FROM stdin;
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_challenges (id, user_id, challenge_type, session_data, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_credentials (id, user_id, credential_id, public_key, attestation_type, aaguid, sign_count, transports, backup_eligible, backed_up, friendly_name, created_at, updated_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: akreditif_kalem_taksitleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.akreditif_kalem_taksitleri (id, kalem_id, taksit_no, vade_tarihi, tutar, odendi_mi, odeme_tarihi) FROM stdin;
\.


--
-- Data for Name: akreditif_kalemleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.akreditif_kalemleri (id, akreditif_id, tip, aciklama, tutar, vade_tarihi, odendi_mi, odeme_tarihi, odenen_tutar) FROM stdin;
8	4	ODEME		24000.00	2026-08-02	t	2026-08-02	24000.00
\.


--
-- Data for Name: akreditif_maliyet_dagitimlari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.akreditif_maliyet_dagitimlari (id, akreditif_id, stok_seri_no_id, yontem, kur, tutar_try, olusturma_tarihi) FROM stdin;
\.


--
-- Data for Name: akreditifler; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.akreditifler (id, sirket_id, siparis_id, banka_hesap_id, akreditif_no, tip, para_birimi, tutar, acilis_tarihi, vade_tarihi, durum, notlar, olusturma_tarihi) FROM stdin;
5	1	12	1	1	VADELI	USD	120000.00	2026-07-17	2026-12-17	ACIK		2026-07-17 07:00:59.126568
6	1	14	1		VADELI	USD	80775.00	2026-08-02	2026-11-02	ACIK		2026-08-02 17:34:41.38643
4	1	12	1	121	VADELI	USD	74000.00	2026-05-14	\N	KISMI_ODENDI		2026-07-14 12:31:46.066334
\.


--
-- Data for Name: bakim_kayitlari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bakim_kayitlari (id, sirket_id, stok_seri_no_id, tarih, tip, aciklama, ilgili_cari_id, tutar, para_birimi, odendi_tahsil_edildi_mi) FROM stdin;
\.


--
-- Data for Name: banka_hareketleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.banka_hareketleri (id, sirket_id, banka_hesap_id, tarih, tip, tutar, aciklama, karsi_hesap_id, kullanilan_kur, kaynak_tablo, kaynak_id, cari_id, olusturan_kullanici_id, olusturma_tarihi, tutar_try_karsiligi) FROM stdin;
6	1	1	2026-07-05	GIRIS	25000.00	Sale-leaseback finansmanı"	\N	\N	\N	\N	7	1	2026-07-14 13:53:11.187881	1175146.05
9	1	4	2026-07-15	CIKIS	-32000.00	AHMET MEHMET - MAAS	\N	\N	PERSONEL_ODEME	1	\N	1	2026-07-15 19:23:10.317992	\N
13	1	4	2026-07-15	CIKIS	-20000.00	Sabit gider ödemesi	\N	\N	SABIT_GIDER	4	\N	1	2026-07-15 19:28:03.320325	\N
14	1	4	2026-07-15	CIKIS	-35000.00	Sabit gider ödemesi	\N	\N	SABIT_GIDER	5	\N	1	2026-07-15 19:28:51.465877	\N
15	1	4	2026-07-19	CIKIS	-2000.00	Elektrik Faturası ödemesi	\N	\N	SABIT_GIDER	1	\N	1	2026-07-19 15:38:48.827016	\N
16	1	4	2026-07-19	CIKIS	-500.00	Su Faturası ödemesi	\N	\N	SABIT_GIDER	2	\N	1	2026-07-19 15:38:57.386677	\N
17	1	4	2026-07-19	CIKIS	-32000.00	yakupcalikoglu@hotmail.com	\N	\N	SABIT_GIDER	3	\N	1	2026-07-19 15:40:23.426723	\N
24	1	1	2026-07-20	HESAPLAR_ARASI_TRANSFER	-15000.00	\N	4	47.0000	\N	\N	\N	1	2026-07-19 21:52:38.441795	\N
25	1	4	2026-07-20	HESAPLAR_ARASI_TRANSFER	705000.00	[Otomatik karşı kayıt]	1	47.0000	\N	\N	\N	1	2026-07-19 21:52:38.441795	\N
27	1	1	2026-07-20	GIRIS	25000.00	Çek 343 - TAHSIL_EDILDI	\N	\N	CEKLER	12	6	1	2026-07-20 06:52:56.234605	\N
31	1	4	2026-07-28	CIKIS	-70000.00	Yedek parça alımı - KABİN (1 ADET)	\N	\N	YEDEK_PARCA_HAREKET	6	\N	1	2026-07-28 21:22:56.39358	\N
32	1	4	2026-07-28	GIRIS	80000.00	Yedek parça satışı - KABİN (1 ADET)	\N	\N	YEDEK_PARCA_HAREKET	7	6	1	2026-07-28 21:23:33.686782	\N
36	1	1	2026-08-02	CIKIS	-24000.00	Akreditif 121 - ODEME	\N	\N	AKREDITIF_KALEMI	8	\N	1	2026-08-02 19:24:23.397365	\N
\.


--
-- Data for Name: banka_hesaplari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.banka_hesaplari (id, sirket_id, banka_adi, sube, hesap_adi, iban, para_birimi, guncel_bakiye, aktif) FROM stdin;
1	1	KUVEYTTÜRK	\N	KUVEYT USD	TR00000000000000000	USD	0.00	t
2	1	ZİRAAT BANKASI	\N	ZİRAAT USD	TR00000000000001	USD	0.00	t
4	1	KUVEYTTTÜRK	\N	KUVEYTTÜRK TL	TR00000000000000	TRY	0.00	t
5	1	FINANS KATILIM USD	\N	FINANS KATILIM USD		USD	0.00	t
\.


--
-- Data for Name: borc_odemeleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.borc_odemeleri (id, borc_id, tarih, tutar, aciklama) FROM stdin;
\.


--
-- Data for Name: borclar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.borclar (id, sirket_id, tip, cari_id, tutar, para_birimi, faiz_orani, alinma_tarihi, vade_tarihi, notlar) FROM stdin;
\.


--
-- Data for Name: cari_hareketler; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cari_hareketler (id, cari_id, sirket_id, tarih, aciklama, yon, para_birimi, tutar, tutar_try_karsiligi, kaynak_tablo, kaynak_id, olusturan_kullanici_id, olusturma_tarihi) FROM stdin;
\.


--
-- Data for Name: cari_hesaplar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cari_hesaplar (id, sirket_id, tip, unvan, vergi_no, vergi_dairesi, adres, telefon, email, otomatik_dolduruldu, bakiye_try, bakiye_usd, bakiye_eur, aktif, olusturma_tarihi) FROM stdin;
5	1	TEDARIKCI	JAC	1234567					f	0.00	0.00	0.00	t	2026-07-14 12:19:45.62547
6	1	MUSTERI	OKUYAN SOFRA	1234567889					f	0.00	0.00	0.00	t	2026-07-14 12:20:00.391416
7	1	DIGER	KUVEYTTÜRK	34567789					f	0.00	0.00	0.00	t	2026-07-14 12:20:36.625426
8	1	MUSTERI	PAK TİCARET						f	0.00	0.00	0.00	t	2026-07-26 20:24:20.491416
\.


--
-- Data for Name: cek_hareket_gecmisi; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cek_hareket_gecmisi (id, cek_id, tarih, eski_durum, yeni_durum, aciklama, olusturan_kullanici_id) FROM stdin;
2	12	2026-05-04	PORTFOYDE	TAHSIL_EDILDI	\N	1
\.


--
-- Data for Name: cekler; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cekler (id, sirket_id, tip, cek_no, banka_adi, cari_id, tutar, para_birimi, vade_tarihi, alinma_verilme_tarihi, durum, ciro_edilen_cari_id, ciro_tarihi, notlar, olusturma_tarihi) FROM stdin;
11	1	ALINAN	20260345	akbank	6	76000.00	TRY	2026-09-15	2026-07-08	PORTFOYDE	\N	\N	\N	2026-07-15 19:41:22.965879
12	1	ALINAN	343	kuveyt	6	25000.00	USD	2026-07-15	2026-05-04	TAHSIL_EDILDI	\N	\N	\N	2026-07-17 06:57:48.612566
\.


--
-- Data for Name: demirbaslar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.demirbaslar (id, sirket_id, kategori, ad, tanimlayici_no, konum, durum, kiraci_cari_id, maliyet_try, alim_tarihi, satis_fiyati_try, satis_tarihi, notlar, olusturma_tarihi, maliyet_orijinal, para_birimi, amortisman_orani) FROM stdin;
\.


--
-- Data for Name: doviz_kurlari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.doviz_kurlari (id, para_birimi, tarih, alis, satis) FROM stdin;
\.


--
-- Data for Name: duzenleme_kayitlari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.duzenleme_kayitlari (id, sirket_id, kullanici_id, tablo_adi, kayit_id, degisiklikler, tarih) FROM stdin;
1	1	1	siparisler	13	{"Notlar": {"eski": "", "yeni": "yakupcalikoglu@hotmail.com"}, "Ürünler": {"eski": "1x #7@12000.00", "yeni": "1x #7@12000"}}	2026-07-16 12:08:30.228962
2	1	1	sabit_giderler	3	{"Tutar": {"eski": "32000.00", "yeni": "32000"}, "Kur": {"eski": "1.000000", "yeni": "1"}, "TL Karşılığı": {"eski": "32000.00", "yeni": "32000"}, "Açıklama": {"eski": "", "yeni": "yakupcalikoglu@hotmail.com"}}	2026-07-19 15:39:40.31941
3	1	1	sabit_giderler	3	{"Tutar": {"eski": "32000.00", "yeni": "32000"}, "Kur": {"eski": "1.000000", "yeni": "1"}, "TL Karşılığı": {"eski": "32000.00", "yeni": "32000"}}	2026-07-19 15:40:11.767278
4	1	1	banka_hareketleri	22	{"Tutar": {"eski": "15000.00", "yeni": "-15000"}, "Kur": {"eski": "47.0000", "yeni": "47"}}	2026-07-19 21:39:15.221803
5	1	1	stok_maliyet_kalemleri	42	{"Tedarikçi": {"eski": null, "yeni": 5}, "Para Birimi": {"eski": "TRY", "yeni": "USD"}, "Tutar": {"eski": "18600.00", "yeni": "18600"}, "Kur": {"eski": "1.0000", "yeni": "32"}}	2026-07-26 15:32:48.843018
6	1	1	stok_maliyet_kalemleri	42	{"Tutar": {"eski": "18600.00", "yeni": "18600"}, "Kur": {"eski": "32.0000", "yeni": "32"}}	2026-07-26 16:09:49.279428
7	1	1	kiralama_sozlesmeleri	12	{"Depozito": {"eski": "0.00", "yeni": "0"}, "Aylık Kira Tutarı": {"eski": "45000.00", "yeni": "45000"}, "Ürün Kalemleri": {"eski": "1x #10@45000.00", "yeni": "1x #10@45000"}}	2026-07-26 21:06:19.456809
8	1	1	kiralama_sozlesmeleri	11	{"Depozito": {"eski": "0.00", "yeni": "0"}, "Aylık Kira Tutarı": {"eski": "32000.00", "yeni": "32000"}, "Ürün Kalemleri": {"eski": "1x #6@32000.00", "yeni": "1x #6@32000"}}	2026-07-26 21:06:43.811531
9	1	1	yedek_parcalar	1	{"Birim Fiyat": {"eski": "1300.00", "yeni": "1300"}, "Min Stok Seviyesi": {"eski": "0.00", "yeni": "1"}, "Notlar": {"eski": null, "yeni": "yakupcalikoglu@hotmail.com"}}	2026-07-28 18:30:39.526269
10	1	1	yedek_parcalar	1	{"Birim Fiyat": {"eski": "615759.59", "yeni": "13000"}, "Min Stok Seviyesi": {"eski": "1.00", "yeni": "1"}}	2026-07-28 20:58:58.016402
11	1	1	yedek_parcalar	1	{"Birim Fiyat": {"eski": "13000.00", "yeni": "13000"}, "Min Stok Seviyesi": {"eski": "1.00", "yeni": "1"}}	2026-07-28 20:58:59.587639
12	1	1	yedek_parcalar	2	{"Birim Fiyat": {"eski": "80000.00", "yeni": "80000"}, "Min Stok Seviyesi": {"eski": "0.00", "yeni": "2"}, "Notlar": {"eski": null, "yeni": "yakupcalikoglu@hotmail.com"}}	2026-07-28 21:20:28.384188
13	1	1	yedek_parcalar	2	{"Birim Fiyat": {"eski": "80000.00", "yeni": "80000"}, "Min Stok Seviyesi": {"eski": "2.00", "yeni": "2"}}	2026-07-28 21:20:30.040586
14	1	1	yedek_parcalar	2	{"Birim Fiyat": {"eski": "80000.00", "yeni": "80000"}, "Min Stok Seviyesi": {"eski": "2.00", "yeni": "1"}}	2026-07-28 21:20:47.26298
15	1	1	yedek_parcalar	2	{"Birim Fiyat": {"eski": "80000.00", "yeni": "80000"}, "Min Stok Seviyesi": {"eski": "1.00", "yeni": "5"}}	2026-07-28 21:22:18.291229
\.


--
-- Data for Name: fatura_detay; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fatura_detay (id, fatura_id, stok_karti_id, stok_seri_no_id, aciklama, miktar, birim_fiyat, kdv_orani) FROM stdin;
6	4	10	\N	JAC 3 TON ELEKTRIKLI, 4.5 MT, SIDESHIFT, SOLID TIRES	1.00	12000.00	20.00
7	4	6	\N	JAC 3 TON DİZEL, 4.5 MT, SIDESHIFT, SOLID TIRES	1.00	10000.00	20.00
\.


--
-- Data for Name: faturalar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.faturalar (id, sirket_id, fatura_no, proforma_id, cari_id, tarih, para_birimi, ara_toplam, kdv_tutari, genel_toplam, odeme_durumu, notlar, olusturan_kullanici_id, olusturma_tarihi) FROM stdin;
4	1	FT-2026-001	7	6	2026-07-08	USD	22000.00	4400.00	26400.00	ODENMEDI		\N	2026-07-15 09:34:28.453286
\.


--
-- Data for Name: gumruk_beyannameleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gumruk_beyannameleri (id, sirket_id, siparis_id, beyanname_no, beyanname_tarihi, gumruk_musaviri_cari_id, tutar, para_birimi, kur, tutar_try, notlar, olusturma_tarihi, kdv_tutari) FROM stdin;
\.


--
-- Data for Name: harcama_turleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.harcama_turleri (id, ad, aktif) FROM stdin;
1	Kira	t
2	Maaş	t
3	Depozito	t
4	Komisyon	t
5	Prim	t
6	SGK	t
7	Elektrik Faturası	t
8	Su Faturası	t
9	Doğalgaz Faturası	t
10	İnternet Faturası	t
11	Telefon Faturası	t
12	Reklam	t
13	Araç Kirası	t
14	Araç Bakımı	t
15	Yakıt	t
16	Otopark	t
17	HGS/Köprü-Otoyol	t
18	Yemek	t
19	Fuar	t
20	Gezi	t
21	Tatil	t
22	Konaklama	t
23	Uçak Bileti	t
24	Ofis Malzemesi	t
25	Temizlik	t
26	Sigorta	t
27	Vergi	t
28	Muhasebe/Mali Müşavirlik	t
29	Hukuk/Danışmanlık	t
30	Kargo/Nakliye	t
31	Gümrük Müşavirliği	t
32	Banka Masrafı	t
33	Kredi Kartı Komisyonu	t
34	Bakım/Onarım	t
35	Yazılım/Abonelik	t
36	Eğitim	t
37	Hediye/İkram	t
38	Diğer	t
\.


--
-- Data for Name: islem_loglari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.islem_loglari (id, sirket_id, kullanici_id, tablo_adi, kayit_id, islem_tipi, eski_deger, yeni_deger, tarih) FROM stdin;
\.


--
-- Data for Name: izinler; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.izinler (id, kod, modul, aciklama) FROM stdin;
1	SIRKET_YONET	SIRKET	Şirket bilgilerini yönetme
2	STOK_GORUNTULE	STOK	Stok ekranını görüntüleme
3	STOK_DUZENLE	STOK	Stok kaydı ekleme/düzenleme
4	SIPARIS_GORUNTULE	SIPARIS	Sipariş ekranını görüntüleme
5	SIPARIS_DUZENLE	SIPARIS	Sipariş ekleme/düzenleme
6	CARI_GORUNTULE	CARI	Cari ekranını görüntüleme
7	CARI_DUZENLE	CARI	Cari kaydı ekleme/düzenleme
8	BANKA_GORUNTULE	BANKA	Banka ekranını görüntüleme
9	BANKA_DUZENLE	BANKA	Banka hareketi ekleme
10	KASA_GORUNTULE	KASA	Kasa ekranını görüntüleme
11	KASA_DUZENLE	KASA	Kasa hareketi ekleme
12	CEK_GORUNTULE	CEK	Çek ekranını görüntüleme
13	CEK_DUZENLE	CEK	Çek ekleme/düzenleme
14	LEASING_GORUNTULE	LEASING	Leasing ekranını görüntüleme
15	LEASING_DUZENLE	LEASING	Leasing ekleme/düzenleme
16	KIRALAMA_GORUNTULE	KIRALAMA	Kiralama ekranını görüntüleme
17	KIRALAMA_DUZENLE	KIRALAMA	Kiralama ekleme/düzenleme
18	BAKIM_GORUNTULE	BAKIM	Bakım ekranını görüntüleme
19	BAKIM_DUZENLE	BAKIM	Bakım kaydı ekleme
20	PERSONEL_GORUNTULE	PERSONEL	Personel ekranını görüntüleme
21	PERSONEL_DUZENLE	PERSONEL	Personel/ödeme yönetimi
22	GIDER_GORUNTULE	GIDER	Sabit gider ekranını görüntüleme
23	GIDER_DUZENLE	GIDER	Sabit gider ekleme/ödeme
24	BORC_GORUNTULE	BORC	Ortak/dış borç ekranını görüntüleme
25	BORC_DUZENLE	BORC	Borç ekleme/ödeme
26	FATURA_GORUNTULE	FATURA	Proforma/fatura ekranını görüntüleme
27	FATURA_DUZENLE	FATURA	Proforma/fatura oluşturma
28	RAPOR_GORUNTULE	RAPOR	Raporlama ekranını görüntüleme
29	KULLANICI_YONET	KULLANICI	Kullanıcı/rol/izin yönetimi
32	AKREDITIF_GORUNTULE	FINANSAL	Akreditif kayıtlarını görüntüleme
33	AKREDITIF_DUZENLE	FINANSAL	Akreditif ekleme/düzenleme
34	TAKSIT_GORUNTULE	Finansal Takip	Taksitli satış görüntüleme
35	TAKSIT_DUZENLE	Finansal Takip	Taksitli satış ekleme/düzenleme
\.


--
-- Data for Name: kasa_hareketleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kasa_hareketleri (id, sirket_id, tarih, yon, tutar, aciklama, kaynak_tablo, kaynak_id, olusturan_kullanici_id, olusturma_tarihi, para_birimi, tutar_try_karsiligi, cari_id) FROM stdin;
\.


--
-- Data for Name: kdv_manuel_girisler; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kdv_manuel_girisler (id, sirket_id, ay, tutar_try, aciklama, olusturma_tarihi) FROM stdin;
\.


--
-- Data for Name: kiralama_kalem_urunleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kiralama_kalem_urunleri (id, kalem_id, stok_seri_no_id) FROM stdin;
3	3	118
4	4	93
\.


--
-- Data for Name: kiralama_odemeleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kiralama_odemeleri (id, sozlesme_id, donem_basi, donem_sonu, tutar, odendi_mi, odeme_tarihi, tahsilat_kaynak_tablo, tahsilat_kaynak_id) FROM stdin;
2	11	2026-07-26	2026-08-26	32000.00	f	\N	\N	\N
\.


--
-- Data for Name: kiralama_sozlesme_kalemleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kiralama_sozlesme_kalemleri (id, sozlesme_id, stok_karti_id, miktar, birim_fiyat) FROM stdin;
3	12	10	1	45000.00
4	11	6	1	32000.00
\.


--
-- Data for Name: kiralama_sozlesmeleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kiralama_sozlesmeleri (id, sirket_id, stok_seri_no_id, kiraci_cari_id, baslangic_tarihi, bitis_tarihi, aylik_kira_tutari, para_birimi, depozito, durum, notlar, referans_kur) FROM stdin;
11	1	\N	6	2026-07-26	\N	32000.00	TRY	0.00	AKTIF	\N	1.000000
12	1	\N	6	2026-07-26	\N	45000.00	TRY	0.00	AKTIF	\N	1.000000
\.


--
-- Data for Name: kullanici_rolleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kullanici_rolleri (kullanici_id, rol_id, sirket_id) FROM stdin;
1	1	1
\.


--
-- Data for Name: kullanici_sirket_erisim; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kullanici_sirket_erisim (id, kullanici_id, sirket_id) FROM stdin;
1	1	1
2	1	3
3	1	4
\.


--
-- Data for Name: kullanicilar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kullanicilar (id, ad_soyad, email, sifre_hash, telefon, aktif, son_giris, olusturma_tarihi, sifre_sifirlama_token, sifre_sifirlama_son_gecerlilik) FROM stdin;
1	Admin	yakupcalikoglu@hotmail.com	$2b$12$npstmHDvGvoi4d7t9XIDDuQcMhkMQ2QM5pINQSwX1PKkcfDZp6jly	\N	t	\N	2026-07-01 08:37:13.190099	\N	\N
\.


--
-- Data for Name: leasing_kalem_urunleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leasing_kalem_urunleri (id, kalem_id, stok_seri_no_id) FROM stdin;
\.


--
-- Data for Name: leasing_odeme_plani; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leasing_odeme_plani (id, leasing_id, taksit_no, vade_tarihi, tutar, odendi_mi, odeme_tarihi, banka_hareket_id) FROM stdin;
25	3	1	2026-08-14	2083.33	f	\N	\N
26	3	2	2026-09-14	2083.33	f	\N	\N
27	3	3	2026-10-14	2083.33	f	\N	\N
28	3	4	2026-11-14	2083.33	f	\N	\N
29	3	5	2026-12-14	2083.33	f	\N	\N
30	3	6	2027-01-14	2083.33	f	\N	\N
31	3	7	2027-02-14	2083.33	f	\N	\N
32	3	8	2027-03-14	2083.33	f	\N	\N
33	3	9	2027-04-14	2083.33	f	\N	\N
34	3	10	2027-05-14	2083.33	f	\N	\N
35	3	11	2027-06-14	2083.33	f	\N	\N
36	3	12	2027-07-14	2083.37	f	\N	\N
\.


--
-- Data for Name: leasing_sozlesme_kalemleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leasing_sozlesme_kalemleri (id, leasing_id, stok_karti_id, miktar, birim_fiyat) FROM stdin;
1	3	10	1	25000.00
\.


--
-- Data for Name: leasing_sozlesmeleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leasing_sozlesmeleri (id, sirket_id, leasing_firmasi_cari_id, stok_seri_no_id, sozlesme_no, baslangic_tarihi, toplam_tutar, para_birimi, taksit_sayisi, notlar) FROM stdin;
3	1	7	\N	11	2026-07-14	25000.00	USD	12	\N
\.


--
-- Data for Name: personel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.personel (id, sirket_id, ad_soyad, pozisyon, aylik_maas, ise_baslama_tarihi, aktif) FROM stdin;
1	1	AHMET MEHMET	SATIS SORUMLUSU	32000.00	\N	t
\.


--
-- Data for Name: personel_odemeleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.personel_odemeleri (id, personel_id, donem, tip, tutar, odendi_mi, odeme_tarihi, aciklama) FROM stdin;
1	1	2026-07-02	MAAS	32000.00	t	2026-07-08	\N
\.


--
-- Data for Name: proforma_detay; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proforma_detay (id, proforma_id, stok_karti_id, aciklama, miktar, birim_fiyat, kdv_orani) FROM stdin;
10	7	10	JAC 3 TON ELEKTRIKLI, 4.5 MT, SIDESHIFT, SOLID TIRES	1.00	12000.00	20.00
11	7	6	JAC 3 TON DİZEL, 4.5 MT, SIDESHIFT, SOLID TIRES	1.00	10000.00	20.00
\.


--
-- Data for Name: proforma_faturalar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proforma_faturalar (id, sirket_id, proforma_no, cari_id, tarih, gecerlilik_tarihi, para_birimi, ara_toplam, kdv_tutari, genel_toplam, durum, notlar, olusturan_kullanici_id, olusturma_tarihi) FROM stdin;
7	1	PRF-2026-001	6	2026-07-08	\N	USD	22000.00	4400.00	26400.00	FATURALASTI		\N	2026-07-15 09:33:02.052272
\.


--
-- Data for Name: rol_izinleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rol_izinleri (rol_id, izin_id) FROM stdin;
1	1
1	2
1	3
1	4
1	5
1	6
1	7
1	8
1	9
1	10
1	11
1	12
1	13
1	14
1	15
1	16
1	17
1	18
1	19
1	20
1	21
1	22
1	23
1	24
1	25
1	26
1	27
1	28
1	29
1	32
1	33
1	34
1	35
\.


--
-- Data for Name: roller; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roller (id, sirket_id, ad, aciklama) FROM stdin;
1	1	Yönetici	Tam yetkili rol
\.


--
-- Data for Name: sabit_gider_kategorileri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sabit_gider_kategorileri (id, ad) FROM stdin;
1	Kira
2	Aidat
3	Elektrik
4	Su
5	Doğalgaz
6	Diğer
\.


--
-- Data for Name: sabit_giderler; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sabit_giderler (id, sirket_id, kategori_id, donem, tutar, odendi_mi, odeme_tarihi, aciklama, kategori, para_birimi, kur, tutar_try) FROM stdin;
4	1	\N	2026-07-08	20000.00	t	2026-07-08		Kargo/Nakliye	TRY	1.000000	20000.00
5	1	\N	2026-07-08	35000.00	t	2026-07-08		AA ANTREPO	TRY	1.000000	35000.00
6	1	\N	2026-07-08	28000.00	f	\N		NAVLUN	TRY	1.000000	28000.00
1	1	\N	2026-07-08	2000.00	t	2026-07-19		Elektrik Faturası	TRY	1.000000	2000.00
2	1	\N	2026-07-08	500.00	t	2026-07-19		Su Faturası	TRY	1.000000	500.00
3	1	\N	2026-07-08	32000.00	t	2026-07-19	yakupcalikoglu@hotmail.com	KİRA	TRY	1.000000	32000.00
\.


--
-- Data for Name: siparis_detay; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.siparis_detay (id, siparis_id, stok_karti_id, miktar, birim_fiyat, para_birimi, birim_agirlik_kg, aciklama, kdv_orani) FROM stdin;
11	12	6	3	10000.00	USD	\N	\N	20.00
12	12	10	2	12000.00	USD	\N	\N	20.00
13	12	8	10	1200.00	USD	\N	\N	20.00
14	12	9	10	800.00	USD	\N	\N	20.00
16	13	7	1	12000.00	USD	\N	\N	20.00
17	14	7	5	1475.00	USD	\N	\N	20.00
18	14	10	2	11500.00	USD	\N	\N	20.00
19	14	6	4	12600.00	USD	\N	\N	20.00
20	15	7	24	1450.00	USD	\N	\N	20.00
\.


--
-- Data for Name: siparis_odemeleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.siparis_odemeleri (id, siparis_id, tarih, tutar, notlar, olusturma_tarihi, odeme_yontemi, cek_id) FROM stdin;
\.


--
-- Data for Name: siparisler; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.siparisler (id, sirket_id, siparis_no, tedarikci_cari_id, kaynak, kopya_kaynak_siparis_id, siparis_tarihi, tahmini_teslim_tarihi, durum, para_birimi, cikis_limani, varis_limani, konsimento_no, gumruk_beyanname_no, notlar, olusturan_kullanici_id, olusturma_tarihi) FROM stdin;
12	1	2026-001	5	ITHALAT	\N	2026-05-14	\N	IPTAL	USD			\N	\N		\N	2026-07-14 12:28:33.716438
14	1	2026-003	5	ITHALAT	\N	2026-08-02	2026-10-26	TESLIM_ALINDI	USD			\N	\N		\N	2026-08-02 16:54:29.714858
13	1	2026002	5	ITHALAT	\N	2026-07-01	2026-09-01	TESLIM_ALINDI	USD			\N	\N	yakupcalikoglu@hotmail.com	\N	2026-07-16 12:08:19.783141
15	1	2026-004	5	ITHALAT	\N	2026-08-02	\N	TASLAK	USD			\N	\N		\N	2026-08-02 19:48:09.429117
\.


--
-- Data for Name: sirketler; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sirketler (id, unvan, vergi_dairesi, vergi_no, adres, telefon, email, logo_dosya_yolu, aktif, olusturma_tarihi) FROM stdin;
3	Aa	\N	\N	\N	\N	\N	\N	t	2026-07-17 21:03:13.375796
1	Marmara Metal Makina Lift Dış Ticaret Sanayi ve Ticaret Limited Şirketi	AKYAZI	6121723189	Ömercikler Mahallesi. 8005 Sokak. Copkayaoğlu apartmanı. No: 5/1	+90 542 303 67 36	info@marmaralift.com	/tmp/kinetik-erp-logolar/1_6243c70671824f55aa0c0ac138167955.png	t	2026-07-01 08:37:13.190099
4	aaaa	\N	\N	\N	\N	\N	\N	t	2026-08-02 19:59:47.110477
\.


--
-- Data for Name: stok_kartlari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stok_kartlari (id, sirket_id, kategori_id, marka, model, aciklama, birim, birim_agirlik_kg, olusturma_tarihi, mense_ulke, gtip_kodu, standart_alt_metin) FROM stdin;
7	1	\N	JAC	SETAKERS 1,5 TON-3 MT 20 Ah		ADET	865.00	2026-07-08 06:40:13.058495			\N
8	1	\N	JAC	STEAKER	1.5 Ton 3m Elektrikli	ADET	\N	2026-07-14 12:21:34.02724			\N
9	1	\N	JAC	TRANSPALET	24V Elektrikli	ADET	\N	2026-07-14 12:22:27.621104			\N
10	1	\N	JAC	3 TON ELEKTRIKLI, 4.5 MT, SIDESHIFT, SOLID TIRES		ADET	\N	2026-07-14 12:26:16.466378			\N
6	1	\N	JAC	3 TON DİZEL, 4.5 MT, SIDESHIFT, SOLID TIRES		ADET	\N	2026-07-05 19:49:22.074247		8427.20.19.00.00	\N
\.


--
-- Data for Name: stok_kategorileri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stok_kategorileri (id, sirket_id, ad) FROM stdin;
\.


--
-- Data for Name: stok_maliyet_kalemleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stok_maliyet_kalemleri (id, stok_seri_no_id, tip, aciklama, tedarikci_cari_id, para_birimi, tutar, kur, tutar_try, belge_no, tarih, odendi_mi, referans_usd_kuru) FROM stdin;
8	92	SATINALMA	Satınalma (Teslim Al)	5	USD	10000.00	47.0058	470058.42	\N	2026-07-14	f	\N
9	93	SATINALMA	Satınalma (Teslim Al)	5	USD	10000.00	47.0058	470058.42	\N	2026-07-14	f	\N
10	94	SATINALMA	Satınalma (Teslim Al)	5	USD	10000.00	47.0058	470058.42	\N	2026-07-14	f	\N
11	95	SATINALMA	Satınalma (Teslim Al)	5	USD	12000.00	47.0058	564070.10	\N	2026-07-14	f	\N
12	96	SATINALMA	Satınalma (Teslim Al)	5	USD	12000.00	47.0058	564070.10	\N	2026-07-14	f	\N
13	97	SATINALMA	Satınalma (Teslim Al)	5	USD	1200.00	47.0058	56407.01	\N	2026-07-14	f	\N
14	98	SATINALMA	Satınalma (Teslim Al)	5	USD	1200.00	47.0058	56407.01	\N	2026-07-14	f	\N
15	99	SATINALMA	Satınalma (Teslim Al)	5	USD	1200.00	47.0058	56407.01	\N	2026-07-14	f	\N
16	100	SATINALMA	Satınalma (Teslim Al)	5	USD	1200.00	47.0058	56407.01	\N	2026-07-14	f	\N
17	101	SATINALMA	Satınalma (Teslim Al)	5	USD	1200.00	47.0058	56407.01	\N	2026-07-14	f	\N
18	102	SATINALMA	Satınalma (Teslim Al)	5	USD	1200.00	47.0058	56407.01	\N	2026-07-14	f	\N
19	103	SATINALMA	Satınalma (Teslim Al)	5	USD	1200.00	47.0058	56407.01	\N	2026-07-14	f	\N
20	104	SATINALMA	Satınalma (Teslim Al)	5	USD	1200.00	47.0058	56407.01	\N	2026-07-14	f	\N
21	105	SATINALMA	Satınalma (Teslim Al)	5	USD	1200.00	47.0058	56407.01	\N	2026-07-14	f	\N
22	106	SATINALMA	Satınalma (Teslim Al)	5	USD	1200.00	47.0058	56407.01	\N	2026-07-14	f	\N
23	107	SATINALMA	Satınalma (Teslim Al)	5	USD	800.00	47.0058	37604.67	\N	2026-07-14	f	\N
24	108	SATINALMA	Satınalma (Teslim Al)	5	USD	800.00	47.0058	37604.67	\N	2026-07-14	f	\N
25	109	SATINALMA	Satınalma (Teslim Al)	5	USD	800.00	47.0058	37604.67	\N	2026-07-14	f	\N
26	110	SATINALMA	Satınalma (Teslim Al)	5	USD	800.00	47.0058	37604.67	\N	2026-07-14	f	\N
27	111	SATINALMA	Satınalma (Teslim Al)	5	USD	800.00	47.0058	37604.67	\N	2026-07-14	f	\N
28	112	SATINALMA	Satınalma (Teslim Al)	5	USD	800.00	47.0058	37604.67	\N	2026-07-14	f	\N
29	113	SATINALMA	Satınalma (Teslim Al)	5	USD	800.00	47.0058	37604.67	\N	2026-07-14	f	\N
30	114	SATINALMA	Satınalma (Teslim Al)	5	USD	800.00	47.0058	37604.67	\N	2026-07-14	f	\N
31	115	SATINALMA	Satınalma (Teslim Al)	5	USD	800.00	47.0058	37604.67	\N	2026-07-14	f	\N
32	116	SATINALMA	Satınalma (Teslim Al)	5	USD	800.00	47.0058	37604.67	\N	2026-07-14	f	\N
33	92	NAKLIYE	\N	\N	USD	300.00	47.0058	14101.75	\N	2026-07-14	f	\N
34	95	NAKLIYE	\N	\N	USD	200.00	47.0058	9401.17	\N	2026-07-14	f	\N
35	99	NAKLIYE	\N	\N	USD	100.00	47.0058	4700.58	\N	2026-07-14	f	\N
36	114	NAKLIYE	\N	\N	USD	100.00	47.0058	4700.58	\N	2026-07-14	f	\N
37	97	MILLILESTIRME	\N	\N	USD	160.00	47.2600	7561.60	\N	2026-07-08	f	\N
38	98	MILLILESTIRME	\N	\N	USD	160.00	47.2600	7561.60	\N	2026-07-08	f	\N
39	99	MILLILESTIRME	\N	\N	USD	160.00	47.2600	7561.60	\N	2026-07-08	f	\N
40	100	MILLILESTIRME	\N	\N	USD	160.00	47.2600	7561.60	\N	2026-07-08	f	\N
41	101	MILLILESTIRME	\N	\N	USD	160.00	47.2600	7561.60	\N	2026-07-08	f	\N
43	118	SATINALMA	Öz Mal ilk kaydı	\N	USD	18600.00	33.0000	613800.00	\N	2026-07-26	t	\N
44	119	SATINALMA	Satınalma (Teslim Al)	5	USD	1475.00	47.5478	70132.95	\N	2026-08-02	f	\N
45	120	SATINALMA	Satınalma (Teslim Al)	5	USD	1475.00	47.5478	70132.95	\N	2026-08-02	f	\N
46	121	SATINALMA	Satınalma (Teslim Al)	5	USD	1475.00	47.5478	70132.95	\N	2026-08-02	f	\N
47	122	SATINALMA	Satınalma (Teslim Al)	5	USD	1475.00	47.5478	70132.95	\N	2026-08-02	f	\N
48	123	SATINALMA	Satınalma (Teslim Al)	5	USD	1475.00	47.5478	70132.95	\N	2026-08-02	f	\N
49	124	SATINALMA	Satınalma (Teslim Al)	5	USD	11500.00	47.5478	546799.24	\N	2026-08-02	f	\N
50	125	SATINALMA	Satınalma (Teslim Al)	5	USD	11500.00	47.5478	546799.24	\N	2026-08-02	f	\N
51	126	SATINALMA	Satınalma (Teslim Al)	5	USD	12600.00	47.5478	599101.78	\N	2026-08-02	f	\N
52	127	SATINALMA	Satınalma (Teslim Al)	5	USD	12600.00	47.5478	599101.78	\N	2026-08-02	f	\N
53	128	SATINALMA	Satınalma (Teslim Al)	5	USD	12600.00	47.5478	599101.78	\N	2026-08-02	f	\N
54	129	SATINALMA	Satınalma (Teslim Al)	5	USD	12600.00	47.5478	599101.78	\N	2026-08-02	f	\N
55	130	SATINALMA	Satınalma (Teslim Al)	5	USD	12000.00	47.5478	570573.12	\N	2026-08-02	f	\N
\.


--
-- Data for Name: stok_seri_no; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stok_seri_no (id, sirket_id, stok_karti_id, seri_no, sasi_no, uretim_yili, kaynak, siparis_id, durum, tedarikci_cari_id, satinalma_maliyeti_try, nakliye_maliyeti_try, gumruk_maliyeti_try, antrepo_maliyeti_try, millilestirme_maliyeti_try, leasing_maliyeti_try, diger_maliyet_try, satis_fiyati_try, satis_tarihi, musteri_cari_id, giris_tarihi, olusturma_tarihi, garanti_bitis_tarihi, barkod, satis_cek_id, sahiplik_tipi) FROM stdin;
113	1	9	JAC-T-07	\N	\N	ITHALAT	12	GUMRUKTE	5	37604.67	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
115	1	9	JAC-T-09	\N	\N	ITHALAT	12	GUMRUKTE	5	37604.67	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
116	1	9	JAC-T-10	\N	\N	ITHALAT	12	GUMRUKTE	5	37604.67	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
114	1	9	JAC-T-08	\N	\N	ITHALAT	12	GUMRUKTE	5	37604.67	4700.58	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
96	1	10	JAC E2	\N	\N	ITHALAT	12	GUMRUKTE	5	564070.10	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
102	1	8	JAC-S-06	\N	\N	ITHALAT	12	GUMRUKTE	5	56407.01	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
103	1	8	JAC-S-07	\N	\N	ITHALAT	12	GUMRUKTE	5	56407.01	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
104	1	8	JAC-S-08	\N	\N	ITHALAT	12	GUMRUKTE	5	56407.01	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
105	1	8	JAC-S-09	\N	\N	ITHALAT	12	GUMRUKTE	5	56407.01	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
106	1	8	JAC-S-10	\N	\N	ITHALAT	12	GUMRUKTE	5	56407.01	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
107	1	9	JAC-T-01	\N	\N	ITHALAT	12	GUMRUKTE	5	37604.67	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
108	1	9	JAC-T-02	\N	\N	ITHALAT	12	GUMRUKTE	5	37604.67	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
109	1	9	JAC-T-03	\N	\N	ITHALAT	12	GUMRUKTE	5	37604.67	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
110	1	9	JAC-T-04	\N	\N	ITHALAT	12	GUMRUKTE	5	37604.67	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
111	1	9	JAC-T-05	\N	\N	ITHALAT	12	GUMRUKTE	5	37604.67	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
112	1	9	JAC-T-06	\N	\N	ITHALAT	12	GUMRUKTE	5	37604.67	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
95	1	10	JAC E1	\N	\N	ITHALAT	12	SATILDI	5	564070.10	9401.17	0.00	0.00	0.00	0.00	0.00	677275.82	2026-07-08	6	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
92	1	6	JAC D1	\N	\N	ITHALAT	12	SATILDI	5	470058.42	14101.75	0.00	0.00	0.00	0.00	0.00	564396.52	2026-07-08	6	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
93	1	6	JAC D2	\N	\N	ITHALAT	12	KIRADA	5	470058.42	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
118	1	10	634635	54	2024	YURTICI_ALIM	\N	DEPODA	\N	613800.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-26 16:11:13.55669	\N	\N	\N	OZ_MAL
119	1	7	123	\N	\N	ITHALAT	14	GUMRUKTE	5	70132.95	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-02 16:58:18.482578	2027-08-02	\N	\N	TICARI
120	1	7	1234	\N	\N	ITHALAT	14	GUMRUKTE	5	70132.95	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-02 16:58:18.482578	2026-08-02	\N	\N	TICARI
121	1	7	12345	\N	\N	ITHALAT	14	GUMRUKTE	5	70132.95	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-02 16:58:18.482578	\N	\N	\N	TICARI
98	1	8	JAC-S-02	\N	\N	ITHALAT	12	DEPODA	5	56407.01	0.00	0.00	0.00	7561.60	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
99	1	8	JAC-S-03	\N	\N	ITHALAT	12	DEPODA	5	56407.01	4700.58	0.00	0.00	7561.60	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
100	1	8	JAC-S-04	\N	\N	ITHALAT	12	DEPODA	5	56407.01	0.00	0.00	0.00	7561.60	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
101	1	8	JAC-S-05	\N	\N	ITHALAT	12	DEPODA	5	56407.01	0.00	0.00	0.00	7561.60	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
97	1	8	JAC-S-01	\N	\N	ITHALAT	12	SATILDI	5	56407.01	0.00	0.00	0.00	7561.60	0.00	0.00	76000.00	2026-07-08	6	\N	2026-07-14 13:35:38.702207	\N	\N	11	TICARI
122	1	7	123456	\N	\N	ITHALAT	14	GUMRUKTE	5	70132.95	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-02 16:58:18.482578	\N	\N	\N	TICARI
123	1	7	1234567	\N	\N	ITHALAT	14	GUMRUKTE	5	70132.95	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-02 16:58:18.482578	\N	\N	\N	TICARI
124	1	10	11	\N	\N	ITHALAT	14	GUMRUKTE	5	546799.24	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-02 16:58:18.482578	\N	\N	\N	TICARI
125	1	10	112	\N	\N	ITHALAT	14	GUMRUKTE	5	546799.24	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-02 16:58:18.482578	\N	\N	\N	TICARI
126	1	6	121	\N	\N	ITHALAT	14	GUMRUKTE	5	599101.78	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-02 16:58:18.482578	\N	\N	\N	TICARI
127	1	6	122	\N	\N	ITHALAT	14	GUMRUKTE	5	599101.78	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-02 16:58:18.482578	\N	\N	\N	TICARI
128	1	6	1221	\N	\N	ITHALAT	14	GUMRUKTE	5	599101.78	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-02 16:58:18.482578	\N	\N	\N	TICARI
129	1	6	12222	\N	\N	ITHALAT	14	GUMRUKTE	5	599101.78	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-02 16:58:18.482578	\N	\N	\N	TICARI
130	1	7	sfdsfsd	\N	\N	ITHALAT	13	GUMRUKTE	5	570573.12	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-08-02 18:27:36.344091	\N	\N	\N	TICARI
94	1	6	JAC D3	\N	\N	ITHALAT	12	DEPODA	5	470058.42	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	2026-07-14 13:35:38.702207	\N	\N	\N	TICARI
\.


--
-- Data for Name: taksit_detay; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.taksit_detay (id, plan_id, taksit_no, vade_tarihi, tutar, odendi_mi, odeme_tarihi, tahsilat_kaynak_tablo, tahsilat_kaynak_id, odenen_tutar, ilk_taksit_id) FROM stdin;
1	1	1	2026-08-08	103472.69	f	\N	\N	\N	0.00	\N
2	1	2	2026-09-08	103472.69	f	\N	\N	\N	0.00	\N
3	1	3	2026-10-08	103472.69	f	\N	\N	\N	0.00	\N
4	1	4	2026-11-08	103472.69	f	\N	\N	\N	0.00	\N
5	1	5	2026-12-08	103472.69	f	\N	\N	\N	0.00	\N
6	1	6	2027-01-08	103472.69	f	\N	\N	\N	0.00	\N
7	1	7	2027-02-08	103472.69	f	\N	\N	\N	0.00	\N
8	1	8	2027-03-08	103472.69	f	\N	\N	\N	0.00	\N
9	1	9	2027-04-08	103472.69	f	\N	\N	\N	0.00	\N
10	1	10	2027-05-08	103472.69	f	\N	\N	\N	0.00	\N
11	1	11	2027-06-08	103472.69	f	\N	\N	\N	0.00	\N
12	1	12	2027-07-08	103472.75	f	\N	\N	\N	0.00	\N
\.


--
-- Data for Name: taksitli_satis_kalemleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.taksitli_satis_kalemleri (id, plan_id, stok_karti_id, miktar, birim_fiyat) FROM stdin;
1	1	10	1	677275.82
2	1	6	1	564396.52
\.


--
-- Data for Name: taksitli_satis_planlari; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.taksitli_satis_planlari (id, sirket_id, musteri_cari_id, stok_seri_no_id, toplam_tutar, para_birimi, pesinat, taksit_sayisi, baslangic_tarihi, notlar) FROM stdin;
1	1	6	\N	1241672.34	TRY	0.00	12	2026-07-08	\N
\.


--
-- Data for Name: urun_sahiplik_gecmisi; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.urun_sahiplik_gecmisi (id, stok_seri_no_id, eski_cari_id, yeni_cari_id, aciklama, tarih, olusturma_tarihi) FROM stdin;
\.


--
-- Data for Name: yedek_parca_hareketleri; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.yedek_parca_hareketleri (id, yedek_parca_id, tarih, yon, miktar, birim_fiyat_try, ilgili_cari_id, aciklama, olusturma_tarihi, birim_fiyat_orijinal, para_birimi, kur, maliyet_birim_fiyat_try, odeme_yontemi, banka_hesap_id, ilgili_stok_seri_no_id) FROM stdin;
6	2	2026-07-28	GIRIS	1.00	70000.00	\N	\N	2026-07-28 21:22:56.39358	70000.00	TRY	1.000000	\N	BANKA	4	\N
7	2	2026-07-28	CIKIS	1.00	80000.00	6	\N	2026-07-28 21:23:33.686782	80000.00	TRY	1.000000	70000.00	BANKA	4	95
\.


--
-- Data for Name: yedek_parcalar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.yedek_parcalar (id, sirket_id, ad, birim, mevcut_miktar, birim_fiyat_try, min_stok_seviyesi, notlar, olusturma_tarihi) FROM stdin;
2	1	KABİN	ADET	0.00	70000.00	5.00	yakupcalikoglu@hotmail.com	2026-07-28 21:20:13.87046
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2026-07-01 07:55:53
20211116045059	2026-07-01 07:55:54
20211116050929	2026-07-01 07:55:54
20211116051442	2026-07-01 07:55:54
20211116212300	2026-07-01 07:55:54
20211116213355	2026-07-01 07:55:54
20211116213934	2026-07-01 07:55:54
20211116214523	2026-07-01 07:55:54
20211122062447	2026-07-01 07:55:55
20211124070109	2026-07-01 07:55:55
20211202204204	2026-07-01 07:55:55
20211202204605	2026-07-01 07:55:55
20211210212804	2026-07-01 07:55:55
20211228014915	2026-07-01 07:55:56
20220107221237	2026-07-01 07:55:56
20220228202821	2026-07-01 07:55:56
20220312004840	2026-07-01 07:55:56
20220603231003	2026-07-01 07:55:56
20220603232444	2026-07-01 07:55:56
20220615214548	2026-07-01 07:55:56
20220712093339	2026-07-01 07:55:57
20220908172859	2026-07-01 07:55:57
20220916233421	2026-07-01 07:55:57
20230119133233	2026-07-01 07:55:57
20230128025114	2026-07-01 07:55:57
20230128025212	2026-07-01 07:55:57
20230227211149	2026-07-01 07:55:57
20230228184745	2026-07-01 07:55:57
20230308225145	2026-07-01 07:55:58
20230328144023	2026-07-01 07:55:58
20231018144023	2026-07-01 07:55:58
20231204144023	2026-07-01 07:55:58
20231204144024	2026-07-01 07:55:58
20231204144025	2026-07-01 07:55:58
20240108234812	2026-07-01 07:55:58
20240109165339	2026-07-01 07:55:59
20240227174441	2026-07-01 07:55:59
20240311171622	2026-07-01 07:55:59
20240321100241	2026-07-01 07:55:59
20240401105812	2026-07-01 07:56:00
20240418121054	2026-07-01 07:56:00
20240523004032	2026-07-01 07:56:00
20240618124746	2026-07-01 07:56:00
20240801235015	2026-07-01 07:56:00
20240805133720	2026-07-01 07:56:01
20240827160934	2026-07-01 07:56:01
20240919163303	2026-07-01 07:56:01
20240919163305	2026-07-01 07:56:01
20241019105805	2026-07-01 07:56:01
20241030150047	2026-07-01 07:56:02
20241108114728	2026-07-01 07:56:02
20241121104152	2026-07-01 07:56:02
20241130184212	2026-07-01 07:56:02
20241220035512	2026-07-01 07:56:02
20241220123912	2026-07-01 07:56:02
20241224161212	2026-07-01 07:56:02
20250107150512	2026-07-01 07:56:02
20250110162412	2026-07-01 07:56:03
20250123174212	2026-07-01 07:56:03
20250128220012	2026-07-01 07:56:03
20250506224012	2026-07-01 07:56:03
20250523164012	2026-07-01 07:56:03
20250714121412	2026-07-01 07:56:03
20250905041441	2026-07-01 07:56:03
20251103001201	2026-07-01 07:56:03
20251120212548	2026-07-01 07:56:04
20251120215549	2026-07-01 07:56:04
20260218120000	2026-07-01 07:56:04
20260326120000	2026-07-01 07:56:04
20260514120000	2026-07-01 07:56:04
20260527120000	2026-07-01 07:56:04
20260528120000	2026-07-01 07:56:05
20260603120000	2026-07-01 07:56:05
20260605120000	2026-07-01 07:56:05
20260606110000	2026-07-01 07:56:05
20260616120000	2026-07-01 07:56:05
20260624120000	2026-07-01 07:56:06
20260626120000	2026-07-22 14:19:01
20260706120000	2026-07-22 14:19:01
20260707120000	2026-07-22 14:19:02
20260709120000	2026-07-22 14:19:02
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at, action_filter, selected_columns) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_analytics (name, type, format, created_at, updated_at, id, deleted_at) FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_vectors (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-07-01 06:14:54.544815
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-07-01 06:14:54.584174
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-07-01 06:14:54.590681
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-07-01 06:14:54.633416
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-07-01 06:14:54.64929
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-07-01 06:14:54.654924
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-07-01 06:14:54.661156
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-07-01 06:14:54.667171
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-07-01 06:14:54.676184
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-07-01 06:14:54.682973
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-07-01 06:14:54.688989
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-07-01 06:14:54.696095
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-07-01 06:14:54.702676
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-07-01 06:14:54.708535
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-07-01 06:14:54.714595
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-07-01 06:14:54.741477
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-07-01 06:14:54.747827
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-07-01 06:14:54.754059
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-07-01 06:14:54.760779
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-07-01 06:14:54.769076
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-07-01 06:14:54.775676
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-07-01 06:14:54.784493
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-07-01 06:14:54.801944
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-07-01 06:14:54.8132
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-07-01 06:14:54.819138
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-07-01 06:14:54.824979
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-07-01 06:14:54.831489
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-07-01 06:14:54.836899
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-07-01 06:14:54.842462
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-07-01 06:14:54.848488
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-07-01 06:14:54.853947
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-07-01 06:14:54.862526
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-07-01 06:14:54.869308
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-07-01 06:14:54.878546
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-07-01 06:14:54.884017
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-07-01 06:14:54.889914
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-07-01 06:14:54.898026
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-07-01 06:14:54.90626
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-07-01 06:14:54.915319
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-07-01 06:14:54.928978
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-07-01 06:14:54.934347
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-07-01 06:14:54.940876
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-07-01 06:14:54.946097
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-07-01 06:14:54.951998
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-07-01 06:14:54.957513
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-07-01 06:14:54.963592
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-07-01 06:14:54.975783
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-07-01 06:14:54.982602
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-07-01 06:14:54.987926
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-07-01 06:14:55.005576
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-07-01 06:14:55.011773
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-07-01 06:14:55.030147
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-07-01 06:14:55.032264
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-07-01 06:14:55.043013
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-07-01 06:14:55.046335
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-07-01 06:14:55.04855
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-07-01 06:14:55.05498
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-07-01 06:14:55.061826
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-07-01 06:14:55.067425
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-07-01 06:14:55.073705
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-07-01 06:14:55.07942
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata, metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.vector_indexes (id, name, bucket_id, data_type, dimension, distance_metric, metadata_configuration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: -
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: -
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 1, false);


--
-- Name: akreditif_kalem_taksitleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.akreditif_kalem_taksitleri_id_seq', 1, false);


--
-- Name: akreditif_kalemleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.akreditif_kalemleri_id_seq', 8, true);


--
-- Name: akreditif_maliyet_dagitimlari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.akreditif_maliyet_dagitimlari_id_seq', 1, false);


--
-- Name: akreditifler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.akreditifler_id_seq', 6, true);


--
-- Name: bakim_kayitlari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bakim_kayitlari_id_seq', 1, false);


--
-- Name: banka_hareketleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.banka_hareketleri_id_seq', 36, true);


--
-- Name: banka_hesaplari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.banka_hesaplari_id_seq', 5, true);


--
-- Name: borc_odemeleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.borc_odemeleri_id_seq', 1, false);


--
-- Name: borclar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.borclar_id_seq', 1, false);


--
-- Name: cari_hareketler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cari_hareketler_id_seq', 1, false);


--
-- Name: cari_hesaplar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cari_hesaplar_id_seq', 8, true);


--
-- Name: cek_hareket_gecmisi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cek_hareket_gecmisi_id_seq', 2, true);


--
-- Name: cekler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cekler_id_seq', 12, true);


--
-- Name: demirbaslar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.demirbaslar_id_seq', 1, false);


--
-- Name: doviz_kurlari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.doviz_kurlari_id_seq', 1, false);


--
-- Name: duzenleme_kayitlari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.duzenleme_kayitlari_id_seq', 15, true);


--
-- Name: fatura_detay_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fatura_detay_id_seq', 7, true);


--
-- Name: faturalar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.faturalar_id_seq', 4, true);


--
-- Name: gumruk_beyannameleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gumruk_beyannameleri_id_seq', 1, false);


--
-- Name: harcama_turleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.harcama_turleri_id_seq', 38, true);


--
-- Name: islem_loglari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.islem_loglari_id_seq', 1, false);


--
-- Name: izinler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.izinler_id_seq', 35, true);


--
-- Name: kasa_hareketleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kasa_hareketleri_id_seq', 5, true);


--
-- Name: kdv_manuel_girisler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kdv_manuel_girisler_id_seq', 1, false);


--
-- Name: kiralama_kalem_urunleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kiralama_kalem_urunleri_id_seq', 4, true);


--
-- Name: kiralama_odemeleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kiralama_odemeleri_id_seq', 2, true);


--
-- Name: kiralama_sozlesme_kalemleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kiralama_sozlesme_kalemleri_id_seq', 4, true);


--
-- Name: kiralama_sozlesmeleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kiralama_sozlesmeleri_id_seq', 12, true);


--
-- Name: kullanici_sirket_erisim_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kullanici_sirket_erisim_id_seq', 3, true);


--
-- Name: kullanicilar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kullanicilar_id_seq', 2, true);


--
-- Name: leasing_kalem_urunleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leasing_kalem_urunleri_id_seq', 1, false);


--
-- Name: leasing_odeme_plani_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leasing_odeme_plani_id_seq', 36, true);


--
-- Name: leasing_sozlesme_kalemleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leasing_sozlesme_kalemleri_id_seq', 1, true);


--
-- Name: leasing_sozlesmeleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leasing_sozlesmeleri_id_seq', 3, true);


--
-- Name: personel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.personel_id_seq', 1, true);


--
-- Name: personel_odemeleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.personel_odemeleri_id_seq', 2, true);


--
-- Name: proforma_detay_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.proforma_detay_id_seq', 11, true);


--
-- Name: proforma_faturalar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.proforma_faturalar_id_seq', 7, true);


--
-- Name: roller_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roller_id_seq', 1, true);


--
-- Name: sabit_gider_kategorileri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sabit_gider_kategorileri_id_seq', 6, true);


--
-- Name: sabit_giderler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sabit_giderler_id_seq', 6, true);


--
-- Name: siparis_detay_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.siparis_detay_id_seq', 20, true);


--
-- Name: siparis_odemeleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.siparis_odemeleri_id_seq', 1, false);


--
-- Name: siparisler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.siparisler_id_seq', 15, true);


--
-- Name: sirketler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sirketler_id_seq', 4, true);


--
-- Name: stok_kartlari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stok_kartlari_id_seq', 10, true);


--
-- Name: stok_kategorileri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stok_kategorileri_id_seq', 1, false);


--
-- Name: stok_maliyet_kalemleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stok_maliyet_kalemleri_id_seq', 55, true);


--
-- Name: stok_seri_no_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stok_seri_no_id_seq', 130, true);


--
-- Name: taksit_detay_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.taksit_detay_id_seq', 12, true);


--
-- Name: taksitli_satis_kalemleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.taksitli_satis_kalemleri_id_seq', 2, true);


--
-- Name: taksitli_satis_planlari_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.taksitli_satis_planlari_id_seq', 1, true);


--
-- Name: urun_sahiplik_gecmisi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.urun_sahiplik_gecmisi_id_seq', 1, false);


--
-- Name: yedek_parca_hareketleri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.yedek_parca_hareketleri_id_seq', 7, true);


--
-- Name: yedek_parcalar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.yedek_parcalar_id_seq', 2, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: -
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_identifier_key UNIQUE (identifier);


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_client_states
    ADD CONSTRAINT oauth_client_states_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: akreditif_kalem_taksitleri akreditif_kalem_taksitleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditif_kalem_taksitleri
    ADD CONSTRAINT akreditif_kalem_taksitleri_pkey PRIMARY KEY (id);


--
-- Name: akreditif_kalemleri akreditif_kalemleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditif_kalemleri
    ADD CONSTRAINT akreditif_kalemleri_pkey PRIMARY KEY (id);


--
-- Name: akreditif_maliyet_dagitimlari akreditif_maliyet_dagitimlari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditif_maliyet_dagitimlari
    ADD CONSTRAINT akreditif_maliyet_dagitimlari_pkey PRIMARY KEY (id);


--
-- Name: akreditifler akreditifler_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditifler
    ADD CONSTRAINT akreditifler_pkey PRIMARY KEY (id);


--
-- Name: bakim_kayitlari bakim_kayitlari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bakim_kayitlari
    ADD CONSTRAINT bakim_kayitlari_pkey PRIMARY KEY (id);


--
-- Name: banka_hareketleri banka_hareketleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hareketleri
    ADD CONSTRAINT banka_hareketleri_pkey PRIMARY KEY (id);


--
-- Name: banka_hesaplari banka_hesaplari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hesaplari
    ADD CONSTRAINT banka_hesaplari_pkey PRIMARY KEY (id);


--
-- Name: borc_odemeleri borc_odemeleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.borc_odemeleri
    ADD CONSTRAINT borc_odemeleri_pkey PRIMARY KEY (id);


--
-- Name: borclar borclar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.borclar
    ADD CONSTRAINT borclar_pkey PRIMARY KEY (id);


--
-- Name: cari_hareketler cari_hareketler_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_hareketler
    ADD CONSTRAINT cari_hareketler_pkey PRIMARY KEY (id);


--
-- Name: cari_hesaplar cari_hesaplar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_hesaplar
    ADD CONSTRAINT cari_hesaplar_pkey PRIMARY KEY (id);


--
-- Name: cek_hareket_gecmisi cek_hareket_gecmisi_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cek_hareket_gecmisi
    ADD CONSTRAINT cek_hareket_gecmisi_pkey PRIMARY KEY (id);


--
-- Name: cekler cekler_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cekler
    ADD CONSTRAINT cekler_pkey PRIMARY KEY (id);


--
-- Name: demirbaslar demirbaslar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demirbaslar
    ADD CONSTRAINT demirbaslar_pkey PRIMARY KEY (id);


--
-- Name: doviz_kurlari doviz_kurlari_para_birimi_tarih_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doviz_kurlari
    ADD CONSTRAINT doviz_kurlari_para_birimi_tarih_key UNIQUE (para_birimi, tarih);


--
-- Name: doviz_kurlari doviz_kurlari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doviz_kurlari
    ADD CONSTRAINT doviz_kurlari_pkey PRIMARY KEY (id);


--
-- Name: duzenleme_kayitlari duzenleme_kayitlari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duzenleme_kayitlari
    ADD CONSTRAINT duzenleme_kayitlari_pkey PRIMARY KEY (id);


--
-- Name: fatura_detay fatura_detay_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fatura_detay
    ADD CONSTRAINT fatura_detay_pkey PRIMARY KEY (id);


--
-- Name: faturalar faturalar_fatura_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faturalar
    ADD CONSTRAINT faturalar_fatura_no_key UNIQUE (fatura_no);


--
-- Name: faturalar faturalar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faturalar
    ADD CONSTRAINT faturalar_pkey PRIMARY KEY (id);


--
-- Name: gumruk_beyannameleri gumruk_beyannameleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gumruk_beyannameleri
    ADD CONSTRAINT gumruk_beyannameleri_pkey PRIMARY KEY (id);


--
-- Name: harcama_turleri harcama_turleri_ad_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.harcama_turleri
    ADD CONSTRAINT harcama_turleri_ad_key UNIQUE (ad);


--
-- Name: harcama_turleri harcama_turleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.harcama_turleri
    ADD CONSTRAINT harcama_turleri_pkey PRIMARY KEY (id);


--
-- Name: islem_loglari islem_loglari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.islem_loglari
    ADD CONSTRAINT islem_loglari_pkey PRIMARY KEY (id);


--
-- Name: izinler izinler_kod_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.izinler
    ADD CONSTRAINT izinler_kod_key UNIQUE (kod);


--
-- Name: izinler izinler_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.izinler
    ADD CONSTRAINT izinler_pkey PRIMARY KEY (id);


--
-- Name: kasa_hareketleri kasa_hareketleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kasa_hareketleri
    ADD CONSTRAINT kasa_hareketleri_pkey PRIMARY KEY (id);


--
-- Name: kdv_manuel_girisler kdv_manuel_girisler_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kdv_manuel_girisler
    ADD CONSTRAINT kdv_manuel_girisler_pkey PRIMARY KEY (id);


--
-- Name: kiralama_kalem_urunleri kiralama_kalem_urunleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_kalem_urunleri
    ADD CONSTRAINT kiralama_kalem_urunleri_pkey PRIMARY KEY (id);


--
-- Name: kiralama_odemeleri kiralama_odemeleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_odemeleri
    ADD CONSTRAINT kiralama_odemeleri_pkey PRIMARY KEY (id);


--
-- Name: kiralama_sozlesme_kalemleri kiralama_sozlesme_kalemleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_sozlesme_kalemleri
    ADD CONSTRAINT kiralama_sozlesme_kalemleri_pkey PRIMARY KEY (id);


--
-- Name: kiralama_sozlesmeleri kiralama_sozlesmeleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_sozlesmeleri
    ADD CONSTRAINT kiralama_sozlesmeleri_pkey PRIMARY KEY (id);


--
-- Name: kullanici_rolleri kullanici_rolleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanici_rolleri
    ADD CONSTRAINT kullanici_rolleri_pkey PRIMARY KEY (kullanici_id, rol_id, sirket_id);


--
-- Name: kullanici_sirket_erisim kullanici_sirket_erisim_kullanici_id_sirket_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanici_sirket_erisim
    ADD CONSTRAINT kullanici_sirket_erisim_kullanici_id_sirket_id_key UNIQUE (kullanici_id, sirket_id);


--
-- Name: kullanici_sirket_erisim kullanici_sirket_erisim_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanici_sirket_erisim
    ADD CONSTRAINT kullanici_sirket_erisim_pkey PRIMARY KEY (id);


--
-- Name: kullanicilar kullanicilar_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanicilar
    ADD CONSTRAINT kullanicilar_email_key UNIQUE (email);


--
-- Name: kullanicilar kullanicilar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanicilar
    ADD CONSTRAINT kullanicilar_pkey PRIMARY KEY (id);


--
-- Name: leasing_kalem_urunleri leasing_kalem_urunleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_kalem_urunleri
    ADD CONSTRAINT leasing_kalem_urunleri_pkey PRIMARY KEY (id);


--
-- Name: leasing_odeme_plani leasing_odeme_plani_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_odeme_plani
    ADD CONSTRAINT leasing_odeme_plani_pkey PRIMARY KEY (id);


--
-- Name: leasing_sozlesme_kalemleri leasing_sozlesme_kalemleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_sozlesme_kalemleri
    ADD CONSTRAINT leasing_sozlesme_kalemleri_pkey PRIMARY KEY (id);


--
-- Name: leasing_sozlesmeleri leasing_sozlesmeleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_sozlesmeleri
    ADD CONSTRAINT leasing_sozlesmeleri_pkey PRIMARY KEY (id);


--
-- Name: personel_odemeleri personel_odemeleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personel_odemeleri
    ADD CONSTRAINT personel_odemeleri_pkey PRIMARY KEY (id);


--
-- Name: personel personel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personel
    ADD CONSTRAINT personel_pkey PRIMARY KEY (id);


--
-- Name: proforma_detay proforma_detay_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_detay
    ADD CONSTRAINT proforma_detay_pkey PRIMARY KEY (id);


--
-- Name: proforma_faturalar proforma_faturalar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_faturalar
    ADD CONSTRAINT proforma_faturalar_pkey PRIMARY KEY (id);


--
-- Name: proforma_faturalar proforma_faturalar_proforma_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_faturalar
    ADD CONSTRAINT proforma_faturalar_proforma_no_key UNIQUE (proforma_no);


--
-- Name: rol_izinleri rol_izinleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rol_izinleri
    ADD CONSTRAINT rol_izinleri_pkey PRIMARY KEY (rol_id, izin_id);


--
-- Name: roller roller_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roller
    ADD CONSTRAINT roller_pkey PRIMARY KEY (id);


--
-- Name: sabit_gider_kategorileri sabit_gider_kategorileri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sabit_gider_kategorileri
    ADD CONSTRAINT sabit_gider_kategorileri_pkey PRIMARY KEY (id);


--
-- Name: sabit_giderler sabit_giderler_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sabit_giderler
    ADD CONSTRAINT sabit_giderler_pkey PRIMARY KEY (id);


--
-- Name: siparis_detay siparis_detay_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparis_detay
    ADD CONSTRAINT siparis_detay_pkey PRIMARY KEY (id);


--
-- Name: siparis_odemeleri siparis_odemeleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparis_odemeleri
    ADD CONSTRAINT siparis_odemeleri_pkey PRIMARY KEY (id);


--
-- Name: siparisler siparisler_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparisler
    ADD CONSTRAINT siparisler_pkey PRIMARY KEY (id);


--
-- Name: siparisler siparisler_siparis_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparisler
    ADD CONSTRAINT siparisler_siparis_no_key UNIQUE (siparis_no);


--
-- Name: sirketler sirketler_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sirketler
    ADD CONSTRAINT sirketler_pkey PRIMARY KEY (id);


--
-- Name: stok_kartlari stok_kartlari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_kartlari
    ADD CONSTRAINT stok_kartlari_pkey PRIMARY KEY (id);


--
-- Name: stok_kategorileri stok_kategorileri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_kategorileri
    ADD CONSTRAINT stok_kategorileri_pkey PRIMARY KEY (id);


--
-- Name: stok_maliyet_kalemleri stok_maliyet_kalemleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_maliyet_kalemleri
    ADD CONSTRAINT stok_maliyet_kalemleri_pkey PRIMARY KEY (id);


--
-- Name: stok_seri_no stok_seri_no_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_seri_no
    ADD CONSTRAINT stok_seri_no_pkey PRIMARY KEY (id);


--
-- Name: stok_seri_no stok_seri_no_seri_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_seri_no
    ADD CONSTRAINT stok_seri_no_seri_no_key UNIQUE (seri_no);


--
-- Name: taksit_detay taksit_detay_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksit_detay
    ADD CONSTRAINT taksit_detay_pkey PRIMARY KEY (id);


--
-- Name: taksitli_satis_kalemleri taksitli_satis_kalemleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_kalemleri
    ADD CONSTRAINT taksitli_satis_kalemleri_pkey PRIMARY KEY (id);


--
-- Name: taksitli_satis_planlari taksitli_satis_planlari_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_planlari
    ADD CONSTRAINT taksitli_satis_planlari_pkey PRIMARY KEY (id);


--
-- Name: urun_sahiplik_gecmisi urun_sahiplik_gecmisi_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.urun_sahiplik_gecmisi
    ADD CONSTRAINT urun_sahiplik_gecmisi_pkey PRIMARY KEY (id);


--
-- Name: yedek_parca_hareketleri yedek_parca_hareketleri_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yedek_parca_hareketleri
    ADD CONSTRAINT yedek_parca_hareketleri_pkey PRIMARY KEY (id);


--
-- Name: yedek_parcalar yedek_parcalar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yedek_parcalar
    ADD CONSTRAINT yedek_parcalar_pkey PRIMARY KEY (id);


--
-- Name: messages messages_payload_exclusive; Type: CHECK CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages
    ADD CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL))) NOT VALID;


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_vectors
    ADD CONSTRAINT buckets_vectors_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_created_at_idx ON auth.custom_oauth_providers USING btree (created_at);


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_enabled_idx ON auth.custom_oauth_providers USING btree (enabled);


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_identifier_idx ON auth.custom_oauth_providers USING btree (identifier);


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_provider_type_idx ON auth.custom_oauth_providers USING btree (provider_type);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_oauth_client_states_created_at ON auth.oauth_client_states USING btree (created_at);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_created_at_desc ON auth.users USING btree (created_at DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_email ON auth.users USING btree (email);


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_last_sign_in_at_desc ON auth.users USING btree (last_sign_in_at DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_name ON auth.users USING btree (((raw_user_meta_data ->> 'name'::text))) WHERE ((raw_user_meta_data ->> 'name'::text) IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_expires_at_idx ON auth.webauthn_challenges USING btree (expires_at);


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_user_id_idx ON auth.webauthn_challenges USING btree (user_id);


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX webauthn_credentials_credential_id_key ON auth.webauthn_credentials USING btree (credential_id);


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_credentials_user_id_idx ON auth.webauthn_credentials USING btree (user_id);


--
-- Name: idx_banka_hareket_hesap; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_banka_hareket_hesap ON public.banka_hareketleri USING btree (banka_hesap_id);


--
-- Name: idx_banka_hareket_tarih; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_banka_hareket_tarih ON public.banka_hareketleri USING btree (tarih);


--
-- Name: idx_cari_hareket_cari; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cari_hareket_cari ON public.cari_hareketler USING btree (cari_id);


--
-- Name: idx_cari_hareket_tarih; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cari_hareket_tarih ON public.cari_hareketler USING btree (tarih);


--
-- Name: idx_stok_seri_durum; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stok_seri_durum ON public.stok_seri_no USING btree (durum);


--
-- Name: idx_stok_seri_no_arama; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stok_seri_no_arama ON public.stok_seri_no USING btree (seri_no);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_selec; Type: INDEX; Schema: realtime; Owner: -
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_action_filter_selec ON realtime.subscription USING btree (subscription_id, entity, filters, action_filter, COALESCE(selected_columns, '{}'::text[]));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX buckets_analytics_unique_name_idx ON storage.buckets_analytics USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name_lower ON storage.objects USING btree (bucket_id, lower(name) COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX vector_indexes_name_bucket_id_idx ON storage.vector_indexes USING btree (name, bucket_id);


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: -
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER protect_buckets_delete BEFORE DELETE ON storage.buckets FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER protect_objects_delete BEFORE DELETE ON storage.objects FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: akreditif_kalemleri akreditif_kalemleri_akreditif_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditif_kalemleri
    ADD CONSTRAINT akreditif_kalemleri_akreditif_id_fkey FOREIGN KEY (akreditif_id) REFERENCES public.akreditifler(id);


--
-- Name: akreditifler akreditifler_banka_hesap_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditifler
    ADD CONSTRAINT akreditifler_banka_hesap_id_fkey FOREIGN KEY (banka_hesap_id) REFERENCES public.banka_hesaplari(id);


--
-- Name: akreditifler akreditifler_siparis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditifler
    ADD CONSTRAINT akreditifler_siparis_id_fkey FOREIGN KEY (siparis_id) REFERENCES public.siparisler(id);


--
-- Name: akreditifler akreditifler_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.akreditifler
    ADD CONSTRAINT akreditifler_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: bakim_kayitlari bakim_kayitlari_ilgili_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bakim_kayitlari
    ADD CONSTRAINT bakim_kayitlari_ilgili_cari_id_fkey FOREIGN KEY (ilgili_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: bakim_kayitlari bakim_kayitlari_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bakim_kayitlari
    ADD CONSTRAINT bakim_kayitlari_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: bakim_kayitlari bakim_kayitlari_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bakim_kayitlari
    ADD CONSTRAINT bakim_kayitlari_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: banka_hareketleri banka_hareketleri_banka_hesap_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hareketleri
    ADD CONSTRAINT banka_hareketleri_banka_hesap_id_fkey FOREIGN KEY (banka_hesap_id) REFERENCES public.banka_hesaplari(id);


--
-- Name: banka_hareketleri banka_hareketleri_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hareketleri
    ADD CONSTRAINT banka_hareketleri_cari_id_fkey FOREIGN KEY (cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: banka_hareketleri banka_hareketleri_karsi_hesap_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hareketleri
    ADD CONSTRAINT banka_hareketleri_karsi_hesap_id_fkey FOREIGN KEY (karsi_hesap_id) REFERENCES public.banka_hesaplari(id);


--
-- Name: banka_hareketleri banka_hareketleri_olusturan_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hareketleri
    ADD CONSTRAINT banka_hareketleri_olusturan_kullanici_id_fkey FOREIGN KEY (olusturan_kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: banka_hareketleri banka_hareketleri_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hareketleri
    ADD CONSTRAINT banka_hareketleri_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: banka_hesaplari banka_hesaplari_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banka_hesaplari
    ADD CONSTRAINT banka_hesaplari_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: borc_odemeleri borc_odemeleri_borc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.borc_odemeleri
    ADD CONSTRAINT borc_odemeleri_borc_id_fkey FOREIGN KEY (borc_id) REFERENCES public.borclar(id) ON DELETE CASCADE;


--
-- Name: borclar borclar_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.borclar
    ADD CONSTRAINT borclar_cari_id_fkey FOREIGN KEY (cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: borclar borclar_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.borclar
    ADD CONSTRAINT borclar_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: cari_hareketler cari_hareketler_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_hareketler
    ADD CONSTRAINT cari_hareketler_cari_id_fkey FOREIGN KEY (cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: cari_hareketler cari_hareketler_olusturan_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_hareketler
    ADD CONSTRAINT cari_hareketler_olusturan_kullanici_id_fkey FOREIGN KEY (olusturan_kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: cari_hareketler cari_hareketler_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_hareketler
    ADD CONSTRAINT cari_hareketler_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: cari_hesaplar cari_hesaplar_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cari_hesaplar
    ADD CONSTRAINT cari_hesaplar_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: cek_hareket_gecmisi cek_hareket_gecmisi_cek_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cek_hareket_gecmisi
    ADD CONSTRAINT cek_hareket_gecmisi_cek_id_fkey FOREIGN KEY (cek_id) REFERENCES public.cekler(id) ON DELETE CASCADE;


--
-- Name: cek_hareket_gecmisi cek_hareket_gecmisi_olusturan_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cek_hareket_gecmisi
    ADD CONSTRAINT cek_hareket_gecmisi_olusturan_kullanici_id_fkey FOREIGN KEY (olusturan_kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: cekler cekler_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cekler
    ADD CONSTRAINT cekler_cari_id_fkey FOREIGN KEY (cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: cekler cekler_ciro_edilen_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cekler
    ADD CONSTRAINT cekler_ciro_edilen_cari_id_fkey FOREIGN KEY (ciro_edilen_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: cekler cekler_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cekler
    ADD CONSTRAINT cekler_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: demirbaslar demirbaslar_kiraci_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demirbaslar
    ADD CONSTRAINT demirbaslar_kiraci_cari_id_fkey FOREIGN KEY (kiraci_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: demirbaslar demirbaslar_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demirbaslar
    ADD CONSTRAINT demirbaslar_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: duzenleme_kayitlari duzenleme_kayitlari_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duzenleme_kayitlari
    ADD CONSTRAINT duzenleme_kayitlari_kullanici_id_fkey FOREIGN KEY (kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: duzenleme_kayitlari duzenleme_kayitlari_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duzenleme_kayitlari
    ADD CONSTRAINT duzenleme_kayitlari_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: fatura_detay fatura_detay_fatura_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fatura_detay
    ADD CONSTRAINT fatura_detay_fatura_id_fkey FOREIGN KEY (fatura_id) REFERENCES public.faturalar(id) ON DELETE CASCADE;


--
-- Name: fatura_detay fatura_detay_stok_karti_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fatura_detay
    ADD CONSTRAINT fatura_detay_stok_karti_id_fkey FOREIGN KEY (stok_karti_id) REFERENCES public.stok_kartlari(id);


--
-- Name: fatura_detay fatura_detay_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fatura_detay
    ADD CONSTRAINT fatura_detay_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: faturalar faturalar_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faturalar
    ADD CONSTRAINT faturalar_cari_id_fkey FOREIGN KEY (cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: faturalar faturalar_olusturan_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faturalar
    ADD CONSTRAINT faturalar_olusturan_kullanici_id_fkey FOREIGN KEY (olusturan_kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: faturalar faturalar_proforma_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faturalar
    ADD CONSTRAINT faturalar_proforma_id_fkey FOREIGN KEY (proforma_id) REFERENCES public.proforma_faturalar(id);


--
-- Name: faturalar faturalar_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faturalar
    ADD CONSTRAINT faturalar_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: stok_seri_no fk_stok_siparis; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_seri_no
    ADD CONSTRAINT fk_stok_siparis FOREIGN KEY (siparis_id) REFERENCES public.siparisler(id);


--
-- Name: gumruk_beyannameleri gumruk_beyannameleri_gumruk_musaviri_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gumruk_beyannameleri
    ADD CONSTRAINT gumruk_beyannameleri_gumruk_musaviri_cari_id_fkey FOREIGN KEY (gumruk_musaviri_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: gumruk_beyannameleri gumruk_beyannameleri_siparis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gumruk_beyannameleri
    ADD CONSTRAINT gumruk_beyannameleri_siparis_id_fkey FOREIGN KEY (siparis_id) REFERENCES public.siparisler(id);


--
-- Name: gumruk_beyannameleri gumruk_beyannameleri_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gumruk_beyannameleri
    ADD CONSTRAINT gumruk_beyannameleri_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: islem_loglari islem_loglari_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.islem_loglari
    ADD CONSTRAINT islem_loglari_kullanici_id_fkey FOREIGN KEY (kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: islem_loglari islem_loglari_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.islem_loglari
    ADD CONSTRAINT islem_loglari_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: kasa_hareketleri kasa_hareketleri_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kasa_hareketleri
    ADD CONSTRAINT kasa_hareketleri_cari_id_fkey FOREIGN KEY (cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: kasa_hareketleri kasa_hareketleri_olusturan_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kasa_hareketleri
    ADD CONSTRAINT kasa_hareketleri_olusturan_kullanici_id_fkey FOREIGN KEY (olusturan_kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: kasa_hareketleri kasa_hareketleri_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kasa_hareketleri
    ADD CONSTRAINT kasa_hareketleri_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: kdv_manuel_girisler kdv_manuel_girisler_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kdv_manuel_girisler
    ADD CONSTRAINT kdv_manuel_girisler_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: kiralama_kalem_urunleri kiralama_kalem_urunleri_kalem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_kalem_urunleri
    ADD CONSTRAINT kiralama_kalem_urunleri_kalem_id_fkey FOREIGN KEY (kalem_id) REFERENCES public.kiralama_sozlesme_kalemleri(id);


--
-- Name: kiralama_kalem_urunleri kiralama_kalem_urunleri_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_kalem_urunleri
    ADD CONSTRAINT kiralama_kalem_urunleri_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: kiralama_odemeleri kiralama_odemeleri_sozlesme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_odemeleri
    ADD CONSTRAINT kiralama_odemeleri_sozlesme_id_fkey FOREIGN KEY (sozlesme_id) REFERENCES public.kiralama_sozlesmeleri(id) ON DELETE CASCADE;


--
-- Name: kiralama_sozlesme_kalemleri kiralama_sozlesme_kalemleri_sozlesme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_sozlesme_kalemleri
    ADD CONSTRAINT kiralama_sozlesme_kalemleri_sozlesme_id_fkey FOREIGN KEY (sozlesme_id) REFERENCES public.kiralama_sozlesmeleri(id);


--
-- Name: kiralama_sozlesme_kalemleri kiralama_sozlesme_kalemleri_stok_karti_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_sozlesme_kalemleri
    ADD CONSTRAINT kiralama_sozlesme_kalemleri_stok_karti_id_fkey FOREIGN KEY (stok_karti_id) REFERENCES public.stok_kartlari(id);


--
-- Name: kiralama_sozlesmeleri kiralama_sozlesmeleri_kiraci_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_sozlesmeleri
    ADD CONSTRAINT kiralama_sozlesmeleri_kiraci_cari_id_fkey FOREIGN KEY (kiraci_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: kiralama_sozlesmeleri kiralama_sozlesmeleri_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_sozlesmeleri
    ADD CONSTRAINT kiralama_sozlesmeleri_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: kiralama_sozlesmeleri kiralama_sozlesmeleri_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kiralama_sozlesmeleri
    ADD CONSTRAINT kiralama_sozlesmeleri_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: kullanici_rolleri kullanici_rolleri_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanici_rolleri
    ADD CONSTRAINT kullanici_rolleri_kullanici_id_fkey FOREIGN KEY (kullanici_id) REFERENCES public.kullanicilar(id) ON DELETE CASCADE;


--
-- Name: kullanici_rolleri kullanici_rolleri_rol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanici_rolleri
    ADD CONSTRAINT kullanici_rolleri_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES public.roller(id) ON DELETE CASCADE;


--
-- Name: kullanici_rolleri kullanici_rolleri_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanici_rolleri
    ADD CONSTRAINT kullanici_rolleri_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: kullanici_sirket_erisim kullanici_sirket_erisim_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanici_sirket_erisim
    ADD CONSTRAINT kullanici_sirket_erisim_kullanici_id_fkey FOREIGN KEY (kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: kullanici_sirket_erisim kullanici_sirket_erisim_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kullanici_sirket_erisim
    ADD CONSTRAINT kullanici_sirket_erisim_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: leasing_kalem_urunleri leasing_kalem_urunleri_kalem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_kalem_urunleri
    ADD CONSTRAINT leasing_kalem_urunleri_kalem_id_fkey FOREIGN KEY (kalem_id) REFERENCES public.leasing_sozlesme_kalemleri(id);


--
-- Name: leasing_kalem_urunleri leasing_kalem_urunleri_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_kalem_urunleri
    ADD CONSTRAINT leasing_kalem_urunleri_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: leasing_odeme_plani leasing_odeme_plani_banka_hareket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_odeme_plani
    ADD CONSTRAINT leasing_odeme_plani_banka_hareket_id_fkey FOREIGN KEY (banka_hareket_id) REFERENCES public.banka_hareketleri(id);


--
-- Name: leasing_odeme_plani leasing_odeme_plani_leasing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_odeme_plani
    ADD CONSTRAINT leasing_odeme_plani_leasing_id_fkey FOREIGN KEY (leasing_id) REFERENCES public.leasing_sozlesmeleri(id) ON DELETE CASCADE;


--
-- Name: leasing_sozlesme_kalemleri leasing_sozlesme_kalemleri_leasing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_sozlesme_kalemleri
    ADD CONSTRAINT leasing_sozlesme_kalemleri_leasing_id_fkey FOREIGN KEY (leasing_id) REFERENCES public.leasing_sozlesmeleri(id);


--
-- Name: leasing_sozlesme_kalemleri leasing_sozlesme_kalemleri_stok_karti_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_sozlesme_kalemleri
    ADD CONSTRAINT leasing_sozlesme_kalemleri_stok_karti_id_fkey FOREIGN KEY (stok_karti_id) REFERENCES public.stok_kartlari(id);


--
-- Name: leasing_sozlesmeleri leasing_sozlesmeleri_leasing_firmasi_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_sozlesmeleri
    ADD CONSTRAINT leasing_sozlesmeleri_leasing_firmasi_cari_id_fkey FOREIGN KEY (leasing_firmasi_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: leasing_sozlesmeleri leasing_sozlesmeleri_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_sozlesmeleri
    ADD CONSTRAINT leasing_sozlesmeleri_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: leasing_sozlesmeleri leasing_sozlesmeleri_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leasing_sozlesmeleri
    ADD CONSTRAINT leasing_sozlesmeleri_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: personel_odemeleri personel_odemeleri_personel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personel_odemeleri
    ADD CONSTRAINT personel_odemeleri_personel_id_fkey FOREIGN KEY (personel_id) REFERENCES public.personel(id);


--
-- Name: personel personel_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personel
    ADD CONSTRAINT personel_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: proforma_detay proforma_detay_proforma_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_detay
    ADD CONSTRAINT proforma_detay_proforma_id_fkey FOREIGN KEY (proforma_id) REFERENCES public.proforma_faturalar(id) ON DELETE CASCADE;


--
-- Name: proforma_detay proforma_detay_stok_karti_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_detay
    ADD CONSTRAINT proforma_detay_stok_karti_id_fkey FOREIGN KEY (stok_karti_id) REFERENCES public.stok_kartlari(id);


--
-- Name: proforma_faturalar proforma_faturalar_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_faturalar
    ADD CONSTRAINT proforma_faturalar_cari_id_fkey FOREIGN KEY (cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: proforma_faturalar proforma_faturalar_olusturan_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_faturalar
    ADD CONSTRAINT proforma_faturalar_olusturan_kullanici_id_fkey FOREIGN KEY (olusturan_kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: proforma_faturalar proforma_faturalar_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proforma_faturalar
    ADD CONSTRAINT proforma_faturalar_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: rol_izinleri rol_izinleri_izin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rol_izinleri
    ADD CONSTRAINT rol_izinleri_izin_id_fkey FOREIGN KEY (izin_id) REFERENCES public.izinler(id) ON DELETE CASCADE;


--
-- Name: rol_izinleri rol_izinleri_rol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rol_izinleri
    ADD CONSTRAINT rol_izinleri_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES public.roller(id) ON DELETE CASCADE;


--
-- Name: roller roller_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roller
    ADD CONSTRAINT roller_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: sabit_giderler sabit_giderler_kategori_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sabit_giderler
    ADD CONSTRAINT sabit_giderler_kategori_id_fkey FOREIGN KEY (kategori_id) REFERENCES public.sabit_gider_kategorileri(id);


--
-- Name: sabit_giderler sabit_giderler_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sabit_giderler
    ADD CONSTRAINT sabit_giderler_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: siparis_detay siparis_detay_siparis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparis_detay
    ADD CONSTRAINT siparis_detay_siparis_id_fkey FOREIGN KEY (siparis_id) REFERENCES public.siparisler(id) ON DELETE CASCADE;


--
-- Name: siparis_detay siparis_detay_stok_karti_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparis_detay
    ADD CONSTRAINT siparis_detay_stok_karti_id_fkey FOREIGN KEY (stok_karti_id) REFERENCES public.stok_kartlari(id);


--
-- Name: siparis_odemeleri siparis_odemeleri_cek_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparis_odemeleri
    ADD CONSTRAINT siparis_odemeleri_cek_id_fkey FOREIGN KEY (cek_id) REFERENCES public.cekler(id);


--
-- Name: siparis_odemeleri siparis_odemeleri_siparis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparis_odemeleri
    ADD CONSTRAINT siparis_odemeleri_siparis_id_fkey FOREIGN KEY (siparis_id) REFERENCES public.siparisler(id);


--
-- Name: siparisler siparisler_kopya_kaynak_siparis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparisler
    ADD CONSTRAINT siparisler_kopya_kaynak_siparis_id_fkey FOREIGN KEY (kopya_kaynak_siparis_id) REFERENCES public.siparisler(id);


--
-- Name: siparisler siparisler_olusturan_kullanici_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparisler
    ADD CONSTRAINT siparisler_olusturan_kullanici_id_fkey FOREIGN KEY (olusturan_kullanici_id) REFERENCES public.kullanicilar(id);


--
-- Name: siparisler siparisler_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparisler
    ADD CONSTRAINT siparisler_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: siparisler siparisler_tedarikci_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.siparisler
    ADD CONSTRAINT siparisler_tedarikci_cari_id_fkey FOREIGN KEY (tedarikci_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: stok_kartlari stok_kartlari_kategori_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_kartlari
    ADD CONSTRAINT stok_kartlari_kategori_id_fkey FOREIGN KEY (kategori_id) REFERENCES public.stok_kategorileri(id);


--
-- Name: stok_kartlari stok_kartlari_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_kartlari
    ADD CONSTRAINT stok_kartlari_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: stok_kategorileri stok_kategorileri_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_kategorileri
    ADD CONSTRAINT stok_kategorileri_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: stok_maliyet_kalemleri stok_maliyet_kalemleri_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_maliyet_kalemleri
    ADD CONSTRAINT stok_maliyet_kalemleri_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id) ON DELETE CASCADE;


--
-- Name: stok_maliyet_kalemleri stok_maliyet_kalemleri_tedarikci_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_maliyet_kalemleri
    ADD CONSTRAINT stok_maliyet_kalemleri_tedarikci_cari_id_fkey FOREIGN KEY (tedarikci_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: stok_seri_no stok_seri_no_musteri_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_seri_no
    ADD CONSTRAINT stok_seri_no_musteri_cari_id_fkey FOREIGN KEY (musteri_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: stok_seri_no stok_seri_no_satis_cek_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_seri_no
    ADD CONSTRAINT stok_seri_no_satis_cek_id_fkey FOREIGN KEY (satis_cek_id) REFERENCES public.cekler(id);


--
-- Name: stok_seri_no stok_seri_no_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_seri_no
    ADD CONSTRAINT stok_seri_no_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: stok_seri_no stok_seri_no_stok_karti_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_seri_no
    ADD CONSTRAINT stok_seri_no_stok_karti_id_fkey FOREIGN KEY (stok_karti_id) REFERENCES public.stok_kartlari(id);


--
-- Name: stok_seri_no stok_seri_no_tedarikci_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stok_seri_no
    ADD CONSTRAINT stok_seri_no_tedarikci_cari_id_fkey FOREIGN KEY (tedarikci_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: taksit_detay taksit_detay_ilk_taksit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksit_detay
    ADD CONSTRAINT taksit_detay_ilk_taksit_id_fkey FOREIGN KEY (ilk_taksit_id) REFERENCES public.taksit_detay(id);


--
-- Name: taksit_detay taksit_detay_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksit_detay
    ADD CONSTRAINT taksit_detay_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.taksitli_satis_planlari(id) ON DELETE CASCADE;


--
-- Name: taksitli_satis_kalemleri taksitli_satis_kalemleri_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_kalemleri
    ADD CONSTRAINT taksitli_satis_kalemleri_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.taksitli_satis_planlari(id);


--
-- Name: taksitli_satis_kalemleri taksitli_satis_kalemleri_stok_karti_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_kalemleri
    ADD CONSTRAINT taksitli_satis_kalemleri_stok_karti_id_fkey FOREIGN KEY (stok_karti_id) REFERENCES public.stok_kartlari(id);


--
-- Name: taksitli_satis_planlari taksitli_satis_planlari_musteri_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_planlari
    ADD CONSTRAINT taksitli_satis_planlari_musteri_cari_id_fkey FOREIGN KEY (musteri_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: taksitli_satis_planlari taksitli_satis_planlari_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_planlari
    ADD CONSTRAINT taksitli_satis_planlari_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: taksitli_satis_planlari taksitli_satis_planlari_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taksitli_satis_planlari
    ADD CONSTRAINT taksitli_satis_planlari_stok_seri_no_id_fkey FOREIGN KEY (stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: yedek_parca_hareketleri yedek_parca_hareketleri_banka_hesap_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yedek_parca_hareketleri
    ADD CONSTRAINT yedek_parca_hareketleri_banka_hesap_id_fkey FOREIGN KEY (banka_hesap_id) REFERENCES public.banka_hesaplari(id);


--
-- Name: yedek_parca_hareketleri yedek_parca_hareketleri_ilgili_cari_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yedek_parca_hareketleri
    ADD CONSTRAINT yedek_parca_hareketleri_ilgili_cari_id_fkey FOREIGN KEY (ilgili_cari_id) REFERENCES public.cari_hesaplar(id);


--
-- Name: yedek_parca_hareketleri yedek_parca_hareketleri_ilgili_stok_seri_no_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yedek_parca_hareketleri
    ADD CONSTRAINT yedek_parca_hareketleri_ilgili_stok_seri_no_id_fkey FOREIGN KEY (ilgili_stok_seri_no_id) REFERENCES public.stok_seri_no(id);


--
-- Name: yedek_parca_hareketleri yedek_parca_hareketleri_yedek_parca_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yedek_parca_hareketleri
    ADD CONSTRAINT yedek_parca_hareketleri_yedek_parca_id_fkey FOREIGN KEY (yedek_parca_id) REFERENCES public.yedek_parcalar(id);


--
-- Name: yedek_parcalar yedek_parcalar_sirket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.yedek_parcalar
    ADD CONSTRAINT yedek_parcalar_sirket_id_fkey FOREIGN KEY (sirket_id) REFERENCES public.sirketler(id);


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_vectors(id);


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: akreditif_kalem_taksitleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.akreditif_kalem_taksitleri ENABLE ROW LEVEL SECURITY;

--
-- Name: akreditif_kalemleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.akreditif_kalemleri ENABLE ROW LEVEL SECURITY;

--
-- Name: akreditif_maliyet_dagitimlari; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.akreditif_maliyet_dagitimlari ENABLE ROW LEVEL SECURITY;

--
-- Name: akreditifler; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.akreditifler ENABLE ROW LEVEL SECURITY;

--
-- Name: bakim_kayitlari; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bakim_kayitlari ENABLE ROW LEVEL SECURITY;

--
-- Name: banka_hareketleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.banka_hareketleri ENABLE ROW LEVEL SECURITY;

--
-- Name: banka_hesaplari; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.banka_hesaplari ENABLE ROW LEVEL SECURITY;

--
-- Name: borc_odemeleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.borc_odemeleri ENABLE ROW LEVEL SECURITY;

--
-- Name: borclar; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.borclar ENABLE ROW LEVEL SECURITY;

--
-- Name: cari_hareketler; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cari_hareketler ENABLE ROW LEVEL SECURITY;

--
-- Name: cari_hesaplar; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cari_hesaplar ENABLE ROW LEVEL SECURITY;

--
-- Name: cek_hareket_gecmisi; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cek_hareket_gecmisi ENABLE ROW LEVEL SECURITY;

--
-- Name: cekler; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cekler ENABLE ROW LEVEL SECURITY;

--
-- Name: demirbaslar; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.demirbaslar ENABLE ROW LEVEL SECURITY;

--
-- Name: doviz_kurlari; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.doviz_kurlari ENABLE ROW LEVEL SECURITY;

--
-- Name: duzenleme_kayitlari; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.duzenleme_kayitlari ENABLE ROW LEVEL SECURITY;

--
-- Name: fatura_detay; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fatura_detay ENABLE ROW LEVEL SECURITY;

--
-- Name: faturalar; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.faturalar ENABLE ROW LEVEL SECURITY;

--
-- Name: gumruk_beyannameleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.gumruk_beyannameleri ENABLE ROW LEVEL SECURITY;

--
-- Name: harcama_turleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.harcama_turleri ENABLE ROW LEVEL SECURITY;

--
-- Name: islem_loglari; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.islem_loglari ENABLE ROW LEVEL SECURITY;

--
-- Name: izinler; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.izinler ENABLE ROW LEVEL SECURITY;

--
-- Name: kasa_hareketleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kasa_hareketleri ENABLE ROW LEVEL SECURITY;

--
-- Name: kdv_manuel_girisler; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kdv_manuel_girisler ENABLE ROW LEVEL SECURITY;

--
-- Name: kiralama_kalem_urunleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kiralama_kalem_urunleri ENABLE ROW LEVEL SECURITY;

--
-- Name: kiralama_odemeleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kiralama_odemeleri ENABLE ROW LEVEL SECURITY;

--
-- Name: kiralama_sozlesme_kalemleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kiralama_sozlesme_kalemleri ENABLE ROW LEVEL SECURITY;

--
-- Name: kiralama_sozlesmeleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kiralama_sozlesmeleri ENABLE ROW LEVEL SECURITY;

--
-- Name: kullanici_rolleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kullanici_rolleri ENABLE ROW LEVEL SECURITY;

--
-- Name: kullanici_sirket_erisim; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kullanici_sirket_erisim ENABLE ROW LEVEL SECURITY;

--
-- Name: kullanicilar; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kullanicilar ENABLE ROW LEVEL SECURITY;

--
-- Name: leasing_kalem_urunleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.leasing_kalem_urunleri ENABLE ROW LEVEL SECURITY;

--
-- Name: leasing_odeme_plani; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.leasing_odeme_plani ENABLE ROW LEVEL SECURITY;

--
-- Name: leasing_sozlesme_kalemleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.leasing_sozlesme_kalemleri ENABLE ROW LEVEL SECURITY;

--
-- Name: leasing_sozlesmeleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.leasing_sozlesmeleri ENABLE ROW LEVEL SECURITY;

--
-- Name: personel; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.personel ENABLE ROW LEVEL SECURITY;

--
-- Name: personel_odemeleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.personel_odemeleri ENABLE ROW LEVEL SECURITY;

--
-- Name: proforma_detay; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.proforma_detay ENABLE ROW LEVEL SECURITY;

--
-- Name: proforma_faturalar; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.proforma_faturalar ENABLE ROW LEVEL SECURITY;

--
-- Name: rol_izinleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.rol_izinleri ENABLE ROW LEVEL SECURITY;

--
-- Name: roller; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.roller ENABLE ROW LEVEL SECURITY;

--
-- Name: sabit_gider_kategorileri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sabit_gider_kategorileri ENABLE ROW LEVEL SECURITY;

--
-- Name: sabit_giderler; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sabit_giderler ENABLE ROW LEVEL SECURITY;

--
-- Name: siparis_detay; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.siparis_detay ENABLE ROW LEVEL SECURITY;

--
-- Name: siparis_odemeleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.siparis_odemeleri ENABLE ROW LEVEL SECURITY;

--
-- Name: siparisler; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.siparisler ENABLE ROW LEVEL SECURITY;

--
-- Name: sirketler; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sirketler ENABLE ROW LEVEL SECURITY;

--
-- Name: stok_kartlari; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stok_kartlari ENABLE ROW LEVEL SECURITY;

--
-- Name: stok_kategorileri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stok_kategorileri ENABLE ROW LEVEL SECURITY;

--
-- Name: stok_maliyet_kalemleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stok_maliyet_kalemleri ENABLE ROW LEVEL SECURITY;

--
-- Name: stok_seri_no; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stok_seri_no ENABLE ROW LEVEL SECURITY;

--
-- Name: taksit_detay; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.taksit_detay ENABLE ROW LEVEL SECURITY;

--
-- Name: taksitli_satis_kalemleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.taksitli_satis_kalemleri ENABLE ROW LEVEL SECURITY;

--
-- Name: taksitli_satis_planlari; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.taksitli_satis_planlari ENABLE ROW LEVEL SECURITY;

--
-- Name: urun_sahiplik_gecmisi; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.urun_sahiplik_gecmisi ENABLE ROW LEVEL SECURITY;

--
-- Name: yedek_parca_hareketleri; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.yedek_parca_hareketleri ENABLE ROW LEVEL SECURITY;

--
-- Name: yedek_parcalar; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.yedek_parcalar ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.vector_indexes ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: -
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


--
-- PostgreSQL database dump complete
--

\unrestrict adgGEhyY9gTVnxknZ7o5bMkZ8OQcgX8c1OVfTWfb4cvLepWAFRH2XbmGMnNbEec

